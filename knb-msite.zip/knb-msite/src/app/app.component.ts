import {
    ChangeDetectorRef,
    Component,
    ElementRef,
    NgZone,
    OnInit,
    ViewChild,
} from '@angular/core';
import { fromEvent, merge, Observable, Observer } from 'rxjs';
import { map } from 'rxjs/operators';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { Store } from '@ngrx/store';
import { ConfigService, ErrorHandlerService, getAccessToken, getLoaderStatus } from './auth/auth.index';
import { BundleLoaderInitializerService } from './modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { SESSION_TIMEOUT_PATHS } from './app.constant';
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
    title = 'mSite';
    isOnline!: boolean;

    internetConWarning = false;

    loaderStatusFromStore!: boolean;
    bundleLoaderStatus!: boolean;
    @ViewChild('routePath') routeElement!: ElementRef;
    idleState!: string;
    countdown!: number | null;
    lastPing!: Date | null;
    accessTokenFromStore!: string;
    startIdle!: false;

    constructor(
        private router: Router,
        private store: Store,
        private ngZone: NgZone,
        private bundleLoaderInitializerService: BundleLoaderInitializerService,
        private _snackBar: MatSnackBar,
        private config: ConfigService,
        private errorHandlerService: ErrorHandlerService,
        private idle: Idle, 
        private cd: ChangeDetectorRef
    ) { 
        this.getDataFromStore();
        this.handleIdleTime();

        this.store.select(getLoaderStatus).subscribe((loaderStatus) => {
            this.loaderStatusFromStore = loaderStatus;
        });

        this.bundleLoaderInitializerService.bundleLoaderStatusCast.subscribe(
            (resp: boolean) => {
                setTimeout(() => {
                    this.bundleLoaderStatus = resp;
                }, 0);
            }
        );

        router.events.subscribe((event) => {
        if (event instanceof NavigationStart) {
            window.history.replaceState(null, '', '');
            if ((event.navigationTrigger === 'hashchange') || (event.navigationTrigger === 'popstate')) {
            this.routeChange();
            }
        }
        if (event instanceof NavigationEnd) {
           // this.track(event.url);
            window.history.replaceState(null, '', '');
        }
        });
    }

    ngOnInit(): void {

        this.bundleLoaderInitializerService.startIdleTimeoutCast.subscribe((resp) => {
            if (resp) {
              this.startIdle = resp;
            }
          });

        this.ngZone.runOutsideAngular(() => {
           // this.idleService.setElementRef(this.routeElement);
        });

        this.createOnline$().subscribe((isOnline) => {
            if(this.internetConWarning) {
              let message;
              this.isOnline = isOnline;
              message = isOnline ? 'We are back online!' : 'You are not connected to the internet.'
              this._snackBar.open(message, 'close', {
              duration: 5000
            })
            }
            
            this.internetConWarning = true;
        });

        this.router.navigate(['login/'], {
            skipLocationChange: environment.skipURI,
        });

        this.reset();
    }

    ngOnDestroy() {
        this.routeChange();
    }

    public routeChange() {
        this.clearCookies();
        this.router.navigateByUrl('/login', { skipLocationChange: environment.skipURI });
    }

    private clearCookies() {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
          const cookie = cookies[i];
          const eqPos = cookie.indexOf('=');
          const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
          document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
        }
    }

    private createOnline$() {
        return merge(
            fromEvent(window, 'offline').pipe(map(() => false)),
            fromEvent(window, 'online').pipe(map(() => true)),
            new Observable((sub: Observer<boolean>) => {
                sub.next(navigator.onLine);
                sub.complete();
            })
        );
    }

    public onRightClick() {
      return false;
    }

    private handleIdleTime() {
        const idleTime = this.config.getConfig('idleTime');
        if(idleTime){
          environment.idleTime = <any>idleTime;
        }
        this.idle.setIdle(environment.idleTime.idleTimeOut); 
        this.idle.setTimeout(environment.idleTime.timeOut);
        this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

        // do something when the user becomes idle
        this.idle.onIdleStart.subscribe(() => {
            this.idleState = "IDLE";
        });

        this.idle.onIdleEnd.subscribe(() => {
            this.idleState = "NOT_IDLE";
            this.countdown = null;
            this.cd.detectChanges(); // how do i avoid this kludge?
        });

        this.idle.onTimeoutWarning.subscribe(seconds => this.countdown = seconds);

        this.idle.onTimeout.subscribe(() => {
          if (this.accessTokenFromStore) {
            this.timeOutApiCall();
          } else {
            this.redirect();
          }
        });

        // set keepalive parameters, omit if not using keepalive
        //this.keepalive.interval(15); // will ping at this interval while not idle, in seconds
        //this.keepalive.onPing.subscribe(() => this.lastPing = new Date()); // do something when it pings
    }

    private timeOutApiCall() {
       // this.chatbotService.closechatbot(environment.chatBotCloseParams);
        this.errorHandlerService.logoutWithSpecificPageNavigation(SESSION_TIMEOUT_PATHS.sessionTimeout);
        this.router.navigateByUrl(SESSION_TIMEOUT_PATHS.sessionTimeout, { skipLocationChange: environment.skipURI });
    }
    
      private redirect() {
        if (this.startIdle) {
            this.router.navigateByUrl(SESSION_TIMEOUT_PATHS.sessionTimeout);
            this.resetTimeOut();
        } else {
          this.reset();
        }
    }

    private resetTimeOut() {
        this.idle.stop();
        this.idle.onIdleStart.unsubscribe();
        this.idle.onTimeoutWarning.unsubscribe();
      }

    reset() {
        this.idle.watch();
        this.idleState = "NOT_IDLE";
        this.countdown = null;
        this.lastPing = null;
    }
    
    private getDataFromStore() {
        this.store.select(getAccessToken).subscribe((resp) => {
            this.accessTokenFromStore = resp;
        });
    }
}
