import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppPreloadingStrategy } from './app-preloading-strategy/app-preloading-strategy';
const routes: Routes = [
    {
        path: 'login',
        loadChildren: () => import('./modules/login/login.module').then(m => m.LoginModule),
    },
    {
        path: 'onboarding',
        loadChildren: () => import('./modules/onboarding/onboarding.module').then(m => m.OnboardingModule),
        data: { preload: true, delay: 5000 }
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: '**',
        redirectTo: 'login',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true, preloadingStrategy: AppPreloadingStrategy })],
    exports: [RouterModule],
    providers: [AppPreloadingStrategy]
})
export class AppRoutingModule { }
