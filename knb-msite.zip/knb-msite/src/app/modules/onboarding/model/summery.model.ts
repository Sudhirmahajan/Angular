// export interface IlLabilitiesSummaryResponseVO{
//       cashCreditAccount: IAccountDetailsVO;
// 	  overDraftAccount:IAccountDetailsVO;
// 	  creditCard:ICreditSummaryDetailsVO;
// 	  loan: ILoanSummaryDetailsVO;
// 	  offers:NotificationResponse[];

// }

// export interface IAccountDetailsVO{
//       name:string;
// 	  totalValue:string;
// 	  currencyWiseTotalAmt:List<CurrencyWiseTotalAmt>;
//      accounts: List<Account>
// }

// export interface ICreditSummaryDetailsVO{
//   name:string;
// 	  totalValue:string;
// 	  creditCardDetails:List<CcDetailsCustSummaryResponseVO>;
// }

// export interface ILoanSummaryDetailsVO{
//       name:string;
// 	  totalValue:string;
// 	  loanDetails:List<LoanResponseVO>;
// }

// export interface MutualFundDetailsVO {

//     mfAccNo: string;
//     currentBal: string;
//     holderName: string;
//     amtInvested: string;
//     gainLoss: string;

// }



// export interface MutualFund {
//     name: string;
//     totalValue: string;
//     mutualFundDetails: MutualFundDetailsVO[];

// }

// export interface MutualFund {
//     errorCode: string;
//     errorMessage: string;
// }

// export interface CurrencyWiseTotalAmt {
//     currencyCode: string;
//     totalAmt: string;
// }



// export interface AccountDetailsVO {
//     name: string;
//     currencyWiseTotalAmt: CurrencyWiseTotalAmt[];
//     accounts: Account[];
// }



// export interface Account {
//     jointHolders: string;
//     accType: string;
//     custName: string;
//     clrBalance: string;
//     acctCrncyCode: string;
//     primaryAccFlag: string;
//     accountNo: string;
//     depositType: string;
//     schmType: string;
// }
// export interface NpsDetailsVo {
//     pranNo: string;
//     currentValue: string;
//     holderName: string;
//     amtInvested: string;
//     gainLoss: string;
// }

// export interface NpsVO {
//     name: string;
//     totalValue: string;
//     npsDetails: NpsDetailsVo[];
// }
// export interface NpsVO {
//     errorCode: string;
//     errorMessage: string;
// }
// export interface DmatBalanceVO {
//     dmatAccNo: string;
//     balance: string;
//     holderName: string;
//     amtInvested: string;
//     gainLoss: string;
// }
// export interface Dmat {
//     errorCode: string;
//     errorMessage: string;
// }
// export interface Dmat {
//     name: string;
//     totalValue: string;
//     dmatDetails: DmatBalanceVO[];
// }

// export interface InsuranceDetailsResponseVO {
//     category: string;
//     daysLeft: string;
//     manageFlag: string;
//     policyNumber: string;
//     premiumAmount: string;
//     premiumDueDate: string;
//     productCd: string;
//     productName: string;
//     proposalNumber: string;
//     status: string;
//     type: string;
//     uin: string;
//     frequency: string;
//     sumAssured: string;
// }
// export interface InsuranceAssetsDetailsVO {
//     name: string;
//     totalValue: string;
//     insuranceDetails: InsuranceDetailsResponseVO[];
// }
// export interface WealthCustomerVo {
//     name: string;
//     amount: string;
// }

// export interface WealthCustomerDeailsVo {
//     aif: WealthCustomerVo;
//     nonAif: WealthCustomerVo;
// }




// export interface IForexCard {
//     cardName: string;
//     cardType: string;
//     customerName: string;
//     tcCustomerInfoList: ITcDetailsProductInfoDetails;
//     tcDetailsProductInfoDetails: object;
//     error?: Ierror;
//     forEach(arg0: (element: any, i: any) => void);
// }

// export interface ITcDetailsProductInfoDetails {
//     cardNo: string;
//     cardStatus: string;
//     cardValue: string;
//     expiryDate: string;
//     packetRefNo: string;
//     forEach(arg0: (element: any, i: any) => void);
// }


    






    export interface IAssetsSummaryResponse {
        mutualFund: any;
        account: any;
        deposit: any;
        nps: any;
        dmat: any ;
        insurance: any;
        offers: any[];
        wealthCustomer: any;
        wealthCustomerDeails: any;
    }
    
    export interface ILiabilitiesSummaryResponse {
    
         cashCreditAccount:any;
         overDraftAccount:any;
          creditCard:any;
         loan:any;
         offers:any[];
    
    }


    export interface IGenericAsset {
        name:string;
        totalAmt:any;
        currencycode:string;
        account:IAssetAccount[];

    }

       
    export interface IGenericLiabilities {
        name:string;
        totalAmt:any;
        account:ILianilitiesAccount[];

    }
    export interface ILianilitiesAccount {
        clrBalance: string;
        accountNo: string;
        schmType: string;
    }

    export interface IAssetAccount {
            clrBalance: string;
            acctCrncyCode: string;
            accountNo: string;
            schmType: string;
        }

