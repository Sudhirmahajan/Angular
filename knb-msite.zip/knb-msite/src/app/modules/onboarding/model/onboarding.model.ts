
export interface IUserDetails {
    crn: string;
    fullName: string;
    prefEmailId: string;
    image?: string;
    homeBranch?: string;
    customerSegmentCd: string;
    classificationCd: string;
    userPref: {
        amtFormat: string
        langPref:string
    },
    logo?: string;
    partyItType: string;
    partyItTypeCd: string;
    shortName: string;
    failedLoginDate: string;
    isCorporateCust:string;
    showAddressCard:string;
    addr1:string;
    addr2:string;
    addr3:string;
    showSafeBankingCard:string;
    city:string;
    pinCode:string;
}


export interface IDialogData {
    dialogHeader: string;
    dialogInfo: string;
}

export interface ILayout {
    dashboardWidgetResponseVO: IDashboardWidgetResponseVO[];
    menu: Imenu[];
}


export interface Imenu {
    topMenuVO: ITopMenuVO[];
    lhs: ILhsVO[];
}
export interface IDashboardWidgetResponseVO {
    dispOrder: string;
    downtimeFlag: string;
    downtimeMsg: string;
    mfaFlag: string;
    preferanceOrderingFlag: string;
    widgetCode: string;
    widgetName: string;
}
export interface ITopMenuVO {
    dispOrder: number;
    menuCode: string;
    menuPanel?: string;
    menuType?: string;
    topSubMenu: ITopSubMenu[];
}
export interface ITopSubMenu {
    dispOrder: number;
    label?: string;
    menuCode: string;
    menuPanel?: string;
    menuType?: string;
    url?: string;
    textdata?: IemergencyJson;
}

export interface ILhsVO {
    dispOrder: number;
    downtimeFlag: string;
    menuCode: string;
    menuId: number;
    menuType: string;
    mfaFlag: string;
    name: string;
    notificationFlag: string;
    showInfoTag: string;
    subMenu: ISubMenu[];

}

export interface ISubMenu {
    crossSaleUrl?: string;
    dispOrder: number;
    downTimeUrl?: string;
    downtimeFlag: string;
    menuCode: string;
    menuId: number;
    menuType: string;
    mfaFlag: string;
    name: string;
    notificationFlag?: string;
    notificationMsg?: string;
    parentMenuId: string;
    showInfoTag: string;
}

export interface IemergencyJson {
    src: string;
    detail?: object;
}
export interface IlhsObj {
    img: string;
    menuCode: string;
}

export interface IRmData {


    timestamp: string;
    httpStatusCode: number;
    error_code: string;
    error_desc: string;
    rm_code: string;
    rm_name: string;
    rm_mobile: string;
    rm_email: string

}

export interface IAccountListNew {

    savingsAccts: AccountInfo[],
    currentAccts: AccountInfo[],
    overDraftAccts: AccountInfo[],
    currencyWiseResponse: CurrencyWiseResponse[],

}

export interface CurrencyWiseResponse {
    currencyCode: string,
    totalValue: string
}

export interface AccountInfo {
    accType: string,
    custName: string,
    acctCrncyCode: string,
    isDeLinked: string,
    accountNo: string,
    custReltnCode: string,
    uniqAccId: string,
    acctOpnDate: string,
    account811: string,
    acctName: string,
    count?:any,
    balanceInfo: BalanceInfo,
    dblAmountValue: number,
    isSpend:string,
    holderCount?:string,
    arrayHolder?:any,
  

}

export interface BalanceInfo {
    amountValue: string,
    currencyCode: string,
    balanceType: string,
    indicator: string,
    errorCode?:string
}

export interface ICrossSaleResponse {
    [index: number]: {
        crossalePrdCd: string;
        crossalePrdName: string;
        dispOrder: number;
        hyplinkText: string;
        menuCode: string;
        mfaFlag: string;
        trackingCode: string;
        urlType: string;
        imageUrl: string;
    }
}

export interface INudge {
    menuId: number;
    imageUrl: string;
    staticUrl: number;
    widgetName: string;
    widgetCode: string;
    mfaFlag: string;
    downtimeMsg: object;
    downtimeFlag: string;
    messageText: string;
}



export interface ImutualFaund {
    invCd: string;
    crval: string;
    holderName?: string;
    amtInvested?: string;
    gainLoss?: string;
}
export interface Inps {
    pranNo: string;
    currentValue: string;
    holderName?: string;
    amtInvested?: string;
    gainLoss?: string;
}

export interface Idamat {
    dpmClientId: string;
    balance: string;
    holderName?: string;
    amtInvested?: string;
    gainLoss?: string;
}

export interface IinvestmentGen {
    key: string;
    name: string;
    acctNo: string;
    balance: number;
    holderName?: string;
    amtInvested?: any;
    gainLoss?: string;
}

export interface IDepositBalAttr {
    index: number;
    accountData: IAccountList;
}
export interface IAccountList {
    schmCode: string;
    primarySolId: string;
    acctName: string;
    schmType: string;
    acctOpenDate: object;
    custReltnCode: string;
    custName: string;
    clrBalAmt: string;
    frezCode: string;
    acctCrncyCode: string;
    acctStatus: string;
    cifId: string;
    FORACID: string;
    uniqAccId: string;
}

export interface IPopUpData {
    currBal: string;
    amtMemoDb: string;
    amtMemoCr: string;
    creditLimit: string;
    availCredit: string;
    cashCrlim: string;
    cashAvailCredit: string;
    loanCrlim: string;
    loanAvailable: string;
    loanBalance: string;
    blockCode1: string;
    blockCode2: string;
    stateOfIssue: string;
    internalStatus: string;
    billingCycle: string;
    pmtCtd: string;
    pmtTotAmtDue: string;
    cashPlanNbr: string;
    retailPlanNbr: string;
    tempCreditLimit: string;
    datePmtDue: string;
    graceDayExpirDate: string;
    dateLastStmt: string;
    qualGraceBal: string;
    availBtLimit: string;
}

export interface InsuranceWidget {
    category: string;
    daysLeft: string;
    manageFlag: string;
    policyNumber: string;
    premiumAmount: string;
    premiumDueDate: string;
    productCd: string;
    productName: string;
    proposalNumber: string;
    status: string;
    type: string;
}