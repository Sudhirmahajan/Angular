import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { NavigationService, getCardDetails } from 'src/app/auth/auth.index';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { cardEndPoints } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import {Clipboard} from '@angular/cdk/clipboard';


@Component({
  selector: 'app-debit-card-details',
  templateUrl: './debit-card-details.component.html',
  styleUrls: ['./debit-card-details.component.scss']
})
export class DebitCardDetailsComponent implements OnInit {
  public showCvvError!: boolean;
  public cvvData!: string;
  public isCVV = false;
  public heading!: string;
  loader: boolean = false;
  public dCard: any = {};
  public cCardDetail: any = {};
  cName!: string;
  public debitBal: any;
  public posLimin: any;
  public selectedCardNo!: string;
  public expiry!: string;

  constructor(private navigation: NavigationService,
    private store: Store, private service: OnboardingService, private widgetService: WidgetService, 
    private clipboard: Clipboard ) { }



  ngOnInit(): void {

    this.debitCardData()
  }

  debitCardData() {

    this.store.select(getCardDetails).subscribe({
      next: (resp: any) => {
       
        this.cCardDetail = resp['cardDetail'];
        this.dCard = resp['cardObj'];
      
        this.debitBal = this.cCardDetail['atmLimit'];
        this.posLimin = this.cCardDetail['posLimit'];
        this.selectedCardNo = this.widgetService.getPlainText(this.cCardDetail['cardNo']);
        this.expiry = this.widgetService.getPlainText(this.cCardDetail['expiryDate']);
        this.loader = true;

        this.cName = this.dCard.cardName

        this.heading = this.dCard.cardNo
          .substr(this.dCard.cardNo
            .length - 6);


      }

    })

  }




  public showCvv(card: any, expiryDate: any, cardType: any) {
    if (card && expiryDate) {
      this.getCvv(card, expiryDate, cardType);
    }
  }

  private getCvv(card: any, expiryDate: any, cardTypeData: any) {
   

    const payload = {
      cardNumber: card,
      expiryDatetime: expiryDate,
      cardType: cardTypeData,
      source: "HOME_DC_WDGT"
    };

    this.service.handleCard(payload,
      cardEndPoints.cvvDetails)
      .subscribe({
        next: (res: any) => {
         
          this.isCVV = true;
         
          if (res['error']) {
            if (res['error']['errorCoode'] === 'CS1026') {
             
              this.showCvvError = true;
            } else {
              this.cvvData = res['error']['errorMessage'];
             
            }
          } else {
          
            this.cvvData = res['cvv'];
            this.cvvData = this.widgetService.getPlainText(res['cvv']);
          }
         

        }, error: (error) => {
          this.isCVV = true;
          this.cvvData = error.errorMessage;

        }
      });

  }
  copyData(data:string) {
    this.clipboard.copy(data);
  }

  goBack() {
    this.navigation.goBack();
  }

}
