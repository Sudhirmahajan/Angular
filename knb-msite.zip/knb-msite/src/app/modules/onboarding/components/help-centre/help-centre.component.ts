import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getPageDetails, getUserDetails, setPageName } from 'src/app/auth/auth.index';
import { NavigationService } from 'src/app/auth/services/navigation/navigation.service';
import { environment } from 'src/environments/environment';
import { helpSection } from '../../onboarding-analytics';
import { ROUTE_KEY } from '../../onboarding.constant';
import { RmDialogBoxComponent } from '../rm-dialog-box/rm-dialog-box.component';


@Component({
  selector: 'app-help-centre',
  templateUrl: './help-centre.component.html',
  styleUrls: ['./help-centre.component.scss']
})
export class HelpCentreComponent implements OnInit {
  @Output() goBackemit= new EventEmitter<boolean>();
  @ViewChild(MatSidenav)
  sidenav: any = MatSidenav;
  crn: any;
  page_name: any;
  
  constructor(
    private store: Store,
     private navigation: NavigationService,
     public router: Router,
     private dialog: MatDialog,) {}

  ngOnInit(): void {
    this.accountDetails();
    this.store.dispatch(setPageName({ value: 'Help Center' }));
  }

  public accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
     this.crn=user['crn']
    })
  }

  setAnalytics(ctaname:any){
   // this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    const value={'ctaname':ctaname,'page-name':'help','crn':this.crn}
    window.digitalData=helpSection(value)
    window._satellite?.track("NB-Msiteclick");
  }

  public redirectToHlpCntr(): void {
   window.open(environment.hlpCntrURL, "_blank");
  }

  public redirectToCall(): void {
    window.open(environment.contactUsURL, "_blank");
  }

  public redirectToRedressal(): void {
    window.open(environment.grievanceRedressalURL, "_blank");
  }

  public redirectToAtmOrBrnch(): void {
    window.open(environment.atmOrBrnchURL, "_blank");
  }

  goBack() {
    // FOR BACK button redirection
    this.navigation.goBack();
   }

   reviewScreen(){
    this.router.navigateByUrl(ROUTE_KEY['DASHBOARD'], { skipLocationChange: environment.skipURI });  
  }
  
  public openRMDialog(): void {
    this.dialog.open(RmDialogBoxComponent, { panelClass: 'custom-dialog-container', backdropClass: 'backdropBackground' });
    

}
}
