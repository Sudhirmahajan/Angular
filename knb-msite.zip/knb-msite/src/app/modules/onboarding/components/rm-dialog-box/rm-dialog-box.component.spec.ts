import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmDialogBoxComponent } from './rm-dialog-box.component';

describe('RmDialogBoxComponent', () => {
  let component: RmDialogBoxComponent;
  let fixture: ComponentFixture<RmDialogBoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RmDialogBoxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RmDialogBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
