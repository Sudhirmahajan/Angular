import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { getRmData } from 'src/app/auth/auth.index';
import { IRmData } from '../../model/onboarding.model';

@Component({
  selector: 'app-rm-dialog-box',
  templateUrl: './rm-dialog-box.component.html',
  styleUrls: ['./rm-dialog-box.component.scss']
})
export class RmDialogBoxComponent  {
public rmDetail!:IRmData;
public rmInitial!:string;
  constructor( private store: Store,
   
  ) { }




  ngOnInit(): void {

    this.store.select(getRmData).subscribe((rm: IRmData) => {
      this.rmDetail=rm;
       this.rmInitial=rm.rm_name.split(" ").map((n,i,a)=> i === 0 || i+1 === a.length ? n[0] : null).join("").toUpperCase();
      
     
  
    })

  }



}
