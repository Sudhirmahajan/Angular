import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getUserDetails, setFlow, setUniqAcctId } from 'src/app/auth/auth.index';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { AccountInfo, IAccountListNew } from '../../model/onboarding.model';
import { icidWidget } from '../../onboarding-analytics';
import { accountEndPoints, ROUTE_KEY, widgetCodes } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

@Component({
  selector: 'app-dasboard-accounts',
  templateUrl: './dasboard-accounts.component.html',
  styleUrls: ['./dasboard-accounts.component.scss']
})
export class DasboardAccountsComponent implements OnInit {
  showMyContainerA: any = {};
  showMyContainerC:any={};
  showMyContainerO:any={};
  showMyContainerP:any={};

  hideS: boolean = true;
  hideC: boolean = true;
  hideO: boolean = true;
  hideP: boolean = true;

  public spendAccList: AccountInfo[] = [];crn: any;
;
  public isPrepaid = false;
  savingAcct: AccountInfo[] = [];
  CurrentAcct: AccountInfo[] = [];
  overDraft: AccountInfo[] = [];
  savingTotal=0.00;
  currentTotal=0.00;
  overDraftTotal=0.00;
  panelOpenState: any;
  panelOpenStateC: any;
  panelOpenStateO: any;
  parseFloat = parseFloat;
  public accountListResp!: any;
  public errorString: string = "Record Not Found";
  loader: boolean=false;
   accerror:boolean=false
   public prepaidRefresh = false;
   public isPrepaidAllFail = false;
   public showMorePrepaid = false;
   public spendzAccTotal: number = 0;
   public acctListLength!: number;
   public isAccountcall = false;
   public isaccountShow = true;
   public currentListFlag = false;
   public savingListFlag = false;
   public isTryShow = [];
   public accountBalFlag = [];
   public accountBalDetailsFlag = [];
   public accountBalanceResp: any;
   public AccountTypeFull!: string;
   public dataAcctDisplayCount!: number;
   public dataAcctDisplayCountArr = [2,2,2,2]
   public showMoreHide = [true,true,true,true]
   public showBalance = [false,false,false,false]
   public showMore = false;
   public showMoreCurrent = false;
   public showMoreSavings = false;
   public showMoreOverDraft = false;
   public showLessAcct = false;
   public showMore10 = false;
   public showMoreRedirect = false;
   public AcctObj = {
     Index: '',
     AcctId: ''
   };
   public primaryCurrency!:string;
   public errorResList = false;
   public isCurrentAllFail = false;
   public isSavingAllFail = false;
   public isOverDraftAllFail = false;
   public isCurrentRefresh = false;
   public isSavingRefresh = false;
   public isOverDraftRefresh = false;
   public isCuurent = false;
   public isSaving = false;
   public isOverDraft = false;
   public errorResBal!: object;
   public errViewAcctBal = [];
   public isBalDetaError = false;
   public widgetName = 'dashboard.drag-arrange-widget.ACCOUNTS';
   public currencyCode!: string;
   public currentDate = new Date();
   errorList: any;
   show = false;
   seemoreSA: string = "dashboard.common.see-more";
   seemoreCA: string = "dashboard.common.see-more";
   seemoreOD: string = "dashboard.common.see-more";
   seemorePP: string = "dashboard.common.see-more";
   pluse: string = "+ ";
 
  constructor(
    private store: Store, private onboradingService:OnboardingService, private router: Router,  
    private widgetService: WidgetService,
    private _snackBar: MatSnackBar,
  ) { }

  ngOnInit(): void {

    const downtime = this.widgetService.getDownTimeFlag(widgetCodes.ACCOUNTS);
    if (downtime === 'Y') {
            this._snackBar.open('There seems to be a technical glitch. While we check on it, why don’t you explore other products  and services. Come back in sometime and we will be ready to service your request.', '', {
        duration: 5000
      })

    }  

   this.accountDetails();
   this.accountListData();

  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
    const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }
 

public accountListData(){
  this.loader=false;
  this.onboradingService.handleAccount({}, accountEndPoints.accountTypeList).subscribe({
    next: (accountList: any) => {
      this.loader=true;
      if (!accountList['error']) {
      accountList.savingsAccts && this.getSpendAcc(accountList.savingsAccts);  
      this.accointListSuc(accountList);
    } else {
      this.errorList = accountList['error'];
    }
    },
    error: () =>  {
       this.accerror = true;
       this.loader=true;
     }
  })
}



  private accointListSuc(resp:IAccountListNew){
    this.errorResList = false;
    
       this.accountListResp =resp;
       this.CurrentAcct = resp.currentAccts;
       this.overDraft = resp.overDraftAccts;
       this.isCuurent = this.checkStatus('currentAccts' ,0);
       this.isSaving = this.checkStatus('savingsAccts' ,0);
       this.isOverDraft = this.checkStatus('overDraftAccts' ,0);
       
       this.isCurrentRefresh = this.refeshBalanceCheck(this.accountListResp['currentAccts']);
       this.isSavingRefresh = this.refeshBalanceCheck(this.accountListResp['savingsAccts']);
       this.isOverDraftRefresh = this.refeshBalanceCheck(this.accountListResp['overDraftAccts']);
       this.prepaidRefresh = this.refeshBalanceCheck(this.spendAccList);

       this.isCurrentAllFail = this.accountListResp['currentAccts'].length > 1 ? this.checkAllBalanceFail(this.accountListResp['currentAccts']) :  this.isCurrentAllFail;
       this.isSavingAllFail = this.accountListResp['savingsAccts'].length > 1 ? this.checkAllBalanceFail(this.accountListResp['savingsAccts']) : this.isSavingAllFail;
       this.isOverDraftAllFail = this.accountListResp['overDraftAccts'].length > 1 ? this.checkAllBalanceFail(this.accountListResp['overDraftAccts']) : this.isOverDraftAllFail;
       this.isPrepaidAllFail = this.spendAccList.length > 1 ? this.checkAllBalanceFail(this.spendAccList) : this.isPrepaidAllFail;
       if(!this.isCurrentAllFail ){
        this.showBalance[0] =true;
      
        
       }
       if(!this.isSavingAllFail ){
        this.showBalance[1] =true;
       }
       if(!this.isOverDraftAllFail){
        this.showBalance[2] =true;
       }
       if(!this.isPrepaidAllFail ){
        this.showBalance[3] =true;
       }
       this.showMoreCurrent = this.checkStatus('currentAccts',2);  
       this.showMoreSavings = this.checkStatus('savingsAccts',2);
       this.showMoreOverDraft = this.checkStatus('overDraftAccts',2);
       this.showMorePrepaid = this.spendAccList.length > 2;
       let currencyList =this.accountListResp['currencyWiseResponse'];  
       let currencyType = currencyList.find((item: { [x: string]: string; })=>item['currencyCode'] === "INR") || currencyList[0];
        this.currencyCode=currencyType;
       this.accountListResp['primaryCurrency']=currencyType['currencyCode'];
       this.primaryCurrency=currencyType['currencyCode'];
       this.totalOfAccount('currentAccts', currencyType['currencyCode']);
       this.totalOfAccount('savingsAccts', currencyType['currencyCode']);
       this.totalOfAccount('overDraftAccts', currencyType['currencyCode']);
       this.getPrepaidAccTotal(this.spendAccList, currencyType['currencyCode']);

       this.isCuurent  && this.jointAccount(this.accountListResp['currentAccts']);    
       this.isSaving  && this.jointAccount(this.accountListResp['savingsAccts']);    
       this.isOverDraft  && this.jointAccount(this.accountListResp['overDraftAccts']);  
       this.isPrepaid && this.jointAccount(this.spendAccList);  
        this.acctListLength = (Object.keys(this.accountListResp).length);
        if (this.acctListLength <= 3) {
          this.showMore = false;
        } else {
          this.showMore = true;
        }
        if (this.acctListLength === 0 || this.acctListLength === -1) {
          this.isaccountShow = false;
        }
  }


  private jointAccount (accountType:any){
    accountType.forEach((item:any) => {
      if (!item.jointHolders) {
        item.holderCount = 'single';
      } else {
        item.holderCount = 'multi';
        let spiltHolder = [];
        if (item.jointHolders.indexOf(',') !== -1) {
          spiltHolder = item.jointHolders.split(',');
        } else {
          spiltHolder.push(item['jointHolders']);
        }
        spiltHolder.unshift(item['acctName']);
        item.arrayHolder = spiltHolder;
        item.count = spiltHolder.length - 1;
      }
     
      
    });
  }

  private getSpendAcc(savingAccList:any) {
    this.spendAccList = savingAccList.filter((acc: { isSpend: string; }) => acc.isSpend === 'Y');
    this.savingAcct = savingAccList.filter((acc: { isSpend: string; }) => acc.isSpend !== 'Y');
    this.isPrepaid = this.spendAccList && this.spendAccList.length > 0 ? true : false;
  }

  private getPrepaidAccTotal(acclist:any, currency:any) {
    const total = acclist.reduce((result:any, item:any)=>{
      if(this.checkBalnceAvailable(item,currency)){
         result= result + (+item['balanceInfo']['amountValue'])
      }
      return result;
     },0)
     this.spendzAccTotal = total;
  }

  private checkBalnceAvailable(item:any,currency:any){
    return item['balanceInfo'] && !item['balanceInfo']['errorCode'] && item['balanceInfo']['currencyCode'] === currency && (+item['balanceInfo']['amountValue']) > 0
  }
  

  
  private totalOfAccount(obj:any,currency:any){   
    const total =this.accountListResp[obj].reduce((result: number, item:any)=>{
     if(this.checkBalnceAvailable(item,currency)){
        result= result + (+item['balanceInfo']['amountValue'])
     }
     return result;
    },0)
    if(obj=='savingsAccts'){
      this.savingTotal=total;
      
    }
    if(obj=='currentAccts'){
     this.currentTotal=total;
    }
    if(obj=='overDraftAccts'){
      this.overDraftTotal=total;
    }
   }

   private checkStatus(type:any, length:any){
    return  this.accountListResp[type].length > length ? true : false;
  }

  private refeshBalanceCheck(accType:any){
    const checkErorr = accType.filter((item: { [x: string]: { [x: string]: any; }; })=> item['balanceInfo'] && item['balanceInfo']['errorCode']);
    return  checkErorr.length > 0 ? true : false;
  }

  private checkAllBalanceFail(accType:any){
    const checkErorr = accType.filter((item: { [x: string]: { [x: string]: any; }; })=> item['balanceInfo']['errorCode']);
    return  checkErorr.length === accType.length ? true : false;
  }
  
  public accountRecall() {
    this.errorResList = false;
    this.isAccountcall = true;
    this.accountListResp= null;
    this.accountListData();
  }

  getCurrentBalance() {
    this.hideC = !this.hideC;
   
     }
getSavingBalance() {
   
    this.hideS = !this.hideS;
   
  }


  getoverDraftBalance() {
    this.hideO = !this.hideO;
  
  }

  getPrepaidBalance() {
    this.hideP = !this.hideP;
   
  }

  acctSummary(uniqAccId:string){
    this.store.dispatch(setFlow({ value: "ACCOUNT_WIDGET" }));
    this.store.dispatch(setUniqAcctId({ value:uniqAccId}));

    this.router.navigateByUrl(ROUTE_KEY['ACCOUNTS'], { skipLocationChange: environment.skipURI });

  }

  public seeMoreForSA() {
    this.show = !this.show
    if (this.show) {
      this.seemoreSA = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.seemoreSA = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }

  public seeMoreForCA() {
    this.show = !this.show
    if (this.show) {
      this.seemoreCA = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.seemoreCA = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }

  public seeMoreForOD() {
    this.show = !this.show
    if (this.show) {
      this.seemoreOD = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.seemoreOD = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }

  

  public seeMoreForPrepaid() {
    this.show = !this.show
    if (this.show) {
      this.seemorePP = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.seemorePP = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }




}


