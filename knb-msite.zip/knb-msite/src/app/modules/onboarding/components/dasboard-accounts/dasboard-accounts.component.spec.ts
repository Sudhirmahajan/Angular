import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DasboardAccountsComponent } from './dasboard-accounts.component';

describe('DasboardAccountsComponent', () => {
  let component: DasboardAccountsComponent;
  let fixture: ComponentFixture<DasboardAccountsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DasboardAccountsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DasboardAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
