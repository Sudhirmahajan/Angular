import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getUserDetails, setCardDetails } from 'src/app/auth/auth.index';
import { TwofaOtpService } from 'src/app/modules/shared/services/TwoFa-Otp/twofa-otp.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { icidWidget } from '../../onboarding-analytics';
import { ROUTE_KEY, typeOfProduct } from '../../onboarding.constant';

@Component({
  selector: 'app-forex-card-widget',
  templateUrl: './forex-card-widget.component.html',
  styleUrls: ['./forex-card-widget.component.scss']
})
export class ForexCardWidgetComponent implements OnInit {
  @Input() forexCardRefactor: any;
  @Input() index!: number;
  public hide: any[] = [];
  public forexBalFlag: any[] = [];
  public loaded: boolean = false;
  public j!: number
  twoFaCheckTriggeredFrom!: string;

  twoFaVerified: any;
  crn: any;
  constructor(private store: Store, private twofaOtpService: TwofaOtpService, private widgetService: WidgetService, private router: Router) { }

  ngOnInit(): void {
    this.accountDetails();
  }
  
  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
    const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }
 
  public viewForexBalance(i: any) {
    this.hide[i] = !this.hide[i];
    setInterval(() => { this.loaded = false; }, 200);
    this.loaded = true;
    this.forexBalFlag[i] = !this.forexBalFlag[i];
  }


  routeToLink(j: number) {
    this.j = j;
    const payload = {
      id: 'RDR-CARD-POP',
      type: typeOfProduct.menu
    };
    this.checkTwoFaValidationStatus();
    this.twofaOtpService.validateTwoFaAndProceed(payload);
    this.widgetService.validateTwoFaResponseCast.subscribe((response: any) => {
      if (response && !response.showMfaFlag && !this.twoFaVerified && this.twoFaCheckTriggeredFrom === 'POPUP') {
        this.twoFaVerified = true;

        this.widgetService.setValidateTwoFaResponse('');
      }
    });



  }


  private checkTwoFaValidationStatus() {
    this.widgetService.otpvalidationResCast.subscribe((resp: any) => {
      if (resp && resp === 'suc' && !this.twoFaVerified) {
        this.twoFaVerified = true;
        this.routeToDetailsPage()
        this.widgetService.setotpvalidationRes('');
      }
    });
  }
  routeToDetailsPage() {

    this.store.dispatch(setCardDetails({ value: this.forexCardRefactor.tcCustomerInfoList[this.j] }))
    this.router.navigateByUrl(ROUTE_KEY['FOREXCARD'], { skipLocationChange: environment.skipURI });
  }
}
