import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForexCardWidgetComponent } from './forex-card-widget.component';

describe('ForexCardWidgetComponent', () => {
  let component: ForexCardWidgetComponent;
  let fixture: ComponentFixture<ForexCardWidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForexCardWidgetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForexCardWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
