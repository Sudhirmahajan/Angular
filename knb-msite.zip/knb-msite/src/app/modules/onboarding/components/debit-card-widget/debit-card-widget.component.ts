import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';

import { getUserDetails, setCardDetails } from 'src/app/auth/auth.index';
import { TwofaOtpService } from 'src/app/modules/shared/services/TwoFa-Otp/twofa-otp.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { icidWidget } from '../../onboarding-analytics';

import { cardEndPoints, ROUTE_KEY, typeOfProduct } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

@Component({
  selector: 'app-debit-card-widget',
  templateUrl: './debit-card-widget.component.html',
  styleUrls: ['./debit-card-widget.component.scss']
})
export class DebitCardWidgetComponent implements OnInit {
  public hide: boolean = false;
  public cvvData!: string;
  public dCardObj: any = {};
  public isCVV = false;
  public debitListLength!: number;
  public debitPopup: any = {};
  public debitdata: any = {};
  public getDebitCardWidgets = {};
  public dataServiceDebitFlag = [];
  public debitBalFlag = [];
  public widgetCode = 'DCARD';
  public debitBal: any;
  public posLimin: any;
  public errorResDebitList!: object;
  public errorResDebitBalance!: boolean;
  public debitPopupSucErr!: string;
  public errorRespopupBalance!: boolean;
  public cardType!: string;
  public showCvvError!: boolean;
  public imageToDisplay!: string;
  public isVirtualDebit!: boolean;
  public loaded: boolean = false;

  public selectedCardNo: string = '';
  @Input() debitCardList: any;
  @Input() index!: number;
  public errorString: string = 'dashboard.common.balance-unavailable';
  twoFaVerified!: boolean;
  twoFaCheckTriggeredFrom!: string;
  acctId: any;
  expiry: any;
  crn: any;
  constructor(
    private service: OnboardingService,
    private store: Store,
    private router: Router,
    private widgetService: WidgetService,
    private twofaOtpService: TwofaOtpService
  ) { }

  ngOnInit(): void {
    this.accountDetails();
    this.chkisVirtualDebit()
  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
    const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }
 


  public getDebitBalance(acctId: any) {
    this.hide = !this.hide;
    const dcCardNumber = acctId;
    this.loaded = true;
    this.service.handleCard
      ({ dcCardNumber, source: "HOME_DC_WDGT" },
        cardEndPoints.dcDailyLimit).subscribe({
          next: (resp: any) => {
            this.loaded = false
            this.errorResDebitBalance = false;
            this.debitdata = resp;

            if (this.debitdata['error']) {
              this.errorResDebitBalance = true;
            } else {
              this.errorResDebitBalance = false;
              this.debitBal = this.debitdata['atmLimit'];
              this.posLimin = this.debitdata['posLimit'];


            }

          }, error: () => {
            this.loaded = false
            this.errorResDebitBalance = true;

          }
        });
  }





  public routeToLink(acctId: any, expiry: any) {

    const payload = {
      id: 'RDR-CARD-POP',
      type: typeOfProduct.menu
    };

    this.acctId = acctId;
    this.expiry = expiry;

    this.checkTwoFaValidationStatus();
    this.twofaOtpService.validateTwoFaAndProceed(payload);

    this.widgetService.validateTwoFaResponseCast.subscribe((response) => {
      if (response && !response.showMfaFlag && !this.twoFaVerified && this.twoFaCheckTriggeredFrom === 'POPUP') {
        this.twoFaVerified = true;
        this.getDebitBalance(acctId);
        this.widgetService.setValidateTwoFaResponse('');
      }
    });
  }


  private chkisVirtualDebit() {
    if (this.debitCardList['cardType'] === 'ENOWE' || this.debitCardList['cardType'] === 'EMI'
      || this.debitCardList['cardType'] === 'EINV' || this.debitCardList['cardType'] === 'PNOW'
      || this.debitCardList['cardType'] === 'ENOW') {
      this.isVirtualDebit = true;
    } else {
      this.isVirtualDebit = false;
    }
  }

  private checkTwoFaValidationStatus() {
    this.widgetService.otpvalidationResCast.subscribe((resp) => {
      
      if (resp && resp === 'suc' && !this.twoFaVerified) {
        this.twoFaVerified = true;
        this.routeToDetailsPage();
        this.widgetService.setotpvalidationRes('');
      }
    });
  }

  routeToDetailsPage() {
    this.dCardObj = {};
    const dcCardNumber = this.acctId;
    let payLoad = { expiryDate: this.expiry, dcCardNumber: dcCardNumber, source: "HOME_DC_WD" };
    this.service.handleCard
      (payLoad,
        cardEndPoints.dcDailyLimit).subscribe({
          next: (resp: any) => {
            this.errorResDebitBalance = false;
            this.debitPopup = resp;

            if (this.debitPopup['error']) {
              this.errorResDebitBalance = true;
            } else {
              this.errorResDebitBalance = false;
              this.selectedCardNo = resp['cardNo'];
              this.dCardObj = { cardDetail: resp, cardObj: this.debitCardList }

              this.store.dispatch(setCardDetails({ value: this.dCardObj }))
              this.router.navigateByUrl(ROUTE_KEY['DEBITCARD'], { skipLocationChange: environment.skipURI });


            }

          }, error: () => {

            this.errorResDebitBalance = true;

          }
        });
  }



}
