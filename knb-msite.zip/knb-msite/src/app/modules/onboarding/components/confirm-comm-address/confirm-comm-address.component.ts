import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { SCREEN_ROUTING_KEYS } from 'src/app/modules/login/login.constant';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { DialogBoxComponent } from 'src/app/modules/shared/utils/dialog-box/dialog-box.component';

@Component({
  selector: 'app-confirm-comm-address',
  templateUrl: './confirm-comm-address.component.html',
  styleUrls: ['./confirm-comm-address.component.scss']
})
export class ConfirmCommAddressComponent implements OnInit {

  @Output() commAddr = new EventEmitter<boolean>();

  add1: any;
  add2: any;
  add3: any;

  constructor(
    private widgetService: WidgetService,
    private dialog: MatDialog,
    private cardService:SetOnboardCardService,
  ) { }

  ngOnInit(): void {
    this.showModal();
  }

  public showModal() {
    this.widgetService.isShowCommuAddressresCat.subscribe((res: { isShowModal: string; addr1: any; addr2: any; addr3: string; city: string; pinCode: string; })  => {
          this.add1 = res.addr1;
          this.add2 = res.addr2;
          this.add3 = res.addr3 + " " + res.city + " " + res.pinCode;
      })
  }

  updateAddress() {
    this.cardService.navigateToView(SCREEN_ROUTING_KEYS.SERVICE_NOT_FOUND);

    //this.dialog.open(DialogBoxComponent, { panelClass: 'custom-dialog-container', backdropClass: 'backdropBackground', data: { dialogHeader: 'dashboard.Alert.notification', dialogInfo: "This Feature is currently not available in Kotak M-Site" }, });
  }

  
  commAddress(value:boolean){
    this.commAddr.emit(value);
  }

}
