import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { BioCatchService, getBackId } from 'src/app/auth/auth.index';
import { ViewportScroller } from '@angular/common';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY } from '../../onboarding.constant';
import { TwofaOtpService } from 'src/app/modules/shared/services/TwoFa-Otp/twofa-otp.service';
import { getUserDetails, setPageName } from 'src/app/auth/auth.index';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  public loaded: boolean = false;
  hide: boolean = false;
  public customerSegmentCd!: string;
  domId!: string;
  crn: any;
  RA: boolean = true;
  CC: boolean = true;
  TD: boolean = true

  constructor(private store: Store, private scroller: ViewportScroller ,    private bioCatchService: BioCatchService,
    private router: Router, private otpService: TwofaOtpService) {
    this.backon()
  }
  ngAfterViewInit(): void {
  }

  ngOnInit(): void {
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_DASHBOARD_LANDING_PAGE);

    this.backon()
    setInterval(() => { this.loaded = true; }, 300);
    this.accountDetails();

  }
  accountDetails() {
    this.store.dispatch(setPageName({ value: 'home' }));
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn = user['crn'];
      this.customerSegmentCd = user['customerSegmentCd'];;
      if (this.customerSegmentCd == 'TD') {
        this.TD = false;
      }
      if (this.customerSegmentCd == 'RA') {
        this.RA = false;
      }
      if (this.customerSegmentCd == 'CC') {
        this.CC = false;
      }
    })


  }



  otppage() {
    const payload = {
      id: 'CCARD',
      type: 'WIDGET'
    };
    this.otpService.validateTwoFaAndProceed(payload);
    this.router.navigateByUrl(ROUTE_KEY['ONBOARDING-OTP'], { skipLocationChange: environment.skipURI });
  }


  backon() {
    this.store.select(getBackId).subscribe({
      next: (resp: string) => {
        this.domId = resp;


      }
    });

  }

}




