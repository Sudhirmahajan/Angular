import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { getCardDetails } from 'src/app/auth/auth.index';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { OnboardingModule } from '../../onboarding.module';

import { ForexCardDetailsComponent } from './forex-card-details.component';

describe('ForexCardDetailsComponent', () => {
  let component: ForexCardDetailsComponent;
  let fixture: ComponentFixture<ForexCardDetailsComponent>;
  let store: MockStore;
  const MokeResp = { cardNo: "1234567890" }
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        OnboardingModule,
        NoopAnimationsModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateModule,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ ForexCardDetailsComponent ],
      providers: [

        provideMockStore(
          {
            selectors: [
              {
                selector: getCardDetails,
                value: MokeResp
              },
            ]
          })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForexCardDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    store = TestBed.inject<Store>(Store) as MockStore<any>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should Test Stroredata', () => {

    component.forexCardDetails();
        store.select(getCardDetails).subscribe((resp) => {
          expect(resp).not.toBeNull();
          expect(resp).toBe(MokeResp);
          expect(component.fCard).toBe(resp);
    
          expect(component.heading).toBe('xx7890');
          expect(component.loader).toBe(true);
        });
    
      });

      it('should test Back', () => {
        component.goBack();
      });

});
