import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getCardDetails, NavigationService } from 'src/app/auth/auth.index';

@Component({
  selector: 'app-forex-card-details',
  templateUrl: './forex-card-details.component.html',
  styleUrls: ['./forex-card-details.component.scss']
})
export class ForexCardDetailsComponent implements OnInit  {
public heading:string='';
loader:boolean=false;
public fCard: any = {};
  constructor(private store:Store,private navigation: NavigationService) { }

 

  ngOnInit(): void {
    this.forexCardDetails()
  }
  
forexCardDetails(){

  this.store.select(getCardDetails).subscribe({
    next: (resp: any) => {
      this.loader=true;
     this.fCard=resp;
      resp.cardName
      let last4 = resp.cardNo.substr(resp.cardNo.length - 4);
      this.heading = "xx" + last4

    }

  })
}

goBack() {
  this.navigation.goBack();
}

}
