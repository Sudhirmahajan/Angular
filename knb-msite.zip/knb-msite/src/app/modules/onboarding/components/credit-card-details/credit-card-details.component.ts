import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getCardDetails, NavigationService } from 'src/app/auth/auth.index';
import { cardEndPoints } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import {Clipboard} from '@angular/cdk/clipboard';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';

@Component({
  selector: 'app-credit-card-details',
  templateUrl: './credit-card-details.component.html',
  styleUrls: ['./credit-card-details.component.scss']
})
export class CreditCardDetailsComponent implements OnInit {
  public showCvvError!: boolean;
  public cvvData!: string;
  public isCVV = false;
  public heading!: string;
  loader: boolean = false;
  public cCard: any = {};
  public cCardDetail: any = {};
  cName!: string;

  constructor(private navigation: NavigationService,
    private store: Store, private service: OnboardingService, private clipboard: Clipboard, private widgetService:WidgetService ) { }


  ngOnInit(): void {

    this.creditCardData()
  }
  creditCardData() {

    this.loader = false;

    this.store.select(getCardDetails).subscribe({
      next: (resp: any) => {
       
        this.cCardDetail = resp['cardDetail'];
       
        this.cCard = resp['cardObj'];
        
        this.loader = true;

        this.cName = this.cCard.cardName
      
        this.heading = this.cCard.maskedCardNumber
          .substr(this.cCard.maskedCardNumber
            .length - 6);


      }

    })

  }

 

  public showCvv(card: any, expiryDate: any, cardType: any) {
    if (card && expiryDate) {
      this.getCvv(card, expiryDate, cardType);
    }
  }

  public getCvv(card: any, expiryDate: any, cardTypeData: any) {
    const payload = {
      encryptCardNumber: card,
      expiryDatetime: expiryDate,
      cardType: cardTypeData,
      source: "HOME_CC_WDGT"
    };

    this.service.handleCard(payload,
      cardEndPoints.cvvDetails)
      .subscribe({
        next: (res: any) => {
          this.isCVV = true;
          if (res['error']) {
            if (res['error']['errorCoode'] === 'CS1026') {
              this.showCvvError = true;
            } else {
              this.cvvData = res['error']['errorMessage'];
            }
          } else {
            this.cvvData = res['cvv'];
            this.cvvData = this.widgetService.getPlainText(res['cvv']);
          }
         

        }, error: (error) => {
          this.isCVV = true;
          this.cvvData = error.errorMessage;
        }
      });

  }

  copyData(data:string) {
    this.clipboard.copy(data);
  }

  goBack() {
    this.navigation.goBack();
  }


}
