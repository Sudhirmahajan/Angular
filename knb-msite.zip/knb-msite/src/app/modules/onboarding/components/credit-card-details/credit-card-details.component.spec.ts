import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { getCardDetails } from 'src/app/auth/auth.index';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { cardEndPoints } from '../../onboarding.constant';
import { OnboardingModule } from '../../onboarding.module';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

import { CreditCardDetailsComponent } from './credit-card-details.component';

describe('CreditCardDetailsComponent', () => {
  let component: CreditCardDetailsComponent;
  let fixture: ComponentFixture<CreditCardDetailsComponent>;
  let store: MockStore;
  let Mockservice = jasmine.createSpyObj('OnboardingService', ['handleCard']);
  let Mockwidgetservice = jasmine.createSpyObj('WidgetService',['getPlainText']);
  let service: jasmine.SpyObj<OnboardingService>;
  let widgetservice: jasmine.SpyObj<WidgetService>;
  let MokeResp = {cardObj:{cardName:"Test", maskedCardNumber:"xx7890"},cardDetail:{}}
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        OnboardingModule,
        NoopAnimationsModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateModule,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ CreditCardDetailsComponent ],
      providers: [
        { provide: OnboardingService, useValue: Mockservice },
        { provide: WidgetService, useValue: Mockwidgetservice },
        provideMockStore(
          {
            selectors: [
              {
                selector: getCardDetails,
                value: MokeResp
              },
            ]
          })
      ]
  
    
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCardDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    service = TestBed.inject(OnboardingService) as jasmine.SpyObj<OnboardingService>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should Test Stroredata', () => {

    component.creditCardData();
        store.select(getCardDetails).subscribe((resp) => {
          expect(resp).not.toBeNull();
          expect(resp).toBe(MokeResp);
          expect(component.cCardDetail).toBe(resp['cardDetail']);
          expect(component.cCard).toBe(resp['cardObj']);
    
          expect(component.heading).toBe('xx7890');
          expect(component.loader).toBe(true);
        });
    
      });

      it('should test Back', () => {
        component.goBack();
      });

      
      it('should test show cvv', () => {
        spyOn(component, 'getCvv' );
        component.showCvv("8987780990","8/24","CC_CARD");


      });

      it('should test show getCvv', () => {
        const payload = {
          encryptCardNumber: "8987780990",
          expiryDatetime: "8/24",
          cardType: "CC_CARD",
          source: "HOME_CC_WDGT"
        };
       service.handleCard.and.returnValue(of("676"));
        component.getCvv("8987780990","8/24","CC_CARD");
        service.handleCard({payload}, cardEndPoints.cvvDetails).subscribe({
          next: (resp) => {
          
            expect(component.isCVV ).toBe(true);
          }
        }) 
        

      });


      it('should test show getCvv Error ', () => {
        const payload = {
          encryptCardNumber: "8987780990",
          expiryDatetime: "8/24",
          cardType: "CC_CARD",
          source: "HOME_CC_WDGT"
        };
       // const data = {error: {'errorCode':"CS1026"}} ;
       service.handleCard.and.returnValue(of(throwError(() => null)));
       
       component.getCvv("8987780990","8/24","CC_CARD");
       
        service.handleCard({payload}, cardEndPoints.cvvDetails).subscribe({
          error: (error) => {
          
            expect(component.isCVV ).toBe(true);
            expect(component.cvvData ).toBe(error.errorMessage);
          }
        }) 
        

      });


      it('should copy text', () => {
        component.copyData("Copy Data");
      
      });

});
