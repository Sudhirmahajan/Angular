import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { userPersonaEndPoints } from '../../onboarding.constant';

@Component({
  selector: 'app-safe-banking-tips-modal',
  templateUrl: './safe-banking-tips-modal.component.html',
  styleUrls: ['./safe-banking-tips-modal.component.scss']
})
export class SafeBankingTipsModalComponent implements OnInit {

  @Output() safeBankingtips = new EventEmitter<boolean>();

  headerArray: string[]=["English","हिंदी","मराठी","ગુજરાતી"];
  public langArray : string[] = ["English","हिंदी","मराठी","ગુજરાતી","বাংলা","ಕನ್ನಡ","தமிழ்","മലയാളം","اردو","ଓଡିଆ","অসমীয়া"];
  lang: boolean=false;
  languageSelected:string="English";
  
  constructor(private onboardingService: OnboardingService) { }

  ngOnInit(): void {
  }

  showlang(){
    this.lang=true;
  }
  close(){
    this.lang=false;
  }

  langselected(selectedlang:string){
    this.languageSelected=selectedlang;
    this.lang=false;
  }
  
  safeBankingTips(value:boolean){
    this.onboardingService.handleUserPersona({}, userPersonaEndPoints.safeBankingCard).subscribe((resp) => { 
      this.safeBankingtips.emit(value);
    },err=>{
      this.safeBankingtips.emit(value);
    })
  }
}
