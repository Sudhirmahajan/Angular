import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SafeBankingTipsModalComponent } from './safe-banking-tips-modal.component';

describe('SafeBankingTipsModalComponent', () => {
  let component: SafeBankingTipsModalComponent;
  let fixture: ComponentFixture<SafeBankingTipsModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SafeBankingTipsModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SafeBankingTipsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
