
import { Component, Inject, OnInit } from '@angular/core';
import { IinvestmentGen } from '../../model/onboarding.model';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-investment-details',
  templateUrl: './investment-details.component.html',
  styleUrls: ['./investment-details.component.scss']
})
export class InvestmentDetailsComponent implements OnInit {

  loader: boolean = false;
  heading: any;
  investmentAcctNo!: any;
  public investmentGenObj: IinvestmentGen = {
    key: '',
    name: '',
    acctNo: '',
    balance: 0
  };


  constructor(@Inject(MAT_DIALOG_DATA) public diaogData: IinvestmentGen,) {
    this.investmentGenObj = diaogData;
  }

  ngOnInit(): void {
    let last4 = this.investmentGenObj.acctNo.substr(this.investmentGenObj.acctNo.length - 4);
    this.heading = 'xx' + last4

  }





}