import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { getInvestmentDetails } from 'src/app/auth/auth.index';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { OnboardingModule } from '../../onboarding.module';
import { InvestmentDetailsComponent } from './investment-details.component';

describe('InvestmentDetailsComponent', () => {
  let component: InvestmentDetailsComponent;
  let fixture: ComponentFixture<InvestmentDetailsComponent>;
  let store: MockStore;
  const MokeResp = { acctNo: "1234567890" }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        OnboardingModule,
        NoopAnimationsModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateModule,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [InvestmentDetailsComponent],
      providers: [

        provideMockStore(
          {
            selectors: [
              {
                selector: getInvestmentDetails,
                value: MokeResp
              },
            ]
          })
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvestmentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    store = TestBed.inject<Store>(Store) as MockStore<any>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should Test Stroredata', () => {

component.getInvestmentDetails();
    store.select(getInvestmentDetails).subscribe((resp) => {
      expect(resp).not.toBeNull();
      expect(resp).toBe(MokeResp);
      expect(component.investmentGenObj).toBe(resp);

      expect(component.heading).toBe('xx7890');
      expect(component.loader).toBe(true);
    });

  });

  it('should test back', () => {
    component.goBack();
  });
  

});
