import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { getPageDetails, getUserDetails, setPageName } from 'src/app/auth/auth.index';
import { ChatbotService } from 'src/app/auth/services/chatbot/chatbot.service';
import { environment } from 'src/environments/environment';
import { footer } from '../../onboarding-analytics';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  @Input () footerBottomMenu!:any;
  @Output() newTabEvent = new EventEmitter<string>();
  crn: any;
  page_name: any;


  
  constructor(
    private store: Store,private chatbotService: ChatbotService  ) { }

  ngOnInit(): void {
    this.accountDetails();
    }

  public accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
     this.crn=user['crn']
    })
  }
  
  setAnalytics(ctaname:any,footerlink:any){
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    const value={'ctaname':ctaname,'page-name':this.page_name,'footer-link':footerlink,'crn':this.crn}
    window.digitalData=footer(value)
    window._satellite?.track("NB-Msiteclick");
  }
  
  public goToKeya() {
    this.store.dispatch(setPageName({ value: 'ask keya' }));
    const chatBotConfig = { ...environment.chatBotInitParams, ...{ endPointToGenerateMacForPP: environment.endPointToGenerateMacForPP } };
    this.chatbotService.loadChatbot(chatBotConfig);
  }

  public routeToLink(link: string){
    this.newTabEvent.emit(link);

  }

}
