import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YourLoansDetailsComponent } from './your-loans-details.component';

describe('YourLoansDetailsComponent', () => {
  let component: YourLoansDetailsComponent;
  let fixture: ComponentFixture<YourLoansDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YourLoansDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YourLoansDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
