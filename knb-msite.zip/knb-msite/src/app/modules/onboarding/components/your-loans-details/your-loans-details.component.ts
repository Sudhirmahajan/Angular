import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { getLoanDetails, NavigationService } from 'src/app/auth/auth.index';


@Component({
  selector: 'app-your-loans-details',
  templateUrl: './your-loans-details.component.html',
  styleUrls: ['./your-loans-details.component.scss']
})
export class YourLoansDetailsComponent implements OnInit {

  public loanHeading!: string;
  loader: boolean = false;
  public loans: any = {};
  constructor(@Inject(MAT_DIALOG_DATA) public diaogData: any,) { 
    this.loans=diaogData;
  }


  ngOnInit(): void {
    let loanName = this.loans.loanTypeCode
        let last4 = this.loans.loanAccNo.substr(this.loans.loanAccNo.length - 4);
        this.loanHeading = "xx" + last4
  }





}
