import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

import { SummaryComponent } from './summary.component';

describe('SummaryComponent', () => {
  let component: SummaryComponent;
  let fixture: ComponentFixture<SummaryComponent>;
 // let service: OnboardingService;
 // let mockMatDialog: MatDialog
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SummaryComponent]
    })

      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  //  service = TestBed.inject(OnboardingService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });




});
