import { Component, OnInit } from '@angular/core';
import { investmentEndPoints, widgetCodes } from '../../onboarding.constant';
import { IAssetsSummaryResponse, ILiabilitiesSummaryResponse, IGenericAsset, IAssetAccount, ILianilitiesAccount, IGenericLiabilities } from '../../model/summery.model';
import { MatDialog } from '@angular/material/dialog';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { DialogBoxComponent } from 'src/app/modules/shared/utils/dialog-box/dialog-box.component';
import { Store } from '@ngrx/store';
import { getUserDetails } from 'src/app/auth/auth.index';
import { icidWidget } from '../../onboarding-analytics';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { MatSnackBar, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';


@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})

export class SummaryComponent implements OnInit {

  hide: boolean = true;
  hideLib: boolean = true;
  showMyContainerA: any = {};
  showMyContainerL: any = {};

  panelOpenState: any;
  parseFloat = parseFloat;
  public liabilityBalObj: any[] = [];
  public liabilityBal = 0.00;
  public assetBal = 0.00;
  public liabilityBal2 = 0.00;
  public isIntBalErr: boolean = false;
  public isIntBalErrL: boolean = false;
  public errorLib: boolean = false;
  public errorAssets: boolean = false;

  public assetBalObj: any[] = [];
  public totalValue: any;
  public loaded: boolean = false;
  public loadedL: boolean = false;
  public errorString = '';
  public errorStringL = '';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  assetGenObj: IGenericAsset[] = [];
  liaBilityGebObj: IGenericLiabilities[] = [];
  CurrencyCode: string = ''

  seemore: string = "dashboard.common.see-more";
  pluse: string = "+ ";


  seemoreL: string = "dashboard.common.see-more";
  pluseL: string = "+ ";
  crn: any;
  constructor(
    private store: Store, 
    private summaryService: OnboardingService,
    private dialog: MatDialog,
    private widgetService: WidgetService,
    private _snackBar: MatSnackBar,
  ) { }

  ngOnInit(): void {
    const downtime = this.widgetService.getDownTimeFlag(widgetCodes.SUMMARY);
    if (downtime === 'Y') {
            this._snackBar.open('There seems to be a technical glitch. While we check on it, why don’t you explore other products  and services. Come back in sometime and we will be ready to service your request.', '', {
        duration: 5000,
        verticalPosition: this.verticalPosition,
      })
    } 
    this.accountDetails();
  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
   const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
   window.digitalData=icidWidget(value)
   window._satellite?.track("NB-Msiteclick");
  }

  openAssetsDialog() {
    this.dialog.open(DialogBoxComponent, { panelClass: 'custom-dialog-container', backdropClass: 'backdropBackground', data: { dialogHeader: 'dashboard.Assets.heading', dialogInfo: 'dashboard.toolTip.asset' }, });
  }

  openLiabilityDialog() {
    this.dialog.open(DialogBoxComponent, { panelClass: 'custom-dialog-container', backdropClass: 'backdropBackground', data: { dialogHeader: 'dashboard.liability.heading', dialogInfo: 'dashboard.toolTip.liability' }, });
  }
  public getAssetsBalance() {

    if (!this.hide) {
      this.hide = true;
      this.setAnalytics('Your Summary','Assets',this.hide ? 'Hide Balance' : 'View Balance')
      return
    }
    this.loaded = true;
    this.summaryService.handleInvestment({}, investmentEndPoints.assetSummary).subscribe({
      next: (response: IAssetsSummaryResponse) => {
        this.loaded = false;
        this.hide = !this.hide;
        this.assetGenObj = [];
        this.assetBalObj = [];
        this.setAnalytics('Your Summary','Assets',this.hide ? 'Hide Balance' : 'View Balance')
        this.getAssetObject(response);

      },
      error: () => {

        this.errorAssets = true;
        this.errorString = 'dashboard.common.asset-unavailable';
      }
    })
  }


  public currencyWiseDataAccount(valueAcc: any) {

    let depInr = valueAcc.currencyWiseTotalAmt.filter((value: { currencyCode: string; }) => value.currencyCode === 'INR');
    let depDoller = valueAcc.currencyWiseTotalAmt.filter((value: { currencyCode: string; }) => value.currencyCode === 'EURO');
    let depUsd = valueAcc.currencyWiseTotalAmt.filter((value: { currencyCode: string; }) => value.currencyCode === 'USD');
    let depInrData = valueAcc.accounts.filter((value: { acctCrncyCode: string; }) => value.acctCrncyCode === 'INR');
    let depDollerData = valueAcc.accounts.filter((value: { acctCrncyCode: string; }) => value.acctCrncyCode === 'EURO');
    let depUsdData = valueAcc.accounts.filter((value: { acctCrncyCode: string; }) => value.acctCrncyCode === 'USD');


    if (depInr.length > 0) {
      let inrTotalAmt = depInr[0].totalAmt;
      let name: string = valueAcc.name;
      let accountsArrObj: IAssetAccount[] = [];
      let accountArray: any[] = depInrData;
      if (name == "Banking Accounts") {
        accountArray.forEach(acc => {
          let accountsObj: IAssetAccount = {
            schmType: 'dashboard.navItem.CURR' + acc.schmType, clrBalance: acc.clrBalance,
            acctCrncyCode: acc.acctCrncyCode, accountNo: acc.accountNo
          };
          accountsArrObj.push(accountsObj);
        });
      }
      if (name == "Deposits") {
        accountArray.forEach(acc => {
          let accountsObj: IAssetAccount = {
            schmType: acc.depositType, clrBalance: acc.clrBalance,
            acctCrncyCode: acc.acctCrncyCode, accountNo: acc.accountNo
          };
          accountsArrObj.push(accountsObj);
        });
      }
      this.assetGenObj.push({ name: name, totalAmt: inrTotalAmt, currencycode: 'INR', account: accountsArrObj });
    }
    if (depDoller.length > 0) {
      let dollerTotalAmt = depDoller[0].totalAmt;
      let name: string = valueAcc.name;
      let accountsArrObj: IAssetAccount[] = [];
      let accountArray: any[] = depDollerData;
      if (name == "Banking Accounts") {
        accountArray.forEach(acc => {
          let accountsObj: IAssetAccount = {
            schmType: 'dashboard.navItem.CURR' + acc.schmType, clrBalance: acc.clrBalance,
            acctCrncyCode: acc.acctCrncyCode, accountNo: acc.accountNo
          };
          accountsArrObj.push(accountsObj);
        });
      }
      if (name == "Deposits") {
        accountArray.forEach(acc => {
          let accountsObj: IAssetAccount = {
            schmType: acc.depositType, clrBalance: acc.clrBalance,
            acctCrncyCode: acc.acctCrncyCode, accountNo: acc.accountNo
          };
          accountsArrObj.push(accountsObj);
        });
      }
      this.assetGenObj.push({ name: name, totalAmt: dollerTotalAmt, currencycode: 'EURO', account: accountsArrObj });
    }
    if (depUsd.length > 0) {
      let usdTotalAmt = depUsd[0].totalAmt;
      let name: string = valueAcc.name;
      let accountsArrObj: IAssetAccount[] = [];
      let accountArray: any[] = depUsdData;
      if (name == "Banking Accounts") {
        accountArray.forEach(acc => {
          let accountsObj: IAssetAccount = {
            schmType: 'dashboard.navItem.CURR' + acc.schmType, clrBalance: acc.clrBalance,
            acctCrncyCode: acc.acctCrncyCode, accountNo: acc.accountNo
          };
          accountsArrObj.push(accountsObj);
        });
      }
      if (name == "Deposits") {
        accountArray.forEach(acc => {
          let accountsObj: IAssetAccount = {
            schmType: acc.depositType, clrBalance: acc.clrBalance,
            acctCrncyCode: acc.acctCrncyCode, accountNo: acc.accountNo
          };
          accountsArrObj.push(accountsObj);
        });
      }
      this.assetGenObj.push({ name: name, totalAmt: usdTotalAmt, currencycode: 'USD', account: accountsArrObj });
    }
  }

  public getAssetObject(res: IAssetsSummaryResponse) {

    for (let [key, value] of Object.entries(res)) {
      if (!this.isEmpty(value)) {
        if (value.name == 'Banking Accounts' || value.name == 'Deposits') {
          this.currencyWiseDataAccount(value)

        }
        if (value.name == 'Mutual Fund') {
          let accountsArrObj: IAssetAccount[] = [];
          let accountArray: any[] = value.mutualFundDetails;

          accountArray.forEach(acc => {
            let accountsObj: IAssetAccount = {
              schmType: "", clrBalance: acc.currentBal,
              acctCrncyCode: "INR", accountNo: acc.mfAccNo
            };
            accountsArrObj.push(accountsObj);
          });
          this.assetGenObj.push({ name: value.name, totalAmt: value.totalValue, currencycode: 'INR', account: accountsArrObj })
        }
        if (value.name == 'Demat Account') {
          let accountsArrObj: IAssetAccount[] = [];
          let accountArray: any[] = value.dmatDetails
            ;


          accountArray.forEach(acc => {
            let accountsObj: IAssetAccount = {
              schmType: "", clrBalance: acc.balance,
              acctCrncyCode: "INR", accountNo: acc.dmatAccNo
            };
            accountsArrObj.push(accountsObj);


          });
          this.assetGenObj.push({ name: value.name, totalAmt: value.totalValue, currencycode: 'INR', account: accountsArrObj })

        }
        if (value.name == 'National Pension Scheme') {
          let accountsArrObj: IAssetAccount[] = [];
          let accountArray: any[] = value.npsDetails;

          accountArray.forEach(acc => {
            let accountsObj: IAssetAccount = {
              schmType: "", clrBalance: acc.currentValue,
              acctCrncyCode: "INR", accountNo: acc.pranNo
            };
            accountsArrObj.push(accountsObj);
          });
          this.assetGenObj.push({ name: value.name, totalAmt: value.totalValue, currencycode: 'INR', account: accountsArrObj })
        }
        if (value.name == 'Insurance') {
          let accountsArrObj: IAssetAccount[] = [];
          let accountArray: any[] = value.npsDetails;

          accountArray.forEach(acc => {
            let accountsObj: IAssetAccount = {
              schmType: "", clrBalance: acc.sumAssured,
              acctCrncyCode: "INR", accountNo: acc.productName
            };
            accountsArrObj.push(accountsObj);
          });
        }
        if (value && value.wealthCustomer && value.wealthCustomerDeails && value.wealthCustomerDeails.aif) {
          const valwc = parseFloat(value.wealthCustomerDeails.aif.amount);
          this.assetGenObj.push({
            name: 'dashboard.common.otherInvestMent', totalAmt: valwc, currencycode: 'INR', account: [{
              schmType: "", clrBalance: "",
              acctCrncyCode: "INR", accountNo: ""
            }]
          })
        }
        if (value.wealthCustomer && value && value.wealthCustomerDeails && value.wealthCustomerDeails.nonAif) {

          const valwc = parseFloat(value.wealthCustomerDeails.nonAif.amount);
          value += valwc;
          this.assetGenObj.push({
            name: 'dashboard.common.optimus', totalAmt: valwc, currencycode: 'INR', account: [{
              schmType: "", clrBalance: "",
              acctCrncyCode: "INR", accountNo: ""
            }]
          })

        }
      }
    }

    this.assetGenObj = this.assetGenObj.sort((a, b) => a.name.localeCompare(b.name));

    let value = 0;
    for (const val of this.assetGenObj) {
      if (val.currencycode == 'INR') {
        if (!this.isEmpty(val.totalAmt)) {
          val.totalAmt = parseFloat(val.totalAmt);
          value += val.totalAmt;
        }
      }
    }
    this.assetBal = value;
    if (this.assetBal > 0) {
      this.isIntBalErr = false;
    } else {
      this.isIntBalErr = true;
    }

  }


  ///////////////////////////////////////Liabilities////////////////////////////////////////////

  public getLiabilitiesBalance() {

    if (!this.hideLib) {
      this.hideLib = true;
      this.setAnalytics('Your Summary','Liablities',this.hideLib ? 'Hide Balance' : 'View Balance'); 
      return
    }
    this.loadedL = true;

    this.summaryService.handleInvestment({}, investmentEndPoints.liablitiesSummary).subscribe({
      next: (response: ILiabilitiesSummaryResponse) => {
        this.loadedL = false;
        this.hideLib = !this.hideLib;
        this.liaBilityGebObj = [];
        this.liabilityBalObj = [];
        this.getLiabilityObject(response);
        this.setAnalytics('Your Summary','Liablities',this.hideLib ? 'Hide Balance' : 'View Balance'); 
      },
      error: () => {
        this.errorLib = true;
        this.errorStringL = 'dashboard.common.liability-unavailable';
      }
    })

  }



  getLiabilityObject(res: ILiabilitiesSummaryResponse) {

    for (let [key, value] of Object.entries(res)) {
      if (value !== null) {
        if (value.name == 'Loans') {
          let accountsArrObj: ILianilitiesAccount[] = [];
          let loanArray: any[] = value.loanDetails;

          loanArray.forEach(acc => {
            let accountsObj: ILianilitiesAccount = {
              schmType: "dashboard.loans." + acc.loanTypeCode, clrBalance: acc.totalOs
              ,
              accountNo: acc.loanAccNo

            };
            accountsArrObj.push(accountsObj);
          });

          this.liaBilityGebObj.push({ name: value.name, totalAmt: value.totalValue, account: accountsArrObj })
        }

        if (value.name == 'Over Draft Account') {
          let accountsArrObj: ILianilitiesAccount[] = [];
          let accountArray: any[] = value.accounts;
          accountArray.forEach(acc => {
            let accountsObj: ILianilitiesAccount = {
              schmType: acc.schmType, clrBalance: acc.clrBalance
              ,
              accountNo: acc.accountNo
            };
            accountsArrObj.push(accountsObj);
          });
          this.liaBilityGebObj.push({ name: value.name, totalAmt: value.totalValue, account: accountsArrObj })

        }
        if (value.name == 'Cash credit account') {
          let accountsArrObj: ILianilitiesAccount[] = [];
          let accountArray: any[] = value.accounts;

          accountArray.forEach(acc => {
            let accountsObj: ILianilitiesAccount = {
              schmType: acc.schmType, clrBalance: acc.currentBal,
              accountNo: acc.accountNo
            };
            accountsArrObj.push(accountsObj);


          });

          this.liaBilityGebObj.push({ name: value.name, totalAmt: value.totalValue, account: accountsArrObj })


        }

        if (value.name == 'Credit Card') {
          let accountsArrObj: ILianilitiesAccount[] = [];
          let accountArray: any[] = value.creditCardDetails;
          accountArray.forEach(acc => {

            let cardArray: any[] = acc.cardDataDetails;
            cardArray.forEach(acc2 => {
              let accountsObj: ILianilitiesAccount = {
                schmType: acc2.cardName, clrBalance: acc.availableLimit,
                accountNo: acc2.maskedCardNumber
              };
              accountsArrObj.push(accountsObj);
            })



          });

          this.liaBilityGebObj.push({ name: value.name, totalAmt: value.totalValue, account: accountsArrObj })


        }


      }
    }
    this.liaBilityGebObj = this.liaBilityGebObj.sort((a, b) => a.name.localeCompare(b.name));
    let value = 0;
    for (const val of this.liaBilityGebObj) {
      if (val) {
        if (val.totalAmt) {
          val.totalAmt = parseFloat(val.totalAmt);
          value += val.totalAmt;
        }
      }
    }
    this.liabilityBal = value;


    if (this.liabilityBal > 0) {
      this.isIntBalErrL = false;
    } else {
      this.isIntBalErrL = true;
    }
  }

  public seeMore(i: number) {
    this.showMyContainerA[i] = !this.showMyContainerA[i];
    if (this.showMyContainerA[i]) {

      this.seemore = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.seemore = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }

  public seeMoreL(i:number)
  {
    this.showMyContainerL[i]=!this.showMyContainerL[i];
    if(this.showMyContainerL[i]){
     
      this.seemoreL='dashboard.account-summary.see-less'
      this.pluseL="- "
    }
    else{
      this.seemoreL="dashboard.common.see-more";
      this.pluseL="+ "
    }
  
  }
  public isEmpty(value: any) {
    return (
      (!value) ||
      (value.hasOwnProperty('length') && value.length === 0) ||
      (value.constructor === Object && Object.keys(value).length === 0)
    );
  }
}

