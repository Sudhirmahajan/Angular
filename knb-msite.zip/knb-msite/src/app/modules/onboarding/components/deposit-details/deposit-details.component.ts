import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-deposi-details',
  templateUrl: './deposit-details.component.html',
  styleUrls: ['./deposit-details.component.scss']
})
export class DepositDetailsComponent implements OnInit {
  aactNo:any;
  heading:any;
  deposteNo:any;
 data:any={};
 loader:boolean=false;
domId:string='#';
dasBoard:boolean=false;
public botton:string="NextOne";

  constructor(@Inject(MAT_DIALOG_DATA) public diaogData:any,) {
    this.data=diaogData;  
   }
 

  ngOnInit(): void {
    let last4 = this.data.accountNo.substr(this.data.accountNo.length-4);
     this.heading = 'xx'+last4

  }
 


 
}
