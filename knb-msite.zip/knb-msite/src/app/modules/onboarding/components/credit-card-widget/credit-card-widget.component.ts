import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getUserDetails, setCardDetails } from 'src/app/auth/auth.index';
import { TwofaOtpService } from 'src/app/modules/shared/services/TwoFa-Otp/twofa-otp.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { icidWidget } from '../../onboarding-analytics';
import { cardEndPoints, ROUTE_KEY, typeOfProduct } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

@Component({
  selector: 'app-credit-card-widget',
  templateUrl: './credit-card-widget.component.html',
  styleUrls: ['./credit-card-widget.component.scss']
})
export class CreditCardWidgetComponent implements OnInit {
  @Input()
  creditCardList: any;
  @Input()
  index!: number;
  public hide: any[] = [];
  public i!: number;
  public cvvData!: string;
  public isCVV = false;
  public dataServiceData!: object;
  public creditPopup: any = {};
  public getCreditCardWidgets = {};
  public dataServiceCreditFlag = [];
  public creditBalFlag: any[] = [];
  public showDownloadOption = false;
  // public creditBalAttr: ICreditBalAttr = {} as any;
  public widgetCode!: string;
  public errorResCreditBalance: boolean=false;
  public creditPopupSucErr!: string;
  public showCvvError!: boolean;
public cCardObj :any={};
  private twoFaVerified = false;
  public loaded:boolean=false;
  public errorString:string='dashboard.common.balance-unavailable';
  private twoFaCheckTriggeredFrom!: string;
  acctId: any;
  expiry: any;
  Jindex:any;
  crn: any;
  constructor(private service: OnboardingService, private store: Store,private router: Router,private widgetService: WidgetService,
    private twofaOtpService: TwofaOtpService
  ) { }

  ngOnInit(): void {
    
    this.accountDetails();
  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
    const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }
 

  public getCreditBalance(acctId: any, j: any) {
    this.hide[j] = !this.hide[j];
    const creditCardNo = acctId;
    this.loaded=true;
    
    this.service.handleCard({ creditCardNo, souce: "HOME_CC_WDGT" },
      cardEndPoints.ccBal).subscribe({
        next: (resp: any) => {
          this.loaded=false

          if (resp['error']) {
            this.errorResCreditBalance = true;
          } else {
            this.creditPopup = resp;
           
          }
        },
        error: () => {
          this.loaded=false
          this.errorResCreditBalance = true;

        }

      })

  }

  public routelink(acctId: any, j: any,  expiry:any) {
    this.acctId = acctId;
    this.expiry = expiry;
    this.Jindex=j;
    const payload = {
      id: 'RDR-CARD-POP',
      type: typeOfProduct.menu
    };

    this.checkTwoFaValidationStatus();
    this.twofaOtpService.validateTwoFaAndProceed(payload);
    // this.router.navigateByUrl(ROUTE_KEY['ONBOARDING-OTP'], { skipLocationChange: environment.skipURI });

    this.widgetService.validateTwoFaResponseCast.subscribe((response) => {
      if (response && !response.showMfaFlag && !this.twoFaVerified && this.twoFaCheckTriggeredFrom === 'POPUP') {
        this.twoFaVerified = true;
       // this.getDebitBalance(acctId);
        this.widgetService.setValidateTwoFaResponse('');
      }
    });

  }


  public routeToDetailsPage() {
    this.hide[this.Jindex] = !this.hide[this.Jindex];
    this.loaded=true;
    this.cCardObj={};
    const creditCardNo = this.acctId;
    this.service.handleCard({ expiryDate : this.expiry,creditCardNo, souce: "HOME_CC_WDGT" },
      cardEndPoints.ccBal).subscribe({
        next: (resp: any) => {

       

          if (resp['error']) {
            this.errorResCreditBalance = true;
          } else {
            this.creditCardList["cardDataDetails"][this.Jindex].cardNumber =  this.widgetService.getPlainText(resp['cardNo']);
            this.creditCardList["cardDataDetails"][this.Jindex]["expiryDate"] =  this.widgetService.getPlainText(resp['expiryDate']);  
            this.errorResCreditBalance = false;
            this.cCardObj={cardDetail:resp, cardObj:this.creditCardList.cardDataDetails[this.Jindex]}
           
            this.store.dispatch(setCardDetails({value:this.cCardObj}))
            this.router.navigateByUrl(ROUTE_KEY['CCARD'], { skipLocationChange: environment.skipURI });
          }
        },
        error: () => {

          this.errorResCreditBalance = true;

        }

      })

  }




   private checkTwoFaValidationStatus() {
    this.widgetService.otpvalidationResCast.subscribe((resp) => {
      
      if (resp && resp === 'suc' && !this.twoFaVerified) {
        this.twoFaVerified = true;
        this.routeToDetailsPage();
        //this.getDebitBalance(this.debitBalAttr.acctId, this.debitBalAttr.index, this.debitBalAttr.type, '');
        this.widgetService.setotpvalidationRes('');
      }
    });
  }


}
