import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';

import { Subscription } from 'rxjs';
import { getUserDetails, setDepositDetails } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ICrossSaleResponse, IDepositBalAttr, INudge } from '../../model/onboarding.model';
import { icidWidget } from '../../onboarding-analytics';
import { accountEndPoints, ROUTE_KEY } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { MatDialog } from '@angular/material/dialog';
import { DepositDetailsComponent } from '../deposit-details/deposit-details.component';

@Component({
  selector: 'app-desposit-list',
  templateUrl: './desposit-list.component.html',
  styleUrls: ['./desposit-list.component.scss']
})
export class DespositListComponent implements OnInit {

  public isDeposit = true;


  public depositListResp: any[] = [];
  public depositOptions!: ICrossSaleResponse;
  public isDepositOptions = false;
  public dataServiceCreditFlag = [];
  public depositBalFlag:any[] = [];
  public flagCheck:any[] = [];
  public dataServiceData!: object;
  public widgetCode = 'DEPOSITS';
  public depositDropdown = {};
  public depositNumber!: number;
  public acctId!: string;
  public nudgeRes!: INudge;
  public dataAcctDisplayCount!: number;
  public seeMoreDeposit = false;
  public seeLessDeposit = false;
  public showMore10 = false;
  public showMoreRedirect = false;
  public depositBalObj!: IDepositBalAttr;
  public depositOtp!: object;
  public errorResDepositList = false;
  public errorResDepositBalance!: object;
  public errorDepositList!:boolean;
  public widgetName = 'dashboard.drag-arrange-widget.DEPOSITS';
  public downtime!: boolean;
  public downtimeError!: {};
  public showDetailsFlag = false;
  private httpSubscription!: Subscription;
  private httpSubscriptioncMenu!: Subscription;
  private twoFaVerified = false;
  public response:any;
  deposit: any[] = [];
  data:any={};
  public hide: any[] = [];
  public i!: number;
  showMyContainerA: any = {};
	
  seemore:string="dashboard.common.see-more";
  pluse:string="+ ";
  public errorString: string = "dashboard.errorLoan.unavailable";
  depositLoader: boolean=false;
  crn: any;



  constructor(public dialog: MatDialog,private service:OnboardingService, private store: Store, private router:Router) { }

  ngOnInit(): void {
    this.accountDetails();
    this.depositListData()
  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
    const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }

  public seeMore(i: number) {
    this.showMyContainerA[i] = !this.showMyContainerA[i];
    if (this.showMyContainerA[i]) {
      this.setAnalytics('Your deposits','your deposits','see more')
      this.seemore = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.setAnalytics('Your deposits','your deposits','see less')
      this.seemore = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }

  public routeToLink(iDep: number) {
    

    this.deposit=this.response['depositDtls'];
     this.data=this.deposit[iDep]

     const dialogRef = this.dialog.open(DepositDetailsComponent, {
      width: '85vw',
      panelClass: 'custom-dialog-container',
      backdropClass: 'backdropBackground',
      data:this.data
      
    });

   
  }


  public depositListData() {

    

    this.httpSubscription = this.service.handleAccount({},
      accountEndPoints.deposit)
      .subscribe({
        next:(resp:any)=>{
          
          this.depositLoader=true;
         this.response=resp;
          if (resp['offers']) {
            this.nudgeRes = resp['offers'];
          }
          if (resp['crossSaleDetails']) {
            this.depositOptions = resp['crossSaleDetails'];
            if (resp['crossSaleDetails'].length > 0) {
              this.isDepositOptions = true;
            }
          }
  
          if (!resp['error']) {
            this.depositLoader=true;
            this.depositListResp = resp['depositDtls'];
          
            this.errorResDepositList = false;
            if (resp['depositDtls'].length > 0) {
              this.depositNumber = (Object.keys(this.depositListResp).length);
            } else {
              this.isDeposit = false;
              this.depositNumber = 0;
            }
            if (resp['depositDtls'].length === 0 || resp['depositDtls'][0]['errorCode'] || resp['errorCode']) {
              this.isDeposit = false;
              this.depositNumber = 0;
              this.depositLoader=true;
            }
            
          } else {
            this.errorDepositList = resp['error'];
            this.depositLoader=true;
          }
      
  
        },
        error: () =>  {
           this.errorResDepositList = true;
           this.depositLoader=true;
         }
      })

     
      
        
  }

  public clickMoreOutside() {
    const popupAnimation: NodeListOf<Element> = document.querySelectorAll('.popupAnimation');
    for (const item of popupAnimation as any) {
      item.classList.remove('show');
    }
  }

  public depositeRecall(i:Number) {
  }

  public viewDepositBalance(data: any, index: number, event: any) {
    event.stopPropagation();
    this.flagCheck[index] = true;
    this.depositDropdownList(data, index);
  }
  public depositDropdownAPI(data: any, index: number) {
    const resp = {
      depositAmount: data['depositAmount']
    };
    this.depositListResp[index]['depBal'] = resp;
    this.showDetailsFlag = true;
  }

  public closeDetailsPopUp() {
    this.showDetailsFlag = false;
  }

  public depositDropdownList(data: any, i: any) {
    this.twoFaVerified = false;
    this.depositBalObj = {
      accountData: data,
      index: i
    };
    const payload = {
      id: 'DEPOSITS',
      type: 'WIDGET'
    };
    this.checkTwoFaValidationStatus();

   this.twoFaVerified = true;
   this.viewDepositBalOtp(data, i);
  }
  public viewDepositBalOtp(data: any, index: number) {
    data.depositAmount = data['depositAmount'];
    const resp = {
      depositAmount: data['depositAmount'],
      interestRate: data['interestRate'],
      maturityAmt: data['maturityAmt'],
      maturityDate: data['maturityDate'],
      lienAmt: data['lienAmt']
    };
    this.depositDropdown = resp;
    this.depositListResp[index]['depBal'] = resp;
    this.depositBalFlag[index] = !this.depositBalFlag[index];
  }

  public closeSevicePopup() {
    this.dataServiceCreditFlag = [];
  }
  public redirectIframe(depositType: string) {
   
  }

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
    if (this.httpSubscriptioncMenu) {
      this.httpSubscriptioncMenu.unsubscribe();
    }
  }

  private checkTwoFaValidationStatus() {
   
   }

   public viewAccBalance(i: number) {
    this.hide[i] = !this.hide[i];
  }


}
