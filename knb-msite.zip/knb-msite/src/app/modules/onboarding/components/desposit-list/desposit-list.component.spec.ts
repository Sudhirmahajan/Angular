import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DespositListComponent } from './desposit-list.component';

describe('DespositListComponent', () => {
  let component: DespositListComponent;
  let fixture: ComponentFixture<DespositListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DespositListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DespositListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
