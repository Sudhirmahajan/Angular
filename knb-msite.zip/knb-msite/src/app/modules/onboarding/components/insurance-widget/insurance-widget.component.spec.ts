import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuranceWidgetComponent } from './insurance-widget.component';

describe('InsuranceWidgetComponent', () => {
  let component: InsuranceWidgetComponent;
  let fixture: ComponentFixture<InsuranceWidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InsuranceWidgetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InsuranceWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
