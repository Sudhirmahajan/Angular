import { Component, ElementRef, OnInit } from '@angular/core';
import { ICrossSaleResponse, InsuranceWidget } from '../../model/onboarding.model';
import { investmentEndPoints } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

@Component({
  selector: 'app-insurance-widget',
  templateUrl: './insurance-widget.component.html',
  styleUrls: ['./insurance-widget.component.scss']
})
export class InsuranceWidgetComponent implements OnInit {



  public insuranceData!: InsuranceWidget[];
  public insuranceDataLength = true;
  public loader = true;
  public showInsuranceDownloadOption = false;
  public openInsurancePopupFlag = false;
  public errorInsuranceList!: object;
  public widgetCodepass = 'INSURANCE';
  public showMoreIns = false;
  public showLessIns = false;
  public dataInsuranceDisCount!: number;
  public insuranceListLength!: number;
  public errorRes!: boolean;
  public errorResKGI!: boolean;
  public errorString: string='';
  public errorResKLI!: boolean;
  public insuranceOptions!: ICrossSaleResponse;
  public isInsuranceerror = false;
  public widgetName = 'dashboard.yourinsurance.insurance';




  constructor(
    private service: OnboardingService,
 
  ) {

  }

  ngOnInit() {
    this.getInsuranceDetail();
 
  }





  public getInsuranceDetail() {
   this.service.handleInvestment({},
      investmentEndPoints.insuranceDetails)
      .subscribe((resp: any) => {
        this.insuranceData = [];
        
        this.isInsuranceerror = false;
        if (!this.isEmpty(resp['crossSaleDetails'])) {
          this.insuranceOptions = resp['crossSaleDetails'];
        }
       

        if (!this.isEmpty(resp['kgiInsuranceDetails'])) {
          this.insuranceRes(resp['kgiInsuranceDetails'], 'kgiInsuranceDetails');
        }
        if (!this.isEmpty(resp['kliInsuranceDetails'])) {
          this.insuranceRes(resp['kliInsuranceDetails'], 'kliInsuranceDetails');
        }
        if (!this.isEmpty(resp['insuranceDetails'])) {
          this.insuranceRes(resp['insuranceDetails'], 'insurance');
        } else if (this.isEmpty(resp['insuranceDetails'])) {
          this.loader = false;
        }
        if (this.insuranceData.length === 0) {
          this.insuranceDataLength = false;
        }
        this.multiAPIErrorHandlling();
      },
        (error) => {
          this.loader = false;
          this.isInsuranceerror = true;
        }
      );

  }

  public insuranceRes(data:any, type:any) {
    if (data[0]['errorCode']) {
      this.loader = false;
      if (data[0]['errorCode'] !== 'CS1004' &&
        data[0]['errorCode'] !== 'ERR0001' && data[0]['errorCode'] !== 'BE2001') {
        if (type === 'insurance') {
          this.errorRes = true;
        }
        if (type === 'kgiInsuranceDetails') {
          if (data[0]['errorCode'] !== 'IS1005') {
            this.errorResKGI = true;
          }

        }
        if (type === 'kliInsuranceDetails') {
          if (data[0]['errorCode'] !== 'IS1005') {
            this.errorResKLI = true;
          }

        }
      }
    } else if (!data['errorCode']) {
      this.insuranceData = [...data];
      this.loader = false;
      if (this.insuranceData) {
        if (this.insuranceData.length === 0) {
          this.insuranceDataLength = false;
        }
        this.insuranceListLength = (Object.keys(this.insuranceData).length);
        if (this.insuranceListLength <= 3) {
          this.showMoreIns = false;
        } else {
          this.showMoreIns = true;
        }
      }
    }
  }

  // public redirectIframe() {
  //   const productName = internalProductNames.insuranceMoreDetail;
  //   this.productProcessorRouterService.pageProductProcessorNavigation(productName);
  // }

  public insuranceRecall() {
    this.loader = true;
    this.getInsuranceDetail();
  }

  public showMoreInsurance() {
    this.dataInsuranceDisCount = this.insuranceListLength;
    this.showLessIns = true;
    this.showMoreIns = false;
  }

  public showLessInsurance() {
    this.dataInsuranceDisCount = 3;
    this.showLessIns = false;
    this.showMoreIns = true;
  }

  private multiAPIErrorHandlling() {
    if (this.errorRes && this.errorResKGI && this.errorResKLI) {
      this.errorString = 'dashboard.common.insuranceErrorAll';
    } else if (this.errorRes && this.errorResKGI) {
      this.errorString = 'dashboard.common.insurance-kgiinsurance-unavailable';
    } else if (this.errorResKGI && this.errorResKLI) {
      this.errorString = 'dashboard.common.kgiinsurance-klinsurance-unavailable';
    } else if (this.errorRes && this.errorResKLI) {
      this.errorString = 'dashboard.common.insurance-klinsurance-unavailable';
    } else if (this.errorRes) {
      this.errorString = 'dashboard.common.insuranceError-insurance';
    } else if (this.errorResKGI) {
      this.errorString = 'dashboard.common.insuranceError-insuranceKGI';
    } else if (this.errorResKLI) {
      this.errorString = 'dashboard.common.insuranceError-insuranceKLI';
    }
  }
  private isEmpty(value:any) {
    return (
      (value === null) ||
      (value.hasOwnProperty('length') && value.length === 0) ||
      (value.constructor === Object && Object.keys(value).length === 0)
    );
  }

}
