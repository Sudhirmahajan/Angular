import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, of, throwError } from 'rxjs';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

import { YourLoansComponent } from './your-loans.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { OnboardingModule } from '../../onboarding.module';
import { investmentEndPoints } from '../../onboarding.constant';

describe('YourLoansComponent', () => {

  let component: YourLoansComponent;
  let fixture: ComponentFixture<YourLoansComponent>;
  let Mockservice = jasmine.createSpyObj('OnboardingService', ['handleInvestment']);
  let service: jasmine.SpyObj<OnboardingService>;
  let store: MockStore;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let router: Router;
  let data: any = {

    loanDetails: [

      {
        loanTypeCode: 'Non-Life',

        loanAccNo: 'MST7896',

        agrValue: '811.00',

        nxtEmiDate: '',

        nxtEmiAmt: '811.00',

        proposalNumber: '445566.90',

        chargesOs: '99.87',

        intRate: '5.00',

        balTenure: '',

        totalOs: '0.00'

      }

    ],

    offers: [

      {
        offerContentHeader: 'Request Chequebook',
        offerBtnText: 'Apply',
        offerBtnHRef: 'http://www.kotak.com/main_land_china.html',
        offerBtnTarget: 'IFR or EXT',
        offerImg: 'https://nbuat.kotak.com/Offers/unica/images/http://www.kotak.com/main_land_china.html',
        offerOrigin: 'local',
        widgetId: 1507,
        messageId: 7,
        msgText: 'Request Chequebook|Apply'

      }
    ],

    crossSaleDetails: [

      {
        menuCode: 'PMJJY',
        mfaFlag: 'N',
        crossalePrdCd: 'CS-PMJJY',
        crossalePrdName: 'PMJJY',
        imageUrl: 'https://www.kotak.com/content/dam/Kotak/svg-icons/offers-everyday.svg',
        hyplinkText: 'Open',
        urlType: 'EXT',
        dispOrder: 1

      },

      {
        menuCode: 'PMJJBY',
        mfaFlag: 'N',
        crossalePrdCd: 'CS-PMJJBY',
        crossalePrdName: 'PMJJBY',
        imageUrl: 'https://www.kotak.com/content/dam/Kotak/svg-icons/offers-everyday.svg',
        hyplinkText: 'Open',
        urlType: 'EXT',
        dispOrder: 2

      }

    ]

  };
  beforeEach(async () => {

    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        OnboardingModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [YourLoansComponent],

      providers: [
        { provide: OnboardingService, useValue: Mockservice },
        provideMockStore({
          selectors: [

          ]
        })


      ],
    })
      .compileComponents();
  });

  beforeEach(() => {

    fixture = TestBed.createComponent(YourLoansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges;
    service = TestBed.inject(OnboardingService) as jasmine.SpyObj<OnboardingService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    httpTestingController = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });



  it("should call Loan and return list of LoanDetails", () => {
  
    service.handleInvestment.and.returnValue(of(data));
    component.getLoan();
    service.handleInvestment({}, investmentEndPoints.loanDetails).subscribe({
      next: (resp) => {
      
        expect(resp).toBe(data);
      }
    })

    expect(component.response).toEqual(data);

  });


  it('should fetch error', () => {
  
    service.handleInvestment.and.returnValue(throwError(() => null));
    component.getLoan();
    service.handleInvestment({}, investmentEndPoints.loanDetails).subscribe({
      error: (error) => {

        expect(component.isLoanError).toEqual(true);
        expect(component.loanLoader).toEqual(true);
      }
    })

  });


  it('should getLoan response error', () => {
    const data = {loanDetails: [{'errorCode':true}]} ;
    service.handleInvestment.and.returnValue(of(data));
    component.getLoan();
    service.handleInvestment({}, investmentEndPoints.loanDetails).subscribe({
      next: (resp) => {
      
        expect(component.isLoanError).toBe(true);
        expect(component.loanLoader).toBe(true);
      }
    }) 
  });


  it('should getLoan response error[0]', () => {
    const data = {error: {'errorCode':"b122"}} ;
    service.handleInvestment.and.returnValue(of(data));
    component.getLoan();
    service.handleInvestment({}, investmentEndPoints.loanDetails).subscribe({
      next: (resp) => {
      
        expect(component.isLoanError).toBe(true);
        expect(component.loanLoader).toBe(true);
      }
    }) 
  });



  it('should store data and rout to next detail page', () => {



    component.response = data;
    spyOn(store, 'dispatch').and.callThrough();
    spyOn(router, 'navigateByUrl');
    component.routeToLink(1);
    expect(router.navigateByUrl).toHaveBeenCalled();
    expect(store.dispatch).toHaveBeenCalled();

  });



  it('should return true IsEmpty', () => {
    const data = { test: 'test' }
    const returnValue = component.isEmpty(data);
    expect(returnValue).toBe(false);
  });


  it('should return true IsEmpty', () => {
    const data = {}
    const returnValue = component.isEmpty(data);
    expect(returnValue).toBe(true);
  });



});



