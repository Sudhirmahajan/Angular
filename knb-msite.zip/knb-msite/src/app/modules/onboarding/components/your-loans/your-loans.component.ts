import { Component, OnInit } from '@angular/core';
import { ICrossSaleResponse, INudge, } from '../../model/onboarding.model';
import { investmentEndPoints } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY } from '../../onboarding.constant';
import { Store } from '@ngrx/store';
import { getUserDetails, setLoanDetails } from 'src/app/auth/auth.index';
import { icidWidget } from '../../onboarding-analytics';
import { MatDialog } from '@angular/material/dialog';
import { YourLoansDetailsComponent } from '../your-loans-details/your-loans-details.component';


@Component({
  selector: 'app-your-loans',
  templateUrl: './your-loans.component.html',
  styleUrls: ['./your-loans.component.scss']
})
export class YourLoansComponent implements OnInit {

  public accountBalFlag = [];
  public rowid!: number;
  public loanDetails: any[] = [];
  public acctListLength!: number;
  public loanDetailsLength = true;
  public loader = true;
  public afterBalnce = false;
  public errorResNudge!: object;
  public loansOptions!: ICrossSaleResponse;
  public contextMenuRes!: object;
  public dataAcctDisplayCount!: number;
  public showMore = false;
  public showMore10 = false;
  public showLess = false;
  public errorRes: any;
  public widgetName = 'dashboard.yourLoan.errorLoan';
  public isLoanError = false;
  public downtime!: boolean;
  public downtimeError: {} | undefined;
  public widgetCode = 'LOANS';
  public nudgeRes!: INudge;
  public hide: any[] = [];
  public i!: number;
  showMyContainerA: any = {};
  public loans: any = {};
  private link!: any;
  private twoFaVerified = false;
  public errorString: string = "dashboard.errorLoan.unavailable";
 
  public loanLoader: boolean = false;
  public response: any;
  public loanDetails1: any[] = [];
  public loan: any = {};
   public loanName:any;
  seemore:string="dashboard.common.see-more";
  pluse:string="+ ";
  crn: any;
  translate: any;
 



  constructor(public dialog: MatDialog,private service: OnboardingService,  private router: Router, private store: Store,) {
   
   }

  ngOnInit(): void {
   this.accountDetails();
    this.getLoan();
  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){

    switch(productname){
      case "HF": this.loanName = "Home Loan"; break;
      case "CSG":this.loanName = "Business Loan"; break;
      case "CV": this.loanName = "Commercial Vehicles Loan"; break;
      case "CE": this.loanName = "Construction Equipment Loan"; break;
      case "SPL":this.loanName = "Personal Loan"; break;
      case "SPLN": this.loanName = "Personal Loan"; break;
      case "CFB": this.loanName = "Consumer Durable Loan"; break;
      case "TFE":this.loanName = "Tractor & Farm Equipment Loan"; break;
      case "SA": this.loanName = "UNNATI [SARAL]"; break;
      case "LAP": this.loanName = "Loan Against Property"; break;
      case "LCV":this.loanName = "Light Commercial Vehicles Loan"; break;
      case "GLN": this.loanName = "Gold Loan"; break;
      case "RHB": this.loanName = "Rural Housing Business Loan"; break;
      case "AF":this.loanName = "Agri Loans"; break;
      case "ACF": this.loanName = "Agri Loans"; break;
      case "IHL":this.loanName = "Home Loan"; break;
      case "ICV": this.loanName = "Commercial Loan"; break;
      case "ISPL": this.loanName = "Personal Loan"; break;
      case "IGLN":this.loanName = "Gold Loan"; break;
      case "ILAP":this.loanName = "Home Loan"; break;
      default:this.loanName=productname;
     }

    const value={'widget-name':widgetname,'product-name':this.loanName,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }
 

  public routeToLink(i: any) {
   
    const dialogRef = this.dialog.open(YourLoansDetailsComponent, {
      width: '85vw',
      panelClass: 'custom-dialog-container',
      backdropClass: 'backdropBackground',
      data:this.response['loanDetails'][i]
      
    });
    // this.store.dispatch(setLoanDetails({ value: this.response['loanDetails'][i] }))
    // this.router.navigateByUrl(ROUTE_KEY['LOAN'], { skipLocationChange: environment.skipURI });
  }



  public getLoan() {
    this.service.handleInvestment({},
      investmentEndPoints.loanDetails).subscribe({
        next: (resp: any) => {
          this.response = resp;
          
 
          if (resp['loanDetails'][0] && resp['loanDetails'][0]['errorCode']) {
          
            this.isLoanError = true;
            this.loanLoader = true;
          }
          else if (resp['error']) {
            this.errorRes = resp['error'];
            this.loanLoader = true;
            this.isLoanError = false;
            this.loanDetailsLength = false;
          } else {
            this.isLoanError = false;
            this.loanDetails = resp['loanDetails'];
            this.loanLoader = true;
            if (this.loanDetails) {
              if (this.loanDetails.length === 0) {
                this.loanDetailsLength = false;
              } else if (this.loanDetails.length > 0) {
                this.acctListLength = (Object.keys(this.loanDetails).length);
                if (this.acctListLength <= 3) {
                  this.showMore = false;
                } else {
                  this.showMore = true;
                }
              }
            }

          }

        },
        error: () => {

          this.isLoanError = true;
          this.loanLoader = true;

        }


      })


  }
  public viewAccBalance(i: number) {
    this.hide[i] = !this.hide[i];
  }




  public isEmpty(value: any) {
    return (
      (!value) ||
      (value.hasOwnProperty('length') && value.length === 0) ||
      (value.constructor === Object && Object.keys(value).length === 0)
    );
  }
public seeMore(i:number)
{
  this.showMyContainerA[i]=!this.showMyContainerA[i];
  if(this.showMyContainerA[i]){
    this.setAnalytics('Your Loans','your loans','see more')
    this.seemore='dashboard.account-summary.see-less'
    this.pluse="- "
  }
  else{
    this.setAnalytics('Your Loans','your loans','see less')
    this.seemore="dashboard.common.see-more";
    this.pluse="+ "
  }

}



}

