import { Component, Input, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { IDashboardWidgetResponseVO } from '../../model/onboarding.model';
import { cardEndPoints, widgetCodes } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

@Component({
  selector: 'app-card-detail',
  templateUrl: './card-detail.component.html',
  styleUrls: ['./card-detail.component.scss']
})
export class CardDetailComponent implements OnInit {

  
  @Input() var1!: string;

  public CardList: number=0;
  public cardNudgeData!: object;
  public debitCardList:any;
  public forexCardList:any;
  public forexCard!: {};
  public forexListLength!: number;
  public forexCardRefactor:any;
  public debitListLength!: number;
  public creditListLength: number=0;
  public creditCardList: any;
  public dataCardsDisplayCount = 3;
  public cardsOptions: any;
  public hideWidget!: boolean;
  public nudgeRes:any;
 
  public totalCards!: number;
  public widgetListData!: IDashboardWidgetResponseVO[];
  public cardListData!: any[];
  public iscardAppiFail = true;
  public loader = true;
  public errorResCreditList = false;
  public errorCreditList: any;
  public debitRetry!: boolean;
  public creditRetry!: boolean;
  public forexRetry!: boolean;
  public isCarderr: boolean=false;
  public errorString!: string;
  public i!: number;
  items = 3;
  public errorResDebitList = false;
  public errorDebitList: any;

  public errorResForexList = false;
  public errorForexList: any;

  public downtime!: boolean;
  public debitCardDowntime!: boolean;
  public creditCardDowntime!: boolean;
  public forexCardDowntime!: boolean;
  public downtimeError:any;
  public downtimeErrorDC:any;
  public downtimeErrorCC:any;
  public downtimeErrorFC:any;
  private httpSubscriptionNudge!: Subscription;
  private httpSubscriptionForexList!: Subscription;
  private httpSubscriptionDebitList!: Subscription;
  private httpSubscriptionCreditList!: Subscription;
  showMyContainerA: any = {};
  	
  seemore:string="dashboard.common.see-more";
  pluse:string="+ ";
  constructor(
    private service: OnboardingService,
   
  
  ) {
    /**
     * 'DOWNTIME' is treated as error code for downtime
     */
    this.downtimeError = {
      errorCode: widgetCodes.DOWNTIME
    };
  }

  ngOnInit() {
 
    this.cardDetail();
  }

  public cardDetail() {
    this.cardListData = [];
    this.loader = true;
    this.debitRetry = false;
    this.creditRetry = false;
    this.forexRetry = false;
    this.errorString = '';
    this.httpSubscriptionDebitList = this.service.handleCard(
      {source:"HOME_CARD_WDGT"}, cardEndPoints.cards)
      .subscribe({
        next: (resp: any) => {

       if (!this.isEmpty(resp)) {
        this.loader = false;
        this.isCarderr = false;
        if (!resp['error']) {
          if (!this.isEmpty(resp['crossSaleDetails'])) {
            this.cardsOptions = resp['crossSaleDetails'];
          }
          if (!this.isEmpty(resp['offers'])) {
            this.nudgeRes = resp['offers'];
          }
          if (!this.isEmpty(resp['creditCardDtls']) && !this.creditCardDowntime) {
            this.creditcardRes(resp['creditCardDtls']);
          }

          if (!this.isEmpty(resp['debitCardDtls']) && !this.debitCardDowntime) {
            this.debitcardRes(resp['debitCardDtls']);
          }

          if (!this.isEmpty(resp['tcCardDtls']) && !this.forexCardDowntime) {
            this.forexcardRes(resp['tcCardDtls']);
          }
          if (!this.debitCardDowntime && !this.creditCardDowntime && !this.forexCardDowntime && this.cardListData.length === 0) {
            this.iscardAppiFail = false;
          }
        } else {
          if (resp['error']['errorCode'] === 'CS1031'
            || resp['error']['errorCode'] === 'CS1020'
            || resp['error']['errorCode'] === 'CS1029'
            || resp['error']['errorCode'] === 'CS1030'
            || resp['error']['errorCode'] === 'MWFBE001') {
            this.loader = false;
            this.isCarderr = true;
            this.cardsOptions = {};
          }
        }
      }
      },
      error: () => {
          this.loader = false;
          this.isCarderr = true;
          this.cardsOptions = {};
        }
      });
    this.multiAPIErrorHandlling();
   
    
  }
  public debitcardRes(data:any) {
    this.debitCardList = data;
    if (!this.debitCardList[0]['errorCode']) {
      this.errorResDebitList = false;
      for (const data in this.debitCardList) {
        this.cardListData.push({
          key: 'DCARD',
          list: this.debitCardList[data]
        });
      }
      if (this.debitCardList) {
        this.debitListLength = this.debitCardList.length;
        this.CardList += this.debitListLength;
      } else {
        this.debitListLength = 0;
      }
    } else {
      if ((this.debitCardList[0]['errorCode'] !== 'CS1004') && (this.debitCardList[0]['errorCode'] !== 'ERR0001')) {
        this.debitRetry = true;
      }
      if (this.debitCardList[0]['errorCode'] === 'ERR0001' || this.debitCardList[0]['errorCode'] === 'MWFBE001') {
        this.debitRetry = true;
      }
    }
  }
  public creditcardRes(resp:any) {
    this.creditCardList = resp;
    if (!this.creditCardList[0]['errorCode']) {
      
      this.errorResCreditList = false;
      for (const data in resp) {
        this.cardListData.push({
          key: 'CCARD',
          list: resp[data]
        });
      }
      
      if (this.creditCardList) {
      
        this.creditCardList.forEach((len: any)=>{
          this.creditListLength =len.cardDataDetails.length
        });
        
      } else {
        this.creditListLength = 0;
      }
      this.CardList += this.creditListLength;
     
    } else {
      if ((this.creditCardList[0]['errorCode'] !== 'CS1004') && (this.creditCardList[0]['errorCode'] !== 'ERR0001')) {
        this.creditRetry = true;
      }
      if (this.creditCardList[0]['errorCode'] === 'ERR0001' || this.creditCardList[0]['errorCode'] === 'MWFBE001') {
        this.creditRetry = true;
      }
    }
  }
  public forexcardRes(resp:any) {
    this.forexCardList = resp;
    if (!this.forexCardList['errorCode']) {
      this.errorResForexList = false;
      if (this.forexCardList) {
        this.forexListLength = (Object.keys(this.forexCardList).length);
        for (const key in this.forexCardList.tcCustomerInfoList) {
          this.forexCardList.tcCustomerInfoList[key]['map'] = this.forexCardList.tcDetailsProductInfoDetails;
        }
        this.forexCardRefactor = this.forexCardList;
        this.cardListData.push({
          key: 'FCARD',
          list: this.forexCardRefactor
        });
        this.CardList += (this.forexCardRefactor['tcCustomerInfoList']).length;
      } else {
        this.forexListLength = 0;
      }
    } else {
      if ((this.forexCardList['errorCode'] !== 'CS1004' && (this.forexCardList['errorCode'] !== 'ERR0001'))) {
        this.forexRetry = true;
      }
      if (this.forexCardList['errorCode'] === 'ERR0001' || this.forexCardList['errorCode'] === 'MWFBE001') {
        this.forexRetry = true;
      }
    }


  }
 


  ngOnDestroy() {
    if (this.httpSubscriptionNudge) {
      this.httpSubscriptionNudge.unsubscribe();
    }
  }

  private multiAPIErrorHandlling() {
    if (this.debitRetry && this.creditRetry && this.forexRetry) {
      this.errorString = 'dashboard.common.debit-credit-forex-unavailable';
    } else if (this.debitRetry && this.creditRetry) {
      this.errorString = 'dashboard.common.debit-credit-unavailable';
    } else if (this.creditRetry && this.forexRetry) {
      this.errorString = 'dashboard.common.credit-forex-unavailable';
    } else if (this.debitRetry && this.forexRetry) {
      this.errorString = 'dashboard.common.debit-forex-unavailable';
    } else if (this.debitRetry) {
      this.errorString = 'dashboard.common.debit-unavailable';
    } else if (this.creditRetry) {
      this.errorString = 'dashboard.common.credit-unavailable';
    } else if (this.forexRetry) {
      this.errorString = 'dashboard.common.forex-unavailable';
    }
    else{
      this.errorString = 'dashboard.common.debit-credit-forex-unavailable';
    }

    
    
  }
  public seeMore(i:number)
  {
    this.showMyContainerA[i]=!this.showMyContainerA[i];
    if(this.showMyContainerA[i]){
     
      this.seemore='dashboard.account-summary.see-less'
      this.pluse="- "
    }
    else{
      this.seemore="dashboard.common.see-more";
      this.pluse="+ "
    }
  
  }


  private isEmpty(value:any) {
    return (
      (!value) ||
      (value.hasOwnProperty('length') && value.length === 0) ||
      (value.constructor === Object && Object.keys(value).length === 0)
    );
  }
}
