import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardDetailComponent } from './card-detail.component';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { of } from 'rxjs';

describe('CardDetailComponent', () => {
  let component: CardDetailComponent;
  let fixture: ComponentFixture<CardDetailComponent>;
  let store: MockStore;
  
  let widgetServiceObj = jasmine.createSpyObj('WidgetService', ['']);

  let MockonboardingService = jasmine.createSpyObj('OnboardingService', ['handleCard']);
  let onboardingServiceObj: jasmine.SpyObj<OnboardingService>;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CardDetailComponent ],

      providers : [{ provide : WidgetService , useValue : widgetServiceObj},
                   { provide : OnboardingService , useValue : MockonboardingService}
                  ]

    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CardDetailComponent);
    component = fixture.componentInstance;
    onboardingServiceObj         = TestBed.inject(OnboardingService) as jasmine.SpyObj<OnboardingService>;
    fixture.detectChanges();
  });

  it('should test card Detail', () => {
    
    const payload = {
      encryptCardNumber: "8987780990",
      expiryDatetime: "8/24",
      cardType: "CC_CARD",
      source: "HOME_CC_WDGT"
    };

    //onboardingServiceObj.handleCard.
    onboardingServiceObj.handleCard.and.returnValue(of({
      flow: 'CREATE_USERNAME',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: 'Y',
    }))

    component.cardDetail();
    
    onboardingServiceObj.handleCard(payload, '/testUrl').subscribe({ next: (resp: any) => {
      expect(component['cardDetail']).toHaveBeenCalled();
    }})

  });
});
