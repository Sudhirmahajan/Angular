import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of } from 'rxjs';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { investmentEndPoints } from '../../onboarding.constant';
import { OnboardingModule } from '../../onboarding.module';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

import { InvestmentsComponent } from './investments.component';

describe('InvestmentsComponent', () => {
  let component: InvestmentsComponent;
  let fixture: ComponentFixture<InvestmentsComponent>;
  let Mockservice = jasmine.createSpyObj('OnboardingService', ['handleInvestment']);
  let service: jasmine.SpyObj<OnboardingService>;
  let store: MockStore;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let router: Router;
const data=[ {
  key: 'MUTFUND',
  list: {
  mfAccNo: '1350232',
  currentBal: '.00',
  holderName: '',
  amtInvested: '',
  gainLoss: ''
  }
  },
  {
  key: 'DEMAT',
  list: {
  dmatAccNo: 'IN302814-10490263',
  balance: '262539.20',
  holderName: '',
  amtInvested: '',
  gainLoss: ''
  }
  },
  {
  key: 'DEMAT',
  list: {
  dmatAccNo: 'IN302814-11342655',
  balance: '2634243.76',
  holderName: '',
  amtInvested: '',
  gainLoss: ''
  }
  },
  {
  key: 'DEMAT',
  list: {
  dmatAccNo: 'IN302814-22919923',
  balance: '.00',
  holderName: '',
  amtInvested: '',
  gainLoss: ''
  }
  },
  {
  key: 'DEMAT',
  list: {
  dmatAccNo: 'IN302814-32919923',
  balance: '.00',
  holderName: '',
  amtInvested: '',
  gainLoss: ''
  }
  }]
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        OnboardingModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ InvestmentsComponent ],

      providers: [
        { provide: OnboardingService, useValue: Mockservice },
        provideMockStore({
          selectors: [

          ]
        })


      ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvestmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.inject(OnboardingService) as jasmine.SpyObj<OnboardingService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    httpTestingController = TestBed.inject(HttpTestingController);
    router = TestBed.inject(Router);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it("should call Loan and return list of LoanDetails", () => {
  
    service.handleInvestment.and.returnValue(of(data));
    component.investmentDetail();
    service.handleInvestment({}, investmentEndPoints.investmentDetails).subscribe({
      next: (resp) => {
      
        expect(resp).toBe(data);
        expect(component.investmentLoader).toBe(true);
      }
    })

    

  });
});
