import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getUserDetails, setInvestmentDetails } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ImutualFaund, IDashboardWidgetResponseVO, Inps, Idamat, INudge, IinvestmentGen } from '../../model/onboarding.model';
import { icidWidget } from '../../onboarding-analytics';
import { investmentEndPoints, productCode, ROUTE_KEY, widgetCodes } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';
import { TxnDetailsDialogBoxComponent } from 'src/app/modules/shared/utils/txn-details-dialog-box/txn-details-dialog-box.component';
import { MatDialog } from '@angular/material/dialog';
import { InvestmentDetailsComponent } from '../investment-details/investment-details.component';

@Component({
  selector: 'app-investments',
  templateUrl: './investments.component.html',
  styleUrls: ['./investments.component.scss']
})
export class InvestmentsComponent implements OnInit {



  public mutualFund!: ImutualFaund;
  public widgetListInvestData!: IDashboardWidgetResponseVO[];
  public mutualFundLenght!: number;
  public nps!: Inps;
  public npsLenght!: number;
  public dmat!: Idamat;
  public dmatLength!: number;
  public dataServiceData!: object;
  public nudgeResp: any;
  public accountListResp!: object;
  public nudgeRes!: INudge;
  public errorResNudge!: object;
  public investListData: any[] = [];
  public isInvestListData = true;
  public seeMoreInvest = false;
  public seeLessInvest = false;
  public totalInvest!: number;
  public dataInvestDisplayCount!: number;
  public investmentsOption: any;
  public showinvestmentDownloadOption!: boolean;
  public errInvestment!: boolean;
  public errorResnps = false;
  public npscount = 0;
  public errornps: any;
  public investmentLoader: boolean = false;
  public errorString = 'Record Not Found'
  public widgetCode = widgetCodes.INVESTMENTS;
  public listOfUnavailableProducts: any[] = [];
  public investmentAcctNo!: any;
  public investmentGenObj: IinvestmentGen[] = [];

  public hide: any[] = [];
  public i!: number;
  showMyContainerA: any = {};
  public investmentGenObj1: IinvestmentGen = {
    key: '',
    name: '',
    acctNo: '',
    balance: 0
  };
  
  seemore:string="dashboard.common.see-more";
  pluse:string="+ ";
  crn: any;
  investmentName: any;
  constructor(public dialog: MatDialog,private service: OnboardingService, private store: Store, private router: Router) { }

  ngOnInit(): void {
    this.accountDetails();
    this.investmentDetail();
  }
  
  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
    
    switch(productname){
      case "dashboard.investments-mutual-fund.heading-mutual-fund": this.investmentName = "Mutual Fund"; break;
      case "dashboard.investments-mutual-fund.amount-invested": this.investmentName = "Amount Invested"; break;
      case "dashboard.investments-mutual-fund.gain": this.investmentName = "Gain"; break;
      case "dashboard.investments-mutual-fund.loss": this.investmentName = "Loss"; break;
      case "dashboard.investments-nps.amount-invested": this.investmentName = "Amount Invested"; break;
      case "dashboard.investments-nps.gain": this.investmentName = "Gain"; break;
      case "dashboard.investments-nps.heading-nps": this.investmentName = "National Pension Scheme"; break;
      case "dashboard.investments-dmat.heading": this.investmentName = "Demat Account"; break;
      case "dashboard.investments-dmat.amount-invested": this.investmentName = "Amount Invested"; break;
      case "dashboard.investments-dmat.gain": this.investmentName = "Gain"; break;
      case "dashboard.investments-dmat.loss": this.investmentName = "Loss"; break;
    }

    const value={'widget-name':widgetname,'product-name':this.investmentName,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=icidWidget(value)
    window._satellite?.track("NB-Msiteclick");
   }

  public isEmpty(value: any) {
    return (
      (value === null) ||
      (value.hasOwnProperty('length') && value.length === 0) ||
      (value.constructor === Object && Object.keys(value).length === 0)
    );
  }

  public investmentDetail() {

    this.errInvestment = false;
    this.listOfUnavailableProducts = [];
    this.service.handleInvestment({}, investmentEndPoints.investmentDetails).subscribe({
      next: (resp: any) => {
        this.investmentLoader = true;
        if (!resp['error']) {
       
          if (!this.isEmpty(resp['mutualFundDetails'])) {
            if (resp['mutualFundDetails'][0]['errorCode'] !== 'SERVERR001' && resp['mutualFundDetails'][0]['errorCode'] !== 'ERR0001'
              && resp['mutualFundDetails'][0]['errorCode'] !== 'BE0002') {
              if (resp['mutualFundDetails'][0]['errorCode'] !== 'BE0012') {
                this.investListData.push(resp['mutualFundDetails']);
              }
            } else {
              this.listOfUnavailableProducts.push(productCode.MUTUALFUND);
            }
          }
          if (!this.isEmpty(resp['dmatDetails'])) {
            if (resp['dmatDetails'][0]['errorCode'] !== 'SERVERR001' && resp['dmatDetails'][0]['errorCode'] !== 'ERR0001'
              && resp['dmatDetails'][0]['errorCode'] !== 'BE0002') {
              if (resp['dmatDetails'][0]['errorCode'] !== 'BE0012') {
                this.investListData.push(resp['dmatDetails']);
              }
            } else {
              this.listOfUnavailableProducts.push(productCode.DEMAT);
            }
          }
          if (!this.isEmpty(resp['npsDetails'])) {
            if (resp['npsDetails'][0]['errorCode'] !== 'SERVERR001' && resp['npsDetails'][0]['errorCode'] !== 'ERR0001'
              && resp['npsDetails'][0]['errorCode'] !== 'BE0002') {
              if (resp['npsDetails'][0]['errorCode'] !== 'BE0012') {
                this.investListData.push(resp['npsDetails']);
              }
            } else {
              this.listOfUnavailableProducts.push(productCode.NPS);
            }
          }
          if (this.investListData.length === 0) {
            this.isInvestListData = false;
          }
          this.getGenObj(this.investListData);


        } else {
          this.errInvestment = true;
        }

      }, error: () => {

        this.errInvestment = true;
        this.investmentLoader = true;

      }


    });
  }


  getGenObj(investListData: any[]) {
    let key: string;
    let name: string;
    let acctNo: string;
    let balance: any;

    investListData.forEach(acc1 => {
      acc1.forEach((acc: { [x: string]: any; amtInvested: any; holderName: any; gainLoss: any; }) => {

        if (acc['mfAccNo']) {
          key = 'MUTFUND';
          name = 'dashboard.investments-mutual-fund.heading-mutual-fund';
          acctNo = acc['mfAccNo'];
          balance = acc['currentBal']

        }
        if (acc['pranNo']) {
          key = 'NPS';
          name = 'dashboard.investments-nps.heading-nps';
          acctNo = acc['pranNo'];
          balance = acc['currentValue']

        }
        if (acc['dmatAccNo']) {
          key = 'DMAT';
          name = 'dashboard.investments-dmat.heading';
          acctNo = acc['dmatAccNo'];
          balance = acc['balance']
        }
        let obj: IinvestmentGen = {
          key: key,
          name: name,
          acctNo: acctNo,
          balance: balance,
          amtInvested: acc.amtInvested,
          holderName: acc.holderName,
          gainLoss: acc.gainLoss
        }
        this.investmentGenObj.push(obj)

      })
    })


  }


  public viewAccBalance(i: number) {
    this.hide[i] = !this.hide[i];
  }


  routeToLink(investmentAcctNo: string) {

    let key: any;
    let name: string;
    let acctNo: string;
    let balance: any;
    this.investListData.forEach(acc1 => {
      acc1.forEach((acc: { [x: string]: any; amtInvested: any; holderName: any; gainLoss: any; }) => {

        if (acc['mfAccNo']) {
          key = 'MUTFUND';
          name = 'dashboard.investments-mutual-fund.heading-mutual-fund';
          acctNo = acc['mfAccNo'];
          balance = acc['crval']

        }
        if (acc['pranNo']) {
          key = 'NPS';
          name = 'dashboard.investments-nps.heading-nps';
          acctNo = acc['pranNo'];
          balance = acc['currentValue']


        }
        if (acc['dmatAccNo']) {
          key = 'DMAT';
          name = 'dashboard.investments-dmat.heading';
          acctNo = acc['dmatAccNo'];
          balance = acc['balance']
        }
        if (acctNo == investmentAcctNo) {
          this.investmentGenObj1 = {
            key: key,
            name: name,
            acctNo: acctNo,
            balance: balance,
            amtInvested: acc.amtInvested,
            holderName: acc.holderName,
            gainLoss: acc.gainLoss

          }

        }


      })
    })
    this.showTxnDetails(this.investmentGenObj1)

  }


  public seeMore(i:number)
{
  this.showMyContainerA[i]=!this.showMyContainerA[i];
  if(this.showMyContainerA[i]){
   
    this.seemore='dashboard.account-summary.see-less'
    this.pluse="- "
  }
  else{
    this.seemore="dashboard.common.see-more";
    this.pluse="+ "
  }

  }





  showTxnDetails(txn: any) {
    const dialogRef = this.dialog.open(InvestmentDetailsComponent, {
      width: '85vw',
      panelClass: 'custom-dialog-container',
      backdropClass: 'backdropBackground',
      data:txn
      
    });

  console.log("print Dialog");
  

  }
}
