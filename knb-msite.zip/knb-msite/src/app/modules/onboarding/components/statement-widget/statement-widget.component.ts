import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { getUserDetails } from 'src/app/auth/auth.index';
import { TxnDetailsDialogBoxComponent } from 'src/app/modules/shared/utils/txn-details-dialog-box/txn-details-dialog-box.component';
import { IAccounts, ITransactionDetails } from '../../modules/statements/model/statements.model';
import { icidWidget } from '../../onboarding-analytics';
import { accountEndPoints, statementEndPoints } from '../../onboarding.constant';
import { OnboardingService } from '../../services/onboarding/onboarding.service';

@Component({
  selector: 'app-statement-widget',
  templateUrl: './statement-widget.component.html',
  styleUrls: ['./statement-widget.component.scss']
})
export class StatementWidgetComponent implements OnInit {
  accountList!: IAccounts[];
  httpSubscription!: Subscription;
  selectedAccId!: string;
  transactionDetails: ITransactionDetails[] = [];
  currencyCode!: string;
  showMyContainerA: any = {};
  items = 5;
  accountForm!: FormGroup;
  selectedAccount!: number;
  public Loader: boolean = false;
  public rLoader: boolean = false;
  accountError:boolean=false;
  accountError1:boolean=false;
  errorString:string="Account Data Unavailable "
  crn: any;
  constructor(
    private store: Store, 
    private onboardingService: OnboardingService,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {



    this.accountListData();
    this.initialize('');
  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(widgetname:any,productname:any,ctaname:any){
   const value={'widget-name':widgetname,'product-name':productname,'ctaname':ctaname,'crn':this.crn}
   window.digitalData=icidWidget(value)
   window._satellite?.track("NB-Msiteclick");
  }

  initialize(uniqAccId: string) {
    this.accountForm = new FormGroup({
      uniqAccId: new FormControl(uniqAccId),
    });
  };

  public accountListData() {
    this.httpSubscription = this.onboardingService.handleAccount({}, accountEndPoints.accounts)
      .subscribe({next: (response: IAccounts[]) => {
        this.Loader=true;
        this.accountError=false;
        this.accountList = response;
        this.selectedAccId = response[0].uniqAccId;
        this.initialize(response[0].uniqAccId);
        this.getRecentTransaction();
      }, error: () => {
        this.Loader=true;
        this.rLoader=true;
        this.accountError1=true;
       
        
      }});
  }

  public getRecentTransaction() {
    
    this.rLoader=false;
    const payload = {
      acId: this.accountForm.value.uniqAccId,
      fromDate: '',
      toDate: '',
      startChequeNo: '',
      endChequeNo: '',
      maxTxnamount: '',
      minTxnamount: '',
      numberOfTxn: '',
      txnType: '',
      sortingOrder: 'D',
      description: '',
      source:"LHS_STMT_ACC_STMT"
    };
    this.httpSubscription = this.onboardingService.handleStatement(payload, statementEndPoints.statement)
      .subscribe({next: (response) => {
        this.rLoader=true;
        this.transactionDetails = response.transactionDetails || [];
        this.currencyCode = response.currencyCode || '';
      }, error: () => {
        this.transactionDetails = [];
        this.rLoader=true;
        this.accountError=true;
      }});

      
  }

  showTxnDetails(txn: ITransactionDetails) {
    const dialogRef = this.dialog.open(TxnDetailsDialogBoxComponent, {
      width: '85vw',
      panelClass: 'custom-dialog-container', 
      backdropClass: 'backdropBackground',
      data: { 
        header: 'Transaction Details',
        RefNo: txn.txnId, 
        txnType: txn.txnType,
        txnDesc: txn.txnDesc,
        amt: txn.txnAmountValue, 
        date: txn.txnDate,
        currencyCode: this.currencyCode
      },
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  
  }
}
