import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatementWidgetComponent } from './statement-widget.component';

describe('StatementWidgetComponent', () => {
  let component: StatementWidgetComponent;
  let fixture: ComponentFixture<StatementWidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatementWidgetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
