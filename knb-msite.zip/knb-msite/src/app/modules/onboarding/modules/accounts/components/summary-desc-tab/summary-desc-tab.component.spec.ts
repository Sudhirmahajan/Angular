import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryDescTabComponent } from './summary-desc-tab.component';

describe('SummaryDescTabComponent', () => {
  let component: SummaryDescTabComponent;
  let fixture: ComponentFixture<SummaryDescTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SummaryDescTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryDescTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
