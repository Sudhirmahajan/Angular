import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountsRoutingModule } from './accounts-routing.module';
import { AccountTabComponent } from './components/account-tab/account-tab.component';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { SummaryDescTabComponent } from './components/summary-desc-tab/summary-desc-tab.component';

import { MoreDetailsAccountsComponent } from './components/more-details-accounts/more-details-accounts.component';
import { AccountsComponent } from './accounts.component';
import { AcctRecentTransactionComponent } from './components/acct-recent-transaction/acct-recent-transaction.component';


const routes: Routes = [
  {
    path: '',
    component: AccountTabComponent
  }
];



@NgModule({
  declarations: [


    AccountTabComponent,
    SummaryDescTabComponent,
    MoreDetailsAccountsComponent,
    AccountsComponent,
    AcctRecentTransactionComponent,
    

  ],
  imports: [
    CommonModule,
    SharedModule,
    AccountsRoutingModule,


    [RouterModule.forChild(routes)]
  ],
  exports: [RouterModule,]
})
export class AccountsModule { }
