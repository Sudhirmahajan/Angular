import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { getLang, getUserDetails, setPageName } from 'src/app/auth/auth.index';
import { accountinfo } from '../../onboarding-analytics';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
})
export class AccountsComponent implements OnInit {
lang!:string;
  crn: any;
  constructor(private store:Store, private translate:TranslateService) {
    this.translate.setDefaultLang('en');
    this.getlang1();
   }

  ngOnInit(): void {
    //this.getlang1();
    this.accountDetails();

  }

  public getlang1(){
    this.store.select(getLang).subscribe((lang) => { 
    this.translate.use(lang);
    });
  }
  accountDetails(){
    this.store.dispatch(setPageName({ value: 'accounts' })); 
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
      this.setAnalyticsPageLoad({'crn':this.crn})
     })
  }

  setAnalyticsPageLoad(response:any){
    window.digitalData=accountinfo(response)
    window._satellite?.track("NB-Msiteload");
  }

}
