import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreDetailsAccountsComponent } from './more-details-accounts.component';

describe('MoreDetailsAccountsComponent', () => {
  let component: MoreDetailsAccountsComponent;
  let fixture: ComponentFixture<MoreDetailsAccountsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoreDetailsAccountsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoreDetailsAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
