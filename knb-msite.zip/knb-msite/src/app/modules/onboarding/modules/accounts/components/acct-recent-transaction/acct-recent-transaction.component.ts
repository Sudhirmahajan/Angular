import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { statementEndPoints } from 'src/app/modules/onboarding/onboarding.constant';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { TxnDetailsDialogBoxComponent } from 'src/app/modules/shared/utils/txn-details-dialog-box/txn-details-dialog-box.component';
import { IAccountsData } from '../../model/account.model';

@Component({
  selector: 'app-acct-recent-transaction',
  templateUrl: './acct-recent-transaction.component.html',
  styleUrls: ['./acct-recent-transaction.component.scss']
})
export class AcctRecentTransactionComponent implements OnInit {


  items = 5;
  public loader = true;
  showMyContainerA: any = {};
  seemore:string="dashboard.common.see-more";
  pluse:string="+ ";
  public i!: number;
  currencyCode: string = '';
  public showLoader = true;
  transactionDetails: any[] = [];
  @Input() selectedAccountNumber: IAccountsData = {
    acctNo: '',
    currencyCode: ''
  };

  @Input() flow ="";

  constructor(public dialog: MatDialog, private onboardingService: OnboardingService,) { }

  ngOnChanges(changes: SimpleChanges): void {
    if(changes['selectedAccountNumber']){
    this.getLastTrans()
    }
  }

  ngOnInit(): void {

  }




  public getLastTrans() {
    this.showLoader = true;
    this.loader=true;
    this.currencyCode = this.selectedAccountNumber.currencyCode
    const payload = {
      acId:this.selectedAccountNumber.acctNo,
      fromDate: '',
      toDate: '',
      startChequeNo: '',
      endChequeNo: '',
      maxTxnamount: '',
      minTxnamount: '',
      numberOfTxn: '',
      txnType: '',
      sortingOrder: 'D',
      description: '',
      source:"LHS_STMT_ACC_STMT"
    };
    this.onboardingService.handleStatement(payload, statementEndPoints.statement)
      .subscribe({next: (response) => {
        this.loader=false;
        this.transactionDetails = response.transactionDetails || [];
        this.currencyCode = response.currencyCode || '';
      }, error: () => {
        this.transactionDetails = [];
      }});
  }




  showTxnDetails(txn: any) {
    const dialogRef = this.dialog.open(TxnDetailsDialogBoxComponent, {
      width: '85vw',
      panelClass: 'custom-dialog-container',
      backdropClass: 'backdropBackground',
      data: {
        header: 'Transaction Details',
        RefNo: txn.txnId,
        txnType: txn.txnType,
        txnDesc: txn.txnDesc,
        amt: txn.txnAmountValue,
        date: txn.txnDate,
        currencyCode: this.currencyCode
      },
      
    });

    dialogRef.afterClosed().subscribe(result => {
    });

  }

  public seeMore(i:number)
{
  this.showMyContainerA[i]=!this.showMyContainerA[i];
  if(this.showMyContainerA[i]){
   
    this.seemore='dashboard.account-summary.see-less'
    this.pluse="- "
  }
  else{
    this.seemore="dashboard.common.see-more";
    this.pluse="+ "
  }

}
}


