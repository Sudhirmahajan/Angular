import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getAcctSummary, NavigationService } from 'src/app/auth/auth.index';

@Component({
  selector: 'app-more-details-accounts',
  templateUrl: './more-details-accounts.component.html',
  styleUrls: ['./more-details-accounts.component.scss']
})
export class MoreDetailsAccountsComponent implements OnInit {
  accountDropdownBalance:any
  summaryInside:any
  public effectiveDrawBal!: number;
public loader:boolean=false;
  constructor(private store: Store,private navigation: NavigationService) { }

  ngOnInit(): void {
    this.moreDetail()
  }

  moreDetail(){
    this.loader=false;
    this.store.select(getAcctSummary).subscribe({
   
      next: (resp: any) => {
        this.loader=true;
        this.accountDropdownBalance=resp;
        this.accountDropdownBalance=resp.accountDropdownBalance;
        this.summaryInside=resp.summaryInside;
        if (this.summaryInside['drwpwrBal'] != null && this.summaryInside['drwpwrBal'] != undefined && this.summaryInside['utlamtBal'] != null && this.summaryInside['utlamtBal'] != undefined) {
          this.effectiveDrawBal = this.summaryInside['drwpwrBal'] - this.summaryInside['utlamtBal'];
        } else {
          this.effectiveDrawBal = 0;
        }

      }

    })
  }
  goBack() {
    this.navigation.goBack();
  }
}


