import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcctRecentTransactionComponent } from './acct-recent-transaction.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatDialogModule, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateModule } from '@ngx-translate/core';
import { throwError } from 'rxjs';
import { ConfigService } from 'src/app/auth/auth.index';
import { AuthModule } from 'src/app/auth/auth.module';
import { IDialogData } from 'src/app/modules/onboarding/model/onboarding.model';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { RecentTransactionComponent } from 'src/app/modules/shared/components/recent-transaction/recent-transaction.component';

describe('AcctRecentTransactionComponent', () => {
  let component: AcctRecentTransactionComponent;
  let fixture: ComponentFixture<AcctRecentTransactionComponent>;
  let service: jasmine.SpyObj<OnboardingService>;
  let configService: jasmine.SpyObj<ConfigService>;
  const MockConfigService = jasmine.createSpyObj('ConfigService', ['getAccountEndPointsWithDomain']);
 
  const model: IDialogData = {
    dialogHeader: 'Delete',
    dialogInfo: 'Are you sure?',
  };


  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecentTransactionComponent ],
      imports:[MatDialogModule,
        AuthModule.forRoot('env'),
        BrowserAnimationsModule,
        HttpClientTestingModule,
        TranslateModule.forRoot()],      
       providers: [
        {
          provide: MAT_DIALOG_DATA,
          useValue: model
        },
        { provide: ConfigService, useValue: MockConfigService },

      ]
})
.compileComponents();
});

  beforeEach(() => {
    fixture = TestBed.createComponent(AcctRecentTransactionComponent);
    service = TestBed.inject(OnboardingService) as jasmine.SpyObj<OnboardingService>;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get Last Trans', () => {

    spyOn(service, 'handleAccount').and.returnValue(throwError({}));
    component.getLastTrans();
    expect(service.handleAccount).toHaveBeenCalled();
  });

  
  it('should show Txn Details', () => {

    const ItransList=  {
      tranId: 'txn1234',
      txnDate: '23152001',
      rcreTime: '23152001',
      amount: '9999',
      codDrCr: 'cod',
      txnType: 'debit',
      txnDesc: 'success',
      valueDate: '23301998'
    }
    
    component.showTxnDetails(ItransList);
    expect(component as any ['dialogRef']).toBeTrue

  });


  
  it('should ng On Changes', () => {
    const data={
       
      'selectedAccountNumber': {
                  previousValue: '',
                  currentValue: '',
                  firstChange: true,
                  isFirstChange:() => true,
      }

      }
      component.ngOnChanges(data)
      expect(component.getLastTrans).toBeTrue
      });

      
      it('should see More ', () => {
       
        component.showMyContainerA[1]=false
        component.seeMore(1)
        expect(component.showMyContainerA[1]).toBeTrue
        });   
   


      it('should see More Else Part', () => {
       
          component.showMyContainerA[1]=true
          component.seeMore(1)
          expect(component.showMyContainerA[1]).toBeFalse
   
          });   
     
});
