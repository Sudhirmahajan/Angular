import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BioCatchService, getUserDetails, setAccSummary } from 'src/app/auth/auth.index';
import { accounttabclick } from 'src/app/modules/onboarding/onboarding-analytics';
import { accountEndPoints, ROUTE_KEY } from 'src/app/modules/onboarding/onboarding.constant';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { environment } from 'src/environments/environment';
import { IAccountsData, IAccountSummary } from '../../model/account.model';

@Component({
  selector: 'app-summary-desc-tab',
  templateUrl: './summary-desc-tab.component.html',
  styleUrls: ['./summary-desc-tab.component.scss']
})
export class SummaryDescTabComponent implements OnInit, OnChanges {

  public loader = true;
  show = false;
  checked = false;
  public summaryInside: any;

  @Input() selectedAccountNumber: IAccountsData = {
    acctNo: '',
    currencyCode: ''
  };
  public isFundAvailable = true;
  public monthlyBalanceData: any[] = [];
  public quaterlyBalanceData: any[] = [];
  public summaryError: any = {};
  public accountId: string = '';
  public ambDetail = [];
  public isNomineeAdd = false;
  public isPrimaryAcctFlag = false;
  public isPrimaryDisable = false;
  public accountListLength!: number;
  public isPrimary!: boolean;
  public drwpwrBal!: number;
  public sanlimBal!: number;
  public withdrawnBal!: any;
  public effectiveDrawBal!: number;
  public isaddressAdd = false;
  public aqbDetail = [];
  public summaryBalExpandFlag = false;
  public isSummaryError = false;
  public dataError = false;
  public accountDropdownBalance: any;
  public storeObject: any;
  public ambCurrentBalance!: number;
  seemore: string = "dashboard.common.see-more";
  pluse: string = "+ ";
  crn: any;

  constructor(private service: OnboardingService, private store: Store,    private bioCatchService: BioCatchService,
    private router: Router) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedAccountNumber']) {
      this.summaryDetail();
      this.summaryBalExpand();
    }
  }








  ngOnInit(): void {
   // this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_ACCOUNT_SUMMARY);
    this.accountDetails();
  }

  
  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  setAnalytics(tabname:any,ctaname:any){
    const value={'tabname':tabname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=accounttabclick(value)
    window._satellite?.track("NB-Msiteclick");
   }



  summaryDetail() {
    this.loader = true;

    this.dataError = false;
    this.summaryError = '';

    this.monthlyBalanceData = [];
    this.quaterlyBalanceData = [];
    this.ambDetail = [];
    this.service.handleAccount({ accountId: this.selectedAccountNumber.acctNo },
      accountEndPoints.accountSummary).subscribe({
        next:(resp:IAccountSummary)=>{
        this.summaryInside = resp;
        this.loader = false;

        if (!this.summaryInside['error']) {
          if (!this.summaryInside['jointHolderNames']) {
            this.summaryInside['holderCount'] = 'single';
          } else {
            this.summaryInside['holderCount'] = 'multi';
            let spiltHolder = [];
            if (this.summaryInside['jointHolderNames'].indexOf(',') !== -1) {
              spiltHolder = [this.summaryInside['jointHolderNames'].split(',')];
            } else {
              spiltHolder.push(this.summaryInside['jointHolderNames']);
            }
            spiltHolder.unshift(this.summaryInside['acctName']);
            this.summaryInside['arrayHolder'] = spiltHolder;
            this.summaryInside['count'] = spiltHolder.length - 1;
          }
          if (!this.summaryInside['acctBranch']) {
            this.isaddressAdd = true;
          }
          if (!this.summaryInside['nominee']) {
            this.isNomineeAdd = true;
          }
          if (this.summaryInside['drwpwrBal'] != null && this.summaryInside['drwpwrBal'] != undefined && this.summaryInside['utlamtBal'] != null && this.summaryInside['utlamtBal'] != undefined) {
            this.effectiveDrawBal = this.summaryInside['drwpwrBal'] - this.summaryInside['utlamtBal'];
          } else {
            this.effectiveDrawBal = 0;
          }
          this.drwpwrBal = this.summaryInside['drwpwrBal'];
          this.sanlimBal = this.summaryInside['sanlimBal'];
          this.setPrimaryAcct(this.summaryInside['primaryAccFlag']);
          this.ambDetail = this.summaryInside['aqbAmbResponseDetails']['ambDetailsList'];
          this.ambCurrentBalance = this.summaryInside['aqbAmbResponseDetails']['ambCurrentBalance'];

      
        }
        if (this.summaryInside['error']) {
          this.dataError = true;
          this.summaryError = this.summaryInside['error'].errorCode + ' : ' + this.summaryInside['error'].errorMessage;
        }
      }, error: () => {
        this.summaryInside = {};
        this.dataError = true;
        this.loader = false;
        this.summaryError = 'Something went wrong';
        
  }});
  }



 

  public setPrimaryAcct(flag: string) {
    const val = flag;
    if (flag || flag === 'n' || flag === 'N') {
      this.isPrimaryAcctFlag = false;
      this.isPrimaryDisable = false;
    } else if (flag || flag === 'y' || flag === 'Y') {
      this.isPrimaryAcctFlag = true;
      this.isPrimaryDisable = true;
    }
  }

  summaryBalExpand() {

    const accountId = this.selectedAccountNumber.acctNo;
    this.service.handleAccount({ accountId },
      accountEndPoints.accountBalDtls)
      .subscribe({
        next:(resp:any)=>{


        if (!resp['error']) {
          this.isSummaryError = false;
          this.accountDropdownBalance = resp;
          this.withdrawnBal = this.accountDropdownBalance.withdrawn;
          this.summaryBalExpandFlag = !this.summaryBalExpandFlag;
        } else {
          this.summaryBalExpandFlag = !this.summaryBalExpandFlag;
          this.isSummaryError = true;
        }





      }, error: () => {
        this.summaryBalExpandFlag = !this.summaryBalExpandFlag;
        this.isSummaryError = true;
      }
     } );



  }

  public setPrimaryAccount() {
    const payload = {
      primaryAcc: this.selectedAccountNumber.acctNo
    };
    this.service.handleAccount(payload, accountEndPoints.primaryAccountCard)
    .subscribe({
      next:(resp:any)=>{
        this.isPrimaryAcctFlag = true;

      },
      error: () => {
   } });
  }

  routeToLink() {
    this.storeObject = { summaryInside: this.summaryInside, accountDropdownBalance: this.accountDropdownBalance }

    this.router.navigateByUrl(ROUTE_KEY['ACCSUMMARY'], { skipLocationChange: environment.skipURI });
    this.store.dispatch(setAccSummary({ value: this.storeObject }));
  }

  public seeMore() {
    this.show = !this.show
    if (this.show) {
      this.setAnalytics('summary','see more');
      this.seemore = 'dashboard.account-summary.see-less'
      this.pluse = "- "
    }
    else {
      this.setAnalytics('summary','see less');
      this.seemore = "dashboard.common.see-more";
      this.pluse = "+ "
    }

  }

}