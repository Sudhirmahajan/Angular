import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountTabComponent } from './components/account-tab/account-tab.component';
import { AccountsComponent } from './accounts.component';
import { MoreDetailsAccountsComponent } from './components/more-details-accounts/more-details-accounts.component';

const routes: Routes = [
  {
  path: '',
      component: AccountsComponent,
        children: [   
          {
            path: 'accounttab',
            component: AccountTabComponent,
          },  
          {
            path: 'moredetails',
            component: MoreDetailsAccountsComponent,
          },
        ]

      }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountsRoutingModule { }
