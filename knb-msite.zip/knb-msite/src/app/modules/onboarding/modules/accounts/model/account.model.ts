export interface overviewAccountList {
    accType: string,
    accountNo: string,
    acctCrncyCode:string,
    custName: string,
    primaryAccFlag?: string,
    uniqAccId: string,
}

export interface IAccountsData {
    acctNo: string;
    currencyCode: string;
}

export interface ILasttransList {
    transactionDtls: ItransList[];
}

export interface ItransList {
    tranId: string;
    txnDate: string;
    rcreTime: string;
    amount: string;
    codDrCr: string;
    txnType: string;
    txnDesc: string;
    valueDate: string;

}

export interface RecenttransList {
    amount: string;
	benef_name: string;
    benef_record_id: string;
    currency: string;
    fav_txn: string;
    from_acct: string;
    from_crn: string;
    narration: string;
    reference_no: string;
    to_account_type: string;
    to_acct: string;
    to_bank_name: string;
    to_ifsc_code: string;
    transaction_id: string;
    txType: string;
    txn_date: string;
    txn_type: string;

}

export const transactionType = {
    ACCOUNT: 'ACC',
    CREDITCARD: 'CC'
};

export interface IAccountListViewStatus {
    accType: string;
    custName: string;
    acctCrncyCode: string;
    isDeLinked: string;
    accountNo: string;
    custReltnCode: string;
    uniqAccId: string;
    acctOpnDate: string;
    account811: string;
    acctName: string;
    primaryAccFlag?: string;
    jointHolders?: string;
    holderCount?: string;
    arrayHolder?: any;
    count?: number;
    balance?: string;
    withdrawableBalance?: string;
    unClearedBalance?: string;
    clrBalance?: string | number;
    errorCode?: string | number;
}

export interface IAccountSummary {
    accountId: string;
    accountCurncy: string;
    addressOne: string;
    addressTwo: string;
    addressThree: string;
    addressType: string;
    state: string;
    postalCode: string;
    vpa: string;
    country: string;
    city: string;
    branchId: string;
    branchName: string;
    bankId: string;
    name: string;
    amountValue: string;
    cuurancyCode: string;
    balanceType: string;
    acctOpnDate: string;
    custName: string;
    showWcrmFlag: string;
}
export interface IAccountPopup {
    balance: Ibalance[];
    poolInd: string;
    fdInd: string;
    overDraftLimitInd: string;
    lienInd: string;
    withdrawn: string;
    withdrawnBalInd: string;
}
export interface Ibalance {
    BalType: string;
    BalAmt: {
        amountValue: string;
        currencyCode: string;
    };
}