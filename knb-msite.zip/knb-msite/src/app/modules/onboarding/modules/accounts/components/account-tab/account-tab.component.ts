import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { BioCatchService, getFlow, getUniqAcctId, getUserDetails, setFlow } from 'src/app/auth/auth.index';
import { accounttabclick } from 'src/app/modules/onboarding/onboarding-analytics';
import { accountEndPoints } from 'src/app/modules/onboarding/onboarding.constant';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { IAccountListViewStatus, IAccountsData, ItransList, overviewAccountList } from '../../model/account.model';

@Component({
  selector: 'app-account-tab',
  templateUrl: './account-tab.component.html',
  styleUrls: ['./account-tab.component.scss'],
})
export class AccountTabComponent implements OnInit, OnDestroy {

  public internalErr = false;
  public isNoTrans!: boolean;
  private lasttransaactionType!: string;
  transactionAccountType!: string;
  public accountListerrRes = false;
  public isTrasError = false;
  public transResError: string = '';
  public showLoader = true;
  transactionDetails: ItransList[] = [];
  public transCount!: number;
  currencyCode: string = 'INR';
  items = 5;
  storeFlow!: string;
  public savingList = [];
  public savingListCount = 0;
  public selectedLevel!: string;
  public selectedLevelStore!: string;
  public accountData!: IAccountListViewStatus;
  public primarySelected!: string;
  public selectedAccId!: string;
  selectedAccountNumber: any;
  public selectedAccountData!: IAccountsData;
  public loader: boolean = true;
  accountForm!: FormGroup;
  public header: string = ''
  public accountListResp: overviewAccountList[] = [];
  crn: any;
  activeTabValue: any;
  public customerSegmentCd!: string;
 
 public RA: boolean = true;
  public CC: boolean = true;
  public TD: boolean = true
  constructor(private onboardingService: OnboardingService, private router: Router, private bioCatchService: BioCatchService,
    private widgetService: WidgetService, private store: Store,) {

  }
  ngOnDestroy(): void {
    this.store.dispatch(setFlow({ value: "" }));
  }

  ngOnInit(): void {
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_ACCOUNT_PG);
    this.accountDetails();
    this.accountList();
    this.initialize('');
    this.store.select(getFlow).subscribe((resp) => { this.storeFlow = resp; });
    this.store.select(getUniqAcctId).subscribe((resp) => { this.selectedLevelStore = resp; });



  }

  accountDetails(){
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn = user['crn'];
      this.customerSegmentCd = user['customerSegmentCd'];;
      if (this.customerSegmentCd == 'TD') {
        this.TD = false;
      }
      if (this.customerSegmentCd == 'RA') {
        this.RA = false;
      }
      if (this.customerSegmentCd == 'CC') {
        this.CC = false;
      }
    })
  }

  setAnalytics(tabname:any,ctaname:any){
    const value={'tabname':tabname,'ctaname':ctaname,'crn':this.crn}
    window.digitalData=accounttabclick(value)
    window._satellite?.track("NB-Msiteclick");
   }
 
   activateTab(event: any) {
    this.activeTabValue = <string>event.index;
    if(this.activeTabValue == '0') {
      this.setAnalytics('summary','summary');
    } else if (this.activeTabValue == '1') {
      this.setAnalytics('recent transactions','recent transactions');

    } else {

    }
  }

  // /////////////       NOTE              ///////
  // Data Commin in response accountList() hardcoded menuCode payload
  //  instead of navigation.extras like in knb2-ui 


  initialize(uniqAccId: string) {
    this.accountForm = new FormGroup({
      uniqAccId: new FormControl(uniqAccId),
    });
  };




  public accountList() {
    this.loader = true;
    this.onboardingService.handleAccount({ menuCode: "ALLACC" }, accountEndPoints.allAccounts)
      .subscribe({
        next: (resp: overviewAccountList[]) => {
          this.accountListResp = resp;
          this.loader = false;

          if (this.storeFlow == 'ACCOUNT_WIDGET') {

            this.accountListResp.forEach((resp) => {
              if (this.selectedLevelStore === resp.uniqAccId) {
                this.selectedLevelStore = resp.uniqAccId
                this.widgetService.setAccountCurrencyCode(resp.acctCrncyCode);
                this.currencyCode = resp.acctCrncyCode;
                this.header = resp.accType;
              }
            });
            const payload = {
              acctNo: this.selectedLevelStore,
              currencyCode: this.currencyCode
            };
            this.selectedAccountData = payload;
            this.initialize(this.selectedLevelStore);
          }

          else if (this.accountListResp[0] && this.accountListResp[0].accountNo) {
            this.selectedLevel = this.accountListResp[0].uniqAccId;
            this.widgetService.setAccountCurrencyCode(this.accountListResp[0].acctCrncyCode);
            this.primarySelected = this.accountListResp[0].uniqAccId;
            this.currencyCode = this.accountListResp[0].acctCrncyCode;
            resp.forEach((element) => {
              if (element.primaryAccFlag === 'Y') {
                this.primarySelected = element.uniqAccId;
                this.selectedLevel = element.uniqAccId;
                this.widgetService.setAccountCurrencyCode(element.acctCrncyCode);

              }

            });
            const payload = {
              acctNo: this.selectedLevel,
              currencyCode: this.currencyCode

            };
            this.selectedAccountData = payload;
            this.initialize(this.selectedLevel);
          this.selected()

          }




          

        }, error: () => {
          this.loader = false;
        }

      });

  }


  public selected() {
    this.store.dispatch(setFlow({ value: "" }));
    this.accountListResp.forEach((resp) => {


      if (this.accountForm.value.uniqAccId === resp.uniqAccId) {
        this.widgetService.setAccountCurrencyCode(resp.acctCrncyCode);
        this.currencyCode = resp.acctCrncyCode;
        this.header = resp.accType;
      }
    });
    const payload = {
      acctNo: this.accountForm.value.uniqAccId,
      currencyCode: this.currencyCode
    };
    this.selectedAccountData = payload;

  }








}
