import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditBenificiaryResendOtpComponent } from './edit-benificiary-resend-otp.component';

describe('EditBenificiaryResendOtpComponent', () => {
  let component: EditBenificiaryResendOtpComponent;
  let fixture: ComponentFixture<EditBenificiaryResendOtpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditBenificiaryResendOtpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditBenificiaryResendOtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
