import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { FundTransferService } from '../../services/fundTransfer.service';

import { AccountSelectionScreenComponent } from './account-selection-screen.component';

describe('AccountSelectionScreenComponent', () => {
  let component: AccountSelectionScreenComponent;
  let fixture: ComponentFixture<AccountSelectionScreenComponent>;
  const MockfundTransferService = jasmine.createSpyObj('FundTransferService',['handlePayment']);
 
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports :[ 
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        FormsModule],
      declarations: [ AccountSelectionScreenComponent ],
      providers :[
        { provide : FundTransferService, useValue :MockfundTransferService}
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountSelectionScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call close btn',()=>{
    component.close();
  });
  it('should call getRemitterAcctType check for NULL',()=>{
    let acctType : String = '';
    component.getRemitterAcctType(acctType);
    const returnVal = component.getRemitterAcctType(acctType);
    expect(returnVal).toBe(null);
  });
  it('should call getRemitterAcctType check for SBA',()=>{
      let acctType : String = 'SBA';
      component.getRemitterAcctType(acctType);
      const returnVal = component.getRemitterAcctType(acctType);
       expect(returnVal).toBe('Savings');
       
  });
  it('should call getRemitterAcctType check for CAA',()=>{
    let acctType : String = 'CAA';
    const returnVal = component.getRemitterAcctType(acctType);
    component.getRemitterAcctType(acctType);
    expect(returnVal).toBe('Current');
    
  })
  it('should call getRemitterAcctType check for ODA',()=>{
    let acctType : String = 'ODA';
    component.getRemitterAcctType(acctType);
    const returnVal = component.getRemitterAcctType(acctType);
    expect(returnVal).toBe('Overdraft');
  })

  

});
