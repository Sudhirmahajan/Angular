import { _isNumberValue } from '@angular/cdk/coercion';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CountdownComponent, CountdownEvent } from 'ngx-countdown';
import { Subscription } from 'rxjs';
import { getBeneficiaryDetails, getBeneSuccessRes, getFlow, getIsdCode, getMobileNumber, getOtpPayload, NavigationService, setFooterFlag } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ivrCallReqInfo, paymentApiEndPoint, ROUTE_KEY } from '../../fundTransfer.constant';
import { FundTransferService } from '../../services/fundTransfer.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-add-beneficiary-otp',
  templateUrl: './add-beneficiary-otp.component.html',
  styleUrls: ['./add-beneficiary-otp.component.scss']
})
export class AddBeneficiaryOtpComponent implements OnInit, OnDestroy {
  beneDetails: any;
  beneSuccessResponse: any;
  otpPayload: any;
  @ViewChild('backgroundCounter') backgroundCounter !: CountdownComponent;
  @ViewChild('actualCounter') actualCounter !: CountdownComponent;
  @ViewChild('onSmsOtp') onSmsOtp!: ElementRef;
  mobileOtp!: string;
  serviceIdFromStore!: string;
  storeFlow!: string;
  maskedMobileNumber!: string;
  maskedEmail!: string;
  isdCodeFromStore!: string;
  public resendOTP: boolean = false;
  public backgroundTimer = 30;
  public showTimer = false;
  public callOptionEnable = true;
  public remainingTimeForActualCounter!: number;
  public showOtpExpiryMessage: boolean = false;
  public showHideIcon = 'Show';
  public remainingAttemts!: number;
  public buttonName: string = "Confirm";
  public backButtonName: string = "Back";


  requestInProgress!: boolean;
  displayMfa!: boolean;
  displayDowntime!: boolean;
  errorCode: any;
  httpSubscription!: Subscription;
  authenticationFlagStatus: any;
  askAtLoginFlag!: boolean;
  checkTwoFaOption!: boolean;
  wrongOTP!: boolean;
  thirdAttemptWrongOTP!: boolean;
  otpForm!: FormGroup;
  wrongOTPmsg!: String;
  maxOTPattempt: boolean = false;
  isSkip:boolean=false;

  flowFlag!: string;
  constructor(
    private fundTransferService: FundTransferService,
    private store: Store,
    private router: Router,
    private formBuilder: FormBuilder,
    private navigation: NavigationService,
    private _snackBar: MatSnackBar,

  ) { }
  ngOnDestroy(): void {

  }

  ngOnInit(): void {

    this.store.select(getOtpPayload).subscribe({
      next: (resp: any) => {
        this.otpPayload = resp;

      }

    })
    this.store.select(getFlow).subscribe(value => this.flowFlag = value);
if(this.flowFlag=='DEMOGRAPHIC_CHANGE'){
this.isSkip=true;
}

    this.store.dispatch(setFooterFlag({ value: false }));
    this.store.select(getMobileNumber).subscribe(value => this.maskedMobileNumber = value)
    this.store.select(getIsdCode).subscribe(value => this.isdCodeFromStore = value)
    this.getDataFromStore();
    this.otpForm = this.formBuilder.group({
      txt1: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt2: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt3: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt4: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt5: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt6: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
    });
  }



  clickEvent(e: any, prv: any, curr: any, nxt: any) {
    if (_isNumberValue(curr.value)) {
      let len = curr.value.length;
      let maxlen = curr.getAttribute('maxlength');
      if (len == maxlen) {
        if (nxt != '') {
          nxt.focus();
        }

      }
    }
    if (e.key == 'Backspace') {
      if (prv != '') {
        prv.focus();
      }
    }
  }


  callBackFromChild(event: any) {
    this.resendOTP = false;
  }

  resendOTPFn() {
    let payload = {
      reqInfo: ivrCallReqInfo,
    
      benef_record_id: this.otpPayload.benef_record_id,
    }
    this.fundTransferService.handlePayment(payload, paymentApiEndPoint.beneivr).subscribe({
      next: (res: any) => {
        this._snackBar.open('You will receive a OTP via call', 'close', {
          duration: 5000
        })
      }, error: (err) => {
        this._snackBar.open('We are not able to send OTP', 'close', {
          duration: 5000
        })

      }
    });
  }
  goBack() {
    this.navigation.goBack();
  }

  activateBene() {
    this.mobileOtp = this.otpForm.controls['txt1'].value + this.otpForm.controls['txt2'].value + this.otpForm.controls['txt3'].value + this.otpForm.controls['txt4'].value + this.otpForm.controls['txt5'].value + this.otpForm.controls['txt6'].value;
    if (true) {
      let date = new Date();
      let timestamp = Math.round(date.getTime())


      let payload = {
        reqInfo: {
          p_req_id: "NET_NET_" + timestamp,
          p_req_date_time: timestamp,
          p_mode: "NET",
          p_user: "NET",
          p_application_id: "NET",
          p_sub_user :  'MSITE'

        },
        benef_nick_name: this.otpPayload.benef_nick_name,
        benef_record_id: this.otpPayload.benef_record_id,
        activation_key: CryptoJS.AES.encrypt(this.mobileOtp, environment.getAllActPublicKey).toString(),
      }

      this.fundTransferService.handlePayment(payload, paymentApiEndPoint.activatebenesms).subscribe({
        next: (res: any) => {
          if (res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {
          if(this.flowFlag=='DEMOGRAPHIC_CHANGE'){
            this.router.navigateByUrl(ROUTE_KEY['SUCCESS'], { skipLocationChange: environment.skipURI });

        
          }
          else{
           
            this.router.navigateByUrl(ROUTE_KEY['TRANSFERDETAILS'], { skipLocationChange: environment.skipURI });
          }
        }
          else {
            if (res['statusop']['p_error_flag'] == 'Y' && res['statusop']['p_error_code'] == 'AIB_018') {
              this.wrongOTPmsg = res['statusop']['p_error_desc']
              this.wrongOTP = true;
              this.callOptionEnable = false;
            }

            if (res['statusop']['p_error_flag'] == 'Y' && res['statusop']['p_error_code'] == 'AIB_019') {
              this.wrongOTPmsg = res['statusop']['p_error_desc']
              this.thirdAttemptWrongOTP = true;


            }
            if (res['statusop']['p_error_flag'] == 'Y' && res['statusop']['p_error_code'] == 'AIB_053') {
              this.wrongOTPmsg = res['statusop']['p_error_desc']
              this.wrongOTP = true;
              this.router.navigateByUrl(ROUTE_KEY['EXCEED_BENE'], { skipLocationChange: environment.skipURI });


            }

          }
        }, error: (err) => {
          this._snackBar.open('We are not able to Verify OTP', 'close', {
            duration: 5000
          })

        }
      })

    }
  }

 

  public defaultOnFinished(event: CountdownEvent) {
    if (event.action == 'done') {
      this.callOptionEnable = false;
      this.resetTimer();
    }
  }

  resetTimer() {
    this.backgroundCounter.restart();
    this.backgroundCounter.stop();
  }



  getDataFromStore() {

    this.store.select(getBeneSuccessRes).subscribe({
      next: (resp: any) => {
        this.beneSuccessResponse = resp;
      }
    })
    this.store.select(getBeneficiaryDetails).subscribe({
      next: (resp: any) => {
        this.beneDetails = resp;
      }
    })
  }

 
  public skip() {

    if (this.flowFlag == 'MANAGE_BENEFICIARY') {
      this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });

    }
    else
      this.router.navigateByUrl(ROUTE_KEY['SUCCESS'], { skipLocationChange: environment.skipURI });
  }

}
