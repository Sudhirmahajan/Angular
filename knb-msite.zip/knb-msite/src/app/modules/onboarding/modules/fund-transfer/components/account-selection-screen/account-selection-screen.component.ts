import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import {FloatLabelType} from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';
import { IAllaccounts } from '../../model/fundTransfer.model';

@Component({
  selector: 'app-account-selection-screen',
  templateUrl: './account-selection-screen.component.html',
  styleUrls: ['./account-selection-screen.component.scss']
})
export class AccountSelectionScreenComponent implements OnInit {

 @Input()  allaccounts!:[{
    schme_type: string,
    account_id: Number,
    effective_bal : string,
    acct_name : string,
    checked : string,
    acct_curr_code:string
  }]  ;

  @Input() pageTitle !: string;

  @Output() updateValue = new EventEmitter<IAllaccounts>();
  @Output() closeActSelection = new EventEmitter<IAllaccounts>();

  backBtnName = "";
  button ="Confirm";
  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl('auto' as FloatLabelType);
  options = this._formBuilder.group({
    hideRequired: this.hideRequiredControl,
    floatLabel: this.floatLabelControl,
  });
  selectedActDtls!: IAllaccounts ;
  disable: boolean=true;
  dormantFlag: boolean = false;
  debitFrezFlag: boolean = false;

  goBack() {
    
  }
  

  constructor(
    private _formBuilder: FormBuilder,
    private snackBar: MatSnackBar) {
    
   }

  ngOnInit(): void {
  }

  acctSelected(acct : any){    
    this.selectedActDtls = acct;
    this.disable=false;
  }
  
  confirm(){
    if(this.selectedActDtls.acct_status == 'D'){
      this.dormantFlag = true;
      this.snackBar.open('Selected account '+ this.selectedActDtls.account_id +' is in Freezed/Dormant/Blocked state. Please select another account.', '', {
        duration: 5000
      })
    } else if (this.selectedActDtls.frez_code == 'C' || this.selectedActDtls.frez_code == 'T'){
      this.debitFrezFlag = true; 
      this.snackBar.open('Selected account '+ this.selectedActDtls.account_id +' is in Freezed/Dormant/Blocked state. Please select another account.', '', {
        duration: 5000
      })
    } else {
      this.updateValue.emit(this.selectedActDtls);
    }

  }
  close(){
   this.closeActSelection.emit(this.selectedActDtls);
  }

  getRemitterAcctType(acctType : String) {
    let remitterAcctType = null;
    if(acctType != null) {
      switch(acctType){
        case 'SBA':
          remitterAcctType = 'Savings';
          break;
        case 'CAA':
          remitterAcctType = 'Current';
          break;
        case 'ODA':
          remitterAcctType = 'Overdraft';
          break;
      }
    }
    return remitterAcctType;
  }


}
