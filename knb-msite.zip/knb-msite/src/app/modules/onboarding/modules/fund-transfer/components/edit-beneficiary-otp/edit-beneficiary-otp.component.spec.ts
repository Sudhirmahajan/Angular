import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditBeneficiaryOtpComponent } from './edit-beneficiary-otp.component';

describe('EditBeneficiaryOtpComponent', () => {
  let component: EditBeneficiaryOtpComponent;
  let fixture: ComponentFixture<EditBeneficiaryOtpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditBeneficiaryOtpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditBeneficiaryOtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
