import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FtOtpLockedComponent } from './ft-otp-locked.component';

describe('FtOtpLockedComponent', () => {
  let component: FtOtpLockedComponent;
  let fixture: ComponentFixture<FtOtpLockedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FtOtpLockedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FtOtpLockedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
