import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBeneficiaryOtpComponent } from './add-beneficiary-otp.component';

describe('AddBeneficiaryOtpComponent', () => {
  let component: AddBeneficiaryOtpComponent;
  let fixture: ComponentFixture<AddBeneficiaryOtpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddBeneficiaryOtpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBeneficiaryOtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
