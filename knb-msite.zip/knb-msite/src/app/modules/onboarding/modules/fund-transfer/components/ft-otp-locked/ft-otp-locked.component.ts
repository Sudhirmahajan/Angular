import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ft-otp-locked',
  templateUrl: './ft-otp-locked.component.html',
  styleUrls: ['./ft-otp-locked.component.scss']
})
export class FtOtpLockedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
