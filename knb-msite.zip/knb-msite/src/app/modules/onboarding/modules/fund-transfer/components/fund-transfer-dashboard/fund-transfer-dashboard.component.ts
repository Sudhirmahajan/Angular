import { Component, OnInit,  } from '@angular/core';
import { Router } from '@angular/router'
import { Store } from '@ngrx/store';
import {  getUserDetails, setAllTransferDtls, setBeneficiaryDetails, setFlow, setOneTimeBene, setPageName, setBeneLimit, NavigationService, setDebitAct, setTransferDetails, BioCatchService } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment.uat';

import { FLOW_CONSTANT, paymentApiEndPoint, paymentReqInfo, ROUTE_KEY } from '../../fundTransfer.constant';
import { FundTransferService } from '../../services/fundTransfer.service'
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { accountEndPoints } from 'src/app/modules/onboarding/onboarding.constant';
import { IAccountListViewStatus, IAccountsData, ItransList, overviewAccountList, transactionType } from '../../../accounts/model/account.model';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { FormControl, FormGroup } from '@angular/forms';
import { IBenDetails, ITransferDtls } from '../../model/fundTransfer.model';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
@Component({
  selector: 'app-fund-transfer-dashboard',
  templateUrl: './fund-transfer-dashboard.component.html',
  styleUrls: ['./fund-transfer-dashboard.component.scss']
})
export class FundTransferDashboardComponent implements OnInit {
  
  emptyObj : any = {
    bankName : '',
      ifsc : '',
      acctNum : '',
      reAcctNo : '',
      acctType : '',
      beneOwn :  '',
      beneName : '',
      beneNick : ''
  } ;

  oneTimeTransferObj : IBenDetails = {
    benef_record_id: '',
    benef_bank_ac_no: '',
    benef_bank_acct_type: '',
    benef_bank_acct_type_code: '',
    benef_bank_name: '',
    benef_bank_ifsc_code: '',
    benef_nick_name: '',
    benef_name: '',
    benef_email: '',
    benef_mobile: '',
    my_acct: '',
    favorite_flag: '',
    active_flag: '',
    schme_code : ''
  }

  txnLimitObj!: [{
    limit_record_id: string;
    txn_limit_amt: string;
    day_limit_amt: string;
    benef_nick_name: string
  }];
  txnLimtRecordId!: string;
  txnPerLimit!: string;
  txnDayPerLimit!: string;
  beneData !: IBenDetails;

  
 transferDtlsObj : ITransferDtls = {
  userDtls : {
    account_id : null,
    acct_name : '',
    schme_type : '',
    effective_bal : '',
    acct_status : '',
    ifsc_code :'',
    frez_code :'',
    acct_curr_code:'',
    schme_code :''

  },
  
  beneDtls : this.oneTimeTransferObj ,
  transferDtls : Object,
  paymentMode : ''
}

 allTransferDtls = {
  userDtls: {
    account_id : null,
    acct_name : '',
    schme_type : '',
    effective_bal : '',
    acct_status : '',
    ifsc_code :'',
    frez_code : '',
    acct_curr_code:'',
    schme_code :''
    
  }, 
    beneDtls: {
      benef_record_id: '',
      benef_bank_ac_no: '',
      benef_bank_acct_type: '',
      benef_bank_acct_type_code: '',
      benef_bank_name: '',
      benef_bank_ifsc_code: '',
      benef_nick_name: '',
      benef_name: '',
      benef_email: '',
      benef_mobile: '',
      my_acct: '',
      favorite_flag: '',
      active_flag: '',
      schme_code :''
     
      },
    transferDtls : {
      amount : '',
      remark : ''
    },
    paymentMode : ''
}

  transferDetails = {}

  public loader: boolean = false;
  public profileloader: boolean = false;
  beneficiaryList: any;
  flowFlag!: string;
  selectedAccountNumber: any;
  public accountData!: IAccountListViewStatus;
  public selectedAccountData!: IAccountsData;
  public accountListResp: overviewAccountList[] = [];
  public selectedLevel!: string;
  public primarySelected!: string;
  currencyCode: string = 'INR';
  accountForm!: FormGroup;
  public header:string=''
  crn: any;

  constructor( 
    private fundTransferService: FundTransferService,
    private onboardingService: OnboardingService,
    private widgetService: WidgetService,
    private navigationService: NavigationService,
    public router: Router,
    private bioCatchService: BioCatchService,
    public store : Store) { }

    //
    getBeneficiaries() {
      this.profileloader = true;
      let payload = {
        reqInfo: paymentReqInfo
      }
      this.beneficiaryList = [];
      let tempBeneficiaryList = [];
      this.fundTransferService.handlePayment(payload, paymentApiEndPoint.allbeneficiaries).subscribe({ next :(res : any)=> {
        this.beneficiaryList = res['benef_list'];
        this.profileloader = false;
        this.beneficiaryList = this.beneficiaryList.filter((bene: any) => {
          return bene.active_flag == 'Y';
      });
      
      // Here we are arrange list in order fvrt -> active -> only 20 (In alphbt order)
      this.beneficiaryList = this.beneficiaryList.sort((a:any,b:any)=> (
        (b.favorite_flag == 'Y' ? Number(true) : Number(false))  - (a.favorite_flag == 'Y' ? Number(true) : Number(false)) || a.benef_name.localeCompare(b.benef_name)));
        // Need to show 20 bene only
        this.beneficiaryList.splice(20);
      }});
    };

   ngOnInit(){
    //this.navigationService.resetNavHistory();
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_FT_DASHBOARD);
    
     
     this.getBeneficiaries();
     this.accountList();
     this.initialize('');
     this.accountDetails();
     
  }

  accountDetails(){
    this.store.dispatch(setPageName({ value: 'payment' })); 
    this.store.select(getUserDetails).subscribe((user: any) => {
      this.crn=user['crn']
     })
  }

  // /////////////       NOTE              ///////
  // Data Commin in response accountList() hardcoded menuCode payload
  //  instead of navigation.extras like in knb2-ui 


  initialize(uniqAccId: string) {
    this.accountForm = new FormGroup({
      uniqAccId: new FormControl(uniqAccId),
    });
  };

  addNewBene() {
    this.store.dispatch(setBeneficiaryDetails({ value: this.emptyObj }));

    this.flowFlag = FLOW_CONSTANT['ADDBENE'];
    this.store.dispatch(setFlow({ value: this.flowFlag }))
    this.store.dispatch(setOneTimeBene({ value: this.oneTimeTransferObj }))
    this.store.dispatch(setAllTransferDtls({ value: this.transferDtlsObj }))
    this.store.dispatch(setAllTransferDtls({ value: this.allTransferDtls }))
    this.store.dispatch(setTransferDetails({ value:  this.transferDetails }))
    
    this.router.navigateByUrl(ROUTE_KEY['ADDBENE'], { skipLocationChange: environment.skipURI });
       
  }
  PMCareFund() {
    this.router.navigateByUrl(ROUTE_KEY['FT_REVIEW'], { skipLocationChange: environment.skipURI });
 
  }
  manageBene(){
    this.flowFlag = FLOW_CONSTANT['MANAGE_BENEFICIARY'];
    this.store.dispatch(setFlow({ value: this.flowFlag }))
    this.store.dispatch(setDebitAct({ value: false }))
    this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });
  }
  oneTimeTransfer(){
    this.flowFlag = FLOW_CONSTANT['ONE_TIME_TRANSFER'];
    this.store.dispatch(setFlow({ value: this.flowFlag }))
    this.store.dispatch(setDebitAct({ value: false }))
    this.store.dispatch(setOneTimeBene({ value: this.oneTimeTransferObj }))
    this.store.dispatch(setAllTransferDtls({ value: this.transferDtlsObj }))
    this.store.dispatch(setAllTransferDtls({ value: this.allTransferDtls }))
    this.store.dispatch(setTransferDetails({ value:  this.transferDetails }))
    this.router.navigateByUrl(ROUTE_KEY['ONE_TIME_TRANSFER'], { skipLocationChange: environment.skipURI });
  }
  sendToBene(){
    this.flowFlag = FLOW_CONSTANT['SEND_TO_BENE'];
    this.store.dispatch(setFlow({ value: this.flowFlag }));
    this.store.dispatch(setDebitAct({ value: false }))
    this.store.dispatch(setOneTimeBene({ value: this.oneTimeTransferObj }))
    this.store.dispatch(setAllTransferDtls({ value: this.transferDtlsObj }))
    this.store.dispatch(setAllTransferDtls({ value: this.allTransferDtls }))
    this.store.dispatch(setTransferDetails({ value:  this.transferDetails }))
    
    this.router.navigateByUrl(ROUTE_KEY['SEND_TO_BENE'], { skipLocationChange: environment.skipURI });
  
  }
  sendToKotak(){
    this.flowFlag = FLOW_CONSTANT['SEND_TO_KOTAK'];
    this.store.dispatch(setFlow({ value: this.flowFlag }))
    this.store.dispatch(setAllTransferDtls({ value: this.allTransferDtls }))
    this.store.dispatch(setDebitAct({ value: false }))
    this.store.dispatch(setTransferDetails({ value:  this.transferDetails }))
    
    this.router.navigateByUrl(ROUTE_KEY['SEND_TO_KOTAK'], { skipLocationChange: environment.skipURI });
    //this.router.navigateByUrl(ROUTE_KEY['FT_SUCESS'], { skipLocationChange: environment.skipURI });
 
  }

  onManageBeneficiaryClick(){
    
  }


  getInitials = function (name: string) {
    var parts = name.trim().split(' ')
    var initials = parts[0][0];
    initials = parts.length > 1 ? (initials + parts[parts.length - 1][0]) : initials;
    return initials
  }

  public accountList() {
    this.loader=true;
        this.onboardingService.handleAccount({ menuCode: "ALLACC" }, accountEndPoints.allAccounts)
          .subscribe({
            next: (resp: overviewAccountList[]) => {
              this.accountListResp = resp;
              this.loader=false;
    
              if (this.accountListResp[0] && this.accountListResp[0].accountNo) {
    
                this.selectedLevel = this.accountListResp[0].uniqAccId;
                this.widgetService.setAccountCurrencyCode(this.accountListResp[0].acctCrncyCode);
                this.primarySelected = this.accountListResp[0].uniqAccId;
                this.currencyCode = this.accountListResp[0].acctCrncyCode;
    
                resp.forEach((element) => {
                  if (element.primaryAccFlag === 'Y') {
                    this.primarySelected = element.uniqAccId;
                    this.selectedLevel = element.uniqAccId;
                    this.widgetService.setAccountCurrencyCode(element.acctCrncyCode);
    
                  }
                
                });
    
    
    
                const payload = {
                  acctNo: this.selectedLevel,
                  currencyCode: this.currencyCode
    
                };
                this.selectedAccountData = payload;
    
    
              }
    
    
    
    
              this.initialize(this.selectedLevel);
              this.selected()
             
            }, error: () => {
              this.loader=false;
            }
    
          });
    
      }

      public selected() {

        this.accountListResp.forEach((resp) => {
          if (this.accountForm.value.uniqAccId === resp.uniqAccId) {
            this.widgetService.setAccountCurrencyCode(resp.acctCrncyCode);
            this.currencyCode = resp.acctCrncyCode;
            this.header=resp.accType;
          }
        });
        const payload = {
          acctNo: this.accountForm.value.uniqAccId,
          currencyCode: this.currencyCode
        };
        this.selectedAccountData = payload;
    
      }

      getBeneLimit(bene: any) {
        let date = new Date();
        let timestamp = Math.round(date.getTime())

        const paymentReqInfo = {
            p_req_id: "NET_NET_"+timestamp,
            p_req_date_time: timestamp,
            p_mode:"NET",
            p_user: "NET",
            p_application_id:"NET"
        }

        let payload = {
          reqInfo: paymentReqInfo,
          "benef_nick_name": bene.benef_nick_name,
          "benef_record_id": bene.benef_record_id,
   
        }
        this.flowFlag = FLOW_CONSTANT['SEND_TO_BENE'];
        this.store.dispatch(setFlow({ value: this.flowFlag }));
        let path = paymentApiEndPoint.getbenficiarylimit.trim();
        this.fundTransferService.handlePayment(payload, path).subscribe({
          next: (res: any) => {
            if (res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {
              this.txnLimitObj = res['beneficiaryLimitRcList'];
              this.txnLimtRecordId = this.txnLimitObj[0].limit_record_id;
              this.txnPerLimit = this.txnLimitObj[0].txn_limit_amt;
              this.txnDayPerLimit = this.txnLimitObj[0].day_limit_amt;
              this.txnDayPerLimit = this.txnLimitObj[0].benef_nick_name;
              this.store.dispatch(setBeneLimit({ value: this.txnLimitObj }))
              this.beneData = {
                benef_bank_ac_no: bene.benef_bank_ac_no,
                benef_name: bene.benef_name,
                benef_nick_name: bene.benef_nick_name,
                benef_bank_name: bene.benef_bank_name,
                benef_bank_ifsc_code: bene.benef_bank_ifsc_code,
                benef_bank_acct_type: bene.benef_bank_acct_type,
                benef_record_id: bene.benef_record_id,
                benef_email: bene.benef_email,
                benef_mobile: bene.benef_mobile,
                benef_bank_acct_type_code: bene.benef_bank_acct_type_code,
                my_acct: bene.my_acct,
                favorite_flag: bene.favorite_flag,
                active_flag: bene.active_flag,
                schme_code :''
              }
              this.transferNow()
              return;
     
   
            } else {
            }
   
          }
        })
   
      };

      transferNow() {
        this.store.dispatch(setOneTimeBene({ value: this.beneData }))
        this.router.navigateByUrl(ROUTE_KEY['TRANSFERDETAILS'], { skipLocationChange: environment.skipURI });
      }
 
}
