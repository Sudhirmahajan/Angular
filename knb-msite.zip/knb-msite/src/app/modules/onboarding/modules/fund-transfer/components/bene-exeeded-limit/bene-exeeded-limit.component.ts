import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY } from '../../fundTransfer.constant';

@Component({
  selector: 'app-bene-exeeded-limit',
  templateUrl: './bene-exeeded-limit.component.html',
  styleUrls: ['./bene-exeeded-limit.component.scss']
})
export class BeneExeededLimitComponent implements OnInit {

  constructor( private router: Router) { }

  ngOnInit(): void {
  }
goToHome(){
  this.router.navigateByUrl(ROUTE_KEY['DASHBOARD'], { skipLocationChange: environment.skipURI });

}

}
