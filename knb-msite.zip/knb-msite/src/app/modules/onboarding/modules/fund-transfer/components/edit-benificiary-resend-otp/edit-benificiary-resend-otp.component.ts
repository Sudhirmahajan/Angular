import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getOtpPayload } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { paymentApiEndPoint, ROUTE_KEY } from '../../fundTransfer.constant';
import { FundTransferService } from '../../services/fundTransfer.service';

@Component({
  selector: 'app-edit-benificiary-resend-otp',
  templateUrl: './edit-benificiary-resend-otp.component.html',
  styleUrls: ['./edit-benificiary-resend-otp.component.scss']
})
export class EditBenificiaryResendOtpComponent implements OnInit {
  showHideIcon!: string;
  public remainingAttemts!: null;
  showOtpExpiryMessage!: boolean;
  otpPayload:any;
  EditBene:any;
  smaPath:string=paymentApiEndPoint.sendotp;
  ivrPath:string=paymentApiEndPoint.ivrotp;
  path!:string;

  @Output() updateValue = new EventEmitter<boolean>();
  constructor(public dialog: MatDialog,
    private fundTransferService: FundTransferService,
    private store: Store,
    public router: Router,

    private loaderService: LoaderService,
    private _snackBar: MatSnackBar,) { }

  ngOnInit(): void {

    this.store.select(getOtpPayload).subscribe(value => this.otpPayload = value)
  }
  public cancelBtn(){
    this.updateValue.emit(true);
  }

  public otpViaCall(mode: string) {
    this.showHideIcon = 'Show' ;
    this.updateValue.emit(true);
    this.remainingAttemts = null;
    this.loaderService.startLoader();
    if(mode==="SMS"){
     this.path=this.smaPath;
    }
    else{
      this.path=this.ivrPath;
    }

    this.fundTransferService.handlePayment(this.otpPayload,  this.path)
    .subscribe({
      next: (res: any) => {
        this.loaderService.stopLoader();

        if ( res['status']['p_error_code'] == '5700' ){
          this.router.navigateByUrl(ROUTE_KEY['OTO_LOCKED_FT'], { skipLocationChange: environment.skipURI });

        }
        
    
      }, error: (err) => {
        this.loaderService.stopLoader();
        this._snackBar.open('We are note able to send OTP', 'close', {
          
          duration: 5000
        })
      }
    })
  
  }
}
