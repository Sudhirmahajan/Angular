import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonSuccessScreenComponent } from './common-success-screen.component';

describe('CommonSuccessScreenComponent', () => {
  let component: CommonSuccessScreenComponent;
  let fixture: ComponentFixture<CommonSuccessScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommonSuccessScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonSuccessScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
