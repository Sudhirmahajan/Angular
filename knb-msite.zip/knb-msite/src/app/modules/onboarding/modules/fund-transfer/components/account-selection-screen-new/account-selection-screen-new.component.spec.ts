import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountSelectionScreenNewComponent } from './account-selection-screen-new.component';

describe('AccountSelectionScreenNewComponent', () => {
  let component: AccountSelectionScreenNewComponent;
  let fixture: ComponentFixture<AccountSelectionScreenNewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountSelectionScreenNewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountSelectionScreenNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
