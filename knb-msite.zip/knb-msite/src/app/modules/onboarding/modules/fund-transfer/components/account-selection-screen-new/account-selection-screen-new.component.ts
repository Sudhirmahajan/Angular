import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import {FloatLabelType} from '@angular/material/form-field';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getAccountArray, setDebitAct, setFooterFlag, setSelectedAct } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY } from '../../fundTransfer.constant';
import { IAllaccounts } from '../../model/fundTransfer.model';

@Component({
  selector: 'app-account-selection-screen-new',
  templateUrl: './account-selection-screen-new.component.html',
  styleUrls: ['./account-selection-screen-new.component.scss']
})
export class AccountSelectionScreenNewComponent implements OnInit {



  pageTitle : string = 'Pay Using';
  backBtnName = "";
  button ="Confirm";
 

  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl('auto' as FloatLabelType);
  options = this._formBuilder.group({
    hideRequired: this.hideRequiredControl,
    floatLabel: this.floatLabelControl,
  });
  selectedActDtls!: IAllaccounts ;
  acctArray: any;
  setDebitActFlow!: boolean;
  dormantFlag: boolean = false;
  debitFrezFlag: boolean = false;
  disable: boolean=true;

  constructor(private _formBuilder: FormBuilder,
    public store : Store,
    public router : Router,
    private snackBar: MatSnackBar    ) {}

  ngOnInit(): void {
    this.store.select(getAccountArray).subscribe({
      next: (resp: any) => {
       this.acctArray = resp;
       }
    })
    this.store.dispatch(setFooterFlag({ value: false }));
  }

  ngOnDestroy(): void {
    this.store.dispatch(setFooterFlag({ value: true }));
  }

  acctSelected(acct : any){    
    this.selectedActDtls = acct;
    this.disable=false;
  }
  confirm(){
    if(this.selectedActDtls.acct_status == 'D'){
      this.dormantFlag = true;
      this.snackBar.open('Selected account '+ this.selectedActDtls.account_id +' is in Freezed/Dormant/Blocked state. Please select another account.', '', {
        duration: 5000
      })
    } else if (this.selectedActDtls.frez_code == 'D' || this.selectedActDtls.frez_code == 'T'){
      this.debitFrezFlag = true; 
      this.snackBar.open('Selected account '+ this.selectedActDtls.account_id +' is in Freezed/Dormant/Blocked state. Please select another account.', '', {
        duration: 5000
      })
    } else {
      this.setDebitActFlow = true;
      this.store.dispatch(setDebitAct({ value: this.setDebitActFlow })) 
      this.store.dispatch(setSelectedAct({ value: this.selectedActDtls }))
      this.router.navigateByUrl(ROUTE_KEY['TRANSFERDETAILS'], { skipLocationChange: environment.skipURI });
 
    }

    
  }
  close(){
    this.router.navigateByUrl(ROUTE_KEY['TRANSFERDETAILS'], { skipLocationChange: environment.skipURI });
 
  }

  getRemitterAcctType(acctType : String) {
    let remitterAcctType = null;
    if(acctType != null) {
      switch(acctType){
        case 'SBA':
          remitterAcctType = 'Savings';
          break;
        case 'CAA':
          remitterAcctType = 'Current';
          break;
        case 'ODA':
          remitterAcctType = 'Overdraft';
          break;
      }
    }
    return remitterAcctType;
  }



}
