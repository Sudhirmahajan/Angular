import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundTransferErrorComponent } from './fund-transfer-error.component';

describe('FundTransferErrorComponent', () => {
  let component: FundTransferErrorComponent;
  let fixture: ComponentFixture<FundTransferErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FundTransferErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundTransferErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
