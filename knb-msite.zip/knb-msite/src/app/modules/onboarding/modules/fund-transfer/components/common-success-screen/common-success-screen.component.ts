import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-success-screen',
  templateUrl: './common-success-screen.component.html',
  styleUrls: ['./common-success-screen.component.scss']
})
export class CommonSuccessScreenComponent implements OnInit {

  
  @Input() successMessage ='';
  @Input() successNote ='';
  @Input() actualBene = {
    beneName : '',
    bankName : '',
    acctNum : '',
    acctType : ''
  };
  imgSrc!: string;
  bankName !: string;
  bankArray: string[] =['icic','yes'] ;


  constructor() { }

  ngOnInit(): void {
    this.bankName = this.actualBene.bankName.replace(/\s/g, "");
    if(this.bankArray.includes(this.bankName,0)) {
      this.imgSrc = 'assets/icons/' + this.bankName +'.png';
     } else {
      this.imgSrc = "assets/icons/kotak-32.png";
     }
  }
}
