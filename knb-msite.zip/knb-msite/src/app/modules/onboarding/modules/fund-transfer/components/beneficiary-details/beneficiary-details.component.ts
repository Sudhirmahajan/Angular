import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getBeneficiaryDetails, NavigationService, setBeneficiaryDetails, setBeneSuccessRes, setFlow } from 'src/app/auth/auth.index';
import { ImgBanksLogoService } from 'src/app/modules/shared/services/img-banks-logo.service';
import { environment } from 'src/environments/environment';
import { FLOW_CONSTANT, paymentApiEndPoint, paymentReqInfo, ROUTE_KEY } from '../../fundTransfer.constant';
import { IBenDetails } from '../../model/fundTransfer.model';
import { FundTransferService } from '../../services/fundTransfer.service';

@Component({
  selector: 'app-beneficiary-details',
  templateUrl: './beneficiary-details.component.html',
  styleUrls: ['./beneficiary-details.component.scss']
})
export class BeneficiaryDetailsComponent implements OnInit {
  beneficiaryDetails!: IBenDetails;
  favorite_flag !:string;
  txnLimitObj!: [{
    limit_record_id: string;
    txn_limit_amt: string;
    day_limit_amt: string
  }];
  txnLimtRecordId!: string;
  txnPerLimit!: string;
  txnDayPerLimit!: string;
  bankIcon!: string;
  txnType:any;
  isIMPS:boolean=true;
  isNEFT:boolean=true;
  isRTGS:boolean=true
  ownAcct!:boolean

  constructor(
    private store: Store,
    private fundTransferService: FundTransferService,
    private navigationService: NavigationService,
    private imgBanksLogoService: ImgBanksLogoService,
    private _snackBar: MatSnackBar,
    private router : Router,
  ) { }

  ngOnInit(): void {
    this.getBeneStore();
    this.getBeneLimit();
    this.getBeneTrfType();
  }

getBeneStore(){
  this.store.select(getBeneficiaryDetails).subscribe({ next: (response: IBenDetails) => {
    this.beneficiaryDetails = response;
   
    this.ownAcct=this.beneficiaryDetails.my_acct=='Y'?true : false;
    this.favorite_flag =this.beneficiaryDetails.favorite_flag 
    this.bankIcon = this.imgBanksLogoService.imgLoad(response.benef_bank_name);
  
  }})
}

  getBeneLimit(){
    let payload = {
      reqInfo: paymentReqInfo,
      "benef_nick_name": this.beneficiaryDetails.benef_nick_name,
      "benef_record_id": this.beneficiaryDetails.benef_record_id
     
    }
    let path = paymentApiEndPoint.getbenficiarylimit.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({ next: (res: any)=> {
      if(res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {
        this.txnLimitObj = res['beneficiaryLimitRcList'];
        this.txnLimtRecordId = this.txnLimitObj[0].limit_record_id;
        this.txnPerLimit = this.txnLimitObj[0].txn_limit_amt;
        this.txnDayPerLimit = this.txnLimitObj[0].day_limit_amt;
        return;

      } else {
      }

    }})   

  };

  markBeneFav(benData: any) {
    let payload = {
      reqInfo: paymentReqInfo,
      "beneRecId": Number(benData.benef_record_id)
     
    }
    let path = paymentApiEndPoint.markfavbene.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({ next: (res: any)=> {
      if(res["p_error_flag"] == 'N' && res['p_error_desc'] == 'SUCCESS') {
       this.favorite_flag="Y";
  
        
        this._snackBar.open('Beneficiary marked as favorite successfully', '', {
          duration: 5000
        })
      } else {
        this._snackBar.open('Unable to mark beneficiary as favorite', '', {
          duration: 5000
        })
      }
    }})    
  };

  unmarkBeneFav(benData: any) {
    let payload = {
      reqInfo: paymentReqInfo,
      "beneRecId": Number(benData.benef_record_id)
     
    }
    let path = paymentApiEndPoint.removefavbene.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({ next: (res: any)=> {
      if(res["p_error_flag"] == 'N' && res['p_error_desc'] == 'SUCCESS') {
        this.favorite_flag="N";
 
        
        this._snackBar.open('Beneficiary unmarked as favorite successfully', '', {
          duration: 5000
        })
      } else {
        this._snackBar.open('Unable to unmark beneficiary', '', {
          duration: 5000
        })
      }
    }})
  };

 


editBene(){
  this.store.dispatch(setBeneficiaryDetails({ value: this.beneficiaryDetails}));
  this.router.navigateByUrl(ROUTE_KEY['EDIT_BENEFICIARY'], { skipLocationChange: environment.skipURI });
}


  sendMoney() {
  
    this.store.dispatch(setFlow({ value: FLOW_CONSTANT['SEND_TO_BENE'] }));
    this.store.dispatch(setBeneficiaryDetails({ value: this.beneficiaryDetails }))
    this.router.navigateByUrl(ROUTE_KEY['TRANSFERDETAILS'], { skipLocationChange: environment.skipURI });

  }

  goBack() {
    this.navigationService.goBack();
  }

  getBeneTrfType(){
    let payload = {
      reqInfo: paymentReqInfo,
      "benef_record_id": Number(this.beneficiaryDetails.benef_record_id),
      "benef_nick_name":this.beneficiaryDetails.benef_nick_name

     
    }
    let path = paymentApiEndPoint.getbenficiarytrftype.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({ next: (res: any)=> {
      if(res["status"]["p_error_flag"] == 'N' && res["status"]['p_error_desc'] == 'SUCCESS') {
      this.txnType=  res["benefExclusionRcList"];
      for (var val of this.txnType) {
       
        if (val.payment_type_lu_code == 'NEFT') {
          this.isNEFT=false;
        }if (val.payment_type_lu_code == 'IMPS') {
          this.isIMPS=false
        }
        if (val.payment_type_lu_code == 'RTGS') {
          this.isRTGS=false
        }
      }
      
     
      }
      if(res["status"]["p_error_flag"] == 'Y') {
        res["p_error_flag"]["payment_type_lu_code"]
      
     
      }
      else {
      }
    }, error: (err) => {
    }})
  }

}
