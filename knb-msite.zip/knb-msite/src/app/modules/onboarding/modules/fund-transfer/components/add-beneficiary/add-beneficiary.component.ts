import { Component, OnDestroy, OnInit, } from '@angular/core';
import { FundTransferService } from '../../services/fundTransfer.service';
import { FLOW_CONSTANT, IFSC_REGEX, paymentApiEndPoint, paymentReqInfo, ROUTE_KEY } from '../../fundTransfer.constant';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BioCatchService, getBankandIFSC, getBeneficiaryDetails, getIfsc, setBankandIFSC, setBeneficiaryDetails, setFlow, setIfsc } from 'src/app/auth/auth.index';
import { DialogBoxComponent } from 'src/app/modules/shared/utils/dialog-box/dialog-box.component';
import { MatDialog } from '@angular/material/dialog';
import { IBenDetails } from '../../model/fundTransfer.model';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as CryptoJS from 'crypto-js';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';

@Component({
  selector: 'app-add-beneficiary',
  templateUrl: './add-beneficiary.component.html',
  styleUrls: ['./add-beneficiary.component.scss']
})
export class AddBeneficiaryComponent implements OnInit, OnDestroy {
  loop: boolean = false;
  myAccountFlag = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;
  submitted = false;
  sample_IFSC = '';
  bankdNameRedis: any;
  genericBankRes: any;
  genericBanks: any;
  formEnable = false;
  showNext = true;
  botton = 'Proceed';
  flowFlag!: string;
  reviewBeneDetails!: IBenDetails;
  mismatchError = false;
  passwordMatchErrorMessage = " mismatch error";
  beneDetails !: IBenDetails;
  beneDetailsEmpty !: IBenDetails;
  showIfsc: boolean = false;
  get_bankName!: string;
  subMemberBank!: boolean;
  isKotakAcctValid: boolean = true;
  isOtherAcctValid: boolean = true;
  reAccNoModel!: string;
  constructor(
    private fundTransferService: FundTransferService,
    public router: Router,
    private store: Store,
    private dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private loaderService: LoaderService,
    private bioCatchService: BioCatchService,) {


  }
  ngOnDestroy(): void {
    this.store.dispatch(setIfsc({ value: [] }));
  }

  addBeneForm = new FormGroup({
    bankName: new FormControl('', Validators.required),
    ifsc: new FormControl('', [Validators.required, Validators.pattern("^[a-zA-Z]{4}[A-Za-z0-9]{7}$")]),
    acctNum: new FormControl('', [Validators.required, Validators.maxLength(30), Validators.pattern("^(?! )[a-zA-Z0-9]+$")]),
    reAcctNo: new FormControl('', [Validators.required, Validators.maxLength(30), Validators.pattern("^(?! )[a-zA-Z0-9]+$")]),
    acctType: new FormControl('', Validators.required),
    beneOwn: new FormControl(''),
    beneName: new FormControl('', [Validators.required, Validators.maxLength(50), Validators.pattern("^(?! )[a-zA-Z0-9&' ]+$")]),

    beneNick: new FormControl('', [Validators.required, Validators.maxLength(27), Validators.pattern("^(?! )[a-zA-Z0-9&' ]+$")]),
    beneEmail: new FormControl('', [Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$")]),
    beneMobile: new FormControl('', [Validators.pattern("^((\\+-?)|0)?[0-9]{7,15}$")]),
  });
  get reAcctNo() { return this.addBeneForm.get('username'); }





  ngOnInit() {
    window.scrollTo(0,0);
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_ADD_BENE);

    this.flowFlag = FLOW_CONSTANT['ADDBENE'];
    this.store.dispatch(setFlow({ value: this.flowFlag }));
    this.addBeneForm.patchValue({
      beneOwn: false
    });

    this.store.select(getBankandIFSC).subscribe({
      next: (response: any) => {
        this.genericBanks = response;
      }
    })
    this.store.select(getBeneficiaryDetails).subscribe({
      next: (resp: any) => {
        this.reviewBeneDetails = resp;
      }
    })
    this.getBankDetails();
    if (this.reviewBeneDetails.benef_bank_ac_no != '') {
      this.setOldValue();
    }
    this.setIfscCode();
    let bkName = { value: this.reviewBeneDetails.benef_bank_name };
    this.onBankChange(bkName)
  }




  accountNumberValidation() {
    if (this.addBeneForm.value.reAcctNo != "") {
      if (this.addBeneForm.value.acctNum != this.addBeneForm.value.reAcctNo) {
        this.mismatchError = true;
      } else {
        this.mismatchError = false;
      }
    }
  }

  onBankChange(bank: any) {
    bank = bank.value;
    if (this.genericBanks) {
      for (let i = 0; i < this.genericBanks.length; i++) {
        if (this.genericBanks[i].bank_name == bank) {
          this.showIfsc = false;
          if (this.genericBanks[i].bank_name.toLowerCase().includes("kotak")) {
            this.showIfsc = true;
          }
          this.addBeneForm.patchValue({
            ifsc: this.genericBanks[i].ifsc_code
          })
        }
      }

    }
  }



  setOldValue() {
    this.addBeneForm.patchValue({
      bankName: this.reviewBeneDetails.benef_bank_name,
      ifsc: this.reviewBeneDetails.benef_bank_ifsc_code,
      acctNum: this.reviewBeneDetails.benef_bank_ac_no,
      reAcctNo: this.reviewBeneDetails.benef_bank_ac_no,
      acctType: this.reviewBeneDetails.benef_bank_acct_type,
      beneOwn: this.reviewBeneDetails.my_acct,
      beneName: this.reviewBeneDetails.benef_name,
      beneNick: this.reviewBeneDetails.benef_nick_name,
      beneEmail: this.reviewBeneDetails.benef_email,
      beneMobile: this.reviewBeneDetails.benef_mobile,
    })
    this.store.select(getBankandIFSC).subscribe({
      next: (response: any) => {
        this.genericBanks = response;

      }
    })
  }

  reviewScreen() {
    if (this.addBeneForm.status == "VALID") {
      if (this.addBeneForm.value.acctNum == this.addBeneForm.value.reAcctNo) {
        this.submitted = true;
        this.setValues();
      } else {

      }
    }
  }

  setValues() {
    let bnkName;
    if (!this.subMemberBank && this.addBeneForm.value.bankName == 'OTHER BANKS') {
      bnkName = this.get_bankName;
    }
    else { bnkName = this.addBeneForm.value.bankName; }


    this.beneDetails = {
      benef_bank_ac_no: this.addBeneForm.value.acctNum,
      benef_bank_acct_type: this.addBeneForm.value.acctType,
      benef_bank_ifsc_code: this.addBeneForm.value.ifsc,
      benef_record_id: '',
      benef_bank_acct_type_code: '',
      benef_bank_name: bnkName,
      benef_nick_name: this.addBeneForm.value.beneNick,
      benef_name: this.addBeneForm.value.beneName,
      benef_email: this.addBeneForm.value.beneEmail,
      benef_mobile: this.addBeneForm.value.beneMobile,
      my_acct: this.addBeneForm.value.beneOwn,
      favorite_flag: '',
      active_flag: '',
      schme_code: ''
    }
    this.store.dispatch(setBeneficiaryDetails({ value: this.beneDetails }));
    this.store.dispatch(setFlow({ value: FLOW_CONSTANT['ADDBENE'] }))

    this.router.navigateByUrl(ROUTE_KEY['REVIEWBENE'], { skipLocationChange: environment.skipURI });

  }




  setIfscCode() {

    this.store.select(getIfsc).subscribe({
      next: (resp: any) => {
        this.get_bankName = resp.bankName.toLocaleUpperCase();
        if (resp.ifscCode && resp.bankName) {
          let matchFlag = false;


          if(this.get_bankName.toLocaleUpperCase().includes("KOTAK")){
            this.get_bankName= "KOTAK MAHINDRA BANK";
            if (( IFSC_REGEX.test(resp.ifscCode.substring(4, resp.ifscCode.length)))) {
              this.get_bankName= "OTHER BANKS";
            }
          }


          for (let i = 0; i < this.genericBanks.length; i++) {
            if (this.genericBanks[i].bank_name == this.get_bankName) {
              matchFlag = true;
              this.showIfsc = false;
              if (this.genericBanks[i].bank_name.toLocaleUpperCase().includes("KOTAK")) {
                this.showIfsc = true;

              }
              this.addBeneForm.patchValue({
                bankName: this.genericBanks[i].bank_name

              })
              matchFlag = true;
            }
          }

          if (!matchFlag) {
            this.addBeneForm.patchValue({
              bankName: 'OTHER BANKS'
            })
          }


          this.addBeneForm.patchValue({
            ifsc: resp.ifscCode,

          })
        }
      }
    });

  }
  openAssetsDialog() {
    this.dialog.open(DialogBoxComponent, { panelClass: 'custom-dialog-container', backdropClass: 'backdropBackground', data: { dialogHeader: '', dialogInfo: 'This beneficiary will be displayed under "My Accounts" option. This will make future transfers to your own accounts easier.' }, });
  }
  getbankname() {
    let ifsc1: string = this.addBeneForm.controls['ifsc'].value.toLocaleUpperCase();
    let payload = {
      reqInfo: paymentReqInfo,
      ifscCode: ifsc1,
      bkKey: 'string'
    }

    if (payload.ifscCode.length == 11) {
      this.loaderService.startLoader();

      this.fundTransferService.handlePayment(payload, paymentApiEndPoint.getbankdnameredis).subscribe({
        next: (res: any) => {
          this.loaderService.stopLoader();
          if (res['status']['p_error_flag'] == 'N' && res['status']['p_error_desc'] == 'SUCCESS') {
            this.get_bankName = res.bankName.toLocaleUpperCase().trim();
            let matchFlag = false;
            for (let i = 0; i < this.genericBanks.length; i++) {
              if (this.genericBanks[i].bank_name == this.get_bankName) {
                this.showIfsc = false;
                matchFlag = true;

                if (this.genericBanks[i].bank_name == 'KOTAK MAHINDRA BANK') {
                  if (( IFSC_REGEX.test(ifsc1.substring(4, ifsc1.length)))) {
                    this.showIfsc = false;
                    this.subMemberBank = true;
                    matchFlag = false;
                  } else {
                    this.showIfsc = true;
                    this.subMemberBank = false;
                  }
                }

                this.addBeneForm.patchValue({
                  bankName: this.genericBanks[i].bank_name
                })
              }

            }

            if (!matchFlag) {
              this.addBeneForm.patchValue({
                bankName: 'OTHER BANKS'
              })
            }
          }

          if (res['status']['p_error_flag'] == 'Y' && res['status']['p_error_code'] == 'PFTIFSC008') {
            this.loaderService.stopLoader();

            this._snackBar.open('No Result Found', 'close', {
              duration: 5000
            })
          }
          else if (res['status']['p_error_flag'] == 'Y') {
            this.loaderService.stopLoader();

            this._snackBar.open('Unable to process request', 'close', {
              duration: 5000
            })
          }
        }, error: (err) => {
          this.loaderService.stopLoader();

          this._snackBar.open('Unable to process request', 'close', {
            duration: 5000
          })
        }

      });
    }
  }

  getBankDetails() {
    this.loaderService.startLoader();

    let payload = {
      reqInfo: paymentReqInfo,
    }
    this.fundTransferService.handlePayment(payload, paymentApiEndPoint.getgenericifsc).subscribe({
      next: (res: any) => {
        this.loaderService.stopLoader();

        this.genericBankRes = res;
        this.genericBanks = this.genericBankRes.dataop.data.ifsc_list;
        this.store.dispatch(setBankandIFSC({ value: this.genericBanks }))

      }, error: (err) => {
        this._snackBar.open('Unable to process request', 'close', {
          duration: 5000
        })
      }
    });
  };

  goSearchIfsc() {
    this.router.navigateByUrl(ROUTE_KEY['SEARCHIFSC'], { skipLocationChange: environment.skipURI });

  }

  goBack() {
    this.router.navigateByUrl(ROUTE_KEY['FTDASHBOARD'], { skipLocationChange: environment.skipURI });
  }



  public getKAcct() {
    if (this.addBeneForm.controls['acctNum'].valid || this.addBeneForm.controls['bankName'].value == 'KOTAK MAHINDRA BANK') {
      this.isOtherAcctValid = true;
      this.isKotakAcctValid = true;
    } else {
      this.isOtherAcctValid = false;
      this.isKotakAcctValid = true;

    }
    if (this.addBeneForm.controls['bankName'].value == 'KOTAK MAHINDRA BANK') {

      let payload = {
        reqInfo: paymentReqInfo,
        accNo: this.addBeneForm.controls['acctNum'].value

      }
      let path = paymentApiEndPoint.getAccountDetails;
      this.fundTransferService.handlePayment(payload, path).subscribe({
        next: (res: any) => {
          let acct: any = CryptoJS.AES.decrypt(res['acct_list'], environment.getAllActPublicKey);
          acct = JSON.parse(acct.toString(CryptoJS.enc.Utf8));

          if (acct == null) {
            this.isKotakAcctValid = false;
          } else {
            this.isKotakAcctValid = true;
            this.addBeneForm.controls['beneName'].setValue(acct[0].acct_name);
          }

        }
        , error: (err) => {
          this._snackBar.open('Unable to process request', 'close', {
            duration: 5000
          })
        }
      });

    }

  }





}


