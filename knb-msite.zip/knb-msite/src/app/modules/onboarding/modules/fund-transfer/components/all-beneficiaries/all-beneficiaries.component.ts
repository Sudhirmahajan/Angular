import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges} from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getFlow, setBeneficiaryDetails, setOneTimeBene, setMobileNumber, setOtpPayload, setBeneLimit, setFlow, BioCatchService, setDebitAct } from 'src/app/auth/auth.index';

import { FLOW_CONSTANT, paymentApiEndPoint, paymentReqInfo, ROUTE_KEY } from '../../fundTransfer.constant';
import { IBenDetails } from '../../model/fundTransfer.model';

import { environment } from 'src/environments/environment';
import { FundTransferService } from '../../services/fundTransfer.service';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';


@Component({
  selector: 'app-all-beneficiaries',
  templateUrl: './all-beneficiaries.component.html',
  styleUrls: ['./all-beneficiaries.component.scss']
})
export class AllBeneficiariesComponent implements OnInit {
  beneList!: any[];
  ownAcctBeneList: any[] = [];
  otherBeneList: any[] = [];
  favoraitsBeneList: any[] = [];
  pendingBeneList: any[] = [];
  beneficiaryList: any[] = [];
  txnLimitObj!: [{
    limit_record_id: string;
    txn_limit_amt: string;
    day_limit_amt: string;
    benef_nick_name: string
  }];
  txnLimtRecordId!: string;
  txnPerLimit!: string;
  txnDayPerLimit!: string;
  @Input() selectedTab: string = 'ALL_BEN';
  @Input() Count!: number;
  @Output() benCountEvent = new EventEmitter<object>();
  allBenDataFlag: boolean = false;
  tabCount = 0;
  searchText!: string;
  showBenOptionDialog!: boolean;
  deleteConfDialogContent = "Are you sure you want to delete this beneficiary?"
  deactivateConfDialogContent = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna."
  selectedBenData: any;
  showDelConfirmDialog!: boolean;
  
  flow!: string;
  sendToBene: boolean = false;
  beneData !: IBenDetails;
  loader: boolean = true;
  noBene: boolean = false;
  error: boolean = false;
  faverror: boolean = false;
  ufaverror: boolean = false;
  benCount = { allBenCount: 0, favBenCount: 0, pendingBenCount: 0 };
  benTotalLength: number = 0;
  showSearchFlag: boolean = false;
  flowFlag: string = 'manageBene';
  constructor(private fundTransferService: FundTransferService,
    private store: Store,
    private _snackBar: MatSnackBar,
    private router: Router,
    private bioCatchService: BioCatchService,

    ) { }

  ngOnInit() {

    this.setFlow();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.tabCount == 0) {
      this.getBeneficiaries();
      this.tabCount++;
    } else {
      if(this.benCount.allBenCount>200){
        setTimeout(() => {
          this.loadBenData();
        }, 500)
     }else{
         this.loadBenData();
     }
    }
  }

  getBeneficiaries() {

    let payload = {
      reqInfo: paymentReqInfo
    }
    this.fundTransferService.handlePayment(payload, paymentApiEndPoint.allbeneficiaries).subscribe({
      next: (res: any) => {
        this.loader = false;
        this.error = false;
        if (res['benef_list']) {
          this.beneList = res['benef_list'];
          this.ownAcctBeneList = this.beneList.filter((bene: any) => {
            return this.sendToBene ? bene.my_acct == 'Y' && bene.active_flag == 'Y' : bene.my_acct == 'Y';
          });
          this.otherBeneList = this.beneList.filter((bene: any) => {
            return this.sendToBene ? bene.my_acct == 'N' && bene.active_flag == 'Y' : bene.my_acct == 'N';
          });

          this.favoraitsBeneList = this.beneList.filter((bene: any) => {
            return bene.favorite_flag == 'Y' && bene.active_flag == 'Y';
          });

          this.pendingBeneList = this.beneList.filter((bene: any) => {
            return bene.active_flag == 'N';
          });
          this.benCount = {
            allBenCount: (this.ownAcctBeneList.length + this.otherBeneList.length),
            favBenCount: (this.favoraitsBeneList.length),
            pendingBenCount: (this.pendingBeneList.length)
          }
          this.benTotalLength = this.benCount.allBenCount + this.benCount.favBenCount + this.benCount.pendingBenCount;

          this.benCountEvent.emit(this.benCount)


        }
        if (res['status']['p_error_flag'] == 'Y' && res['status']['p_error_code'] == 'MWF007') {

          this.benCount = {
            allBenCount: 0,
            favBenCount: 0,
            pendingBenCount: 0
          }
          this.benCountEvent.emit(this.benCount)
        }
        this.loadBenData();
      },

      error: () => {

        this.error = true;
        this.loader = false;
      }
    });
  };
  

  loadBenData() {

    this.searchText = '';
    if (this.selectedTab == 'FAV_BEN') {
      this.allBenDataFlag = false;
      this.beneficiaryList = this.favoraitsBeneList;
      this.showSearchFlag = (this.benCount.favBenCount > 0 ? true : false);
    } else if (this.selectedTab == 'PENDING_BEN') {
      this.allBenDataFlag = false;
      this.beneficiaryList = this.pendingBeneList;
      this.showSearchFlag = (this.benCount.pendingBenCount > 0 ? true : false);
    } else {
      this.allBenDataFlag = true;
      this.beneficiaryList = this.ownAcctBeneList;
      this.showSearchFlag = (this.benCount.allBenCount > 0 ? true : false);
    }
  }

  getInitials = function (name: string) {
    var parts = name.trim().split(' ')
    var initials = parts[0][0];
    initials = parts.length > 1 ? (initials + parts[parts.length - 1][0]) : initials;
    return initials
  }

  showBenOptions(ben: any) {
    this.selectedBenData = ben;
    this.showBenOptionDialog = true;
  }

  closeOptionsDialog() {
    this.showBenOptionDialog = false;
  }

  closeDialog() {
    this.showDelConfirmDialog = false;
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_ALL_BENE);
    

  }

  proceedToModify(value: string) {
    this.showBenOptionDialog = false;
    switch (value) {
      case 'VIEW':
        this.store.dispatch(setBeneficiaryDetails({ value: this.selectedBenData }));
        this.router.navigateByUrl(ROUTE_KEY['BENEFICIARY_DETAILS'], { skipLocationChange: environment.skipURI });
        break;
      case 'EDIT':
        this.store.dispatch(setBeneficiaryDetails({ value: this.selectedBenData }));
        this.router.navigateByUrl(ROUTE_KEY['EDIT_BENEFICIARY'], { skipLocationChange: environment.skipURI });
        break;
      case 'DEACTIVATE':
        break;
      case 'DELETE':
        this.showDelConfirmDialog = true;

        break;
    }
  }

  markBeneFav(benData: any) {
    let payload = {
      reqInfo: paymentReqInfo,
      "beneRecId": Number(benData.benef_record_id)

    }
    let path = paymentApiEndPoint.markfavbene.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({
      next: (res: any) => {
        if (res["p_error_flag"] == 'N' && res['p_error_desc'] == 'SUCCESS') {
          this.getBeneficiaries();
          this._snackBar.open('Beneficiary marked as favorite successfully', '', {
            duration: 5000
          })
        } else {
          this._snackBar.open('Unable to mark beneficiary as favorite', 'close', {
            duration: 5000
          })
        }
      },
      error: () => {
        this._snackBar.open('Unmark Beneficiary Error', 'close', {
          duration: 5000
        })
      }
    }

    )
  };

  unmarkBeneFav(benData: any) {
    let payload = {
      reqInfo: paymentReqInfo,
      "beneRecId": Number(benData.benef_record_id)

    }
    let path = paymentApiEndPoint.removefavbene.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({
      next: (res: any) => {
        if (res["p_error_flag"] == 'N' && res['p_error_desc'] == 'SUCCESS') {
          this.getBeneficiaries();
          this._snackBar.open('Beneficiary unmarked as favorite successfully', '', {
            duration: 5000
          })
        } else {
          this._snackBar.open('Unable to unmark beneficiary', 'close', {
            duration: 5000
          })
        }
      },
      error: () => {

        this._snackBar.open('Unmark Beneficiary Error', 'close', {
          duration: 7000
        })

      }
    })
  };

  deleteConfirmation() {

   // this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_DELETE_BENE);

    this.showDelConfirmDialog = false;
    let payload = {
      reqInfo: paymentReqInfo,
      benef_nick_name: this.selectedBenData.benef_nick_name,
      benef_record_id: Number(this.selectedBenData.benef_record_id),
    };

    let path = paymentApiEndPoint.deletebeneficiary.trim();
    this.fundTransferService.handlePayment(payload, path)
      .subscribe({
        next: (res: any) => {
          if (res['status']['p_error_flag'] == 'N' && res['status']['p_error_desc'] == 'SUCCESS') {
            this.getBeneficiaries();

            this._snackBar.open('Beneficiary deleted successfully', 'close', {
              duration: 5000
            })
          }
          if (res['status']['p_error_flag'] == 'Y' ) {
            this.getBeneficiaries();
            this._snackBar.open(res['status']['p_error_desc'], 'close', {
              duration: 5000
            })
          }
     
       

        }, error: (err) => {
          this._snackBar.open('Beneficiary delete Error', 'close', {
            duration: 7000
          })
        }
      })
     
  
  }



  deactivateConfirmation(value: string) {

  }

  setFlow() {
    this.store.select(getFlow).subscribe({
      next: (resp: string) => {
        this.flow = resp;
      }

    })
    if (this.flow == 'SEND_TO_BENE') {
      this.sendToBene = true;
      this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_SEND_TO_BENE);

    }
    else{
      this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_ALL_BENE);

    }
  }

   getBeneLimit(bene: any) {
     let payload = {
       reqInfo: paymentReqInfo,
       "benef_nick_name": bene.benef_nick_name,
       "benef_record_id": bene.benef_record_id,

     }
     let path = paymentApiEndPoint.getbenficiarylimit.trim();
     this.fundTransferService.handlePayment(payload, path).subscribe({
       next: (res: any) => {
         if (res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {
           this.txnLimitObj = res['beneficiaryLimitRcList'];
           this.txnLimtRecordId = this.txnLimitObj[0].limit_record_id;
           this.txnPerLimit = this.txnLimitObj[0].txn_limit_amt;
           this.txnDayPerLimit = this.txnLimitObj[0].day_limit_amt;
           this.txnDayPerLimit = this.txnLimitObj[0].benef_nick_name;
           this.store.dispatch(setBeneLimit({ value: this.txnLimitObj }))
           this.beneData = {
             benef_bank_ac_no: bene.benef_bank_ac_no,
             benef_name: bene.benef_name,
             benef_nick_name: bene.benef_nick_name,
             benef_bank_name: bene.benef_bank_name,
             benef_bank_ifsc_code: bene.benef_bank_ifsc_code,
             benef_bank_acct_type: bene.benef_bank_acct_type,
             benef_record_id: bene.benef_record_id,
             benef_email: bene.benef_email,
             benef_mobile: bene.benef_mobile,
             benef_bank_acct_type_code: bene.benef_bank_acct_type_code,
             my_acct: bene.my_acct,
             favorite_flag: bene.favorite_flag,
            active_flag: bene.active_flag,
            schme_code : ''
           }
           this.transferNow()
           return;
  

         } else {
         }

       }
     })

   };

  transferNow() {
    this.store.dispatch(setDebitAct({ value: false })) 
    this.store.dispatch(setOneTimeBene({ value: this.beneData }))
    this.router.navigateByUrl(ROUTE_KEY['TRANSFERDETAILS'], { skipLocationChange: environment.skipURI });

   }




  activateBene(ben: any) {
    let date = new Date();
    let timestamp = Math.round(date.getTime())

    let payload = {
      reqInfo: {
        p_req_id: "NET_NET_" + timestamp,
        p_req_date_time: timestamp,
        p_mode: "NET",
        p_user: "NET",
        p_application_id: "NET",
        p_sub_user :  'MSITE'

      },
      benef_nick_name: ben.benef_nick_name,
      benef_record_id: ben.benef_record_id,
    }
    let otppayload = {

      benef_nick_name: ben.benef_nick_name,
      benef_record_id: ben.benef_record_id
    }

    this.store.dispatch(setOtpPayload({ value: otppayload }))
    this.fundTransferService.handlePayment(payload, paymentApiEndPoint.activatebenesms).subscribe({
      next: (res) => {
        let benRes: any = res;
        this.store.dispatch(setMobileNumber({ value: benRes['remitterMobNo'] }));
    
        if (benRes['statusop']['p_error_flag'] == 'N') {
          this.store.dispatch(setBeneficiaryDetails({ value: ben }));
          this.store.dispatch(setFlow({ value: FLOW_CONSTANT['MANAGE_BENEFICIARY'] }))
          this.router.navigateByUrl(ROUTE_KEY['GETOTP'], { skipLocationChange: environment.skipURI });

        }
        if (benRes['statusop']['p_error_flag'] == 'Y' && benRes['statusop']['p_error_code'] == 'AIB_053') {
          this.router.navigateByUrl(ROUTE_KEY['EXCEED_BENE'], { skipLocationChange: environment.skipURI });

        }
       else if (benRes['statusop']['p_error_flag'] == 'Y') {
        this._snackBar.open(benRes['statusop']['p_error_desc'], 'close', {
          duration: 5000
        })
        }
      },
      error: () => {

        this._snackBar.open('Active Beneficiary Error', 'close', {
          duration: 5000
        })


      }
    })


  }


}
