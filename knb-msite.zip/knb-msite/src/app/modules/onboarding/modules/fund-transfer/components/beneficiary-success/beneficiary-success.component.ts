import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getBeneficiaryDetails, getBeneSuccessRes, getFlow, setBeneficiaryDetails, setBeneSuccessRes, setFlow, setFooterFlag, setMobileNumber, setOtpPayload } from 'src/app/auth/auth.index';
import { ImgBanksLogoService } from 'src/app/modules/shared/services/img-banks-logo.service';

import { environment } from 'src/environments/environment';
import { FLOW_CONSTANT, paymentApiEndPoint, paymentReqInfo, ROUTE_KEY } from '../../fundTransfer.constant';
import { FundTransferService } from '../../services/fundTransfer.service';

@Component({
  selector: 'app-beneficiary-success',
  templateUrl: './beneficiary-success.component.html',
  styleUrls: ['./beneficiary-success.component.scss']
})
export class BeneficiarySuccessComponent implements OnInit, OnDestroy {
  beneDetails: any;
  flowFlag!: string;
  objectDetails: {} | undefined;
  tempBeneDetail = '';
  successMsg = 'Beneficiary added succesfully';
  successNote = 'You cannot transfer money to the beneficiary until it is activated.';
  botton = 'Activate Beneficiary';
  backBtnName = 'Return to Home';
  imgSrc!: string;
  disable = true;
  showNext = true;
  emptyObj: any = {};
  bankName !: string;
  bankArray: string[] = ['icic', 'yes'];
  errorMsg: String = "Error in processing";
  error: boolean = false;
  beneSuccessResponse: any;
  update: boolean=false;
  constructor(
    private store: Store,
    private router: Router,
    private imgeService: ImgBanksLogoService,
    private fundTransferService: FundTransferService, private _snackBar: MatSnackBar,
  ) { }
  ngOnDestroy(): void {
    
    this.flowFlag = FLOW_CONSTANT['SUCCESS'];
    this.store.dispatch(setFlow({ value: this.flowFlag }))
  }

  ngOnInit(): void {
    this.store.dispatch(setFooterFlag({ value: false }));
    this.beneData();
    this.store.select(getFlow).subscribe(value => this.flowFlag = value);
    if(this.flowFlag=='DEMOGRAPHIC_CHANGE'){
    this.update=true;
    }

  }

  beneData() {
    this.store.select(getBeneficiaryDetails).subscribe({
      next: (resp: any) => {
        this.beneDetails = resp;


        this.imgSrc = this.imgeService.imgLoad(this.beneDetails.benef_bank_name);



      }
    })


  }

  goBack() {
    this.store.dispatch(setBeneSuccessRes({ value: this.emptyObj }))
    this.store.dispatch(setBeneficiaryDetails({ value: this.emptyObj }));
    this.router.navigateByUrl(ROUTE_KEY['DASHBOARD'], { skipLocationChange: environment.skipURI });
  }
  proceed() {
    this.store.select(getBeneSuccessRes).subscribe({
      next: (resp: any) => {
        this.beneSuccessResponse = resp;
      }
    })
    let date = new Date();
    let timestamp = Math.round(date.getTime())
    let payload = {
      
       reqInfo: {
        p_req_id: "NET_NET_" + timestamp,
        p_req_date_time: timestamp,
        p_mode: "NET",
        p_user: "NET",
        p_application_id: "NET",
        p_sub_user :  'MSITE'

      },

      benef_nick_name: this.beneDetails.benef_nick_name,
      benef_record_id: this.beneDetails.benef_record_id,
    }

    let otppayload = {
      benef_nick_name: this.beneDetails.beneNick,
      benef_record_id: this.beneDetails.benef_record_id,
    }


    this.fundTransferService.handlePayment(payload, paymentApiEndPoint.activatebenesms).subscribe({
      next: (res) => {
        let benRes: any = res;
        this.store.dispatch(setMobileNumber({ value: benRes['remitterMobNo'] }));
   
        if (benRes['statusop']['p_error_flag'] == 'N') {
          this.store.dispatch(setBeneficiaryDetails({ value: this.beneDetails }));
          this.router.navigateByUrl(ROUTE_KEY['GETOTP'], { skipLocationChange: environment.skipURI });

        }

        if (benRes['statusop']['p_error_flag'] == 'Y' && benRes['statusop']['p_error_code'] == 'AIB_053') {
          this.router.navigateByUrl(ROUTE_KEY['EXCEED_BENE'], { skipLocationChange: environment.skipURI });

        }
      },
      error: () => {

        this._snackBar.open('Active Beneficiary Error', 'close', {
          duration: 5000
        })

      }
    }
  )}
}
