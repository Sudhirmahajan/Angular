import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BeneExeededLimitComponent } from './bene-exeeded-limit.component';

describe('BeneExeededLimitComponent', () => {
  let component: BeneExeededLimitComponent;
  let fixture: ComponentFixture<BeneExeededLimitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BeneExeededLimitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneExeededLimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
