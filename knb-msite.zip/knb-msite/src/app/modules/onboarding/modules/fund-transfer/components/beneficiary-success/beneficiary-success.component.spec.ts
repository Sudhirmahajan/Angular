import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { getBeneficiaryDetails } from 'src/app/auth/auth.index';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { FundTransferModule } from '../../fund-transfer.module';

import { BeneficiarySuccessComponent } from './beneficiary-success.component';

describe('BeneficiarySuccessComponent', () => {
  let component: BeneficiarySuccessComponent;
  let fixture: ComponentFixture<BeneficiarySuccessComponent>;
  let store: MockStore;
  let router: Router;
  const MokeBeneDetails ={ bankName:"yes" }
  beforeEach(async () => {

    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        FundTransferModule,
        NoopAnimationsModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateModule,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [BeneficiarySuccessComponent],
      providers: [

        provideMockStore(
          {
            selectors: [
              {
                selector: getBeneficiaryDetails,
                value: MokeBeneDetails
            },
            ]
          })
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BeneficiarySuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should Test BeneData', () => {
    component.bankArray = ['icici', 'kotak'];
    component.beneData();
          store.select(getBeneficiaryDetails).subscribe((resp) => {
            expect(resp).not.toBeNull();
            expect(component.beneDetails).toBe(resp);
            expect(component.bankName).toBe(resp.bankName);
          expect(component.imgSrc).toBe("assets/icons/kotak-32.png")
        });
  
  });

  it('should Test BeneData', () => {
    component.bankArray = ['icici', 'yes'];
    component.beneData();
    store.select(getBeneficiaryDetails).subscribe((resp) => {
      expect(resp).not.toBeNull();
      expect(component.beneDetails).toBe(resp);
      expect(component.bankName).toBe(resp.bankName);
    expect(component.imgSrc).toBe('assets/icons/' + resp.bankName + '.png');
  });

});

  it('should goback and empty object in store', () => {
    spyOn(store, 'dispatch').and.callThrough();
    spyOn(router, 'navigateByUrl');
    component.goBack();
    expect(store.dispatch).toHaveBeenCalled();
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

});



