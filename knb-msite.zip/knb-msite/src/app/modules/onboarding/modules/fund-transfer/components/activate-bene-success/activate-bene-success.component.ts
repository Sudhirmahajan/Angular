import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import {  getBeneficiaryDetails, setBeneficiaryDetails, setFooterFlag } from 'src/app/auth/auth.index';
import { ROUTE_KEY } from 'src/app/modules/login/login.constant';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-activate-bene-success',
  templateUrl: './activate-bene-success.component.html',
  styleUrls: ['./activate-bene-success.component.scss']
})
export class ActivateBeneSuccessComponent implements OnInit {

  beneDetails : any;
  objectDetails : {} | undefined;
  tempBeneDetail = '';
  successMsg ='Beneficiary Activated';
  successNote ='Lorem ipsum dolor sit amet, consetetur';
  botton = 'Pay Now';
  backBtnName ="Return to Home";
  
  disable = true;
  showNext = true ;
  emptyObj : any = {
    bankName : '',
      ifsc : '',
      acctNum : '',
      reAcctNo : '',
      acctType : '',
      beneOwn :  '',
      beneName : '',
      beneNick : ''
  } ;
  
  
  constructor(
    private store: Store,
    private router : Router
  ) { }

  ngOnInit(): void {
    this.store.dispatch(setFooterFlag({ value: false }));
    this.beneData();
  }

  beneData() {
    this.store.select(getBeneficiaryDetails).subscribe({next: (resp: any) => {
       this.objectDetails = resp;
       this.beneDetails = this.objectDetails;
       this.tempBeneDetail = resp;
      }
    })
  
  
  }

  goBack(){
    this.store.dispatch(setBeneficiaryDetails({ value: this.emptyObj }));
    this.router.navigateByUrl(ROUTE_KEY['DASHBOARD'], { skipLocationChange: environment.skipURI });
  }
  proceed(){
   
  }


}
