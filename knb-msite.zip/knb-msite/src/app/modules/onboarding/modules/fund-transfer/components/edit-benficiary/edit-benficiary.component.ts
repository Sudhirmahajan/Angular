import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { BioCatchService, getBeneficiaryDetails, NavigationService, setEditBene, setFlow, setMobileNumber, setOtpPayload } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { DialogBoxComponent } from 'src/app/modules/shared/utils/dialog-box/dialog-box.component';
import { environment } from 'src/environments/environment';
import { paymentApiEndPoint, ROUTE_KEY } from '../../fundTransfer.constant';
import { IBenDetails } from '../../model/fundTransfer.model';
import { FundTransferService } from '../../services/fundTransfer.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-edit-benficiary',
  templateUrl: './edit-benficiary.component.html',
  styleUrls: ['./edit-benficiary.component.scss']
})
export class EditBenficiaryComponent implements OnInit {
  editBenForm!: FormGroup;
  MobileNumber!: string;
  sendOtpRs: any;
  beneAcctType!: number;
  ownBankAcct!: string;
  showIfsc: boolean = false;
  validForm: boolean = false;
  genericBankRes!: {
    dataop: {
      data: {
        ifsc_list: []
      }
    }
  };
  genericBanks!: any[];
  deleteConfDialogContent = "Are you sure you want to delete this beneficiary?"
  transType: string = "";
  transTypeR: string = "";
  transArray: string[] = [""];
  transArrayR: string[] = [""];
  myFavBenFlag = false;
  showDelConfirmDialog!: boolean;
  ownBankAccFlag = true;
  impsCheckFlag = true;
  neftCheckFlag = true;
  rtgsCheckFlag = true;
  beneficiaryDetails!: IBenDetails;
  txnLimitObj!: [{
    limit_record_id: string;
    txn_limit_amt: string;
    day_limit_amt: string
  }];
  txnLimtRecordId!: string;
  txnPerLimit!: string;
  txnDayPerLimit!: string;
  EditBene: any;
  updateBeneOwn: any;
  isIMPS: boolean = false;
  isNEFT: boolean = false;
  isRTGS: boolean = false;
  txnType: any;
  trnsDetails: boolean = false;
  constructor(
    private fundTransferService: FundTransferService,
    private dialog: MatDialog,
    private navigationService: NavigationService,
    private store: Store,
    public router: Router,
    private _snackBar: MatSnackBar,
    private loaderService: LoaderService,
    private bioCatchService: BioCatchService,
  ) {
    this.getBankDetails();
    this.initializeForm();
  }


  ngOnInit(): void {
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_UPDATE_BENE);

    this.store.select(getBeneficiaryDetails).subscribe({
      next: (response: IBenDetails) => {

        this.beneficiaryDetails = response;
        this.getBeneLimit();

      }
    })
    this.getBeneTrfType();
  }

  getBeneLimit() {
    let date = new Date();
    let timestamp = Math.round(date.getTime())

    let payload = {
      reqInfo: {
        p_req_id: "NET_NET_" + timestamp,
        p_req_date_time: timestamp,
        p_mode: "NET",
        p_user: "NET",
        p_application_id: "NET"
      },
      "benef_nick_name": this.beneficiaryDetails.benef_nick_name,
      "benef_record_id": this.beneficiaryDetails.benef_record_id

    }
    let path = paymentApiEndPoint.getbenficiarylimit.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({
      next: (res: any) => {
        if (res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {
          this.txnLimitObj = res['beneficiaryLimitRcList'];
          this.txnLimtRecordId = this.txnLimitObj[0].limit_record_id;
          this.txnPerLimit = this.txnLimitObj[0].txn_limit_amt;
          this.txnDayPerLimit = this.txnLimitObj[0].day_limit_amt;
          this.patchValueInForm();
          return;

        } else if (res['status']['p_error_flag'] == 'Y') {
          this._snackBar.open(res['status']['p_error_desc'], 'close', {
            duration: 5000
          })
          this.patchValueInForm();
        } else {
          this._snackBar.open('Unable process request', 'close', {
            duration: 5000
          })
          this.patchValueInForm();
        }

      }, error: (err) => {
        this._snackBar.open('Unable process request', 'close', {
          duration: 5000
        })
        this.patchValueInForm();
      }
    })

  };
  getbankname() {
    if (this.beneficiaryDetails.benef_bank_name == 'KOTAK MAHINDRA BANK LTD') {
      this.showIfsc = true;
    }
  }

  getBankDetails() {
    let date = new Date();
    let timestamp = Math.round(date.getTime())

    let payload = {
      reqInfo: {
        p_req_id: "NET_NET_" + timestamp,
        p_req_date_time: timestamp,
        p_mode: "NET",
        p_user: "NET",
        p_application_id: "NET"
      },
    }
    this.fundTransferService.handlePayment(payload, paymentApiEndPoint.getgenericifsc).subscribe({
      next: (res: any) => {
        this.genericBankRes = res;
        this.genericBanks = this.genericBankRes.dataop.data.ifsc_list;
      }
    });
  };

  initializeForm() {
    this.editBenForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.maxLength(50), Validators.pattern("^(?! )[a-zA-Z0-9 ]+$")]),
      nickname: new FormControl('', [Validators.required, Validators.maxLength(27), Validators.pattern("^(?! )[a-zA-Z0-9 ]+$")]),
      email: new FormControl('', [Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$")]),
      bankName: new FormControl('', [Validators.required, Validators.maxLength(35)]),
      ifsc: new FormControl('', [Validators.required, Validators.maxLength(35)]),
      mobileNo: new FormControl('', [Validators.pattern("^((\\+-?)|0)?[0-9]{7,15}$")]),
      cnfAccountNum: new FormControl('', [Validators.required, Validators.maxLength(35)]),
      acctType: new FormControl('', [Validators.required, Validators.maxLength(35)]),
      myFavBen: new FormControl(false, [Validators.maxLength(35)]),
      ownBankAccount: new FormControl(false, [Validators.maxLength(35)]),
      perTxnLimit: new FormControl('', [Validators.required, Validators.maxLength(35)]),
      perDayTxnLimit: new FormControl('', [Validators.required, Validators.maxLength(35)]),
      impsCheck: new FormControl('', [Validators.maxLength(35)]),
      neftCheck: new FormControl('', [Validators.maxLength(35)]),
      rtgsCheck: new FormControl('', [Validators.maxLength(35)]),
    });

  }

  patchValueInForm() {

    this.updateBeneOwn = this.beneficiaryDetails.my_acct == 'Y' ? true : false;
    this.editBenForm.patchValue({
      name: this.beneficiaryDetails.benef_name,
      nickname: this.beneficiaryDetails.benef_nick_name,
      email: this.beneficiaryDetails.benef_email,
      bankName: this.beneficiaryDetails.benef_bank_name,
      ifsc: this.beneficiaryDetails.benef_bank_ifsc_code,
      mobileNo: this.beneficiaryDetails.benef_mobile,
      cnfAccountNum: this.beneficiaryDetails.benef_bank_ac_no,
      acctType: this.beneficiaryDetails.benef_bank_acct_type,
      myFavBen: (this.beneficiaryDetails.favorite_flag == 'Y' ? true : false),
      ownBankAccount: (this.beneficiaryDetails.my_acct == 'Y' ? true : false),
      perTxnLimit: this.txnPerLimit,
      perDayTxnLimit: this.txnDayPerLimit,
      impsCheck: this.impsCheckFlag,
      neftCheck: this.neftCheckFlag,
      rtgsCheck: this.rtgsCheckFlag,
    })
    this.getbankname();
  }

  openAssetsDialog() {
    this.dialog.open(DialogBoxComponent, { panelClass: 'custom-dialog-container', backdropClass: 'backdropBackground', data: { dialogHeader: 'dashboard.Assets.heading', dialogInfo: 'dashboard.toolTip.ownAcct' }, });
  }

  onBankChange(bank: any) {
    if (this.genericBanks) {
      for (let i = 0; i < this.genericBanks.length; i++) {
        if (this.genericBanks[i].bank_name == bank) {
          this.editBenForm.patchValue({
            ifsc: this.genericBanks[i].ifsc_code
          })
        }
      }
    }
  }

  goBack() {
    this.navigationService.goBack();
  }

  onChange(event: any) {

    if (this.editBenForm.value.neftCheck || this.editBenForm.value.impsCheck || this.editBenForm.value.rtgsCheck) {
      this.trnsDetails = false;
    } else {
      this.trnsDetails = true;
    }
  }

  public updateBeneficiary() {
    this.transArray = [];
    this.transArrayR = [];


    this.loaderService.startLoader();

    if (this.editBenForm.controls['impsCheck'].value != this.impsCheckFlag) {
      if (this.impsCheckFlag == true) {
        this.transArray.push('IMPS');
      }
      if (this.impsCheckFlag == false) {
        this.transArrayR.push('IMPS');
      }

    }
    if (this.editBenForm.controls['neftCheck'].value != this.neftCheckFlag) {
      if (this.neftCheckFlag == true) {
        this.transArray.push('NEFT');
      }
      if (this.neftCheckFlag == false) {
        this.transArrayR.push('NEFT');
      }
    }

    if (this.editBenForm.controls['rtgsCheck'].value != this.rtgsCheckFlag) {
      if (this.rtgsCheckFlag == true) {
        this.transArray.push('RTGS');
      }
      if (this.rtgsCheckFlag == false) {
        this.transArrayR.push('RTGS');
      }

    }



    if (this.transArray) {
      this.transType = this.transArray[0];
      for (let i = 1; i < this.transArray.length; i++) {
        this.transType = this.transType + "~" + this.transArray[i];
      }
    }

    if (this.transArrayR) {
      this.transTypeR = this.transArrayR[0];
      for (let i = 1; i < this.transArrayR.length; i++) {
        this.transTypeR = this.transTypeR + "~" + this.transArrayR[i];
      }
    }
    let otppayload1 = {
      benef_nick_name: this.editBenForm.controls['nickname'].value,
      benef_record_id: this.beneficiaryDetails.benef_record_id
    }
    this.store.dispatch(setOtpPayload({ value: otppayload1 }))
    let date = new Date();
    
    var beneAcctNumber = this.editBenForm.controls['cnfAccountNum'].value;
   beneAcctNumber= CryptoJS.AES.encrypt(beneAcctNumber, environment.getAllActPublicKey).toString();
    let timestamp = Math.round(date.getTime())
    let paymentReqInfo = {
      p_req_id: "NET_NET_" + timestamp,
      p_req_date_time: timestamp,
      p_mode: "NET",
      p_user: "NET",
      p_application_id: "NET",
      p_sub_user: "MSITE"
    }
    let payload1 = {

      "beneRecordID": this.beneficiaryDetails.benef_record_id,
      "beneNickName": this.editBenForm.controls['nickname'].value,
      "beneName": this.editBenForm.controls['name'].value,
      "beneMobileNumber": this.editBenForm.controls['mobileNo'].value,
      "beneEmail": this.editBenForm.controls['email'].value,
      "beneAccNumber": beneAcctNumber,
      "beneComfirmAccNumber": beneAcctNumber,
      "beneAccType": this.editBenForm.controls['acctType'].value,
      "bankIfsc": this.editBenForm.controls['ifsc'].value,
      "bankName": this.editBenForm.controls['bankName'].value,
      "beneTotalTxnLimitPerTxn": this.editBenForm.controls['perTxnLimit'].value,
      "benePerDayLimit": this.editBenForm.controls['perDayTxnLimit'].value,
      "ownAccount": this.editBenForm.controls['ownBankAccount'].value == true ? "Y" : "N",

      "favoriteFlag": this.beneficiaryDetails.favorite_flag,
      "beneLimitRecordID": this.txnLimtRecordId,
      "beneBranch": null,
      "activeFlag": this.beneficiaryDetails.active_flag,
      "createSourceLuCode": "NET",
      "paymentTypeLuCode": "Y",
      "inclusion": this.transTypeR,
      "exclusion": this.transType,


    }

    this.EditBene = payload1;
    let payload = { ...payload1, reqInfo: paymentReqInfo }



    this.ownBankAcct = this.editBenForm.controls['ownBankAccount'].value == true ? "Y" : "N";
    if (this.txnDayPerLimit !== this.editBenForm.controls['perDayTxnLimit'].value || this.txnPerLimit !== this.editBenForm.controls['perTxnLimit'].value) {
      if (this.beneficiaryDetails.benef_nick_name != this.editBenForm.controls['nickname'].value
        || this.beneficiaryDetails.benef_mobile != this.editBenForm.controls['mobileNo'].value
        || this.beneficiaryDetails.benef_email != this.editBenForm.controls['email'].value
        || this.beneficiaryDetails.benef_bank_acct_type != this.editBenForm.controls['acctType'].value
        || this.beneficiaryDetails.my_acct != this.ownBankAcct) {
        this.store.dispatch(setFlow({ value: "DEMOGRAPHIC_CHANGE" }));

      }
      let date = new Date();
      let timestamp = Math.round(date.getTime())
      let beneAcctNumber = <string>this.editBenForm.controls['cnfAccountNum'].value?.toString();

      let otpPayload = {
        reqInfo: {
          p_req_id: "NET_NET_" + timestamp,
          p_req_date_time: timestamp,
          p_mode: "NET",
          p_user: "NET",
          p_application_id: "NET"
        },
        "details": {
          "benefName": this.editBenForm.controls['name'].value,
          "benefNickName": this.editBenForm.controls['nickname'].value,
          "benefBankName": this.editBenForm.controls['bankName'].value,
          "benefBankIfsc": this.editBenForm.controls['ifsc'].value,
          "benefTxnAmt": parseFloat("00").toFixed(2),
          "benefBankAccount": CryptoJS.AES.encrypt(beneAcctNumber, environment.getAllActPublicKey).toString(),
          "txnType": 'BenLim'
        }
      }

      this.fundTransferService.handlePayment(otpPayload, paymentApiEndPoint.sendotp)
        .subscribe({
          next: (res: any) => {
            this.loaderService.stopLoader();
            if (res['status']['p_error_flag'] == 'N') {

              this.MobileNumber = res.rmno;
              this.store.dispatch(setMobileNumber({ value: this.MobileNumber }));
              this.store.dispatch(setOtpPayload({ value: otpPayload }));
              this.store.dispatch(setEditBene({ value: payload }));
              this.sendOtpRs = res;
              this.router.navigateByUrl(ROUTE_KEY['EDIT_BENE_OTP'], { skipLocationChange: environment.skipURI });
            }
            else if (res['status']['p_error_code'] == '5700') {

              this.MobileNumber = res.rmno;
              this.store.dispatch(setMobileNumber({ value: this.MobileNumber }));
              this.store.dispatch(setOtpPayload({ value: otpPayload }));
              this.store.dispatch(setEditBene({ value: payload }));
              this.sendOtpRs = res;
              this.router.navigateByUrl(ROUTE_KEY['OTO_LOCKED_FT'], { skipLocationChange: environment.skipURI });

            }
            else if (res['status']['p_error_flag'] == 'Y') {
              this._snackBar.open('We are not able to process', 'close', {
                duration: 5000
              })
            }
          }, error: (err) => {
            this._snackBar.open('We are not able to send OTP', 'close', {
              duration: 5000
            })

          }
        })


    }
    else {
      this.fundTransferService.handlePayment(payload, paymentApiEndPoint.updateBeneficiary).subscribe({
        next: (res: any) => {
          this.loaderService.stopLoader();

          if (res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {
            if (this.beneficiaryDetails.benef_nick_name != this.editBenForm.controls['nickname'].value
              || this.beneficiaryDetails.benef_mobile != this.editBenForm.controls['mobileNo'].value
              || this.beneficiaryDetails.benef_email != this.editBenForm.controls['email'].value
              || this.beneficiaryDetails.benef_bank_acct_type != this.editBenForm.controls['acctType'].value
              || this.beneficiaryDetails.my_acct != this.ownBankAcct) {

              this.router.navigateByUrl(ROUTE_KEY['GETOTP'], { skipLocationChange: environment.skipURI });

              this._snackBar.open('Beneficiary Updated successfully', 'close', {
                duration: 5000
              })
            }
            else {
              this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });

              this._snackBar.open('Beneficiary Updated successfully', 'close', {
                duration: 5000
              })
            }
          } else {
            this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });

            this._snackBar.open('Unable to Update Beneficiary', 'close', {
              duration: 5000
            })
          }
        }, error: (err) => {
          this._snackBar.open('Unable to Update Beneficiary', 'close', {
            duration: 5000
          })

        }
      });
    }
  }
  deleteBene() {
    this.showDelConfirmDialog = true;
  }
  deleteConfirmation() {
    this.showDelConfirmDialog = false;
    let date = new Date();
    let timestamp = Math.round(date.getTime())

    let payload = {
      reqInfo: {
        p_req_id: "NET_NET_" + timestamp,
        p_req_date_time: timestamp,
        p_mode: "NET",
        p_user: "NET",
        p_application_id: "NET"
      },
      benef_nick_name: this.beneficiaryDetails.benef_nick_name,
      benef_record_id: Number(this.beneficiaryDetails.benef_record_id),
    };

    let path = paymentApiEndPoint.deletebeneficiary.trim();
    this.fundTransferService.handlePayment(payload, path)
      .subscribe({
        next: (res: any) => {
          if (res['status']['p_error_flag'] == 'N' && res['status']['p_error_desc'] == 'SUCCESS') {
            this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });

            this._snackBar.open('Beneficiary deleted successfully', 'close', {
              duration: 5000
            })
          }
          if (res['status']['p_error_flag'] == 'Y' && res['status']['p_error_code'] == 'CBM100') {
            this._snackBar.open(res['status']['p_error_desc'], 'close', {
              duration: 5000
            })
          }
          else if (res['status']['p_error_flag'] == 'Y') {
            this._snackBar.open(res['status']['p_error_desc'], 'close', {
              duration: 5000
            })
          }

        }, error: (err) => {
          this._snackBar.open('Unable to delete beneficiary', 'close', {
            duration: 5000
          })
        }
      })
  }
  closeDialog() {
    this.showDelConfirmDialog = false;


  }



  getAcctLuCode(acctType: string) {
    if (acctType != null) {
      switch (acctType) {
        case 'Savings':
          this.beneAcctType = 10;
          break;
        case 'Current':
          this.beneAcctType = 11;
          break;
        case 'Overdraft':
          this.beneAcctType = 12;
          break;
        case 'Loan':
          this.beneAcctType = 14;
          break;
        case 'NRE':
          this.beneAcctType = 40;
          break;
        case 'Credit Card':
          this.beneAcctType = 52;
          break;
        case 'Cash Credit':
          this.beneAcctType = 13;
          break;

      }
    }
    return this.beneAcctType;
  }




  getBeneTrfType() {
    let date = new Date();
    let timestamp = Math.round(date.getTime())

    let payload = {
      reqInfo: {
        p_req_id: "NET_NET_" + timestamp,
        p_req_date_time: timestamp,
        p_mode: "NET",
        p_user: "NET",
        p_application_id: "NET"
      },
      "benef_record_id": Number(this.beneficiaryDetails.benef_record_id),
      "benef_nick_name": this.beneficiaryDetails.benef_nick_name


    }
    let path = paymentApiEndPoint.getbenficiarytrftype.trim();
    this.fundTransferService.handlePayment(payload, path).subscribe({
      next: (res: any) => {
        if (res["status"]["p_error_flag"] == 'N' && res["status"]['p_error_desc'] == 'SUCCESS') {
          this.txnType = res["benefExclusionRcList"];
          for (var val of this.txnType) {

            if (val.payment_type_lu_code == 'NEFT') {
              this.neftCheckFlag = false;
            } if (val.payment_type_lu_code == 'IMPS') {
              this.impsCheckFlag = false
            }
            if (val.payment_type_lu_code == 'RTGS') {
              this.rtgsCheckFlag = false;
            }
          }


        }
        if (res["status"]["p_error_flag"] == 'Y') {

          res["status"]["p_error_code"]


        }

      }, error: (err) => {
      }
    })
  }

}
