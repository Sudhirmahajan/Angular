import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundTransferDashboardComponent } from './fund-transfer-dashboard.component';

describe('FundTransferDashboardComponent', () => {
  let component: FundTransferDashboardComponent;
  let fixture: ComponentFixture<FundTransferDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FundTransferDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundTransferDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
