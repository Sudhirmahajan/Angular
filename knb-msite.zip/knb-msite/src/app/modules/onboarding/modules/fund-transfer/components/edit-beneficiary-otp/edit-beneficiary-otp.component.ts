import { _isNumberValue } from '@angular/cdk/coercion';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CountdownComponent, CountdownEvent } from 'ngx-countdown';

import {  setFooterFlag, getMobileNumber, getOtpPayload, getEditBene, getFlow, setFlow, setOtpPayload } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import {  paymentApiEndPoint, ROUTE_KEY, FLOW_CONSTANT } from '../../fundTransfer.constant';
import { FundTransferService } from '../../services/fundTransfer.service';

@Component({
  selector: 'app-edit-beneficiary-otp',
  templateUrl: './edit-beneficiary-otp.component.html',
  styleUrls: ['./edit-beneficiary-otp.component.scss']
})
export class EditBeneficiaryOtpComponent implements OnInit, OnDestroy {
  @ViewChild('backgroundCounter') backgroundCounter !: CountdownComponent;
  @ViewChild('actualCounter') actualCounter !: CountdownComponent;
  @ViewChild('onSmsOtp') onSmsOtp!: ElementRef;
  mobileOtp!: string;
  serviceIdFromStore!: string;
  storeFlow!: string;
  MobileNumber!: string;
  maskedEmail!: string;
  otpPayload: any;
  otpPayload1: any;
  EditBene: any;
  beneErrorMsg!: string;
  isdCodeFromStore!: string;
  public resendOTP: boolean = false;
  public backgroundTimer = 45;
  public showTimer = false;
  public callOptionEnable = true;
  public remainingTimeForActualCounter!: number;
  public showOtpExpiryMessage: boolean = false;

  public showHideIcon = 'Show';
  public remainingAttemts!: number;
  public buttonName: string = "Next";

  otpForm!: FormGroup;
  requestInProgress!: boolean;
  displayMfa!: boolean;
  displayDowntime!: boolean;
  errorCode: any;
  wrongOTPmsg!: String;
  flowFlag!: string;
  authenticationFlagStatus: any;
  askAtLoginFlag!: boolean;
  checkTwoFaOption!: boolean;
  wrongOTP!: boolean;
  constructor(private store: Store,
    private formBuilder: FormBuilder,
  
    private loaderService: LoaderService,

    private fundTransferService: FundTransferService,


    public router: Router,
    private _snackBar: MatSnackBar,) { }

  ngOnInit(): void {

    this.store.dispatch(setFooterFlag({ value: false }));
    this.store.select(getMobileNumber).subscribe(value => this.MobileNumber = value);
    this.store.select(getOtpPayload).subscribe(value => this.otpPayload = value)
    this.store.select(getEditBene).subscribe(value => this.EditBene = value)
    this.store.select(getFlow).subscribe(value => this.flowFlag = value)
    this.otpPayload1 = { benef_record_id: this.EditBene.beneRecordID, benef_nick_name: this.EditBene.beneNickName }

    this.otpForm = this.formBuilder.group({
      txt1: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt2: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt3: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt4: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt5: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      txt6: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
    });

  }

  ngOnDestroy(): void {

  }
  public validateOtp() {
    let date = new Date();
    let timestamp = Math.round(date.getTime())

    let paymentReqInfo = {
      p_req_id: "NET_NET_" + timestamp,
      p_req_date_time: timestamp,
      p_mode: "NET",
      p_user: "NET",
      p_application_id: "NET"
    }

    this.loaderService.startLoader();
    this.mobileOtp = this.otpForm.controls['txt1'].value + this.otpForm.controls['txt2'].value + this.otpForm.controls['txt3'].value + this.otpForm.controls['txt4'].value + this.otpForm.controls['txt5'].value + this.otpForm.controls['txt6'].value;
    this.wrongOTP = false;
    this.showOtpExpiryMessage = false;
    this.requestInProgress = true;
    let details1 = this.otpPayload.details;
    details1 = { ...details1, otp: this.mobileOtp }
    this.otpPayload = { ... this.otpPayload, details: details1, reqInfo: paymentReqInfo };



    this.fundTransferService.handlePayment(this.otpPayload, paymentApiEndPoint.validateotp)
      .subscribe({
        next: (res: any) => {

          this.loaderService.stopLoader();
          if (res['p_error_flag'] == 'Y') {
            if (res['p_error_code'] == '5700') {
              this.wrongOTP = true;
              this.showOtpExpiryMessage = true;
              this.callOptionEnable = false;

              this.wrongOTPmsg = res['p_error_desc'];
              this.router.navigateByUrl(ROUTE_KEY['OTO_LOCKED_FT'], { skipLocationChange: environment.skipURI });

            }
            else if (res['p_error_code'] == '5707') {
              this.wrongOTP = true;
              this.showOtpExpiryMessage = true;
              this.callOptionEnable = false;
              this.wrongOTPmsg = res['p_error_desc'];
            }

          }
          else {

            let date = new Date();
            let timestamp = Math.round(date.getTime())

            let paymentReqInfo = {
              p_req_id: "NET_NET_" + timestamp,
              p_req_date_time: timestamp,
              p_mode: "NET",
              p_user: "NET",
              p_application_id: "NET",
              p_sub_user: 'MSITE'
            }
            this.wrongOTP = false;
            this.EditBene = { ... this.EditBene, reqInfo: paymentReqInfo }

            this.fundTransferService.handlePayment(this.EditBene, paymentApiEndPoint.updateBeneficiary).subscribe({
              next: (res: any) => {
                if (res['statusop']['p_error_flag'] == 'N' && res['statusop']['p_error_desc'] == 'SUCCESS') {

                  if (res['addBeneLimitOp']['statusop']['p_error_flag'] == 'Y') {

                    this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });
                    this.beneErrorMsg = res['addBeneLimitOp']['statusop']['p_error_desc']
                    this.store.dispatch(setFlow({ value: FLOW_CONSTANT['MANAGE_BENEFICIARY'] }))
                    this._snackBar.open(this.beneErrorMsg, 'close', {
                      duration: 5000
                    })
                  }




                  else {
                    if (this.flowFlag == 'DEMOGRAPHIC_CHANGE') {
                      this.store.dispatch(setOtpPayload({ value: this.otpPayload1 }))
                      this.router.navigateByUrl(ROUTE_KEY['GETOTP'], { skipLocationChange: environment.skipURI });
                      this.beneErrorMsg = res['addBeneLimitOp']['statusop']['p_error_desc']
                      this._snackBar.open('Beneficiary Updated successfully', 'close', {
                        duration: 5000

                      })

                    } else {

                      this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });
                      this.store.dispatch(setFlow({ value: FLOW_CONSTANT['MANAGE_BENEFICIARY'] }))
                      this._snackBar.open('Beneficiary Updated successfully', 'close', {
                        duration: 5000

                      })
                    }
                  }
                }
              }, error: (err) => {
                this._snackBar.open('Unable to Update Beneficiary ', 'close', {
                  duration: 5000
                })

              }

            });


          }
        }
      })




  }


  clickEvent(e: any, prv: any, curr: any, nxt: any) {
    if (_isNumberValue(curr.value)) {
      let len = curr.value.length;
      let maxlen = curr.getAttribute('maxlength');


      if (len == maxlen) {
        if (nxt != '') {
          nxt.focus();
        }

      }
    }
    if (e.key == 'Backspace') {
      if (prv != '') {
        prv.focus();
      }
    }
  }


  callBackFromChild(event: any) {
    this.resendOTP = false;
  }

  goBack() {
    this.store.dispatch(setFlow({ value: FLOW_CONSTANT['MANAGE_BENEFICIARY'] }))
    this.router.navigateByUrl(ROUTE_KEY['MANAGE_BENEFICIARY'], { skipLocationChange: environment.skipURI });
  }

  public defaultOnFinished(event: CountdownEvent) {
    if (event.action == 'done') {
      this.callOptionEnable = false;
      this.resetTimer();
    }
  }

  resetTimer() {
    this.backgroundCounter.restart();
    this.backgroundCounter.stop();
  }

  public onFinished(event: CountdownEvent) {
    this.callOptionEnable = false;
    this.showTimer = false;
    this.actualCounter.restart();
    this.actualCounter.stop();
  }
  resendOTPFn() {
    this.resendOTP = true;
    this.wrongOTP = false;

  }
}
