import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditBenficiaryComponent } from './edit-benficiary.component';

describe('EditBenficiaryComponent', () => {
  let component: EditBenficiaryComponent;
  let fixture: ComponentFixture<EditBenficiaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditBenficiaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditBenficiaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
