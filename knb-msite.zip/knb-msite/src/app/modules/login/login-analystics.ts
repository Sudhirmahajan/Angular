
    export const redirectToLoginPage = {
        pageName:"login",
        channel:"login",
        platform:"NB2.0",
        loginMethod: "Net banking"
    }  

    export const redirectToKnoworCreateUserName = {
        pageName:"know or create username",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToValidateMobileNo = {
        pageName:"verify mobile number",
        channel:"login",
        platform:"NB2.0",
    }
     
    export const redirectToUserOtp = {
        pageName:"verify otp via sms",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserOtpViaCall = {
        pageName:"verify otp via call",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserNameInfo = {
        pageName:"user name info",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToKnowMyCRNCard = {
        pageName:"crn through card",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToKnowMyCRNMobilleNo = {
        pageName:"crn through mobile number",
        channel:"login",
        platform:"NB2.0",
    }
    export const redirectToValidateUser = {
        pageName:"identify yourself",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToValidateCardNo = {
        pageName:"card number",
        channel:"login",
        platform:"NB2.0",
    }
    export const redirectToValidateCardDetails = {
        pageName:"card details",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserPasswordSet = {
        pageName:"set credentials",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserPasswordUnblockSuccess = {
        pageName:"unblock success",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserPasswordViaPost = {
        pageName:"credential via post",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToRegisterForNetbanking = {
        pageName:"register for net banking",
        channel:"login",
        platform:"NB2.0",
    }
    export const redirectToNetbankingAlreadyRegistered = {
        pageName:"net banking already registered",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserPassword = {
        pageName:"login_pwd",
        channel:"login",
        platform:"NB2.0",
    }

    
    export const redirectToUserSessionExpired = {
        pageName:"session expired",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToUserLoginUnsuccessful = {
        pageName:"login unsuccessful",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToRememberMeCrn = {
        pageName:"credential with user",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToRememberMeCrnList = {
        pageName:"crn list",
        channel:"login",
        platform:"NB2.0",
    }

    export const redirectToRememberMeCrnListRemove = {
        pageName:"crn list remove",
        channel:"login",
        platform:"NB2.0",
    }

  
    export function preLoginCtaListRemove(value:any){
        return {appliedAction:value['appliedAction'],ctaName:value['ctaName'],PageName:value['pageName'],platform:"NB2.0"}
    } 

    export function preLoginCta(value:any){
        return {ctaName:value['ctaName'],PageName:value['pageName'],platform:"NB2.0"}
    }  

    export function loginPageCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"Login",platform:"NB2.0"}
    }  

    export function knoworCreateUserNameCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"know or create username",platform:"NB2.0"}
    }  

    export function validateMobileNoCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"verify mobile number",platform:"NB2.0"}
    }

    export function userOtpCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"verify otp via sms",platform:"NB2.0"}
    }

    export function userOtpViaCallCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"verify otp via call",platform:"NB2.0"}
    }
    export function usernameInfoCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"user name info",platform:"NB2.0"}
    }
    export function knowMyCRNCardCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"crn through card",platform:"NB2.0"}
    }
    export function KnowMyCRNMobilleNoCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"crn through mobile number",platform:"NB2.0"}
    }
    export function validateUserCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"identify yourself",platform:"NB2.0"}
    }

    export function validateCardNoCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"card number",platform:"NB2.0"}
    }

    export function validateCardDetailsCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"card details",platform:"NB2.0"}
    }
    export function userPasswordSetCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"set credentials",platform:"NB2.0"}
    }
    export function userPasswordUnblockSuccessCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"unblock success",platform:"NB2.0"}
    }

    export function userPasswordViaPostCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"credential via post",platform:"NB2.0"}
    }

    export function registerForNetbankingCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"register for net banking",platform:"NB2.0"}
    }

    export function netbankingAlreadyRegisteredCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"net banking already registered",platform:"NB2.0"}
    }

    export function userPasswordCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"login_pwd",platform:"NB2.0"}
    }

    export function userSessionExpiredCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"session expired",platform:"NB2.0"}
    }

    
    export function userLoginUnsuccessfulCtaname(ctaName:any){
        return {ctaName:ctaName,PageName:"login unsuccessful",platform:"NB2.0"}
    }

    export function remembermeOnClick(ctaName:any,appliedAction:any){
        return {ctaName:ctaName,PageName:"Remember me",appliedAction:appliedAction,platform:"NB2.0"}
    }
