export interface IAuthPayload {
    client_id: string;
    state: string;
    authMethod: string;
    guid: string;
    credential: string;
    rememberMeFlag: string;
}

export interface ILoginPayload {
    client_id: string;
    authMethod: string;
    userId: string;
    rememberMeFlag: string;
}

export interface ILoginSuccessResp {
    authMethod: string;
    flow: string;
    guid: string;
    state: string;
    statusCode: number;
    crdntlBlk: string;
    cdtBlk: string;
    chnlBlk: string;
    mblNtUpdtd: string;
    showRecaptcha: string;
    cardDetailsLogin: string;
}

export interface IAccessTokenResp {
    accessToken: string;
    authMethod: string;
    pdfRequested: boolean;
    showRecaptcha: string;
    state: string;

}

export interface IAccessTokenAndOnboardingResp {
    accessToken: string;
    onboarding: string;
    error?: string;
}

export interface IAccessTokenAndCustomerInfoResp {
    accessToken: string;
    onboarding: string;
    error?: string;
    customerInfo: {
        encryptedcrn: string;
        maskcrn: string;
        nickname: string;
        image: string;
        initials: string;
    };
}

export interface IAuthSuccessWithTwoFactoreResp {
    authMethod: string;
    emailId: string;
    isdCode: string;
    message: string;
    mobilenNumber: string;
    state: string;
    statusCode: number;
    twoFaOptions: [
        {
            twoFaMethodLuCode: string;
            prefferdTwoFaFlag: string;
        }
    ];
}

export interface IAuthSuccessResp {
    pdfRequested: boolean;
    showRecaptcha: string,
    authMethod: string;
    emailId: string;
    isdCode: string;
    message: string;
    mobilenNumber: string;
    state: string;
    statusCode: number;
}

export interface IOnlyStateResp {
    state: string;
    authMethod: string;
    pdfRequested: boolean;
}

export interface IVerifyCrnRequest {
    client_id: string;
    flow: string;
    guid: string;
    loginId?: string;
    oprState: string;
}

export interface IVerifyCrnResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    showRecaptcha: string;
}

export interface IValidateCardDetailsRequest {
    client_id: string;
    flow: string;
    oprState: string;
    credential: string;
    guid: string;
}

export interface IValidateCardDetailsResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    rmngAtmpts?: number;
    attempt?: number;
    disableMoreOption?: boolean;
    securityQuestionFlag?: boolean;
    showRecaptcha: string
}

export interface IVerifyMobileNoRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
    mobileNo: string;
}

export interface IVerifyMobileNoResponse {
    showRecaptcha: any;
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    isdCode: string;
    prefEmailId: string;
    prefMobileNo: string;
    rmngAtmpts?: number;
    attempt?: number;
    disableMoreOption?: boolean;
    securityQuestionFlag?: boolean;
}

export interface IValidateOtpRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
    otpValue: string;
}

export interface IValidateOtpResponse {
    attempt?: number;
    username?: string;
    showRecaptcha?: string;
    remainingDays?: string;
    disableMoreOption?: boolean;
    unBlkSecRemaning?: string;
    disableBack?: boolean;
    questions?: object[];
    accountQuestions?: object[],
    rmngAtmpts?: number;
    securityQuestionFlag?: boolean;
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
}

export interface IVerifyCardNoRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
    cardNumber: string;
}

export interface IVerifyCardNoResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    cardNumber: string
}

export interface ISetCredentialRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
    password: string;
}

export interface ISetCredentialResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
}

export interface INextOprMethodRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
}

export interface INextOprMethodResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    questions?: object[];
    disableMoreOption: boolean
    disableBack?: boolean
}

export interface IOtpOnCallRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
}

export interface IOtpOnCallResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    authMethod: string;
    pdfRequested: boolean
}

export interface IPhysicalPinRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
}

export interface IPhysicalPinResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    physicalPinDate?: string;
    physicalPinDays?: number;
}

export interface IOprBackOperationsRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
}

export interface IOprBackOperationsResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
}

export interface IExistingCredentialRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
}

export interface IExistingCredentialResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
}

export interface IReplaceSecurityQuesRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
}

export interface IReplaceSecurityQuesResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    questions: object[];
}

export interface IValidateSecurityQuesRequest {
    client_id: string;
    flow: string;
    guid: string;
    oprState: string;
    secQuestions: object[];
    secAnswers: object[];
}

export interface IValidateSecurityQuesResponse {
    flow: string;
    guid: string;
    nextScreen: string;
    state: string;
    attempt: number;
    rmngAtmpts: number;
}

