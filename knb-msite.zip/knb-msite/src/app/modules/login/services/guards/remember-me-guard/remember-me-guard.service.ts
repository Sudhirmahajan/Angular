import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';
import { environment } from '../../../../../../environments/environment';
import { Storage } from '../../../utils/storage/storage';

@Injectable({
  providedIn: 'root'
})
export class RememberMeGuardService implements CanActivate {

  constructor(private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const storage = new Storage();
    const crnList = storage.getStorageData();
    if (crnList.length === 0) {
      const uri = route.data['uri'];
      this.router.navigateByUrl(uri, { skipLocationChange: environment.skipURI });
    }
    return true;
  }
}
