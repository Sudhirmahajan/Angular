import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';
import { environment } from '../../../../../../environments/environment';
import { Storage } from '../../../utils/storage/storage';
import { RememberMeService } from '../../remember-me/remember-me.service';
@Injectable({
  providedIn: 'root'
})
export class LoginAuthGuardService implements CanActivate {

  public downtimeFromDateAndTime!: string;
  public downtimeToDateAndTime!: string;
  
  constructor(
    private router: Router,
    private rememberMeService: RememberMeService,
  ) { }

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const storage = new Storage();
    const crnList = storage.getStorageData();
    if (crnList.length === 1 && !this.rememberMeService.useAnotherAccountFlag) {
      const uri = route.data['credentialset'];
      this.router.navigateByUrl(uri, { skipLocationChange: environment.skipURI });
    } else if (crnList.length > 1 && !this.rememberMeService.useAnotherAccountFlag) {
      const uri = route.data['uri'];
      this.router.navigateByUrl(uri, { skipLocationChange: environment.skipURI });
    }
    return true;
  }
}
