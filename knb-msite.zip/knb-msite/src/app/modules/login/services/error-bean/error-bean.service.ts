import { HttpErrorResponse } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { getServiceId, setBlockedTimer } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS, SERVICE_ID } from '../../login.constant';

const ERROR_KEYS:any = {
    ERR0001: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    DBSRV001: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    BE0001: SCREEN_ROUTING_KEYS.OLD_NB_LOCKED,
    BE0002: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    BE0003: SCREEN_ROUTING_KEYS.UNBLOCK_LOCKED_CRN,
    BE0004: SCREEN_ROUTING_KEYS.REGENERATION_FAIL_INVALID_LOGINID,
    BE0005: 'loginId is null or blank',
    BE0006: 'Mobile number is null or blank',
    BE0007: 'User details are null or blank',
    BE0008: 'party data details are null or blank',
    BE0009: SCREEN_ROUTING_KEYS.CARD_DETAILS_WRONG_MOBILE_OTP,
    BE0010: SCREEN_ROUTING_KEYS.IB_ALREADY_EXISTS,
    BE0011: SCREEN_ROUTING_KEYS.IB_NOT_ELIGIBLE,
    BE0012: SCREEN_ROUTING_KEYS.REGENERATION_FAIL_INVALID_LOGINID,
    BE0013: 'Alert Failed',
    BE0014: 'Physical pin already requested',
    BE0015: SCREEN_ROUTING_KEYS.ONLINE_CREDENTIAL_LOCKED_7DAYS,
    BE0016: 'Cannot do OPR twice on single day',
    BE0017: 'security question format not correct',
    BE0018: SCREEN_ROUTING_KEYS.CARD_DETAILS_UNSUCCESSFUL,
    BE0019: SCREEN_ROUTING_KEYS.SESSION_EXPIRED,
    BE0019_1: SCREEN_ROUTING_KEYS.SESSION_EXPIRED,
    BE0020: SCREEN_ROUTING_KEYS.MOBILE_NOT_UPDATED,
    BE0021: SCREEN_ROUTING_KEYS.OTP_LOCKED,
    BE0022: SCREEN_ROUTING_KEYS.CREDENTIAL_REG_LOCK_WRONG_MOBILE_OTP,
    BE0023: SCREEN_ROUTING_KEYS.OLD_NB_OTP_LOCK,
    BE0024: SCREEN_ROUTING_KEYS.LOGIN_UNSUCCES,
    BE0025: 'Invalid Access Token',
    BE0026: 'Access token is not sent with request',
    BE0027: 'Sending OTP failed',
    BE0028: 'OTP locked in NB2.0',
    BE0029: 'Invalid Card Bin',
    BE0030: 'Old password and new password required',
    BE0031: SCREEN_ROUTING_KEYS.CREDENTIAL_REG_LOCK_WRONG_MOBILE_OTP,
    BE0032: SCREEN_ROUTING_KEYS.CREDENTIAL_REG_LOCK_WRONG_MOBILE_OTP,
    BE0033: SCREEN_ROUTING_KEYS.CREDENTIAL_REG_LOCK_WRONG_MOBILE_OTP,
    BE0034: SCREEN_ROUTING_KEYS.CREDENTIAL_REG_LOCK_WRONG_MOBILE_OTP,
    BE0035: 'Invalid RSA token',
    BE0036: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    BE0037: SCREEN_ROUTING_KEYS.CREDENTIAL_REG_LOCK_WRONG_MOBILE_OTP,
    BE0040: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    BE0041: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    SERVERR001: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESS,
    BE0043: SCREEN_ROUTING_KEYS.UNABLE_TO_PROCESSFAIL
};

@Injectable({
    providedIn: 'root'
})
export class ErrorBeanService implements OnInit {

    public remainingAttemts!: number;
    private serviceIdFromStore!: string;

    constructor(
        private router: Router,
        private store: Store
    ) { }

    ngOnInit() {
        this.getDataFromStore();
    }

    public handleErrorScenarios(errorBean: HttpErrorResponse) {
        const errCode = errorBean.error.errorCode;
        this.router.navigateByUrl(ROUTE_KEY[ERROR_KEYS[errCode]], { skipLocationChange: environment.skipURI });

    }

    public handleWrongAttempts(errorObj: HttpErrorResponse, formGroup: FormGroup) {
        if (errorObj.error.error.errorCode === 'BE0051') {
            const extraData:NavigationExtras=
            {state:
            {
                isOTPLocked:true
            }
            };
            this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_LOCKED], { ...extraData, ...{ skipLocationChange: environment.skipURI } });
            return;
        }
        let remainingAttemts = null;
        if (errorObj.error.unBlkSecRemaning) {
            this.store.dispatch(setBlockedTimer({ value: errorObj.error.unBlkSecRemaning }))
        }
        if (errorObj.error.rmngAtmpts && errorObj.error.attempt) {
            remainingAttemts = errorObj.error.rmngAtmpts;
        } else {
            this.router.navigateByUrl(ROUTE_KEY[ERROR_KEYS[errorObj.error.error.errorCode]], { skipLocationChange: environment.skipURI });

        }
        formGroup.reset();
        return remainingAttemts;
    }

    public handleErrorScenariosInLogin(error: HttpErrorResponse) {
        if (error.error.errorCode === 'BE0043') {
            this.router.navigateByUrl(ROUTE_KEY[ERROR_KEYS[error.error.errorCode]], { skipLocationChange: environment.skipURI });
        }
        if (error.error.authMethod) {
            if(error.error.authMethod=="OTP_IS_BLOCKED" && error.error.error.errorCode === 'BE0051'){
                const extraData:NavigationExtras=
                {state:
                {
                    isOTPLocked:true
                }
                };
                this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_LOCKED], { ...extraData, ...{ skipLocationChange: environment.skipURI } });

                return;
            }
            this.router.navigateByUrl(ROUTE_KEY[error.error.authMethod], { skipLocationChange: environment.skipURI } );

        } else {
            this.handleWrongAttemptsInLogin(error);
        }
        return this.remainingAttemts;
    }

    public handleFailCount(error: HttpErrorResponse) {
        if (error.error.rmngAtmpts >= 0) {
            let pageToNavigate = error.error.error.errorCode;
            if (this.serviceIdFromStore === SERVICE_ID.cardDetailsFlow) {
                pageToNavigate = 'BE0009';
            }
            (error.error.rmngAtmpts === 0) ? this.router.navigateByUrl(ROUTE_KEY[ERROR_KEYS[pageToNavigate]], { skipLocationChange: environment.skipURI }) :
                this.remainingAttemts = error.error.rmngAtmpts;
        } else {
            if (error.error.error.errorCode === 'BE0051') {
                return;
            }
            this.router.navigateByUrl(ROUTE_KEY[ERROR_KEYS[error.error.error.errorCode]], { skipLocationChange: environment.skipURI })
        }
    }

    private handleWrongAttemptsInLogin(error: HttpErrorResponse) {
        if (error.error.error.errorCode === 'BE0051') {
            const extraData:NavigationExtras=
            {state:
            {
                isOTPLocked:true
            }
            };
            this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_LOCKED], { ...extraData, ...{ skipLocationChange: environment.skipURI } });

        }
        if (error.error.blkHr) {
            this.store.dispatch(setBlockedTimer({ value: error.error.blkHr }))
        }
        if (error.error.dacBlk === 'Y') {
            this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_LOCKED], { skipLocationChange: environment.skipURI });

        } else {
            this.handleFailCount(error);
        }
    }

    private getDataFromStore() {
        this.store.select(getServiceId).subscribe((resp) => {
            this.serviceIdFromStore = resp;
        });
    }
}
