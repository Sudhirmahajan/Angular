import { Injectable } from '@angular/core';
import { AuthenticationService, getFlow, getGUID, getSecretKey, getServerState } from '../../../../auth/auth.index';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { Store } from '@ngrx/store';

@Injectable({
    providedIn: 'root'
})
export class PayloadService {

    private rememberMeFlag = 'N';
    private clientId: string;
    private msiteClientId: string;
    private stateFromStore!: string;
    private secretKeyFromStore!: string;
    private respGuid!: string;
    private flowFromStore!: string;
    public moreLoginOptionsSource = new BehaviorSubject<any>('');
    public moreLoginOptionsSourceCast = this.moreLoginOptionsSource.asObservable();

    constructor(
        private authenticationService: AuthenticationService,
        private store: Store
    ) {
        this.getDataFromStore();
        this.clientId = environment.clientId;
        this.msiteClientId = environment.msiteClientId;
    }

    public setMoreLoginOptionsSource(data: string) {
        this.moreLoginOptionsSource.next(data);
    }

    public generatePayloadForLogin(userID: string, rememberMe: string) {
        this.rememberMeFlag = rememberMe;
        console.log(userID)
        const payload = {
            client_id: this.msiteClientId,
            authMethod: 'NA',
            userId: this.authenticationService.generateEncrptedCredential(userID),
            rememberMeFlag: rememberMe
        };
        return payload;
    }

    public generatePayload(userID: string, rememberMe: string) {
        this.rememberMeFlag = rememberMe;
        const payload = {
            client_id: this.msiteClientId,
            authMethod: 'NA',
            userId:  userID,
            rememberMeFlag: rememberMe
        };
        return payload;
    }

    public generatePayloadForAuth(reqAuthMethod: string, credential: string) {
        let encryptCredential: string;
        if (reqAuthMethod === 'CREDENTIAL' || reqAuthMethod === 'CARD_DETAILS' || reqAuthMethod === 'SET_CREDENTIAL') {
            encryptCredential = this.authenticationService.mergedEncryptedCredential(credential, this.stateFromStore);
        } else {
            encryptCredential = this.authenticationService.generateEncrptedCredential(credential);
        }
        const payload = {
            client_id: this.msiteClientId,
            state: this.stateFromStore,
            authMethod: reqAuthMethod,
            guid: this.respGuid,
            credential: encryptCredential,
            rememberMeFlag: this.rememberMeFlag
        };
        return payload;
    }

    public generatePayloadForOpr(inputVal?: { [getKey: string]: string}, startFlowFlag?: boolean, isEncrypted?: boolean) {

        interface IPayload {
            client_id: string,
            flow: string,
            guid: string,
            oprState: string,
            [getKey: string]: string  
          }

        const payload: IPayload = {
            //client_id: this.clientId,
            client_id: this.msiteClientId,
            flow: this.flowFromStore,
            guid: this.respGuid,
            oprState: startFlowFlag ? '' : this.stateFromStore
        };
        if (inputVal) {
            const key = Object.keys(inputVal);
            const getKey = key[0].toString();
            const getVal = inputVal[getKey];
            let valEncrept: string;
            if (isEncrypted) {
                valEncrept = getVal.toString();
            } else {
                valEncrept = this.authenticationService.generateEncrptedCredential(getVal.toString());
            }
            payload[getKey] = valEncrept;
        }
        return payload;
    }

    public generatePayloadForCrnList(credential: string) {
        const payload = {
            client_id: this.clientId,
            authMethod: 'NA',
            userId: credential,
            rememberMeFlag: this.rememberMeFlag
        };
        return payload;
    }

    public generatePayloadForRememberMeOpr(inputVal?: { [getKey: string]: string}, startFlowFlag?: boolean) {
        interface IPayload {
            client_id: string,
            flow: string,
            guid: string,
            oprState: string,
            [getKey: string]: string  
        }
        const payload: IPayload = {
            client_id: this.clientId,
            flow: this.flowFromStore,
            guid: this.respGuid,
            oprState: startFlowFlag ? '' : this.stateFromStore,
        };
        if (inputVal) {
            const key = Object.keys(inputVal);
            const getKey = key[0].toString();
            const getVal = inputVal[getKey];
            payload[getKey] = getVal.toString();
        }
        return payload;
    }

    public generatePayloadForOprAuth(inputVal?: { [getKey: string]: string}) {
        interface IPayload {
            client_id: string,
            flow: string,
            guid: string,
            oprState: string,
            [getKey: string]: string  
        }
        const payload: IPayload = {
            client_id: this.clientId,
            flow: this.flowFromStore,
            guid: this.respGuid,
            oprState: this.stateFromStore
        };
        if (inputVal) {
            const key = Object.keys(inputVal);
            const getKey = key[0].toString();
            const getVal = inputVal[getKey];
            const valEncrept = this.authenticationService.mergedEncryptedCredential(getVal.toString(), this.stateFromStore);
            payload[getKey] = valEncrept;

        }
        return payload;
    }

    private getDataFromStore() {
        this.store.select(getServerState).subscribe((resp) => {
            this.stateFromStore = resp;
        });
        this.store.select(getGUID).subscribe((resp) => {
            this.respGuid = resp;
        });
        this.store.select(getFlow).subscribe((resp) => {
            this.flowFromStore = resp;
        });
        this.store.select(getSecretKey).subscribe((resp) => {
            this.secretKeyFromStore = resp;
        });
    }

}
