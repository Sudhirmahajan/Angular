import { Injectable } from '@angular/core';
import { ConfigService } from '../../../../auth/auth.index';
import { IAccessTokenAndCustomerInfoResp, IAccessTokenAndOnboardingResp, IAccessTokenResp, IAuthPayload, IAuthSuccessResp, IAuthSuccessWithTwoFactoreResp, ILoginPayload, ILoginSuccessResp, INextOprMethodResponse, IVerifyCardNoResponse, IVerifyCrnResponse, IVerifyMobileNoResponse } from '../../models/login.model';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';


@Injectable({
    providedIn: 'root'
})
export class LoginService {
    public setOnBoardingFlag = new BehaviorSubject<boolean>(false);
    public setOnBoardingFlagCast = this.setOnBoardingFlag.asObservable();
 
    constructor(
        private configService: ConfigService,
        private httpClient: HttpClient,

        ) { }

    public onBoardingFlag(data: any) {
        this.setOnBoardingFlag.next(data);
    }

    public validateUserName(payload: ILoginPayload | IAuthPayload, path: string, params?: { key?: string; captchaValue?: string; rememberMeFlag?: string}) {

        if(params?.key || params?.rememberMeFlag) {
            let url = new URL(this.configService.getLoginEndPointsWithDomain(path));
            params.key && url.searchParams.append("key", params.key);

            params.captchaValue && url.searchParams.append("captcha", params.captchaValue); //<any>this.widgetService.getEncryptedText(params.captchaValue)
            params.rememberMeFlag && url.searchParams.append("rememberMeFlag", params.rememberMeFlag); 

            return this.httpClient.post<ILoginSuccessResp>(url.toString(), payload);
        }

        return this.httpClient.post<ILoginSuccessResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public validatePwd(payload: ILoginPayload | IAuthPayload, path: string) {
        return this.httpClient.post<IAuthSuccessResp | IAccessTokenAndCustomerInfoResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public validateRememberMePwd(payload: ILoginPayload | IAuthPayload, path: string, params?: { key: string; captchaValue: string; }) {
        if(params?.key) {
            let url = new URL(this.configService.getLoginEndPointsWithDomain(path));
            url.searchParams.append("key", params.key);
            url.searchParams.append("captcha", params.captchaValue); 
            return this.httpClient.post<IAccessTokenAndOnboardingResp & IAuthSuccessWithTwoFactoreResp>(url.toString(), payload);
        }
        return this.httpClient.post<IAccessTokenAndOnboardingResp & IAuthSuccessWithTwoFactoreResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public validateOtp(payload: ILoginPayload | IAuthPayload, path: string) {
        return this.httpClient.post<IAccessTokenAndCustomerInfoResp | IAccessTokenAndOnboardingResp | IAccessTokenResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public handleOpr(payload: object, path: string) {
        return this.httpClient.post<any>(this.configService.getOprEndPointsWithDomain(path), payload);
    }

    public handleCardNoOpr(payload: object, path: string) {
        return this.httpClient.post<IVerifyCardNoResponse>(this.configService.getOprEndPointsWithDomain(path), payload);
    }

    public handleOprValidateMobNo(payload: object, path: string) {
        return this.httpClient.post<IVerifyMobileNoResponse>(this.configService.getOprEndPointsWithDomain(path), payload);
    }

    public handleLogin(payload: ILoginPayload | IAuthPayload, path: string) {
        return this.httpClient.post<any>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public handleLoginCaptcha(payload: object, path: string) {
        return this.httpClient.post<any>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public handleLoginRecaptcha(payload: object, path: string) {
        return this.httpClient.post<any>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public handleLoginOpr(payload: ILoginPayload | IAuthPayload, path: string) {
        return this.httpClient.post<IAccessTokenResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public handleLoginRememberMe(payload: ILoginPayload | IAuthPayload, path: string) {
        return this.httpClient.post<ILoginSuccessResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }

    public handleOprAnotherOption(payload: object, path: string) {
        return this.httpClient.post<INextOprMethodResponse>(this.configService.getOprEndPointsWithDomain(path), payload);
    }

    public getSeqQuesList(payload: object, path: string) {
        return this.httpClient.post<any>(this.configService.getSecQusEndPoint(path), payload);
    }

    public validateMsiteUser(payload: ILoginPayload | IAuthPayload, path: string) {
        return this.httpClient.post<IAuthSuccessResp | IAccessTokenAndCustomerInfoResp>(this.configService.getLoginEndPointsWithDomain(path), payload);
    }
}
