// import { Injectable } from '@angular/core';
// import { OPTION_TO_LAND_IN_DASHBOARD, StoreService } from 'knb-shared';
// import { Observable } from 'rxjs';
// import { select } from '@angular-redux/store';

// @Injectable({
//     providedIn: 'root'
// })
// export class IsLoginNb1Service {
//     constructor(private storeService:StoreService){}
//     @select() optionToLandInDashboard: Observable<string>; 

//     public checkIsNbOne(view) {
//         this.optionToLandInDashboard.subscribe((resp) => {
//           if (view === 'NB1' && !resp) {               
//             this.storeService.addToStore(OPTION_TO_LAND_IN_DASHBOARD, 'NBONEVIEW');
//           }
//         });
//       }
    
// }
