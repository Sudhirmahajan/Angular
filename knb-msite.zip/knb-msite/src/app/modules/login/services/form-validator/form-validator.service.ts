import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, FormGroup } from '@angular/forms';

@Injectable({
    providedIn: 'root'
})
export class FormValidatorService {

    public HasError(formGroup: FormGroup, formControl: string) {
        return (formGroup.controls[formControl].invalid && (formGroup.controls[formControl].dirty ||
            formGroup.controls[formControl].touched));
    }

    public FieldHasError(formGroup: FormGroup, formControl: string) {
        return this.checkValidation(formGroup.controls[formControl]);
    }
    public IsAlphabet(event: { keyCode: number; }) {
        if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122)) {
            return true;
        } else {
            return false;
        }
    }
    public numeric(control: FormControl) {
        const val = control.value;

        if (val === null || val === '') {
            return null;
        }

        if (!val.toString().match(/^[0-9]+(\.?[0-9]+)?$/)) {
            return { invalidNumber: true };
        }

        return null;
    }

    public IsNumber(event: { keyCode: number; }) {
        if (event.keyCode >= 48 && event.keyCode <= 57) {
            return true;
        } else {
            return false;
        }
    }

    public name() {
        return 'Prashant';
    }

    public preventSpace(event: { keyCode: number; }) {
        if (event.keyCode === 32) {
            return false;
        } else {
            return true;
        }
    }

    private checkValidation(formControl: AbstractControl) {
        const errorObj = {
            errVisibilityFlag: false,
            errMsg: ''
        };
        if (formControl.errors) {
            const validationArray = Object.keys(formControl.errors);
            errorObj['errVisibilityFlag'] = true;
            switch (validationArray[0]) {
                case 'required': {
                    errorObj['errMsg'] = 'This is required field';
                    break;
                }
                case 'minlength': {
                    errorObj['errMsg'] = 'Minimum length should be ' + formControl.errors['minlength'].requiredLength;
                    break;
                }
                case 'maxlength': {
                    errorObj['errMsg'] = 'Maximum length should be ' + formControl.errors['maxlength'].requiredLength;
                    break;
                }
                default:
                    break;
            }
        }
        return errorObj;
    }

}
