import { Injectable } from '@angular/core';
import { Storage } from '../../utils/storage/storage';

@Injectable({
  providedIn: 'root'
})
export class RememberMeService {

  public storage = new Storage();
  private anotherAccount = false;
  constructor() { }

  public handleRememberMe(userInfo: object[]): void {
    const userData = this.storage.getStorageData();
    userData.unshift(userInfo);
    this.storage.setStorageData(userData);
  }

  set useAnotherAccountFlag(flag: boolean) {
    this.anotherAccount = flag;
  }

  get useAnotherAccountFlag() {
    return this.anotherAccount;
  }
}
