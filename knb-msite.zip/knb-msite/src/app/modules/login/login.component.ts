import { Component, OnInit } from "@angular/core";
import { NavigationEnd, NavigationStart, Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { ConfigService } from "src/app/auth/auth.index";
import { DataEmitterService } from "src/app/auth/services/data-emitter/data-emitter.service";

@Component({
    selector: 'app-login',
    styleUrls: ['login.component.scss'],
    templateUrl: 'login.component.html'
})
export class LoginComponent implements OnInit{
    

    showDowntime:boolean=false;
    switchAppFlag: boolean = false;
    count = 0;
    public downtimeFromDateAndTime!: string;
    public downtimeToDateAndTime!: string;
    public downtimeLinkMsg!: string;
    public downtimeLinkUrl!: string;
    private date!: Date;
    private currentDate = this.js_yyyy_mm_dd_hh_mm_ss(new Date());
    private monthShortNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    downtimeDate!: any;
    public downtimeMsg!: string;
    public downtimeMsgArr:any = [];
    public notificationMsg!: string;
    public notificationMsgArr:any = [];
    public showNotification!: boolean;

  
    constructor(
        private translate: TranslateService,
        private configService: ConfigService,
        private router : Router,
        private dataEmitterService: DataEmitterService
    ) {

        this.router.events.subscribe(event => {
            if(router.url == '/login' || router.url == '/login/credentialWithUser' || router.url == '/login/crnList') {
                this.switchAppFlag = true;
             } else {
                this.switchAppFlag = false;
            }
                
       });
    }
     
    ngOnInit(): void {
        this.handleDownTime(this.configService.getDownTime());
    }
  

    private handleDownTime(resp:any) {

        if (resp && resp['downtimeStart'] && resp['downtimeEnd']) {
            const fromDate = new Date(
                resp['downtimeStart'].replace(/\s/, 'T')
            );
            const toDate = new Date(
                resp['downtimeEnd'].replace(/\s/, 'T')
            );

            const dateToBeStored = fromDate.getDate() + ' ' + this.monthShortNames[fromDate.getMonth()] + ' ' + fromDate.getFullYear();
            this.downtimeDate = {
                date: dateToBeStored,
                fromTime: this.calculateTime(resp['downtimeStart'].split(' ')[1]),
                toTime: this.calculateTime(resp['downtimeEnd'].split(' ')[1])
            };

            this.downtimeFromDateAndTime = this.js_yyyy_mm_dd_hh_mm_ss(fromDate);
            this.downtimeToDateAndTime = this.js_yyyy_mm_dd_hh_mm_ss(toDate);
            if (this.currentDate > this.downtimeFromDateAndTime && this.currentDate < this.downtimeToDateAndTime) {
                const downtimeObj = {
                    downtimeEnd: this.downtimeDate['toTime'],
                    diffInSec: this.calculateTimeDifference(new Date(), toDate)
                };
                this.dataEmitterService.broadcast('downtime', downtimeObj);
                 document.getElementById('splash')!.style.display = 'none'; 
                this.router.navigateByUrl('/login/maintenanceCard', { skipLocationChange: true });
            } else if (this.currentDate < this.downtimeToDateAndTime && this.currentDate < this.downtimeToDateAndTime) {
                this.downtimeMsg = resp['downTimeMsgText'];
                if (this.downtimeMsg) {
                    this.downtimeMsgArr = this.downtimeMsg.split('|');
                }
                this.showDowntime = true;
                this.downtimeLinkMsg = resp['notificationLinkText'];
                this.downtimeLinkUrl = resp['notificationLinkUrl'];
            } else {
                this.handleNotificationMsg(resp);
            }
        }
    }


    private handleNotificationMsg(resp:any) {
        if (resp && resp['notificationDownTimeStart'] && resp['notificationDownTimeEnd']) {
            const fromDate = new Date(
                resp['notificationDownTimeStart'].replace(/\s/, 'T')
            );
            const toDate = new Date(
                resp['notificationDownTimeEnd'].replace(/\s/, 'T')
            );
            const dateToBeStored = fromDate.getDate() + ' ' + this.monthShortNames[fromDate.getMonth()] + ' ' + fromDate.getFullYear();
            this.downtimeDate = {
                date: dateToBeStored,
                fromTime: this.calculateTime(resp['notificationDownTimeStart'].split(' ')[1]),
                toTime: this.calculateTime(resp['notificationDownTimeEnd'].split(' ')[1])
            };
            this.downtimeFromDateAndTime = this.js_yyyy_mm_dd_hh_mm_ss(fromDate);
            this.downtimeToDateAndTime = this.js_yyyy_mm_dd_hh_mm_ss(toDate);
            if (this.currentDate > this.downtimeFromDateAndTime && this.currentDate < this.downtimeToDateAndTime) {
                this.notificationMsg = resp['downTimeNotificationText'];
                if (this.notificationMsg) {
                    this.notificationMsgArr = this.notificationMsg.split('|');
                }
                this.showNotification = true;
                this.downtimeLinkMsg = resp['notificationLinkText'];
                this.downtimeLinkUrl = resp['notificationLinkUrl'];
            }
        }
    }





    private js_yyyy_mm_dd_hh_mm_ss(date: Date) {
        const year = '' + date.getFullYear();
        let month = '' + (date.getMonth() + 1); if (month.length === 1) { month = '0' + month; }
        let day = '' + date.getDate(); if (day.length === 1) { day = '0' + day; }
        let hour = '' + date.getHours(); if (hour.length === 1) { hour = '0' + hour; }
        let minute = '' + date.getMinutes(); if (minute.length === 1) { minute = '0' + minute; }
        let second = '' + date.getSeconds(); if (second.length === 1) { second = '0' + second; }
        return year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
    }


    private calculateTime(time: string) {
        if (time) {
            let hrTime = Number(time.substr(0, 5).replace(':', '.'));
            let finalTime: string;
            let timeZone = 'AM';
            if (hrTime > 12) {
                hrTime = hrTime - 12;
                timeZone = 'PM';
            }
            finalTime = hrTime.toFixed(2);
            if (hrTime < 10) {
                finalTime = '0' + finalTime;
            }
            return finalTime.replace('.', ':') + ' ' + timeZone;
        }else{
            return false;
        }
    }

    private calculateTimeDifference(currentDate:any, toDate:any) {
       
        let diff = toDate - currentDate;
        const seconds = Math.floor(diff / 1000); 
        return seconds;
    }
    
};