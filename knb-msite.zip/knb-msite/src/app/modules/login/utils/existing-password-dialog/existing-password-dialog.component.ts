import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { preLoginCta } from '../../login-analystics';

@Component({
  selector: 'app-existing-password-dialog',
  templateUrl: './existing-password-dialog.component.html',
  styleUrls: ['./existing-password-dialog.component.scss']
})
export class ExistingPasswordDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ExistingPasswordDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { flag: boolean },
  ) { }

  ngOnInit(): void {
  }

  onProceedClick(): void {
    this.dialogRef.close(true);
  }

  setAnalytics(ctaName:any){
    const value = {ctaName:ctaName,pageName:'continue with existing password'}
    window.digitalData=preLoginCta(value)
    window._satellite?.track("NB-Msiteclick");
  }

}
