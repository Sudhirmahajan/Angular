import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { IDialogData } from 'src/app/modules/onboarding/model/onboarding.model';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { ExistingPasswordDialogComponent } from './existing-password-dialog.component';

describe('ExistingPasswordDialogComponent', () => {
  let component: ExistingPasswordDialogComponent;
  let fixture: ComponentFixture<ExistingPasswordDialogComponent>;
  const model: IDialogData = {
    dialogHeader: 'Delete',
    dialogInfo: 'Are you sure?',
  };
  const dialogMock = {
    close: () => { }
}
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExistingPasswordDialogComponent ],
      imports:[MatDialogModule,HttpClientTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )],
      providers: [
        {
          provide: MAT_DIALOG_DATA,
          useValue: model
        },
        { provide: MatDialogRef, useValue: dialogMock  },
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingPasswordDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should Proceed on Click', () => {
    spyOn(component.dialogRef, 'close');
    component.onProceedClick()
    expect(component.dialogRef.close).toHaveBeenCalled();
    
  });


});


