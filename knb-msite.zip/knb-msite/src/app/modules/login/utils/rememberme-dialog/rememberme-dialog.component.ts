import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ConfigService } from 'src/app/auth/auth.index';
import { remembermeOnClick } from '../../login-analystics';

@Component({
  selector: 'app-rememberme-dialog',
  templateUrl: './rememberme-dialog.component.html',
  styleUrls: ['./rememberme-dialog.component.scss']
})
export class RemembermeDialogComponent implements OnInit {
  learnMoreLink!: string;

  constructor(
    private configService: ConfigService,
    public dialogRef: MatDialogRef<RemembermeDialogComponent>,
  ) {}

  onProceedClick(): void {
    this.dialogRef.close(true);
  }

  ngOnInit(): void {
    this.learnMoreLink = this.configService.getStaticLinks('learnMore');
  }

  setAnalytics(cta_name:any,appliedAction:any){
    window.digitalData=remembermeOnClick(cta_name,appliedAction);
    window._satellite?.track("NB-Msiteclick");
  }
}
