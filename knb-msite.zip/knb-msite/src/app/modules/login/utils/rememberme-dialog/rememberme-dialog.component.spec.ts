import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule, ConfigService } from 'src/app/auth/auth.module';
import { IDialogData } from 'src/app/modules/onboarding/model/onboarding.model';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { RemembermeDialogComponent } from './rememberme-dialog.component';

describe('RememberMeDialogComponent', () => {
  let component: RemembermeDialogComponent;
  let fixture: ComponentFixture<RemembermeDialogComponent>;
  const model: IDialogData = {
    dialogHeader: 'Delete',
    dialogInfo: 'Are you sure?',
  };
  const dialogMock = {
    close: () => { }
}
let configService: jasmine.SpyObj<ConfigService>;
const MockConfigService = jasmine.createSpyObj('ConfigService', ['getStaticLinks']);

  

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RemembermeDialogComponent ],
      imports:[MatDialogModule,HttpClientTestingModule,
        AuthModule.forRoot('env'),
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )],
      providers: [
        {
          provide: MAT_DIALOG_DATA,
          useValue: model
        },
        { provide: MatDialogRef, useValue: dialogMock  },
        { provide: ConfigService, useValue: MockConfigService },

      ]
    })
    .compileComponents();
  });


  beforeEach(() => {
    fixture = TestBed.createComponent(RemembermeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should Proceed on Click', () => {
    spyOn(component.dialogRef, 'close');
    component.onProceedClick()
    expect(component.dialogRef.close).toHaveBeenCalled();
    
  });

});
