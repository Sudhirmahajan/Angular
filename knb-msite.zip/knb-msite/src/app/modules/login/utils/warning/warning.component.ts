import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-warning',
  templateUrl: './warning.component.html',
  styleUrls: ['./warning.component.scss']
})
export class WarningComponent {

@Input() errorMsg!: string;
@Input() errorType: string = '';
@Input() count!: number;
@Input() showGoogleCaptchaFlag: boolean = false;
@Input() showCredentialPolicyError: boolean = false;
@Input() showOtpExpiryMessage: boolean = false;
@Input() serviceIdFromStore!: string;
@Input() storeFlow!: string;
@Input() isNicknameSame!: boolean;
@Output() callbackEvent = new EventEmitter<boolean>();
  
  constructor() {
  }

  public triggerCallback() {
    this.callbackEvent.emit();
  }


}
