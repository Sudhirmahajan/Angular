export class Storage {

    setStorageData(data: any[]): void {
        if (data) {
            localStorage.setItem('knbData', JSON.stringify(data));
        }
    }

    getStorageData(): object[] {
        let data = [];
        if (localStorage.getItem('knbData')) {
            data = JSON.parse(localStorage.getItem('knbData') || '');
        }
        return data;
    }
}
