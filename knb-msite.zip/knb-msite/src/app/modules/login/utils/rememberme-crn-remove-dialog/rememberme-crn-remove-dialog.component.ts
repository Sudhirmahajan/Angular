import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { getPageDetails, setPageName } from 'src/app/auth/auth.index';
import { preLoginCta, preLoginCtaListRemove } from '../../login-analystics';

@Component({
  selector: 'app-rememberme-crn-remove-dialog',
  templateUrl: './rememberme-crn-remove-dialog.component.html',
  styleUrls: ['./rememberme-crn-remove-dialog.component.scss']
})
export class RemembermeCrnRemoveDialogComponent implements OnInit {
  page_name: any;

  constructor(
    public store: Store,
    public dialogRef: MatDialogRef<RemembermeCrnRemoveDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { maskcrn: string, removeFlag: boolean },
  ) {}

  ngOnInit(): void {
   // this.store.dispatch(setPageName({ value: "Remove CRN" })); 
  }

  setAnalyticsOnClick(cta_name:any,appliedAction:any){
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    window.digitalData=preLoginCtaListRemove({appliedAction:appliedAction,ctaName:cta_name,pageName:"Remove CRN"});
    window._satellite?.track("NB-Msiteclick");
  }

}
