import { NgModule } from "@angular/core";
import { LoginComponent } from "./login.component";
import { LoginRoutingModule } from "./login-routing.module";
import { UserDetailsComponent } from './components/user-details/user-details.component';
import { UserPasswordComponent } from './components/user-password/user-password.component';
import { SharedModule } from "../shared/shared.module";
import { UserOtpComponent } from './components/user-otp/user-otp.component';
import { KnowMyCrnComponent } from './components/know-my-crn/know-my-crn.component';
import { RemembermeDialogComponent } from './utils/rememberme-dialog/rememberme-dialog.component';
import { RemembermeEnterPasswordComponent } from './components/rememberme-enter-password/rememberme-enter-password.component';
import { ValidateUserComponent } from './components/validate-user/validate-user.component';
import { ValidateMobileNumberComponent } from './components/validate-mobile-number/validate-mobile-number.component';
import { ValidateCardNumberComponent } from './components/validate-card-number/validate-card-number.component';
import { RemembermeCrnListComponent } from './components/rememberme-crn-list/rememberme-crn-list.component';
import { RemembermeCrnRemoveComponent } from "./components/rememberme-crn-remove/rememberme-crn-remove.component";
import { RemembermeCrnRemoveDialogComponent } from "./utils/rememberme-crn-remove-dialog/rememberme-crn-remove-dialog.component";
import { RemembermeCrnRemoveSuccessComponent } from './components/rememberme-crn-remove-success/rememberme-crn-remove-success.component';
import { ValidateCardDetailsComponent } from './components/validate-card-details/validate-card-details.component';
import { CountdownModule } from "ngx-countdown";
import { KnowOrCreateUsernameComponent } from './components/know-or-create-username/know-or-create-username.component';
import { RegisterForNetbankingComponent } from './components/register-for-netbanking/register-for-netbanking.component';
import { UserPasswordViaPdfComponent } from './components/user-password-via-pdf/user-password-via-pdf.component';
import { NetbankingLockedComponent } from './components/netbanking-locked/netbanking-locked.component';
import { NetbankingAlreadyRegisteredComponent } from './components/netbanking-already-registered/netbanking-already-registered.component';
import { UserPasswordViaPostComponent } from './components/user-password-via-post/user-password-via-post.component';
import { WarningComponent } from './utils/warning/warning.component';
import { UserPasswordSetNewComponent } from './components/user-password-set-new/user-password-set-new.component';
import { ExistingPasswordDialogComponent } from './utils/existing-password-dialog/existing-password-dialog.component';
import { UserPasswordSetNewSuccessComponent } from './components/user-password-set-new-success/user-password-set-new-success.component';
import { UserSessionExpiredComponent } from './components/user-session-expired/user-session-expired.component';
import { UnableToProcessComponent } from './components/unable-to-process/unable-to-process.component';
import { SecondFactorAuthenticationOptionsComponent } from './components/second-factor-authentication-options/second-factor-authentication-options.component';
import { MobileBankingInfoComponent } from './components/mobile-banking-info/mobile-banking-info.component';
import { ExpiredMobileBankingComponent } from "./components/expired-mobile-banking/expired-mobile-banking.component";
import { KnowOrCreateUsernameSuccessComponent } from './components/know-or-create-username-success/know-or-create-username-success.component';
import { MobileNotUpdatedErrorComponent } from './components/mobile-not-updated-error/mobile-not-updated-error.component';
import { UserPasswordGenerationLockedComponent } from './components/user-password-generation-locked/user-password-generation-locked.component';
import { NgxCaptchaModule } from 'ngx-captcha';
import { UserLoginUnsuccessfulComponent } from './components/user-login-unsuccessful/user-login-unsuccessful.component';
import { ValidateCardDetailsLockedComponent } from './components/validate-card-details-locked/validate-card-details-locked.component';
import { ValidateCardDetailsUnsuccessfulComponent } from './components/validate-card-details-unsuccessful/validate-card-details-unsuccessful.component';
import { RegisterWithUsernameComponent } from './components/register-with-username/register-with-username.component';
import { NetbankingAccessBlockedComponent } from './components/netbanking-access-blocked/netbanking-access-blocked.component';
import { UserPasswordGenerationLockedWrongMobileOtpComponent } from './components/user-password-generation-locked-wrong-mobile-otp/user-password-generation-locked-wrong-mobile-otp.component';
import { KnowOrCreateUsernameSetSuccessComponent } from './components/know-or-create-username-set-success/know-or-create-username-set-success.component';
import { WelcomeBackComponent } from './components/welcome-back/welcome-back.component';
import { UserPasswordUnblockSuccessComponent } from './components/user-password-unblock-success/user-password-unblock-success.component';
import { OprTwiceLockedComponent } from './components/opr-twice-locked/opr-twice-locked.component';
import { RekycCardComponent } from './components/rekyc-card/rekyc-card.component';
import { SwitchAppComponent } from './components/switch-app/switch-app.component';
import { SecurityQuestionsComponent } from './components/security-questions/security-questions.component';
import { FatcaDeclarationComponent } from './components/fatca-declaration/fatca-declaration.component';
import { ConfirmCommAddressComponent } from './components/confirm-comm-address/confirm-comm-address.component';
import { YouAreAllSetComponent } from './components/you-are-all-set/you-are-all-set.component';
import { StayUpdatedCardComponent } from './components/stay-updated-card/stay-updated-card.component';
import { StayChargedCardComponent } from './components/stay-charged-card/stay-charged-card.component';
import { StaySecureCardComponent } from './components/stay-secure-card/stay-secure-card.component';
import { EmergencyCardComponent } from './components/emergency-card/emergency-card.component';
import { SetNicknameComponent } from './components/set-nickname/set-nickname.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { SwitchOnInternationalCardsComponent } from './components/switch-on-international-cards/switch-on-international-cards.component';
import { SwitchOnForexCardsComponent } from './components/switch-on-forex-cards/switch-on-forex-cards.component';
import { TwofaRegisterComponent } from './components/twofa-register/twofa-register.component';
import { TwofaRegisterInfoComponent } from './components/twofa-register-info/twofa-register-info.component';
import { AuthenticateUsingOtpComponent } from './components/authenticate-using-otp/authenticate-using-otp.component';
import { FatcaSetupComponent } from './components/fatca-setup/fatca-setup.component';
import { MaintenanceCardComponent } from './components/maintenance-card/maintenance-card.component';
import { EnjoyOneTimeTransferCardComponent } from './components/enjoy-one-time-transfer-card/enjoy-one-time-transfer-card.component';
import { SetNetBankingCredentialComponent } from './components/set-net-banking-credential/set-net-banking-credential.component';
import { NetBankingRegistrationSuccessComponent } from './components/net-banking-registration-success/net-banking-registration-success.component';
import { UpdateContactDetailsComponent } from './components/update-contact-details/update-contact-details.component';


@NgModule({
    declarations: [
    LoginComponent,
    UserDetailsComponent,
    UserPasswordComponent,
    UserOtpComponent,
    KnowMyCrnComponent,
    RemembermeDialogComponent,
    RemembermeEnterPasswordComponent,
    ValidateUserComponent,
    ValidateMobileNumberComponent,
    ValidateCardNumberComponent,
    RemembermeCrnListComponent,
    RemembermeCrnRemoveComponent,
    RemembermeCrnRemoveDialogComponent,
    RemembermeCrnRemoveSuccessComponent,
    ValidateCardDetailsComponent,
    KnowOrCreateUsernameComponent,
    RegisterForNetbankingComponent,
    UserPasswordViaPdfComponent,
    NetbankingLockedComponent,
    NetbankingAlreadyRegisteredComponent,
    UserPasswordViaPostComponent,
    WarningComponent,
    UserPasswordSetNewComponent,
    ExistingPasswordDialogComponent,
    UserPasswordSetNewSuccessComponent,
    UserSessionExpiredComponent,
    UnableToProcessComponent,
    SecondFactorAuthenticationOptionsComponent,
    MobileBankingInfoComponent,
    ExpiredMobileBankingComponent,
    KnowOrCreateUsernameSuccessComponent,
    MobileNotUpdatedErrorComponent,
    UserPasswordGenerationLockedComponent,
    UserLoginUnsuccessfulComponent,
    ValidateCardDetailsLockedComponent,
    ValidateCardDetailsUnsuccessfulComponent,
    RegisterWithUsernameComponent,
    NetbankingAccessBlockedComponent,
    UserPasswordGenerationLockedWrongMobileOtpComponent,
    KnowOrCreateUsernameSetSuccessComponent,
    WelcomeBackComponent,
    UserPasswordUnblockSuccessComponent,
    OprTwiceLockedComponent,
    RekycCardComponent,
    SwitchAppComponent,
    SecurityQuestionsComponent,
    FatcaDeclarationComponent,
    ConfirmCommAddressComponent,
    YouAreAllSetComponent,
    StayUpdatedCardComponent,
    StayChargedCardComponent,
    StaySecureCardComponent,
    EmergencyCardComponent,
    SetNicknameComponent,
    WelcomeComponent,
    SwitchOnInternationalCardsComponent,
    SwitchOnForexCardsComponent,
    TwofaRegisterComponent,
    TwofaRegisterInfoComponent,
    AuthenticateUsingOtpComponent,
    FatcaSetupComponent,
    MaintenanceCardComponent,
    EnjoyOneTimeTransferCardComponent,
    SetNetBankingCredentialComponent,
    NetBankingRegistrationSuccessComponent,
    UpdateContactDetailsComponent,
    
  ],
    imports: [
        LoginRoutingModule,
        SharedModule,
        CountdownModule,
        NgxCaptchaModule
    ]
})
export class LoginModule {}