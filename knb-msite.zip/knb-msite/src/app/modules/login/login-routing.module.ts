import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login.component'
import { UserDetailsComponent } from './components/user-details/user-details.component';
import { UserPasswordComponent } from './components/user-password/user-password.component';
import { UserOtpComponent } from './components/user-otp/user-otp.component';
import { KnowMyCrnComponent } from './components/know-my-crn/know-my-crn.component';
import { LoginAuthGuardService, RememberMeGuardService } from './services/guards';
import { RemembermeEnterPasswordComponent } from './components/rememberme-enter-password/rememberme-enter-password.component';
import { ValidateUserComponent } from './components/validate-user/validate-user.component';
import { ValidateMobileNumberComponent } from './components/validate-mobile-number/validate-mobile-number.component';
import { ValidateCardNumberComponent } from './components/validate-card-number/validate-card-number.component';
import { RemembermeCrnListComponent } from './components/rememberme-crn-list/rememberme-crn-list.component';
import { RemembermeCrnRemoveComponent } from './components/rememberme-crn-remove/rememberme-crn-remove.component';
import { RemembermeCrnRemoveSuccessComponent } from './components/rememberme-crn-remove-success/rememberme-crn-remove-success.component';
import { ValidateCardDetailsComponent } from './components/validate-card-details/validate-card-details.component';
import { KnowOrCreateUsernameComponent } from './components/know-or-create-username/know-or-create-username.component';
import { RegisterForNetbankingComponent } from './components/register-for-netbanking/register-for-netbanking.component';
import { UserPasswordViaPdfComponent } from './components/user-password-via-pdf/user-password-via-pdf.component';
import { NetbankingLockedComponent } from './components/netbanking-locked/netbanking-locked.component';
import { NetbankingAlreadyRegisteredComponent } from './components/netbanking-already-registered/netbanking-already-registered.component';
import { UserPasswordViaPostComponent } from './components/user-password-via-post/user-password-via-post.component';
import { UserPasswordSetNewComponent } from './components/user-password-set-new/user-password-set-new.component';
import { UserPasswordSetNewSuccessComponent } from './components/user-password-set-new-success/user-password-set-new-success.component';
import { UserSessionExpiredComponent } from './components/user-session-expired/user-session-expired.component';
import { SecondFactorAuthenticationOptionsComponent } from './components/second-factor-authentication-options/second-factor-authentication-options.component';
import { MobileBankingInfoComponent } from './components/mobile-banking-info/mobile-banking-info.component';
import { ExpiredMobileBankingComponent } from './components/expired-mobile-banking/expired-mobile-banking.component';
import { KnowOrCreateUsernameSuccessComponent } from './components/know-or-create-username-success/know-or-create-username-success.component';
import { MobileNotUpdatedErrorComponent } from './components/mobile-not-updated-error/mobile-not-updated-error.component';
import { UserPasswordGenerationLockedComponent } from './components/user-password-generation-locked/user-password-generation-locked.component';
import { UserLoginUnsuccessfulComponent } from './components/user-login-unsuccessful/user-login-unsuccessful.component';
import { ValidateCardDetailsLockedComponent } from './components/validate-card-details-locked/validate-card-details-locked.component';
import { ValidateCardDetailsUnsuccessfulComponent } from './components/validate-card-details-unsuccessful/validate-card-details-unsuccessful.component';
import { RegisterWithUsernameComponent } from './components/register-with-username/register-with-username.component';
import { UserOtpLockedComponent } from '../shared/utils/user-otp-locked/user-otp-locked.component';
import { UnableToProcessComponent } from './components/unable-to-process/unable-to-process.component';
import { NetbankingAccessBlockedComponent } from './components/netbanking-access-blocked/netbanking-access-blocked.component';
import { UserPasswordGenerationLockedWrongMobileOtpComponent } from './components/user-password-generation-locked-wrong-mobile-otp/user-password-generation-locked-wrong-mobile-otp.component';
import { KnowOrCreateUsernameSetSuccessComponent } from './components/know-or-create-username-set-success/know-or-create-username-set-success.component';
import { WelcomeBackComponent } from './components/welcome-back/welcome-back.component';
import { UserPasswordUnblockSuccessComponent } from './components/user-password-unblock-success/user-password-unblock-success.component';
import { OprTwiceLockedComponent } from './components/opr-twice-locked/opr-twice-locked.component';
import { SecurityQuestionsComponent } from './components/security-questions/security-questions.component';
import { FatcaDeclarationComponent } from './components/fatca-declaration/fatca-declaration.component';
import { YouAreAllSetComponent } from './components/you-are-all-set/you-are-all-set.component';
import { StayUpdatedCardComponent } from './components/stay-updated-card/stay-updated-card.component';
import { StayChargedCardComponent } from './components/stay-charged-card/stay-charged-card.component';
import { StaySecureCardComponent } from './components/stay-secure-card/stay-secure-card.component';
import { EmergencyCardComponent } from './components/emergency-card/emergency-card.component';
import { SetNicknameComponent } from './components/set-nickname/set-nickname.component';
import { ServiceNotFoundComponent } from '../shared/components/service-not-found/service-not-found.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { SwitchOnInternationalCardsComponent } from './components/switch-on-international-cards/switch-on-international-cards.component';
import { SwitchOnForexCardsComponent } from './components/switch-on-forex-cards/switch-on-forex-cards.component';
import { TwofaRegisterInfoComponent } from './components/twofa-register-info/twofa-register-info.component';
import { TwofaRegisterComponent } from './components/twofa-register/twofa-register.component';
import { AuthenticateUsingOtpComponent } from './components/authenticate-using-otp/authenticate-using-otp.component';
import { RekycCardComponent } from './components/rekyc-card/rekyc-card.component';
import { ForexCardDetailsComponent } from '../onboarding/components/forex-card-details/forex-card-details.component';
import { FatcaSetupComponent } from './components/fatca-setup/fatca-setup.component';
import { MaintenanceCardComponent } from './components/maintenance-card/maintenance-card.component';
import { EnjoyOneTimeTransferCardComponent } from './components/enjoy-one-time-transfer-card/enjoy-one-time-transfer-card.component';
import { SetNetBankingCredentialComponent } from './components/set-net-banking-credential/set-net-banking-credential.component';
import { NetBankingRegistrationSuccessComponent } from './components/net-banking-registration-success/net-banking-registration-success.component';

const routes: Routes = [
    {
        path: '',
        component: LoginComponent,
        children: [
          {
            path: '',
            component: UserDetailsComponent,
            canActivate: [LoginAuthGuardService],
            data: { uri: 'login/crnList', credentialset: 'login/credentialWithUser' }
          },
          {
            path: 'password',
            component: UserPasswordComponent,
          },
          {
            path: 'otp',
            component: UserOtpComponent,
          },
          {
            path: 'knowMyCRN',
            component: KnowMyCrnComponent,
          },
          {
            path: 'generatePassword',
            component: ValidateUserComponent,
          },
          {
            path: 'validateMobileNum',
            component: ValidateMobileNumberComponent,
          },
          {
            path: 'cardNumber',
            component: ValidateCardNumberComponent

          },
          {
            path: 'setNetBankingCredential',
            component: SetNetBankingCredentialComponent
          },
          {
            path: 'crnList',
            component: RemembermeCrnListComponent,
            canActivate: [RememberMeGuardService],
                data: { uri: 'login' }
          },
          {
            path: 'crnListRemove',
            component: RemembermeCrnRemoveComponent,
            canActivate: [RememberMeGuardService],
            data: { uri: 'login' }
          },
          {
            path: 'credentialWithUser',
            component: RemembermeEnterPasswordComponent,
          },
          {
            path: 'crnRemovedSuccess',
            component: RemembermeCrnRemoveSuccessComponent
          },
          {
            path: 'cardDetails',
            component: ValidateCardDetailsComponent
          },
          {
            path: 'knowOrCreateUsername',
            component: KnowOrCreateUsernameComponent
          },
          {
            path: 'registerForNetBanking',
            component: RegisterForNetbankingComponent
          },
          {
            path: 'passwordViaPdfComponent',
            component: UserPasswordViaPdfComponent,
            data: { uri: 'login/passwordviapdf' }
          },
          {
            path: 'netBankingLocked',
            component: NetbankingLockedComponent
          },
          {
            path: 'otpLocked',
            component: UserOtpLockedComponent
          },
          {
            path: 'netBankingAlreadyRegistered',
            component: NetbankingAlreadyRegisteredComponent
          },
          {
            path: 'netBankingRegistrationSuccess',
            component: NetBankingRegistrationSuccessComponent,
          },
          {
            path: 'credentialViaPost',
            component: UserPasswordViaPostComponent
          },
          {
            path: 'setCredential',
            component: UserPasswordSetNewComponent
          },
          {
            path: 'credentialSetSuccess',
            component: UserPasswordSetNewSuccessComponent
          },
          {
            path: 'sessionExpired',
            component: UserSessionExpiredComponent
          },
          {
            path: 'secondFactorAuthenticationOptions',
            component: SecondFactorAuthenticationOptionsComponent
          },
          {
            path: 'mobileBankingInfo',
            component: MobileBankingInfoComponent
          },
          {
            path: 'expiredMobileBanking',
            component: ExpiredMobileBankingComponent
          },
          {
            path: 'usernameInfo',
            component: KnowOrCreateUsernameSuccessComponent
          },
          {
            path: 'mobileNotUpdated',
            component: MobileNotUpdatedErrorComponent
          },
          {
            path: 'onlineCredentialLocked',
            component: UserPasswordGenerationLockedComponent
          },
          {
            path: 'loginUnsuccessful',
            component: UserLoginUnsuccessfulComponent
          },
          {
            path: 'cardDetailsLocked',
            component: ValidateCardDetailsLockedComponent
          },
          {
            path: 'CardDetailsUnsuccessful',
            component: ValidateCardDetailsUnsuccessfulComponent
          },
          {
            path: 'createUsername',
            component: RegisterWithUsernameComponent
          },
          {
            path: 'unableToProcess',
            component: UnableToProcessComponent
          },
          {
            path: 'netBankingAccessBlocked',
            component: NetbankingAccessBlockedComponent
          },
          {
            path: 'credentialreglockwrongmobileotp',
            component: UserPasswordGenerationLockedWrongMobileOtpComponent
          },
          {
            path: 'usernameSetSuccess',
            component: KnowOrCreateUsernameSetSuccessComponent
          },
          {
            path: 'welcomeBack',
            component: WelcomeBackComponent
          },
          {
            path: 'unblockSuccess',
            component: UserPasswordUnblockSuccessComponent
          },
          {
            path: 'oprTwiceLocked',
            component: OprTwiceLockedComponent
          },
          {
            path: 'secretQuestion',
            component: SecurityQuestionsComponent,
          },
          {
            path: 'youareAllset',
            component: YouAreAllSetComponent,
          },
          {
            path: 'stayUpdated',
            component: StayUpdatedCardComponent,
          },
          {
            path: 'stayIncharge',
            component: StayChargedCardComponent,
          },
          {
            path: 'banksafeandSecure',
            component: StaySecureCardComponent,
          },
          {
            path: 'actfastduringEmergency',
            component: EmergencyCardComponent,
          },
          {
            path: 'setNickname',
            component: SetNicknameComponent,
          },
          {
            path: 'fatcaSetup',
            component: FatcaSetupComponent
          },
          {
            path: 'fatcaDeclaration',
            component: FatcaDeclarationComponent
          },
          {
            path: 'serviceNotFound',
            component: ServiceNotFoundComponent,
          },
          {
            path: 'welcome',
            component: WelcomeComponent,
          },
          {
            path: 'switchonInternationalCard',
            component: SwitchOnInternationalCardsComponent,
          },

          {
            path: 'switchonforexCard',
            component: SwitchOnForexCardsComponent,
          },

          {
            path: 'twofaRegister',
            component: TwofaRegisterComponent,
          },

          {
            path: 'twofaRegisterInfo',
            component: TwofaRegisterInfoComponent,
          },
          {
            path: 'authenticateOTP',
            component: AuthenticateUsingOtpComponent,
          },
          {
            path: 'reKyc',
            component: RekycCardComponent,
          },
          {
            path: 'maintenanceCard',
            component: MaintenanceCardComponent,
          },
          {
            path: 'enjoyOneTimeTransfer',
            component: EnjoyOneTimeTransferCardComponent,
          },
        ],
      },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginRoutingModule { }