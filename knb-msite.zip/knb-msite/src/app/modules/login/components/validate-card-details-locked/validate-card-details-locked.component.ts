import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getRemainingDays } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-validate-card-details-locked',
  templateUrl: './validate-card-details-locked.component.html',
  styleUrls: ['./validate-card-details-locked.component.scss']
})
export class ValidateCardDetailsLockedComponent implements OnInit {
  remainingDaysFromStore!: string;

  constructor(private store: Store,
    private router: Router) { }

  ngOnInit(): void {
    this.store.select(getRemainingDays).subscribe((resp) => { this.remainingDaysFromStore = resp; });
  }

  public navigateToPhysicalPin() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.GENERATE_PHYSICAL_PIN_PRINT], { skipLocationChange: environment.skipURI });

  }

}
