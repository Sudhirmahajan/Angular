import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';

import { KnowOrCreateUsernameSetSuccessComponent } from './know-or-create-username-set-success.component';

describe('KnowOrCreateUsernameSetSuccessComponent', () => {
  let component: KnowOrCreateUsernameSetSuccessComponent;
  let fixture: ComponentFixture<KnowOrCreateUsernameSetSuccessComponent>;
  let router:Router

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnowOrCreateUsernameSetSuccessComponent ],
      imports:[RouterTestingModule,    
        TranslateModule.forRoot(),
    ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KnowOrCreateUsernameSetSuccessComponent);
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
   
   });
});
