import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getPageDetails } from 'src/app/auth/auth.index';
import{ preLoginCta} from '../../login-analystics';
import { ConfigService } from  'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-switch-app',
  templateUrl: './switch-app.component.html',
  styleUrls: ['./switch-app.component.scss']
})


export class SwitchAppComponent {

  flag: boolean = true;
  page_name: any;

  constructor(
    private store: Store,
    private router : Router,
    private config: ConfigService,
  ) {}

  public redirectToMobile(): void {
   window.open(environment.redirectToPlayStore, "_blank");
  }

  public redirectToWeb() {
        var cookie = 'fad79ea2166a06e' + '=' + 'fad79ea2166a06e';
        var expiration = new Date();
        expiration.setTime(expiration.getTime() + 5000); // duration in hours
        cookie += '; expires=' + expiration.toUTCString()+';path=/';
       
        
        // Set the cookie
        document.cookie = cookie;
        window.open(this.config.getUrlDomain()+'/knb2/', "_self");
        
  }

  ngOnInit(): void {
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
      if(this.router.url == '/login') {
        this.flag = true;
    }
    else{
        this.flag = false;
    }
  }
  setAnalytics(cta_name:any){
    window.digitalData=preLoginCta({ctaName:cta_name,pageName:this.page_name});
    window._satellite?.track("NB-Msiteclick");
  }
  ngOnDestroy() {
    this.flag = false;
  }
}
