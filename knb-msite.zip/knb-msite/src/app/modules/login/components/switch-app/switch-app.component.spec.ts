import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { SwitchAppComponent } from './switch-app.component';

describe('SwitchAppComponent', () => {
  let component: SwitchAppComponent;
  let fixture: ComponentFixture<SwitchAppComponent>;
  let router :Router


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SwitchAppComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )]
    })
    .compileComponents();


    fixture = TestBed.createComponent(SwitchAppComponent);
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should redirect to mobile', () => {
   spyOn(window, 'open').and.callFake(function () {
        return <any>true;
    });  
    component.redirectToMobile()
    expect(window.open).toHaveBeenCalled();
  
  });

  it('should redirect to Web', () => {
    spyOn(window, 'open').and.callFake(function () {
         return <any>true;
     });  
     component.redirectToWeb()
     expect(window.open).toHaveBeenCalled();
   });

});
