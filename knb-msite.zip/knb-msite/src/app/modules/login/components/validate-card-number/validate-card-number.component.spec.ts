import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { getDisableBackFlag, getDisableMoreOptionsFlag, getFlow, getSecurityQuestionFlag } from 'src/app/auth/auth.index';
import { AuthModule } from 'src/app/auth/auth.module';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { INextOprMethodResponse } from '../../models/login.model';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { ValidateCardNumberComponent } from './validate-card-number.component';

describe('ValidateCardNumberComponent', () => {
  let component: ValidateCardNumberComponent;
  let fixture: ComponentFixture<ValidateCardNumberComponent>;
  let store: MockStore;
  let router :Router;
  let loaderService: jasmine.SpyObj<LoaderService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let loginService: jasmine.SpyObj<LoginService>;
  let errorBeanService: jasmine.SpyObj<ErrorBeanService>;
  const MockPayLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['setMoreLoginOptionsSource', 'generatePayloadForOpr', 'generatePayloadForAuth']);
  const MockPayLoginService = jasmine.createSpyObj('LoginService', ['handleCardNoOpr', 'handleOprAnotherOption']);
  const MockErrorBeanService = jasmine.createSpyObj('ErrorBeanService', ['handleWrongAttempts', 'handleErrorScenariosInLogin']);

  

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ValidateCardNumberComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        HttpClientTestingModule,NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],
      providers:[
        provideMockStore({
          selectors:[
            {
             selector: getDisableBackFlag,
             value: true
            },
            {
              selector: getSecurityQuestionFlag,
              value: true
             },
             {
              selector: getFlow,
              value: true
             },
             {
              selector: getDisableMoreOptionsFlag,
              value: true
             }
          ]
      }),
      { provide: LoaderService, useValue: MockPayLoaderService },
      { provide: PayloadService, useValue: MockPayloadService },
      { provide: LoginService, useValue: MockPayLoginService },
      { provide: ErrorBeanService, useValue: MockErrorBeanService },

      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidateCardNumberComponent);
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    errorBeanService = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    router = TestBed.inject(Router);    
    store=TestBed.inject(MockStore)
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should submit form', () => {
       component.submitForm()
    expect(loaderService.startLoader).toHaveBeenCalled();
    });

  it('should loginWithCard', () => {

     const payload = {
      client_id: "knb2",
      flow: '"FORGOT_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4c8d-a86a-c2394db43d56",
      loginId: "ZmJjOWY3MjQtZWwMy221Mj",
      oprState: "testState",
      cardNumber: "1234 4444 4444 6666",
    }
    
    spyOn<any>(component,'handleCardNumberSuccessResponseInOpr').and.callThrough();
    component.submitForm()
    payloadService.generatePayloadForOpr.and.returnValue(payload);

    loginService.handleCardNoOpr.and.returnValue(of({
      client_id: 'knb2',
      flow: 'FORGOT_CREDENTIAL',
      guid: 'ac5c41f4-e4db-4c8d-a86a-c2394db43d56',
      oprState: 'testState',
      cardNumber: "1234 4444 4444 6666",
      nextScreen: 'DASHBOARD',
      state: "ZmJjOWY3MjQtZWIwMy00Mj"
    }))

    loginService.handleCardNoOpr({
      client_id: 'knb2',
      flow: 'FORGOT_CREDENTIAL',
      guid: 'ac5c41f4-e4db-4c8d-a86a-c2394db43d56',
      oprState: 'testState',
      cardNumber: "1234 4444 4444 6666",
      nextScreen: 'DASHBOARD',
      state: "ZmJjOWY3MjQtZWIwMy00Mj"
    },'/testurl').subscribe({next: () => {
      
    expect(component['handleCardNumberSuccessResponseInOpr']).toHaveBeenCalled;
    
      
   }})
   
  });

  it('should handle another Option', () => {

    const payload = {
      client_id: "knb2",
      flow: '"FORGOT_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4c8d-a86a-c2394db43d56",
      loginId: "ZmJjOWY3MjQtZWwMy221Mj",
      oprState: ""
    }
    component.handleAnotherOption()
    expect(loaderService.startLoader).toHaveBeenCalled();
    payloadService.generatePayloadForOpr.and.returnValue(payload);

    

   });


  it('should call validateOtpWithLogin when throws error', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    
    loginService.handleCardNoOpr.and.returnValue(throwError(() => {
     return {
       error: {
        rmngAtmpts : 0,
        showRecaptcha: 'Y',
        error: {
          errorCode: 'BE0050'
        }
       }
     }
   }))

      
   component.submitForm();
   component.httpSubscription = loginService.handleCardNoOpr({
    client_id: 'sample',
    flow: 'expFlow',
    guid: '2123',
    oprState: 'testState',
    cardNumber: '1123456',
    nextScreen: 'DASHBOARD',
    state: "ZmJjOWY3MjQtZWIwMy00Mj"
      }, '/testurl').subscribe({error: (error) => {

      }})
  
  });


  it('should call handle CardNumber Success Response',()=>{
    (component as any).handleCardNumberSuccessResponseInOpr({ value:['state'] })
    spyOn(store, 'dispatch').and.callThrough();
    })
  
   
   it('should call handle Try Another Option Success',()=>{
    (component as any).handleTryAnotherOptionSuccess({ value:['state'] })
    spyOn(store, 'dispatch').and.callThrough();
    })

   it('should call handle Try Another Option Success if Block',()=>{
     spyOn(store, 'dispatch').and.callThrough();
     (component as any).handleTryAnotherOptionSuccess({questions:{'test': 'abc'}})
     expect(store.dispatch).toHaveBeenCalled();
    })

   it('should get Data From Store',()=>{
    (component as any).getDataFromStore()
    spyOn(store, 'dispatch').and.callThrough();
     }) 
      
});
