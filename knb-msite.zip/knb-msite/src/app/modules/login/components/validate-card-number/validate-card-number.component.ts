import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { BioCatchService, getDisableMoreOptionsFlag, getFlow, getSecurityQuestionFlag, setDisableMoreOptionsFlag, setSecurityQuestions, setServerState, setUserId } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { redirectToValidateCardNo, validateCardNoCtaname } from '../../login-analystics';
import { PATHS, ROUTE_KEY } from '../../login.constant';
import { INextOprMethodRequest, INextOprMethodResponse, IVerifyCardNoRequest, IVerifyCardNoResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-validate-card-number',
  templateUrl: './validate-card-number.component.html',
  styleUrls: ['./validate-card-number.component.scss']
})
export class ValidateCardNumberComponent implements OnInit {
  cardNumberForm!: FormGroup;
  httpSubscription!: Subscription;
  storeFlow!: string;
  storeDisableMoreOptionsFlag!: boolean;
  storeSecurityQuestionFlag!: boolean;
  IVerifyCardNoRequest: any;

  constructor(
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private store: Store,
    private router: Router,
    private bioCatchService: BioCatchService
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_OPR_CARD_NUM);
    this.getDataFromStore();
    this.cardNumberForm = new FormGroup({
      cardNo: new FormControl('', [Validators.required, Validators.maxLength(29), Validators.minLength(16)]),
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToValidateCardNo
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=validateCardNoCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

  submitForm() {
    this.loaderService.startLoader();
    const inputField = { cardNumber: this.cardNumberForm.controls['cardNo'].value.split(" ").join("") };
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField);
    if (reqPayload as unknown as IVerifyCardNoRequest) {
      this.httpSubscription = this.loginService.handleCardNoOpr(reqPayload as unknown as IVerifyCardNoRequest, PATHS.verifyCardNumber)
        .subscribe({ next: (resp: IVerifyCardNoResponse) => {
          this.handleCardNumberSuccessResponseInOpr(resp);
        }, error: () => {
          this.loaderService.stopLoader();
          this.cardNumberForm.reset();
        }});
    }
  }

  private handleCardNumberSuccessResponseInOpr(resp: IVerifyCardNoResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value:  resp['state']}))
    this.store.dispatch(setUserId({ value:  resp['cardNumber']}));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  handleAnotherOption() {
    this.loaderService.startLoader();
    const reqPayload = this.payloadService.generatePayloadForOpr();
    if (reqPayload as unknown as INextOprMethodRequest) {
      this.httpSubscription = this.loginService.handleOprAnotherOption(reqPayload as unknown as INextOprMethodRequest, PATHS.oprMfaOptions)
        .subscribe((resp: INextOprMethodResponse) => {
          this.handleTryAnotherOptionSuccess(resp);
        });
    }
  }

  private handleTryAnotherOptionSuccess(resp: INextOprMethodResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value: resp['state'] }));
    this.store.dispatch(setDisableMoreOptionsFlag({ value: resp['disableMoreOption']}));
    if (resp['questions']) {
      this.store.dispatch(setSecurityQuestions( { value: resp['questions']} ));
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }


  private getDataFromStore() {
    this.store.select(getSecurityQuestionFlag).subscribe((resp) => { this.storeSecurityQuestionFlag = resp; });
    this.store.select(getFlow).subscribe((resp) => { this.storeFlow = resp; });
    this.store.select(getDisableMoreOptionsFlag).subscribe((resp) => { this.storeDisableMoreOptionsFlag = resp; });
  }

}
