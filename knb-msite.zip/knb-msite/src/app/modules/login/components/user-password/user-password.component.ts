import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { BioCatchService, ConfigService, getAuthMethod, getFlow, getMsiteAuthMethod, getMsiteFlow, getMsiteUserID, getpartyDetails, getRecaptcha, getUserId, NavigationService, setAccessToken, setEmail, setFlow, setGUID, setIsdCode, setMobileNumber, setMsiteFlow, setRecaptcha, setServerState, setServiceId, setTwoFaAuthOptions } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { FLOWS, PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS, SERVICE_ID } from '../../login.constant';
import { IAccessTokenAndCustomerInfoResp, IAccessTokenAndOnboardingResp, IAuthSuccessResp, IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { SetTrustedDeviceIdService } from 'src/app/modules/shared/services/set-trusted-deviceid/set-trusted-deviceid.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { InvisibleReCaptchaComponent } from 'ngx-captcha';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { redirectToUserPassword, userPasswordCtaname } from '../../login-analystics';
import { GetPartyDataService } from 'src/app/modules/shared/services/get-party-data/get-party-data.service';

@Component({
  selector: 'app-user-password',
  templateUrl: 'user-password.component.html',
  styleUrls: ['user-password.component.scss'],
  providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}]
})
export class UserPasswordComponent implements OnInit, OnDestroy {
  userPasswordForm!: FormGroup;
  hide: boolean = true;
  userId!: string;
  httpSubscription!: Subscription;
  dna:any;
  userIdType!: string;
  forgotPassword: boolean = false;
  remainingAttemts!: number | undefined;
  showGoogleCaptcha!: boolean;
  showCredentialPolicyError!: boolean;
  @ViewChild('captchaElem') captchaElem!: InvisibleReCaptchaComponent;
  public gck!: string;
  errorType: string = 'PASSWORD';
  partyData: any;
  flow !: string;
  authMethod !: String;
  msiteUserId!: string;
  msiteFlow!: string;
  msiteAuthMethod!: string;

  constructor(private store: Store,
    private loginService: LoginService,
    private payloadService: PayloadService,
    private loaderService: LoaderService,
    private setTrustedDeviceIdService: SetTrustedDeviceIdService,
    private rememberMeService: RememberMeService,
    private router: Router,
    public navigation: NavigationService,
    private setOnboardCardService: SetOnboardCardService,
    private errorBeanService : ErrorBeanService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private configService: ConfigService,
    private bioCatchService: BioCatchService,
    private getPartyDataService: GetPartyDataService,
    ) { }

  ngOnDestroy(): void {
    this.httpSubscription && this.httpSubscription.unsubscribe();
  }

  ngOnInit(): void {
    this.setAnalytics('');
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_LOGIN_PASSWD);
    this.gck = this.configService.getGck();
    this.store.select(getUserId).subscribe(userId => {
      const userDetailsArr = userId.split('|')
      this.userId = userDetailsArr[0];
      this.userIdType = userDetailsArr[1];
    });

    this.store.select(getMsiteUserID).subscribe((data) => {
      this.msiteUserId = data;
  });

    this.store.select(getRecaptcha).subscribe((value) => {
      if (value === 'Y') {
        this.showGoogleCaptcha = true;
      }
    });

    this.userPasswordForm = new FormGroup({
      password: new FormControl(''),
      recaptcha: new FormControl('')
    });

    this.store.select(getpartyDetails).subscribe((data) => {
      this.partyData = data;
    });

    this.store.select(getFlow).subscribe((data) => {
      this.flow = data;
    });

    this.store.select(getMsiteFlow).subscribe((data) => {
      this.msiteFlow = data;
    });

    this.store.select(getMsiteAuthMethod).subscribe((data) => {
      this.msiteAuthMethod = data;
    });
    
    this.store.select(getAuthMethod).subscribe((data) => {
      this.authMethod = data;
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserPassword
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=userPasswordCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 

  public getDna(dna: any) {
    this.dna = dna;
  }

  public submitForm() {
    (this.showGoogleCaptcha) ? this.captchaElem.execute() : this.validateCredential();
  }

  public handleSuccess(captchaResponse: string): void {
    if (captchaResponse) {
      this.validateCredential(captchaResponse);
    }
  }

  validateCredential = (captchaResponse?: string) => {
    let reqPayload = this.payloadService.
      generatePayloadForAuth(SCREEN_ROUTING_KEYS.CREDENTIAL, this.userPasswordForm.controls['password'].value);
    if (captchaResponse) {
      reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
    }
    const additionalPayloadForTrustedDevice = {
      mfp: this.dna,
      deviceOS: window['jscd']['os'],
      browser: window['jscd']['browser']
    };
    reqPayload = { ...reqPayload, ...additionalPayloadForTrustedDevice };
    const deviceIdFromLocalStorage = localStorage.getItem('RISKFORT_COOKIE');
    if (deviceIdFromLocalStorage) {
      reqPayload = { ...reqPayload, ...{ deviceId: deviceIdFromLocalStorage } };
    }

    const riskFortValue = localStorage.getItem('RISKFORT_COOKIE');
    if (riskFortValue) {
      reqPayload = { ...reqPayload, ...{ riskFort: riskFortValue } };
    }
    //Creating payload for generic party data
    const payloadForValidUser = this.payloadService.generatePayloadForLogin(this.msiteUserId, 'N');
    if (reqPayload) {
      this.loaderService.startLoader();
      this.httpSubscription = this.loginService.validatePwd(reqPayload, PATHS.authenticate)
        .subscribe({next: (resp: (IAccessTokenAndCustomerInfoResp | IAccessTokenAndOnboardingResp | IAuthSuccessResp)) => {
          this.loaderService.stopLoader();

           const callback = (partyDataFlag: any) => {
          
            if(partyDataFlag) {
              this.handleValidateCredentilSuccessResponse(resp);
            } else {
              this.loaderService.stopLoader();
              this.router.navigateByUrl(ROUTE_KEY['SERVICE_NOT_FOUND'], { skipLocationChange: environment.skipURI });
            }
          }
          this.getPartyDataService.getPartyData(payloadForValidUser,'N', this.msiteFlow, this.msiteAuthMethod, callback);
        
        }, error: (error: HttpErrorResponse) => {
                this.setAnalytics('pwdFail');
                this.handleErrorScenarios(error);
              }});
          }
  }

  generatePassword = () => {
    this.forgotPassword = true;

    this.loaderService.startLoader();
    this.store.dispatch(setFlow({ value: FLOWS.forgotCredential}));
    const inputField = { loginId: this.userId };
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true);
    if (reqPayload as IVerifyCrnRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe({ next: (verifyCrnResponse: IVerifyCrnResponse) => {
          this.flow = verifyCrnResponse.flow;
          this.store.dispatch(setMsiteFlow({ value: verifyCrnResponse.flow}));
          this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_GENERATE_PASSWD);
          this.handleForgotCRedentialSuccessResponse(verifyCrnResponse);

        }, error: (err: HttpErrorResponse) => {
            this.handleErrorScenarios(err);
        }});
    }

  };

  private handleErrorScenarios(error: HttpErrorResponse) {
    this.loaderService.stopLoader();
    if(error.error.error.errorMessage === "Otp not allowed"){
      this.payloadService.setMoreLoginOptionsSource('OTP');
    }
    if (error.error['twoFaOptions'] && error.error['twoFaOptions'].length > 1) {
      this.store.dispatch(setTwoFaAuthOptions({ value: error.error['twoFaOptions'] }))
    }
    this.remainingAttemts = this.errorBeanService.handleErrorScenariosInLogin(error);
    if (error.error['showRecaptcha'] === 'Y') {
      this.showGoogleCaptcha = true;
    }
    this.userPasswordForm.reset();
    let loginId = 'Card'
    if (this.userIdType) {
      loginId = this.userIdType;
    } else {
      loginId = 'Login_pwd' + loginId;
    }
    //BE0019 - check error code
    if (error.error.errorCode === 'BE0044') {
      this.showCredentialPolicyError = true;
    }

  }

  private handleForgotCRedentialSuccessResponse(resp: IVerifyCrnResponse) {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    let loginId = 'NA'
    if (this.userIdType) {
      loginId = this.userIdType;
    } else {
      loginId = 'Login_pwd' + loginId;
    }
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  handleValidateCredentilSuccessResponse(resp: any) {
    this.setAnalytics('pwdSucc');
    this.store.dispatch(setServiceId({value: SERVICE_ID.credentialFlow}));
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.loginService.onBoardingFlag(resp);
    let loginId = 'NA'
    if (this.userIdType) {
      loginId = this.userIdType;
    } else {
      loginId = 'Login_pwd' + loginId;
    }
    if (resp['saveDeviceId'] === 'Y') {
      this.setTrustedDeviceIdService.setDeviceId(resp['deviceId']);
    }
    (resp['accessToken']) ? this.handleAccessTokenResponse(resp) : this.handleSecondFactorAuthenticationResponse(resp);
  }

  handleAccessTokenResponse(resp: any) {
    if (resp['customerInfo']) {
      this.rememberMeService.handleRememberMe(resp['customerInfo']);
    }
    this.store.dispatch(setAccessToken({value: resp['accessToken']}));
    if (resp['onboarding'] === 'Y') {
      this.setOnboardCardService.checkUserOnboarded(resp['onboarding']);
    } else {
      this.router.navigate(['onboarding'], { skipLocationChange: environment.skipURI });
    }
  }

  handleSecondFactorAuthenticationResponse(resp: any) {
    this.store.dispatch(setEmail({value: resp['emailId']}));
    this.store.dispatch(setMobileNumber({value: resp['mobilenNumber']}));
    this.store.dispatch(setIsdCode({value: resp['isdCode']}));
    this.store.dispatch(setServerState({value: resp['state']}));
   
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}));
    }
    console.log("Inside handleSecondFactorAuthenticationResponse :: >>"); 
    (resp['authMethod']) ? this.router.navigateByUrl(ROUTE_KEY[resp['authMethod']], { skipLocationChange: environment.skipURI }) :
      console.log("Before findTwoFactorOptions"); 
    this.findTwoFactorOptions(resp['twoFaOptions']);
  }

  private findTwoFactorOptions(twoFactorOptions: [{prefferdTwoFaFlag: string, twoFaMethodLuCode: string}]) {
    const preferredTwoFactorOption = twoFactorOptions.find((option) => {
      return option['prefferdTwoFaFlag'] === 'Y';
    });
    // here we will check or msite access based on TWOFactorOption
    console.log("Before check TOTP");
    if((preferredTwoFactorOption?.twoFaMethodLuCode == 'TOTP' && preferredTwoFactorOption?.prefferdTwoFaFlag == 'Y') || (preferredTwoFactorOption?.twoFaMethodLuCode == 'MOB_APP_LOGIN' && preferredTwoFactorOption?.prefferdTwoFaFlag == 'Y')){
        this.loaderService.stopLoader();
        console.log("Inside if TOTP");
        this.router.navigateByUrl(ROUTE_KEY['SERVICE_NOT_FOUND'], { skipLocationChange: environment.skipURI });
    } else {
      console.log("Inside else TOTP");
      if (preferredTwoFactorOption) {
        preferredTwoFactorOption['twoFaMethodLuCode'] == 'OTP' && this.router.navigateByUrl(ROUTE_KEY['OTP'], { skipLocationChange: environment.skipURI });
      }
      if (twoFactorOptions.length > 1) {
        this.store.dispatch(setTwoFaAuthOptions({value: twoFactorOptions}));
      }
    }
      
  }

}
