import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { AuthenticationService, AuthModule, ConfigService, getRecaptcha, getUserId } from 'src/app/auth/auth.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { SetTrustedDeviceIdService } from 'src/app/modules/shared/services/set-trusted-deviceid/set-trusted-deviceid.service';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';

import { UserPasswordComponent } from './user-password.component';

describe('UserPasswordComponent', () => {
   
  let component: UserPasswordComponent;
  let fixture: ComponentFixture<UserPasswordComponent>;
  let store: MockStore;
  let router: Router;
  const MockLoginService = jasmine.createSpyObj('LoginService', ['validatePwd', 'handleOpr', 'onBoardingFlag']);
  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['generatePayloadForAuth', 'generatePayloadForOpr', 'setMoreLoginOptionsSource']);
  const MockAuthenticationService = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  const MockBundleLoaderInitializerService = jasmine.createSpyObj('BundleLoaderInitializerService', ['startWatchingIdle', 'changeBundleLoaderStatus']);
  const MockMatDialog = jasmine.createSpyObj('MatDialog', ['open']);
  const MockLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  const MockConfigService = jasmine.createSpyObj('ConfigService', ['getGck']);
  const MockSetTrustedDeviceIdService = jasmine.createSpyObj('SetTrustedDeviceIdService', ['setDeviceId']);
  const MockRememberMeService = jasmine.createSpyObj('RememberMeService', ['handleRememberMe']);
  const MockSetOnboardCardService = jasmine.createSpyObj('SetOnboardCardService', ['checkUserOnboarded']);
  let loginService: jasmine.SpyObj<LoginService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let loaderService: jasmine.SpyObj<LoaderService>;
  let configService: jasmine.SpyObj<ConfigService>;
  let bundleLoaderInitializerService: jasmine.SpyObj<BundleLoaderInitializerService>;
  let rememberMeService: jasmine.SpyObj<RememberMeService>;
  let setOnboardCardService: jasmine.SpyObj<SetOnboardCardService>;
  let authenticationService; let matDialog; 

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ UserPasswordComponent ],
      providers: [
        { provide: LoginService, useValue: MockLoginService },
        { provide: PayloadService, useValue: MockPayloadService },
        { provide: ConfigService, useValue: MockConfigService },
        { provide: AuthenticationService, useValue: MockAuthenticationService },
        { provide: MatDialog, useValue: MockMatDialog },
        { provide: BundleLoaderInitializerService, useValue: MockBundleLoaderInitializerService },
        { provide: LoaderService, useValue: MockLoaderService },
        { provide: SetTrustedDeviceIdService, useValue: MockSetTrustedDeviceIdService },
        { provide: RememberMeService, useValue: MockRememberMeService },
        { provide: SetOnboardCardService, useValue: MockSetOnboardCardService },
        provideMockStore({
          selectors: [
            {
              selector: getUserId,
              value: '12013126'
            },
            {
              selector: getRecaptcha,
              value: 'Y'  
            }
          ]
        })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordComponent);
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    configService = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    rememberMeService = TestBed.inject(RememberMeService) as jasmine.SpyObj<RememberMeService>;
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    authenticationService = TestBed.inject(AuthenticationService);
    matDialog = TestBed.inject(MatDialog);
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    configService.getGck.and.returnValue('test-gck')
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(component.gck).toEqual('test-gck');
    expect(configService.getGck).toHaveBeenCalled();
  });

  it('should get user id', () => {
    component.showGoogleCaptcha = true;
    fixture.detectChanges();
    expect(configService.getGck).toHaveBeenCalled();
    store.select(getUserId).subscribe(userId => {
      expect(component.userId).toEqual(userId);
    });

    store.select(getRecaptcha).subscribe(value => {
      expect(component.showGoogleCaptcha).toBe(true);
    });
  });

  it('should get dna', () => {
    component.getDna('test-dna');
    expect(component.dna).toEqual('test-dna');
  });

  // it('should submit form when user enters passworda and captcha is disable', () => {
  //   component.showGoogleCaptcha = false;
  //   let rendered!:Renderer2;
  //   let zone!:NgZone;
  //   let injector!: Injector;
  //   let scriptService!: ScriptService
  //   let captchaElem = new InvisibleReCaptchaComponent(rendered, zone, injector, scriptService);
  //   spyOn(captchaElem, 'execute');
  //   spyOn(component, 'validateCredential');

  //   component.submitForm();

  //   expect(component.validateCredential).toHaveBeenCalled();
  // });

  it('should handle captcha success', () => {
    spyOn(component, 'validateCredential');

    component.handleSuccess('true');

    expect(component.validateCredential).toHaveBeenCalled();
  })

  it('should validate Credential when success', () => {
    window.jscd = {
      os: '',
      browser: ''
    }
    const resp = {
      accessToken: "NDUzYzZmNmQtYjhjNy00ZDB",
      onboarding: "Y",
      customerInfo: {
        encryptedcrn: "NDUzYzZmNmQtYjhjNy00ZDB",
        maskcrn: '9•••••25',
        nickname: 'test',
        image: 'test',
        initials: 'AB',
      }
    }

    fixture.detectChanges();
    component.userPasswordForm.patchValue({
      password: 'Querty123'
    })
    payloadService.generatePayloadForAuth.and.returnValue({
      authMethod: "CREDENTIAL",
      client_id: "knb2",
      credential: "FHNDRtJS313ifGWM9uTm",
      guid: "6b9bf27c-2e95-4a91-8844-023bdd2b1e76",
      rememberMeFlag: "N",
      state: "ZmJjOWY3MjQtZWIwMy00Mj"
    });
    spyOn(store, 'dispatch');
    spyOn(component, 'handleValidateCredentilSuccessResponse');
    loginService.validatePwd.and.returnValue(of(resp))
    component.validateCredential('GGh787HHG5trI');
    loginService.validatePwd({client_id: '122334',
      state: 'FHNDRtJS313ifGWM9uTm',
      authMethod: 'OTP',
      guid: 'GHHD67rtyyUYU',
      credential: 'GHJGKJS663hjk77',
      rememberMeFlag: 'y',
    }, '').subscribe({next: resp => {
      expect(component.handleValidateCredentilSuccessResponse).toHaveBeenCalled();
    }})

  })

  it('should validate Credential when error', () => {
    window.jscd = {
      os: '',
      browser: ''
    }
    localStorage.setItem('RISKFORT_COOKIE', 'test');
    const resp = {
      accessToken: "NDUzYzZmNmQtYjhjNy00ZDB",
      onboarding: "Y",
      customerInfo: {
        encryptedcrn: "NDUzYzZmNmQtYjhjNy00ZDB",
        maskcrn: '9•••••25',
        nickname: 'test',
        image: 'test',
        initials: 'AB',
      }
    }
    fixture.detectChanges();
    component.userPasswordForm.patchValue({
      password: 'Querty123'
    })
    payloadService.generatePayloadForAuth.and.returnValue({
      authMethod: "CREDENTIAL",
      client_id: "knb2",
      credential: "FHNDRtJS313ifGWM9uTm",
      guid: "6b9bf27c-2e95-4a91-8844-023bdd2b1e76",
      rememberMeFlag: "N",
      state: "ZmJjOWY3MjQtZWIwMy00Mj"
    });
    spyOn<any>(component, 'handleErrorScenarios');
    loginService.validatePwd.and.returnValue(throwError(() => null))
    component.validateCredential('GGh787HHG5trI');
    loginService.validatePwd({client_id: '122334',
      state: 'FHNDRtJS313ifGWM9uTm',
      authMethod: 'OTP',
      guid: 'GHHD67rtyyUYU',
      credential: 'GHJGKJS663hjk77',
      rememberMeFlag: 'y',
    }, '').subscribe({error: () => {
      expect(component['handleErrorScenarios']).toHaveBeenCalled();
    }})
  })

  it('should generate password when success and user type is known', () => {
    component.userId = '12013126';
    component.userIdType = 'CRN';
    const payload = {
      client_id: "knb2",
      flow: '"FORGOT_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4c8d-a86a-c2394db1ad56",
      loginId: "ZmJjOWY3MjQtZWIwMy00Mj",
      oprState: ""
    }
    spyOn(store, 'dispatch');
    spyOn<any>(component, 'handleForgotCRedentialSuccessResponse').and.callThrough();
    payloadService.generatePayloadForOpr.and.returnValue(payload);

    loginService.handleOpr.and.returnValue(of({
      flow: 'FORGOT_CREDENTIAL',
      guid: 'ac5c41f4-e4db-4c8d-a86a-c2394db1ad56',
      nextScreen: 'MOBILE',
      state: 'MWQwMTBmZjUtNDI3MS00NTA5LWExOT',
      showRecaptcha: 'Y'
    }))
    component.generatePassword();

    loginService.handleOpr(payload, '').subscribe({next: resp => {
      expect(resp.nextScreen).toEqual('MOBILE')
      expect(component['handleForgotCRedentialSuccessResponse']).toHaveBeenCalled();
    }})
  })

  it('should generate password when success and user type is not known', () => {
    component.userId = '12013126';
    const payload = {
      client_id: "knb2",
      flow: '"FORGOT_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4c8d-a86a-c2394db1ad56",
      loginId: "ZmJjOWY3MjQtZWIwMy00Mj",
      oprState: ""
    }
    spyOn(store, 'dispatch');
    spyOn<any>(component, 'handleForgotCRedentialSuccessResponse').and.callThrough();
    payloadService.generatePayloadForOpr.and.returnValue(payload);
    loginService.handleOpr.and.returnValue(of({
      flow: 'FORGOT_CREDENTIAL',
      guid: 'ac5c41f4-e4db-4c8d-a86a-c2394db1ad56',
      nextScreen: 'MOBILE',
      state: 'MWQwMTBmZjUtNDI3MS00NTA5LWExOT',
      showRecaptcha: 'Y'
    }))
    component.generatePassword();

    loginService.handleOpr(payload, '').subscribe({next: resp => {
      expect(resp.nextScreen).toEqual('MOBILE')
      expect(component['handleForgotCRedentialSuccessResponse']).toHaveBeenCalled();
    }})
  })

  it('should generate password when error', () => {
    fixture.detectChanges();
    component.userId = '12013126';
    const payload = {
      client_id: "knb2",
      flow: '"FORGOT_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4c8d-a86a-c2394db1ad56",
      loginId: "ZmJjOWY3MjQtZWIwMy00Mj",
      oprState: ""
    }

    const error = new HttpErrorResponse({
      error:{
          twoFaOptions:'Y',
          error: {
              errorCode : 'BE0044',
              errorMessage : 'Otp not allowed'
          },
          showRecaptcha: 'Y'
          
      }
    });
    spyOn(store, 'dispatch');
    spyOn<any>(component, 'handleForgotCRedentialSuccessResponse');
    spyOn<any>(component, 'handleErrorScenarios').and.callThrough();
    payloadService.generatePayloadForOpr.and.returnValue(payload);
    loginService.handleOpr.and.returnValue(throwError(() => error))
    component.generatePassword();

    loginService.handleOpr(payload, '').subscribe({error: (error) => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
    }})
  })

  it('should generate password when error due to twoFaOptions', () => {
    fixture.detectChanges();
    component.userId = '12013126';
    component.userIdType = 'CRN';
    const payload = {
      client_id: "knb2",
      flow: '"FORGOT_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4c8d-a86a-c2394db1ad56",
      loginId: "ZmJjOWY3MjQtZWIwMy00Mj",
      oprState: ""
    }

    const error = new HttpErrorResponse({
      error:{
          error: {
            errorMessage : 'Otp not allowed'
          },
          twoFaOptions: [{
            OTP: 'Y'
          }, {
            APP: 'N'
          }],
          errorCode : 'BE0044',
          showRecaptcha: 'Y'
          
      }
    });
    spyOn(store, 'dispatch').and.callThrough();
    spyOn<any>(component, 'handleForgotCRedentialSuccessResponse');
    spyOn<any>(component, 'handleErrorScenarios').and.callThrough();
    payloadService.generatePayloadForOpr.and.returnValue(payload);
    loginService.handleOpr.and.returnValue(throwError(() => error))
    component.generatePassword();

    loginService.handleOpr(payload, '').subscribe({error: (error) => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
    }})
  })

  it('should validate credential success response', () => {
    spyOn(store, 'dispatch')
    spyOn(component, 'handleAccessTokenResponse')
    spyOn(component, 'handleSecondFactorAuthenticationResponse')
    component.handleValidateCredentilSuccessResponse({saveDeviceId: 'Y', accessToken: 'GGGDhj4jjhg'});
    expect(store.dispatch).toHaveBeenCalled();
    expect(loginService.onBoardingFlag).toHaveBeenCalled();
    expect(bundleLoaderInitializerService.startWatchingIdle).toHaveBeenCalled();
  })

  it('should validate credential success response when access token is not available', () => {
    spyOn(store, 'dispatch')
    spyOn(component, 'handleAccessTokenResponse')
    spyOn(component, 'handleSecondFactorAuthenticationResponse')
    component.userIdType = 'CRN';
    component.handleValidateCredentilSuccessResponse({saveDeviceId: 'Y', accessToken: ''});
    expect(store.dispatch).toHaveBeenCalled();
    expect(loginService.onBoardingFlag).toHaveBeenCalled();
    expect(bundleLoaderInitializerService.startWatchingIdle).toHaveBeenCalled();
  })

  it('should handle access token response', () => {
    spyOn(store, 'dispatch');
    component.handleAccessTokenResponse({ customerInfo: { test: 'abc'}, onboarding: 'Y' });

    expect(store.dispatch).toHaveBeenCalled();
    expect(rememberMeService.handleRememberMe).toHaveBeenCalled();
    expect(setOnboardCardService.checkUserOnboarded).toHaveBeenCalled();
  })

  it('should handle access token response when onboarding flag is N', () => {
    spyOn(store, 'dispatch');
    component.handleAccessTokenResponse({ customerInfo: { test: 'abc'}, onboarding: 'N' });

    expect(store.dispatch).toHaveBeenCalled();
    expect(rememberMeService.handleRememberMe).toHaveBeenCalled();
  })

  it('should handle second factor authentication response', () => {
    spyOn(store, 'dispatch');
    component.handleSecondFactorAuthenticationResponse({ showRecaptcha: 'Y', authMethod: 'OTP' });
    expect(store.dispatch).toHaveBeenCalled();
  })

  it('should handle second factor authentication response', () => {
    spyOn(store, 'dispatch');
    component.handleSecondFactorAuthenticationResponse({ showRecaptcha: 'Y', authMethod: '', twoFaOptions: [{prefferdTwoFaFlag: 'Y', twoFaMethodLuCode: 'OTP'}, {prefferdTwoFaFlag: 'Y', twoFaMethodLuCode: 'APP'}] });
    expect(store.dispatch).toHaveBeenCalled();
  })
});
