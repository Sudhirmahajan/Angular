import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DataEmitterService } from 'src/app/auth/services/data-emitter/data-emitter.service';
import { environment } from 'src/environments/environment';
import { redirectToUserNameInfo, usernameInfoCtaname } from '../../login-analystics';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-know-or-create-username-success',
  templateUrl: './know-or-create-username-success.component.html',
  styleUrls: ['./know-or-create-username-success.component.scss']
})
export class KnowOrCreateUsernameSuccessComponent implements OnInit {

  public username!: string;
  subscription!: Subscription;

  constructor(
    private dataEmitterService: DataEmitterService,
    private router: Router
  ) { }

  ngOnInit() {
      this.setAnalytics('');
      this.subscription = this.dataEmitterService.on('username').subscribe({
      next: (resp: any) => this.username = resp
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserNameInfo
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=usernameInfoCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  
 }

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }
}
