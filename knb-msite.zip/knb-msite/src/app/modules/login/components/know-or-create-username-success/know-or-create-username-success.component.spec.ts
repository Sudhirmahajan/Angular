import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { DataEmitterService } from 'src/app/auth/services/data-emitter/data-emitter.service';
import { KnowOrCreateUsernameSuccessComponent } from './know-or-create-username-success.component';

describe('KnowOrCreateUsernameSuccessComponent', () => {
  let component: KnowOrCreateUsernameSuccessComponent;
  let fixture: ComponentFixture<KnowOrCreateUsernameSuccessComponent>;
  let router:Router
  let service: DataEmitterService;


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnowOrCreateUsernameSuccessComponent ],
      imports:[RouterTestingModule,  
        TranslateModule.forRoot(),
    ],

  })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KnowOrCreateUsernameSuccessComponent);
    service = TestBed.inject(DataEmitterService);
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
    
})

it('should check broadcast and on functions', () => {
  service.broadcast('username', 'test data');
  component.ngOnInit()
  service.on('username').subscribe((response) => {
      expect(response).toEqual('test data');
    });
});

});
