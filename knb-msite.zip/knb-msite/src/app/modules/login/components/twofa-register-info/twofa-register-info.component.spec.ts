import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwofaRegisterInfoComponent } from './twofa-register-info.component';

describe('TwofaRegisterInfoComponent', () => {
  let component: TwofaRegisterInfoComponent;
  let fixture: ComponentFixture<TwofaRegisterInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TwofaRegisterInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TwofaRegisterInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
