import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore } from '@ngrx/store/testing';
import { NgxCaptchaModule } from 'ngx-captcha';
import { CountdownModule } from 'ngx-countdown';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';
import { AuthenticationService, AuthModule, BioCatchService, ConfigService, NavigationService } from 'src/app/auth/auth.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { PATHS } from '../../login.constant';
import { ILoginSuccessResp } from '../../models/login.model';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';

import { RemembermeEnterPasswordComponent } from './rememberme-enter-password.component';

describe('RemembermeEnterPasswordComponent', () => {
  let component: RemembermeEnterPasswordComponent;
  let fixture: ComponentFixture<RemembermeEnterPasswordComponent>;
  
  let router : Router;
  let store: MockStore;
  
  let configObj = jasmine.createSpyObj('ConfigService', ['getGck']);
  let service: jasmine.SpyObj<ConfigService>;
  
  let authenticationObj = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  let authenticationService : jasmine.SpyObj<AuthenticationService>;
  
  let loginObj = jasmine.createSpyObj('LoginService',['handleLoginCaptcha','validateUserName','handleOpr','validateRememberMePwd']);
  let loginService : jasmine.SpyObj<LoginService>;

  let loaderObj = jasmine.createSpyObj('LoaderService',['handleLoginCaptcha','stopLoader','startLoader']);
  let loaderService : jasmine.SpyObj<LoaderService>;
  
  let payloadObj = jasmine.createSpyObj('PayloadService',['generatePayloadForCrnList','generatePayloadForOpr','generatePayloadForAuth','generatePayloadForRememberMeOpr']);
  let payloadService : jasmine.SpyObj<PayloadService>;

 // let navigatioObj = jasmine.createSpyObj('NavigationService',[]);
 // let navigationService : jasmine.SpyObj<NavigationService>;

  let setOnboardCardObj = jasmine.createSpyObj('SetOnboardCardService',['checkUserOnboarded']);
  let setOnboardCardService : jasmine.SpyObj<SetOnboardCardService>;

  let rememberMeObj = jasmine.createSpyObj('RememberMeService',['useAnotherAccountFlag']);
  let rememberMeService : jasmine.SpyObj<RememberMeService>;

  let errorBeanObj  = jasmine.createSpyObj('ErrorBeanService',['handleErrorScenariosInLogin']);
  let errorBeanService : jasmine.SpyObj<ErrorBeanService>;

  let bundleLoaderInitializerObj = jasmine.createSpyObj('BundleLoaderInitializerService',['changeBundleLoaderStatus','startWatchingIdle']);
  let bundleLoaderInitializerService : jasmine.SpyObj<BundleLoaderInitializerService>;

  let bioCatchObj  = jasmine.createSpyObj('BioCatchService',['biocatchSetValues']);
  let bioCatchService : jasmine.SpyObj<BioCatchService>;


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        CountdownModule,
        NgxCaptchaModule],

      declarations: [ RemembermeEnterPasswordComponent ],
      providers:[
        { provide : AuthenticationService ,useValue : authenticationObj},
        { provide: ConfigService, useValue: configObj },
        { provide : LoginService , useValue : loginObj },
        { provide : PayloadService, useValue : payloadObj},
        { provide : LoaderService, useValue : loaderObj},
    //    { provide : NavigationService, useValue : navigatioObj},
        { provide : SetOnboardCardService, useValue : setOnboardCardObj},
        { provide : RememberMeService, useValue : rememberMeObj},
        { provide : ErrorBeanService, useValue : errorBeanObj},
        { provide : BundleLoaderInitializerService, useValue : bundleLoaderInitializerObj},
        { provide : BioCatchService, useValue : bioCatchObj},

      ]

    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemembermeEnterPasswordComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>
    authenticationService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
 //   navigationService = TestBed.inject(NavigationService) as jasmine.SpyObj<NavigationService>;
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    rememberMeService = TestBed.inject(RememberMeService) as jasmine.SpyObj<RememberMeService>;
    errorBeanService = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;
    router = TestBed.inject(Router);
    store = TestBed.inject<Store>(Store) as MockStore<any>;
  });

  it('should create', () => {
    spyOn(component,'getCaptcha');
   // expect(service.getGck()).toHaveBeenCalled()
   fixture.detectChanges();
   (component as any).bioCatchService.biocatchSetValues('',"");
    expect(component).toBeTruthy();
  });

  it('should call getCaptcha', () => {
    let data ={ ad : ''}
    let payload = { key: '' };
    let path = '/login'
    loginService.handleLoginCaptcha.and.returnValue(of(data));
    component.getCaptcha()
    loginService.handleLoginCaptcha(payload, path).subscribe({
      next: (resp) => {
        expect(resp).toBe(data);
      }
    })

   });

   it('should call getCaptcha error',()=>{
      let data ={ ad : ''}
      let payload = { key: '' };
      let path = '/login';
      component.userPasswordForm = new FormGroup({
        password: new FormControl(''),
        captchaElement: new FormControl('', [Validators.minLength(5), Validators.maxLength(5)])
      });
     // spyOn(userPasswordForm,'reset')

      loginService.handleLoginCaptcha.and.returnValue(throwError( () => {
        return {
          error: {
            showRecaptcha: 'Y',
            error: {
              errorCode: 'BE0047'
            }
          }
        }
      }))
      component.getCaptcha();
      loginService.handleLoginCaptcha({}, path).subscribe({ error: (error) => {
        expect(component.showCaptcha).toBeTrue
      } })
   })

  



  it('should call submitForm',() => {
    spyOn(component,'validateCredential')
    component.submitForm();
    expect(component.validateCredential).toHaveBeenCalled()
  })

  it ('should call handleReCaptchaSuccess', () =>{
    let captcharesponse = 'true';
    spyOn(component,'validateCredential')
    component.handleReCaptchaSuccess(captcharesponse);
    expect(component.validateCredential).toHaveBeenCalled();
  })

  it('should call validateCrn', () => {
    
   component.accountList = ['ads','asd'];
    payloadService.generatePayloadForCrnList.and.returnValue({
      client_id: 'sd',
      authMethod: 'NA',
      userId: 'ads',
      rememberMeFlag: 'Y'
    });
    let reqPayload = {
      client_id: '',
      authMethod: '',
      userId: '',
      rememberMeFlag: '',
      };
     let loginSuccessResp :ILoginSuccessResp ={
        authMethod: '',
        flow: '',
        guid: '',
        state: '',
        statusCode: 123,
        crdntlBlk: '',
        cdtBlk: '',
        chnlBlk: '',
        mblNtUpdtd: '',
        showRecaptcha: '',
        cardDetailsLogin: ''
    };

    let data ={
      authMethod: '',
      flow: '',
      guid: '',
      state: '',
      statusCode: 123,
      crdntlBlk: '',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: ''
    }

    loginService.validateUserName.and.returnValue(of(data));
    (component as any).validateCrn();
    loginService.validateUserName(reqPayload, PATHS.login, { rememberMeFlag:'Y' }).subscribe({
      next: (resp) => {
        expect(resp).toEqual(loginSuccessResp);
      }
    });

   
   // expect((component as any).handleCrnSuccessResponse()).toHaveBeenCalled();
  })

  it('should call handleCrnSuccessResponse',()=> {
    spyOn((component as any ),'processBlockedUsername');
    spyOn((component as any ),'handleBlockedUsername')
   let resp = {
      authMethod: 'MOBILE',
      flow: 'UNBLOCK',
      guid: '',
      state: '',
      statusCode: 123,
      crdntlBlk: 'sad',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: '',
  }
    component.handleCrnSuccessResponse(resp)
   expect((component as any).handleBlockedUsername).toHaveBeenCalled()


  })

  it('should call handleCrnSuccessResponse else block',()=>{
    spyOn((component as any ),'processBlockedUsername');
    spyOn((component as any ),'handleBlockedUsername')
   let resp = {
      authMethod: '',
      flow: 'UNBLOCK',
      guid: '',
      state: '',
      statusCode: 123,
      crdntlBlk: 'sad',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: '',
  }
    component.handleCrnSuccessResponse(resp)
   expect((component as any).handleBlockedUsername).toHaveBeenCalled()

  })

  it('it should  call processBlockedUsername',()=>{
    component.accountList = ['ads','asd'];
    let inputField = {
      loginId : ''
    }
  //  payloadService.generatePayloadForOpr(inputField, true, true);
    let data = {
      flow: '',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: ''
    };
    let resp ={
      flow: '',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: ''
    };
    let reqPayload = { client_id: '',
    flow: '',
    guid: '',
    loginId: '',
    oprState: ''
    }

    loginService.handleOpr.and.returnValue(of(data));
    (component as any).processBlockedUsername();
    loginService.handleOpr(reqPayload, PATHS.verifyCrn).subscribe({
      next: (resp) => {
        expect(data).toEqual(resp);
      }
    });

  })

  it('should call notYou',() => {
    component.accountList = ['ads']
    
    spyOn(router, 'navigateByUrl');
    component.notYou();
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should call handleOprSuccessResponse',()=>{
    let resp  = {
      flow: 'asd',
      guid: 'sdas',
      nextScreen: 'as',
      state: 'sd',
      showRecaptcha: 'af',
  }
    spyOn(store,'dispatch');
    (component as any).handleOprSuccessResponse(resp)
     expect(store.dispatch).toHaveBeenCalled()
  })

  it('should call handleValidUsername',()=>{
    let resp = {
      authMethod: '',
      flow: 'UNBLOCK',
      guid: '',
      state: '',
      statusCode: 123,
      crdntlBlk: 'sad',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: '',
  }
  component.accountList = ['ads','asd'];
    spyOn(store,'dispatch');
    (component as any).handleValidUsername(resp)
    expect(store.dispatch).toHaveBeenCalled()
  })

  it('should call validateCredential',()=>{
   
    let reqPayload = {  client_id: '',
      state: '',
      authMethod: '',
      guid: '',
      credential: '',
      rememberMeFlag: ''
    }
    let data : any = {
      authMethod: '',
      emailId: '',
      isdCode: '',
      message: '',
      mobilenNumber: '',
      state: '',
      statusCode: 122,
      twoFaOptions: [
          {
              twoFaMethodLuCode: 'sad',
              prefferdTwoFaFlag: 'asd',
          }
      ]
    }
    let params = { key: '', captchaValue: '' };
    spyOn(store,'dispatch');
    payloadService.generatePayloadForAuth
    loginService.validateRememberMePwd.and.returnValue(data);
    component.validateCredential('resp') 
    loginService.validateRememberMePwd(reqPayload, PATHS.authenticate, params).subscribe({
      next: (resp) => {
        expect(data).toEqual(resp);
      }
    });
    expect((component as any).handleCredentialSuccessResponse).toHaveBeenCalled()
  })

  it('should call handleForgotPasswordSuccessResponse',()=> {
    spyOn(store,'dispatch');
    spyOn(router, 'navigateByUrl');

    let resp = {
      flow: '',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: '',
    };
    (component as any).handleForgotPasswordSuccessResponse(resp);
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should call forgotPassword',() => {
    spyOn(store,'dispatch');
    component.accountList = ['ads','asd'];
    let reqPayload = {
      client_id: '',
      flow: '',
      guid: '',
      loginId: '',
      oprState: '',
    }
    loginService.handleOpr(reqPayload, PATHS.verifyCrn)
    component.forgotPassword();
    expect((component as any).handleForgotPasswordSuccessResponse).toHaveBeenCalled();
  })
 

});