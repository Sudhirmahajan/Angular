import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { InvisibleReCaptchaComponent } from 'ngx-captcha';
import { Observable, Subscription } from 'rxjs';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { AuthenticationService, BioCatchService, ConfigService, getClientSessionId, getPageDetails, getRememberMeDetails, IRememberMeDetails, NavigationService, setAccessToken, setCardDetailsBlockedStatus, setChannelBlockedStatus, setClientSessionId, setCredentialBlockedStatus, setEmail, setFlow, setGUID, setIsdCode, setMobileNotUpdatedStatus, setMobileNumber, setPageName, setRecaptcha, setRememberMeDetails, setServerState, setServiceId, setTwoFaAuthOptions } from 'src/app/auth/auth.index';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { GetPartyDataService } from 'src/app/modules/shared/services/get-party-data/get-party-data.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { preLoginCta, redirectToRememberMeCrn } from '../../login-analystics';
import { FLOWS, PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS, SERVICE_ID } from '../../login.constant';
import { IAccessTokenAndOnboardingResp, IAuthSuccessWithTwoFactoreResp, ILoginSuccessResp, IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { Storage } from '../../utils/storage/storage';

@Component({
  selector: 'app-rememberme-enter-password',
  templateUrl: './rememberme-enter-password.component.html',
  styleUrls: ['./rememberme-enter-password.component.scss']
})
export class RemembermeEnterPasswordComponent implements OnInit {
  clientSessionIdFromStore!: string;
  gck!: string;
  accountList!: any[];
  private httpSubscription!: Subscription;
  private storage = new Storage();
  isValidatedUsername!: boolean;
  rememberMeDetails$!: Observable<IRememberMeDetails>;
  userPasswordForm!: FormGroup;
  hide: boolean = true;
  dna!: string;
  remainingAttemts: number | undefined;
  showGoogleCaptcha!: boolean;
  @ViewChild('captchaElem') captchaElem!: InvisibleReCaptchaComponent;
  params = { key: '', captchaValue: '' };
  captchaSource: string = '';
  captchaError!: boolean;
  showCaptcha!: boolean
  errorType='PASSWORD';
  page_name: any;
  userId: any;
  authMethod !: string;
  flow !: string;

  constructor(private store: Store,
    private configService: ConfigService,
    private authenticationService: AuthenticationService,
    private payloadService: PayloadService,
    private loaderService: LoaderService,
    private loginService: LoginService,
    private router: Router,
 //   public navigation: NavigationService,
    private setOnboardCardService: SetOnboardCardService,
    private rememberMeService: RememberMeService,
    private errorBeanService: ErrorBeanService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private bioCatchService: BioCatchService,
    private getPartyDataService: GetPartyDataService,
    private widgetService:WidgetService
    ) {
      this.bundleLoaderInitializerService.changeBundleLoaderStatus(true);
      this.store.select(getClientSessionId).subscribe((sessionId) => {
      this.clientSessionIdFromStore = sessionId;
      this.rememberMeDetails$ = this.store.select(getRememberMeDetails);
    });
   }

   ngOnDestroy() {
     if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    } 
  }

  ngOnInit(): void {
    this.store.dispatch(setPageName({ value: 'credential with user' })); 
    this.setAnalytics();
    this.bioCatchService.biocatchSetValues(BIO_CATCH_CONTEXT_KEY.MSITE_PRE+this.clientSessionIdFromStore, BIO_CATCH_CONTEXT_KEY.NB_LOGIN_USERNAME_REMEBER);
    this.gck = this.configService.getGck();
    this.userPasswordForm = new FormGroup({
      password: new FormControl(''),
      captchaElement: new FormControl('', [Validators.minLength(5), Validators.maxLength(5)])
    });
    if (!this.clientSessionIdFromStore) {
      this.store.dispatch(setClientSessionId({value: this.authenticationService.generateRandom()}))
    }
    this.accountList = this.storage.getStorageData().map((data) => JSON.parse(data.toString()));

    if (this.accountList.length === 1) {
      this.validateCrn();
    } else {
      this.isValidatedUsername = true;
    }

    this.getCaptcha();
  }

  setAnalytics(){
    window.digitalData=redirectToRememberMeCrn
    window._satellite?.track("NB-Msiteload");    
  }

  setAnalyticsOnClick(cta_name:any){
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    window.digitalData=preLoginCta({ctaName:cta_name,pageName:this.page_name});
    window._satellite?.track("NB-Msiteclick");
  }


  public getDna(dna: string) {
    this.dna = dna;
  }

  getCaptcha() {
    let payload = { key: '' };
    if(this.params.key){
      payload['key'] = this.params.key;
    }
    this.loginService.handleLoginCaptcha(payload , PATHS.getCaptcha).subscribe({next:
      (res)=>{
      this.showCaptcha = true;
      this.captchaSource = "data:image/png;base64," + res['captcha'];
      this.params.key = res['key'];
      document.getElementById('splash')!.style.display = 'none'; 
    }, error:(err)=>{
      
      if(err.status == '404') {
        this.showCaptcha = false;
      } else {
        this.captchaError = true;
        this.loaderService.stopLoader();
        this.userPasswordForm.reset();
      }
    }})
  }

  public submitForm() {
    (this.showGoogleCaptcha) ? this.captchaElem.execute() : this.validateCredential();
  }

  public handleReCaptchaSuccess(captchaResponse: string): void {
    if (captchaResponse) {
      this.validateCredential(captchaResponse);
    }
  }

  private validateCrn() {
    this.userId = this.accountList[0].encryptedcrn;
    //this.userId = this.widgetService.getPlainText(userId);
    const reqPayload = this.payloadService.generatePayloadForCrnList(this.userId);
    if (reqPayload) {
      this.httpSubscription = this.loginService.validateUserName(reqPayload, PATHS.login, { rememberMeFlag:'Y' })
        .subscribe((resp: ILoginSuccessResp) => {
          this.flow = resp.flow;
          this.authMethod = resp.authMethod;
          this.handleCrnSuccessResponse(resp);
        });
    }
  }

  public handleCrnSuccessResponse(resp: ILoginSuccessResp) {
    (resp['authMethod'] === SCREEN_ROUTING_KEYS.MOBILE || resp['flow'] == FLOWS.unblock || resp['flow'] == FLOWS.mobileNotUpdated) ?
      this.handleBlockedUsername(resp) : this.handleValidUsername(resp);
  }
  
  private handleBlockedUsername(resp: ILoginSuccessResp): void {
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.processBlockedUsername();
  }

  private processBlockedUsername(): void {
    const inputField = { loginId: this.accountList[0]['encryptedcrn'] };
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true, true);
    if (reqPayload as IVerifyCrnRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe((resp: IVerifyCrnResponse) => {
          this.loaderService.stopLoader();
          this.handleOprSuccessResponse(resp);
        });
    }
  }

  private handleOprSuccessResponse(resp: IVerifyCrnResponse): void {
    //this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    //this.routerService.navigateToView(resp['nextScreen']);
  }

  private handleValidUsername(resp: ILoginSuccessResp) {
    this.isValidatedUsername = true;
    if (resp['flow'] !== 'LOGIN') {
      this.store.dispatch(setFlow({value: resp['flow']}))
    }
      resp['crdntlBlk'] && this.store.dispatch(setCredentialBlockedStatus({value: resp['flow']}))
    
      resp['cdtBlk'] && this.store.dispatch(setCardDetailsBlockedStatus({value: resp['flow']}))
   
      resp['chnlBlk'] && this.store.dispatch(setChannelBlockedStatus({value: resp['flow']}))
    
      resp['mblNtUpdtd'] && this.store.dispatch(setMobileNotUpdatedStatus({value: resp['flow']}))
    
      resp['showRecaptcha'] && this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    
    this.store.dispatch(setRememberMeDetails({value: this.accountList[0]}))
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
  }

  notYou() {
    if (this.accountList.length === 1) {
      this.rememberMeService.useAnotherAccountFlag = true;
    }
    this.router.navigateByUrl(ROUTE_KEY['CRN_LIST'], { skipLocationChange: environment.skipURI });
  }

  validateCredential(captchaResponse?: string) {
    this.loaderService.startLoader();
    let reqPayload = this.payloadService.generatePayloadForAuth(SCREEN_ROUTING_KEYS.CREDENTIAL, this.userPasswordForm.controls['password'].value);
    if (captchaResponse) {
      reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
    }
    const additionalPayloadForTrustedDevice = {
      mfp: this.dna,
      deviceOS: window['jscd']['os'],
      browser: window['jscd']['browser']
    };
    reqPayload = { ...reqPayload, ...additionalPayloadForTrustedDevice };
    this.params.captchaValue = this.userPasswordForm.controls['captchaElement'].value.trim();
    //Creating payload for generic party data
    const payloadForValidUser = this.payloadService.generatePayload(this.userId, 'Y');

    if (reqPayload) {
      this.httpSubscription = this.loginService.validateRememberMePwd(reqPayload, PATHS.authenticate, this.params)
        .subscribe({ next: (resp: (IAccessTokenAndOnboardingResp & IAuthSuccessWithTwoFactoreResp)) => {
          this.store.dispatch(setRecaptcha({value: ''}))
           const callback = (partyDataFlag: any) => {
          
            if(partyDataFlag) {
              this.handleCredentialSuccessResponse(resp);
            } else {
              this.loaderService.stopLoader();
              this.router.navigateByUrl(ROUTE_KEY['SERVICE_NOT_FOUND'], { skipLocationChange: environment.skipURI });
            }
          }
          this.getPartyDataService.getPartyData(payloadForValidUser,'Y', this.flow, this.authMethod, callback);
        }, error: (error) => {
            this.getCaptcha();
            this.handleErrorScenarios(error);
        }});
    }
  }

  private handleErrorScenarios(error: HttpErrorResponse) {
    this.loaderService.stopLoader();
    this.remainingAttemts = this.errorBeanService.handleErrorScenariosInLogin(error);
    if (error.error['showRecaptcha'] === 'Y') {
      this.showGoogleCaptcha = true;
    }
    this.userPasswordForm.reset();
  }

  handleCredentialSuccessResponse(resp: IAccessTokenAndOnboardingResp & IAuthSuccessWithTwoFactoreResp) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServiceId({value: SERVICE_ID.credentialFlow}))
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.loginService.onBoardingFlag(resp);
    (resp.accessToken) ? this.handleAccessToken(resp) : this.handleSecondFactorAuthentication(resp);
  }

  handleAccessToken(resp: IAccessTokenAndOnboardingResp & IAuthSuccessWithTwoFactoreResp) {
    this.store.dispatch(setAccessToken({value: resp['accessToken']}))
    if (resp['onboarding'] === 'Y') {
      this.setOnboardCardService.checkUserOnboarded(resp['onboarding']);
    } else {
      this.router.navigate(['onboarding'], { skipLocationChange: environment.skipURI });
    }
  }

  handleSecondFactorAuthentication(resp: IAccessTokenAndOnboardingResp & IAuthSuccessWithTwoFactoreResp) {
    this.store.dispatch(setServerState({value: resp['state']}));
    this.store.dispatch(setMobileNumber({value: resp['mobilenNumber']}));
    this.store.dispatch(setEmail({value: resp['emailId']}));
    this.store.dispatch(setIsdCode({value: resp['isdCode']}));
    
    (resp['authMethod']) ? this.router.navigateByUrl(resp['authMethod'], { skipLocationChange: environment.skipURI }) :
      this.handleTwoFactorOptions(resp['twoFaOptions']);
  }

  private handleTwoFactorOptions(twoFactorOptions: [{ prefferdTwoFaFlag: string, twoFaMethodLuCode: string }]) {
    const preferredTwoFactorOption = twoFactorOptions.find((option) => {
      return option['prefferdTwoFaFlag'] === 'Y';
    });

    // here we will check or msite access based on TWOFactorOption
    
    if((preferredTwoFactorOption?.twoFaMethodLuCode == 'TOTP' && preferredTwoFactorOption?.prefferdTwoFaFlag == 'Y') || (preferredTwoFactorOption?.twoFaMethodLuCode == 'MOB_APP_LOGIN' && preferredTwoFactorOption?.prefferdTwoFaFlag == 'Y')){
      this.loaderService.stopLoader();
      this.router.navigateByUrl(ROUTE_KEY['SERVICE_NOT_FOUND'], { skipLocationChange: environment.skipURI });
    } else {
      if (preferredTwoFactorOption) {
        preferredTwoFactorOption['twoFaMethodLuCode'] == 'OTP' && this.router.navigateByUrl(ROUTE_KEY['OTP'], { skipLocationChange: environment.skipURI });
      }
      if (twoFactorOptions.length > 1) {
        this.store.dispatch(setTwoFaAuthOptions({value: twoFactorOptions}))
      }
    }  
  }

  forgotPassword() {
    this.loaderService.startLoader();
    this.store.dispatch(setFlow({value: FLOWS.forgotCredential}))
    const inputField = { loginId: this.accountList[0]['encryptedcrn'] };
    const reqPayload = this.payloadService.generatePayloadForRememberMeOpr(inputField, true);
    if (reqPayload as IVerifyCrnRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe((resp: IVerifyCrnResponse) => {
          this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_GENERATE_PASSWD);
          this.handleForgotPasswordSuccessResponse(resp);
        });
    }
  }

  private handleForgotPasswordSuccessResponse(resp: IVerifyCrnResponse) {
    this.loaderService.stopLoader();
    
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

}