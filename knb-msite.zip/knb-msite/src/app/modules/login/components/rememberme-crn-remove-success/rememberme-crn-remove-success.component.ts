import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getPageDetails, setPageName } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { preLoginCta } from '../../login-analystics';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { Storage } from '../../utils/storage/storage';

@Component({
  selector: 'app-rememberme-crn-remove-success',
  templateUrl: './rememberme-crn-remove-success.component.html',
  styleUrls: ['./rememberme-crn-remove-success.component.scss']
})
export class RemembermeCrnRemoveSuccessComponent implements OnInit {

  private storage = new Storage();
  page_name: any;

  constructor(
    public store: Store,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.store.dispatch(setPageName({ value: 'crn removed success' })); 
  }
  
  setAnalyticsOnClick(cta_name:any){
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    window.digitalData=preLoginCta({ctaName:cta_name,pageName:this.page_name});
    window._satellite?.track("NB-Msiteclick");
  }

  public navigate() {
    const crnList = this.storage.getStorageData();
    const routeUri = (crnList.length === 0) ? SCREEN_ROUTING_KEYS.CRN : SCREEN_ROUTING_KEYS.CRN_LIST;
    this.router.navigateByUrl(ROUTE_KEY[routeUri], { skipLocationChange: environment.skipURI });
  }

}
