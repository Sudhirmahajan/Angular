import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';

@Component({
  selector: 'app-update-contact-details',
  templateUrl: './update-contact-details.component.html',
  styleUrls: ['./update-contact-details.component.scss']
})
export class UpdateContactDetailsComponent implements OnInit {
  contUpdate!: FormGroup;
  mobileMatched: boolean =false;
  moberrorShow: boolean=false;
  emailerrorShow: boolean=false;
  emailIdMatched: boolean=false;
  cardData: any;
  isSelectorDrpdown!: boolean;
  isdList: any;
  EntereddefaultisdList: any;
  selectList: any;
  isdCodelistselect1: any;
  isdCodelistselect2: any;
  enterdRenteredMob!: boolean;
  completedC: any;
  mandatoryFlag: any;

  constructor(
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
  ) { }

  ngOnInit(): void {

    this.initForm();
    this.loadData();

  }

  initForm(){
    this.contUpdate = new FormGroup({
      mobileNo: new FormControl('', [Validators.required, Validators.maxLength(20), Validators.minLength(6)]),
      remobileNo: new FormControl('', [Validators.required, Validators.maxLength(20), Validators.minLength(6)]),
      emailId: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      reemailId: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
    });
  }


  loadData(){

    this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
    });

    const dropdownval = this.cardData.data;
    if (dropdownval !== null) {
      this.isSelectorDrpdown = true;
      this.isdList = this.cardData.data.isdList;
      this.EntereddefaultisdList = this.cardData.data.isdList[0]['isdCode'];
      this.selectList = this.cardData.data;

      this.isdCodelistselect1 = this.selectList.isdList[0].isdCode;
      this.isdCodelistselect1 = this.selectList.isdList[0].isdCode;
      if (this.isdCodelistselect1 === this.isdCodelistselect2) {

        this.enterdRenteredMob = true;
      }

    } else {
      this.isSelectorDrpdown = false;
    }
    this.completedC = this.cardData.completedCard;
    this.mandatoryFlag = this.cardData.mandatoryFlag;
      
  }


  checkMobileNo(){
    if(this.contUpdate.value['remobileNo']){
      this.moberrorShow=true;
      if (this.contUpdate.controls['mobileNo'].value == this.contUpdate.controls['remobileNo'].value) {
        this.mobileMatched=true;
      }else{
        this.mobileMatched=false;
      }
    }else{
      this.moberrorShow=false;
    }
  }


  checkemail(){
     if(this.contUpdate.value['reemailId']){
      this.emailerrorShow=true;
      if (this.contUpdate.controls['emailId'].value == this.contUpdate.controls['reemailId'].value) {
        this.emailIdMatched=true;
      }else{
        this.emailIdMatched=false;
      }
    }else{
      this.emailerrorShow=false;
    }
  }
}
