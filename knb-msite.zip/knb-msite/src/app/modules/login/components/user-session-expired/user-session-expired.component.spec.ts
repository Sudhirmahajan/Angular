import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { Observable } from 'rxjs/internal/Observable';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { UserSessionExpiredComponent } from './user-session-expired.component';
import { BehaviorSubject, of } from 'rxjs';

describe('UserSessionExpiredComponent', () => {
  let component: UserSessionExpiredComponent;
  let fixture: ComponentFixture<UserSessionExpiredComponent>;
  let router :Router;
 /*  let MockBundleLoaderInitializerService = jasmine.createSpyObj('BundleLoaderInitializerService',['setForceLogout']);
  let bundleLoaderInitializerService: jasmine.SpyObj<BundleLoaderInitializerService>; */


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserSessionExpiredComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],
      providers:[
       /*  { provide: BundleLoaderInitializerService, useValue: MockBundleLoaderInitializerService }, */

      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSessionExpiredComponent);
/*     bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
 */    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
})

xit('should call onInit', () => {
  component.ngOnInit();
/*     expect(bundleLoaderInitializerService.setForceLogout).toHaveBeenCalled()
 */
  });


});
