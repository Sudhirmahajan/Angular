import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { BioCatchService } from 'src/app/auth/auth.index';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { environment } from 'src/environments/environment';
import { redirectToUserSessionExpired, userSessionExpiredCtaname } from '../../login-analystics';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-user-session-expired',
  templateUrl: './user-session-expired.component.html',
  styleUrls: ['./user-session-expired.component.scss']
})
export class UserSessionExpiredComponent implements OnInit {
  isForceLogout: any;
  pageName!: string;
  isIdle!: boolean;

  constructor(
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private router: Router,
    private bioCatchService: BioCatchService
  ) {
    if(history.state){
      this.isIdle = history.state.data.isIdleTimeout;
    };
   }

  ngOnInit(): void {
    this.setAnalytics('');
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_SESSION_EXPIRED);
    this.bundleLoaderInitializerService.isForceLogoutCast.subscribe((resp) => {
      if (resp) {
        this.isForceLogout = resp;
        this.bundleLoaderInitializerService.setForceLogout(false);
      }
      this.pageName = this.isForceLogout ? 'Force Logout' : 'Session expired';
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserSessionExpired
      window._satellite?.track("NB-Msiteload");

    }else{
      window.digitalData=userSessionExpiredCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");

    }
  }
 

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

}
