import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import {
    BioCatchService,
    ConfigService,
    getAuthMethod,
    getEmail,
    getFlow,
    getIsdCode,
    getMobileNumber,
    getMsiteAuthMethod,
    getMsiteFlow,
    getMsiteUserID,
    getRecaptcha,
    getServerState,
    getServiceId,
    getTwoFaAuthOptions,
    getUserId,
    NavigationService,
    setAccessToken,
    setAccountQuestions,
    setBlockedTimer,
    setDisableBackFlag,
    setDisableMoreOptionsFlag,
    setFlow,
    setRecaptcha,
    setRemainingDays,
    setSecurityQuestionFlag,
    setSecurityQuestions,
    setServerState,
} from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { FLOWS, PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import {
    IAccessTokenAndCustomerInfoResp,
    IAccessTokenAndOnboardingResp,
    IAccessTokenResp,
    IOnlyStateResp,
    IOtpOnCallRequest,
    IOtpOnCallResponse,
    IValidateOtpRequest,
    IValidateOtpResponse,
} from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { MatSnackBar } from '@angular/material/snack-bar';
import { DataEmitterService } from 'src/app/auth/services/data-emitter/data-emitter.service';
import { SetTrustedDeviceIdService } from 'src/app/modules/shared/services/set-trusted-deviceid/set-trusted-deviceid.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { CountdownComponent, CountdownEvent } from 'ngx-countdown';
import { WidgetService } from '../../../shared/services/widget/widget.service';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { InvisibleReCaptchaComponent } from 'ngx-captcha';
import { HttpErrorResponse } from '@angular/common/http';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { redirectToUserOtp, redirectToUserOtpViaCall, userOtpCtaname, userOtpViaCallCtaname } from '../../login-analystics';
import { GetPartyDataService } from 'src/app/modules/shared/services/get-party-data/get-party-data.service';

declare global {
    interface Window {
        jscd: {
            os: string;
            browser: string;
        };
    }
}

@Component({
    selector: 'app-user-otp',
    templateUrl: './user-otp.component.html',
    styleUrls: ['./user-otp.component.scss'],
})
export class UserOtpComponent implements OnInit, OnDestroy {
    userOtpForm!: FormGroup;
    hide: boolean = true;
    otpValue!: string;
    dna: any;
    httpSubscription!: Subscription;
    serviceIdFromStore!: string;
    storeFlow!: string;
    maskedMobileNumber!: string;
    maskedEmail!: string;
    isdCodeFromStore!: string;
    moreOptionsStatus!: boolean;
    showGoogleCaptcha!: boolean;
    @ViewChild('backgroundCounter') backgroundCounter!: CountdownComponent;
    @ViewChild('actualCounter') actualCounter!: CountdownComponent;
    @ViewChild('captchaElem') captchaElem!: InvisibleReCaptchaComponent;
    callOptionEnable: boolean = false;
    remainingTimeForActualCounter!: number;
    showTimer: boolean = false;
    backgroundTimer = 30;
    showOtpExpiryMessage!: boolean;
    otpViaCallClicked: any;
    callingYou: boolean = false;
    errorType: string = 'OTP';
    isError!: boolean;
    remainingAttemts!: number | undefined;
    gck!: string;
    autuRefreshSession!: any;
    msiteUserId !: string;
    flow !: string;
    authMethod !: string;
    msiteFlow !: string;
    msiteAuthMethod!: string;

    constructor(
        private store: Store,
        private loaderService: LoaderService,
        private payloadService: PayloadService,
        private loginService: LoginService,
        private router: Router,
        private _snackBar: MatSnackBar,
        public navigation: NavigationService,
        public dataEmitterService: DataEmitterService,
        private setTrustedDeviceIdService: SetTrustedDeviceIdService,
        private rememberMeService: RememberMeService,
        private setOnboardCardService: SetOnboardCardService,
        private widgetService: WidgetService,
        private errorBeanService: ErrorBeanService,
        private configService: ConfigService,
        private bioCatchService: BioCatchService,
        private getPartyDataService: GetPartyDataService,
    ) {}

    ngOnDestroy() {
        if (this.httpSubscription) {
            this.httpSubscription.unsubscribe();
        }
    }

    ngOnInit(): void {
        this.setAnalytics('');
        this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_LOGIN_OTP_SMS);
        this.gck = this.configService.getGck();
        this.userOtpForm = new FormGroup({
            otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
        });
        this.store.select(getMsiteUserID).subscribe((data) => {
            this.msiteUserId = data;
        });
        this.store.select(getMsiteFlow).subscribe((data) => {
            this.msiteFlow = data;
        });
      
        this.store.select(getMsiteAuthMethod).subscribe((data) => {
            this.msiteAuthMethod = data;
        });
        this.getDataFromStore();
        this.handleAutoRefresh();
    }

    setAnalytics(ctaname:any) {
        if(ctaname===''){
            if(!this.callingYou){
                window.digitalData=redirectToUserOtp
            }else{
                window.digitalData=redirectToUserOtpViaCall
            }
            window._satellite?.track("NB-Msiteload");
        }else{
            if(!this.callingYou){
                window.digitalData=userOtpCtaname(ctaname)
            }else{
                window.digitalData=userOtpViaCallCtaname(ctaname)
            }
          window._satellite?.track("NB-Msiteclick");
        }
     }
     
    public getDna(dna: any) {
        this.dna = dna;
    }

    public submitForm() {
        (this.showGoogleCaptcha) ? this.captchaElem.execute() : this.validateOtp();
    }

    public handleSuccess(captchaResponse: string): void {
        if (captchaResponse) {
            this.validateOtp(captchaResponse);
        }
    }
    
    private validateOtp(captchaResp?: string) {
        this.userOtpForm.controls['otpValue'].enable();
       (this.storeFlow) ? this.validateOtpWithOpr(captchaResp) : this.validateOtpWithLogin(captchaResp);
    }

    public checkMoreLoginOptions() {
        this.payloadService.setMoreLoginOptionsSource('OTP');
        this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.SECOND_FACTOR_AUTHENTICATION_OPTIONS], { skipLocationChange: environment.skipURI });
    }

    private validateOtpWithOpr(captchaResponse?: string) {
        this.loaderService.startLoader();

        this.isError = false;
        this.showOtpExpiryMessage = false;

        const inputField = { otpValue: this.userOtpForm.controls['otpValue'].value };
        let reqPayload = this.payloadService.generatePayloadForOpr(inputField);
        if (captchaResponse) {
            reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
        }
        const additionalPayloadForTrustedDevice = {
            deviceOS: window['jscd']['os'],
            browser: window['jscd']['browser']
        };
        reqPayload = { ...reqPayload, ...additionalPayloadForTrustedDevice };
        //Creating payload for generic party data
        const payloadForValidUser = this.payloadService.generatePayloadForLogin(this.msiteUserId, 'N');
        if (reqPayload as unknown as IValidateOtpRequest) {
            this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as IValidateOtpRequest, PATHS.validateOtp)
                .subscribe({next: (resp: IValidateOtpResponse) => {
                    this.store.dispatch(setRecaptcha({ value: '' }))

                     const callback = (partyDataFlag: any) => {
          
                        if(partyDataFlag) {
                            this.handlevalidateOtpSuccessResponseWithOpr(resp);
                        } else {
                          this.loaderService.stopLoader();
                          this.router.navigateByUrl(ROUTE_KEY['SERVICE_NOT_FOUND'], { skipLocationChange: environment.skipURI });
                        }
                      }

                    this.getPartyDataService.getPartyData(payloadForValidUser, payloadForValidUser.rememberMeFlag, this.msiteFlow, this.msiteAuthMethod, callback);
                    
                     
                
                
                }, error: (error) => {
                    this.isError = true;
                    this.loaderService.stopLoader();
                    this.resetEnteredAndMaskedValue();
                    if (error.error.error.errorCode === 'BE0047') {
                        this.showOtpExpiryMessage = true;
                        this.userOtpForm.controls['otpValue'].disable();
                    } else {
                        this.remainingAttemts = this.errorBeanService.handleWrongAttempts(error, this.userOtpForm);
                    }
                    if (error.error['showRecaptcha'] === 'Y') {
                        this.showGoogleCaptcha = true;
                    }
                }});
        }
    }

    private resetEnteredAndMaskedValue() {
        this.userOtpForm.reset();
    }

    private handlevalidateOtpSuccessResponseWithOpr(resp: IValidateOtpResponse) {
        this.loaderService.stopLoader();
        this.store.dispatch(setServerState({ value: resp['state']}))
        this.store.dispatch(setFlow({ value: resp['flow']}))
        resp['securityQuestionFlag'] && this.store.dispatch(setSecurityQuestionFlag({ value: resp['securityQuestionFlag']}))
        resp['unBlkSecRemaning'] && this.store.dispatch(setBlockedTimer({ value: resp['unBlkSecRemaning']}))
        resp['disableMoreOption'] && this.store.dispatch(setDisableMoreOptionsFlag({ value: resp['disableMoreOption']}))
        resp['disableBack'] && this.store.dispatch(setDisableBackFlag({ value: resp['disableBack']}))
        resp['questions'] && this.store.dispatch(setSecurityQuestions({value: resp['questions']}));
        resp['accountQuestions'] && this.store.dispatch(setAccountQuestions({ value: resp['accountQuestions']}));
        resp['username'] && this.dataEmitterService.broadcast('username', resp['username']);//check this - sachin
        resp['showRecaptcha'] && this.store.dispatch(setRecaptcha({ value: resp['showRecaptcha']}));
        resp['remainingDays'] && this.store.dispatch(setRemainingDays({ value: resp['remainingDays']}));
        
        (this.storeFlow === FLOWS.netBankingRegister && resp['nextScreen'] === SCREEN_ROUTING_KEYS.CARD_NO) ?
        this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.SET_NET_BANKING_CREDENTIAL], { skipLocationChange: environment.skipURI }) :
        this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
    }

    public validateOtpWithLogin(captchaResponse?: string) {
        this.loaderService.startLoader();

        this.isError = false;
        this.showOtpExpiryMessage = false;

        let reqPayload = this.payloadService.generatePayloadForAuth(
            'OTP',
            this.userOtpForm.controls['otpValue'].value
        );
        if (captchaResponse) {
            reqPayload = {
                ...reqPayload,
                ...{ gCaptchaResponse: captchaResponse },
            };
        }
        const additionalPayloadForTrustedDevice = {
            mfp: this.dna,
            deviceOS: window['jscd']['os'],
            browser: window['jscd']['browser'],
        };
        if (this.serviceIdFromStore) {
            reqPayload = {
                ...reqPayload,
                ...{ serviceId: this.serviceIdFromStore },
                ...additionalPayloadForTrustedDevice,
            };
        }
        const deviceIdFromLocalStorage =
            localStorage.getItem('RISKFORT_COOKIE');
        if (deviceIdFromLocalStorage) {
            reqPayload = {
                ...reqPayload,
                ...{ deviceId: deviceIdFromLocalStorage },
            };
        }

        if (reqPayload) {
            this.httpSubscription = this.loginService
                .validateOtp(reqPayload, PATHS.authenticate)
                .subscribe({next: (resp: (IAccessTokenAndCustomerInfoResp | IAccessTokenAndOnboardingResp | IAccessTokenResp)) => {
                    this.loaderService.stopLoader();
                    this.handlevalidateOtpSuccessResponseWithLogin(resp);
                }, error: (error) => {
                    this.resetEnteredAndMaskedValue();
                    this.loaderService.stopLoader();
                    this.isError = true;
                    if (error.error.rmngAtmpts === 0) {
                        this.payloadService.setMoreLoginOptionsSource('OTP');
                    }
                    if (error.error.error.errorCode === 'BE0050') {
                        this.showOtpExpiryMessage = true;
                        this.userOtpForm.controls['otpValue'].disable();
                    } else {
                        this.remainingAttemts = this.errorBeanService.handleErrorScenariosInLogin(error);
                    }
                    if (error.error['showRecaptcha'] === 'Y') {
                        this.showGoogleCaptcha = true;
                    }
                }})
        
        }
    }

    
    private handlevalidateOtpSuccessResponseWithLogin(resp: (any)) {
        this.loaderService.stopLoader();
        (resp['accessToken']) ? this.handleAccessTokenResponse(resp) : this.handleAuthenticationOptionResponse(resp);
    }

    private handleAuthenticationOptionResponse(resp: any) {
        if (resp['deviceId']) {
            this.setTrustedDeviceIdService.setDeviceId(resp['deviceId']);
        }
        this.store.dispatch(setServerState({ value: resp['state']}))
        this.dataEmitterService.broadcast('riskAssessment', resp['riskAssessment']);
        //this.routerService.navigateToView(resp['authMethod']);
    }

    private handleAccessTokenResponse(resp: any) {
        this.store.dispatch(setAccessToken({ value: resp['accessToken']}))
        if (resp['customerInfo']) {
            this.rememberMeService.handleRememberMe(resp['customerInfo']);
        }

        if (resp['onboarding'] === 'Y') {
            this.setOnboardCardService.checkUserOnboarded(resp['onboarding']);
        } else {
            this.router.navigate(['onboarding'], { skipLocationChange: environment.skipURI });
        }
    }

    public didntReceiveOtp() {
        this.backgroundCounter.stop();
        if (this.backgroundCounter['left'].toString().length > 4) {
            this.remainingTimeForActualCounter = Number(this.backgroundCounter['left'].toString().substring(0, 2));
        } else {
            this.remainingTimeForActualCounter = Number(this.backgroundCounter['left'].toString().substring(0, 1));
        }
        this.showTimer = true;
    }

    resetTimer() {
        this.backgroundCounter.restart();
        this.backgroundCounter.stop();
    }

    public defaultOnFinished(event: CountdownEvent) {
        if(event.action == 'done') {
            this.callOptionEnable = true;
            this.resetTimer();
        }
    }

    public onFinished(event: CountdownEvent) {
        if(event.action == 'done') {
            this.callOptionEnable = true;
            this.showTimer = false;
            this.actualCounter.restart();
            this.actualCounter.stop();
        }
        
    }

    public otpViaCall() {
        this.callingYou = true;
        this.setAnalytics('')
        this.isError = false;
        this.showOtpExpiryMessage = false;
        this.userOtpForm.controls['otpValue'].enable();
        (this.storeFlow) ? this.otpViaCallWithOpr() : this.otpViaCallWithLogin();
    }

    private otpViaCallWithOpr() {
        const reqPayload = this.payloadService.generatePayloadForOpr();
        if (reqPayload as unknown as IOtpOnCallRequest && !this.otpViaCallClicked) {
            this.loaderService.startLoader();
            this.otpViaCallClicked = true;
            this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as IOtpOnCallRequest, PATHS.otpOnCall)
                .subscribe((resp: IOtpOnCallResponse) => {
                    this.handleOtpViaCallSuccessResponseWithOpr(resp);
                });
        }
    }

    private handleOtpViaCallSuccessResponseWithOpr(resp: IOtpOnCallResponse) {
        this.loaderService.stopLoader();
        this.store.dispatch(setServerState({ value: resp['state']}));
        //this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });; 
    }

    private otpViaCallWithLogin() {
        let reqPayload = this.payloadService.
            generatePayloadForAuth(SCREEN_ROUTING_KEYS.OTP_ON_CALL, '');
        if (this.serviceIdFromStore) {
            reqPayload = { ...reqPayload, ...{ serviceId: this.serviceIdFromStore } };
        }
        if (reqPayload && !this.otpViaCallClicked) {
            this.otpViaCallClicked = true;
            this.loaderService.startLoader();
            this.httpSubscription = this.loginService.handleLogin(reqPayload, PATHS.authenticate)
                .subscribe((resp: IOnlyStateResp) => {
                    //resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
                    if (resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true) {
                        this.widgetService.isPWDgenOPR.next(true);
                    }
                    this.handleOtpViaCallSuccessResponseWithLogin(resp);
                });
        }
    }

    private handleOtpViaCallSuccessResponseWithLogin(resp: IOnlyStateResp) {
        this.store.dispatch(setServerState({ value: resp['state']}));
        this.loaderService.stopLoader();
       // this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_ON_CALL], { skipLocationChange: environment.skipURI });

    }

    private getDataFromStore() {
        this.store.select(getFlow).subscribe(value => this.storeFlow = value)
        this.store.select(getMobileNumber).subscribe(value => this.maskedMobileNumber = value)
        this.store.select(getEmail).subscribe(value => this.maskedEmail = value)
        this.store.select(getIsdCode).subscribe(value => this.isdCodeFromStore = value)
        this.store.select(getServiceId).subscribe(value => this.serviceIdFromStore = value)
        this.store.select(getTwoFaAuthOptions).subscribe((value) => {
            if (value) {
                this.moreOptionsStatus = true;
            }
        });
        this.store.select(getRecaptcha).subscribe((value) => {
            if (value === 'Y') {
                this.showGoogleCaptcha = true;
            }
        });
    }

    public resendOTP(type?: string) { 
        clearTimeout(this.autuRefreshSession);
        this.otpViaCallClicked = false;
        this.isError = false;
        this.showOtpExpiryMessage = false;
        if(type=="SMS"){
        let reqPayload = this.payloadService.
            generatePayloadForAuth( SCREEN_ROUTING_KEYS.NEW_OTP , '');
        if (this.serviceIdFromStore) {
            reqPayload = { ...reqPayload, ...{ serviceId: this.serviceIdFromStore } };
        }
        if (reqPayload && !this.otpViaCallClicked) {
            this.otpViaCallClicked = true;
            this.loaderService.startLoader();
            this.httpSubscription = this.loginService.handleLogin(reqPayload, PATHS.authenticate)
                .subscribe({ next:(resp: IOnlyStateResp) => {
                 this.loaderService.stopLoader();
                 if(resp['state']){
                 this.store.dispatch(setServerState({ value: resp['state'] }));
                 }
                    this.userOtpForm.reset();
                   this.userOtpForm.controls['otpValue'].enable();
                   // resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
                    if (resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true) {
                        this.widgetService.isPWDgenOPR.next(true);
                    }
                    this.showOtpExpiryMessage=false;
                },
                error: (err) => {
                    this.resetEnteredAndMaskedValue();
                    this.navigationWithWrongAttempts(err);
                }});
        }
    }else{
        this.otpViaCall();
    }
    }

    public resendOTPinOPR(){
        clearTimeout( this.autuRefreshSession);
        this.otpViaCallClicked = false;
        this.isError = false;
        this.showOtpExpiryMessage = false;
        const reqPayload = this.payloadService.generatePayloadForOpr();
        reqPayload['type']='SMS';
        if (reqPayload as unknown as IOtpOnCallRequest && !this.otpViaCallClicked) {
            this.loaderService.startLoader();
            this.otpViaCallClicked = true;
            this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as IOtpOnCallRequest, PATHS.otpOnCall)
                .subscribe({ next: (resp: IOtpOnCallResponse) => {
                    this.loaderService.stopLoader();
                 if(resp['state']){
                    this.store.dispatch(setServerState({ value: resp['state'] }));
                 }
                   this.userOtpForm.reset();
                   this.userOtpForm.controls['otpValue'].enable();
                   // resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
                    if (resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true) {
                        this.widgetService.isPWDgenOPR.next(true);
                    }
                    this.showOtpExpiryMessage=false;
                },
                error: (err) => {
                    this.resetEnteredAndMaskedValue();
                    this.navigationWithWrongAttempts(err);
                }});
        }
        
    }

    private handleAutoRefresh() {
        this.autuRefreshSession = setTimeout(() => {
            location.reload();
        }, 4 * 60 * 1000);
    }

    private navigationWithWrongAttempts(error: HttpErrorResponse) {
        this.isError = true;
        this.userOtpForm.reset();
        if (error.error.rmngAtmpts === 0) {
            this.payloadService.setMoreLoginOptionsSource('OTP');
        }
        if (error.error.error.errorCode === 'BE0050') {
            this.showOtpExpiryMessage = true;
            this.isError = false;
            this.userOtpForm.controls['otpValue'].disable();
            this.userOtpForm.reset();
        } else {
            this.remainingAttemts = this.errorBeanService.handleErrorScenariosInLogin(error);
        }
        if (error.error['showRecaptcha'] === 'Y') {
            this.showGoogleCaptcha = true;
        }
        this.userOtpForm.reset();
    }

}
