import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { CountdownComponent, CountdownEvent } from 'ngx-countdown';
import { of, throwError } from 'rxjs';
import { AuthModule, ConfigService, getEmail, getFlow, getIsdCode, getMobileNumber, getRecaptcha, getServiceId, getTwoFaAuthOptions } from 'src/app/auth/auth.module';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { SetTrustedDeviceIdService } from 'src/app/modules/shared/services/set-trusted-deviceid/set-trusted-deviceid.service';
import { createTranslateLoader, SharedModule } from 'src/app/modules/shared/shared.module';
import { SCREEN_ROUTING_KEYS } from '../../login.constant';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';

import { UserOtpComponent } from './user-otp.component';

fdescribe('UserOtpComponent', () => {
  let component: UserOtpComponent;
  let store: MockStore;
  let fixture: ComponentFixture<UserOtpComponent>;
  let configService: jasmine.SpyObj<ConfigService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let loaderService: jasmine.SpyObj<LoaderService>;
  let loginService: jasmine.SpyObj<LoginService>;
  let errorBeanService: jasmine.SpyObj<ErrorBeanService>;
  let setOnboardCardService: jasmine.SpyObj<SetOnboardCardService>;
  
  const MockConfigService = jasmine.createSpyObj('ConfigService', ['getGck', 'getOnboardingEndPointsWithDomain']);
  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['setMoreLoginOptionsSource', 'generatePayloadForOpr', 'generatePayloadForAuth']);
  const MockPayLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  const MockPayLoginService = jasmine.createSpyObj('LoginService', ['handleOpr', 'validateOtp', 'handleLogin']);
  const MockErrorBeanService = jasmine.createSpyObj('ErrorBeanService', ['handleWrongAttempts', 'handleErrorScenariosInLogin']);
  const MockSetOnboardCardService = jasmine.createSpyObj('SetOnboardCardService', ['checkUserOnboarded']);
  const backgroundCounter = jasmine.createSpyObj('CountdownComponent', ['stop', 'restart']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        RouterTestingModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ UserOtpComponent, CountdownComponent ],
      providers: [
        { provide: ConfigService, useValue: MockConfigService },
        { provide: PayloadService, useValue: MockPayloadService },
        { provide: LoaderService, useValue: MockPayLoaderService },
        { provide: LoginService, useValue: MockPayLoginService },
        { provide: ErrorBeanService, useValue: MockErrorBeanService },
        { provide: SetOnboardCardService, useValue: MockSetOnboardCardService },
        provideMockStore({
          selectors: [
            {
              selector: getFlow,
              value: 'TEST_FLOW'
            },
            {
              selector: getMobileNumber,
              value: '9898989898'
            },
            {
              selector: getEmail,
              value: 'test@email.com'
            },
            {
              selector: getIsdCode,
              value: '91'
            },
            {
              selector: getServiceId,
              value: 'YgvbnmH'
            },
            {
              selector: getTwoFaAuthOptions,
              value: 'TOTP'
            }
          ]
        })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserOtpComponent);
    configService = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    errorBeanService = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    component = fixture.componentInstance;
    
  });

  it('should create', () => {
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');

    fixture.detectChanges();

    expect(component).toBeTruthy();
    expect(component['getDataFromStore']).toHaveBeenCalled();
    expect(component['handleAutoRefresh']).toHaveBeenCalled();
    
  });

  it('should get dna', () => {
    component.getDna('HHGHG776fffYY');
    expect(component.dna).toEqual('HHGHG776fffYY')
  });

  it('should handle captcha success', () => {
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    spyOn<any>(component, 'validateOtpWithOpr');
    spyOn<any>(component, 'validateOtpWithLogin');

   fixture.detectChanges();
   spyOn<any>(component, 'validateOtp').and.callThrough();
   component.handleSuccess('test-captcha');
   expect(component['validateOtp']).toHaveBeenCalled();
   expect(component['validateOtpWithLogin']).toHaveBeenCalled();
  });

  it('should handle captcha success when opr', () => {
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    spyOn<any>(component, 'validateOtpWithOpr');
    spyOn<any>(component, 'validateOtpWithLogin');
    component.storeFlow = 'true';

    fixture.detectChanges();
   spyOn<any>(component, 'validateOtp').and.callThrough();
   component.handleSuccess('test-captcha');

   expect(component['validateOtp']).toHaveBeenCalled();
   expect(component['validateOtpWithOpr']).toHaveBeenCalled();
  });

  it('should call checkMoreLoginOptions', () => {
    component.checkMoreLoginOptions();
    expect(payloadService.setMoreLoginOptionsSource).toHaveBeenCalled();
  })

  it('should call validateOtpWithOpr', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    spyOn<any>(store, 'dispatch');
    spyOn<any>(component, 'handlevalidateOtpSuccessResponseWithOpr').and.callThrough();
    component.storeFlow = 'true';
    fixture.detectChanges();
    loginService.handleOpr.and.returnValue(of({
      flow: 'OTP',
      nextScreen: 'DASHBOARD',
      guid: "6b9bf27c-2e95-4a91-8844-023bdd2b1e76",
      state: "ZmJjOWY3MjQtZWIwMy00Mj",
      securityQuestionFlag: true,
      unBlkSecRemaning: 1234,
      disableMoreOption: true,
      disableBack: true,
      questions: [{'ques': 'ans'}],
      accountQuestions: [{'ques': 'ans'}],
      username: 'test123',
      showRecaptcha: 'true',
      remainingDays: '5',
    }))
    component.handleSuccess('test-captcha');
    loginService.handleOpr({}, '/test').subscribe({ next: response => {
      expect(component['handlevalidateOtpSuccessResponseWithOpr']).toHaveBeenCalled();
      expect(store.dispatch).toHaveBeenCalled();
    } })
  });

  it('should call validateOtpWithOpr when next screen is card', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    spyOn<any>(store, 'dispatch');
    spyOn<any>(component, 'handlevalidateOtpSuccessResponseWithOpr').and.callThrough();
    component.storeFlow = 'NET_BANKING_REGISTER';
    fixture.detectChanges();
    loginService.handleOpr.and.returnValue(of({
      flow: 'OTP',
      nextScreen: SCREEN_ROUTING_KEYS.CARD_NO,
      guid: "6b9bf27c-2e95-4a91-8844-023bdd2b1e76",
      state: "ZmJjOWY3MjQtZWIwMy00Mj",
      securityQuestionFlag: true,
      unBlkSecRemaning: 1234,
      disableMoreOption: true,
      disableBack: true,
      questions: [{'ques': 'ans'}],
      accountQuestions: [{'ques': 'ans'}],
      username: 'test123',
      showRecaptcha: 'true',
      remainingDays: '5',
    }))
    component.handleSuccess('test-captcha');
    loginService.handleOpr({}, '/test').subscribe({ next: response => {
      expect(component['handlevalidateOtpSuccessResponseWithOpr']).toHaveBeenCalled();
      expect(store.dispatch).toHaveBeenCalled();
    } })
  })

  it('should call validateOtpWithOpr with error', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    spyOn<any>(component, 'resetEnteredAndMaskedValue').and.callThrough();
    spyOn<any>(store, 'dispatch');
    spyOn<any>(component, 'handlevalidateOtpSuccessResponseWithOpr').and.callThrough();
    component.storeFlow = 'true';
    fixture.detectChanges();
    loginService.handleOpr.and.returnValue(throwError( () => {
      return {
        error: {
          showRecaptcha: 'Y',
          error: {
            errorCode: 'BE0047'
          }
        }
      }
    }))
    component.handleSuccess('test-captcha');
    loginService.handleOpr({}, '/test').subscribe({ error: (error) => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(component.showGoogleCaptcha).toBe(true);
      expect(component['resetEnteredAndMaskedValue']).toHaveBeenCalled();
    } })
  });

  it('should call validateOtpWithOpr with remainig attempts', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    spyOn<any>(component, 'resetEnteredAndMaskedValue');
    spyOn<any>(store, 'dispatch');
    spyOn<any>(component, 'handlevalidateOtpSuccessResponseWithOpr').and.callThrough();
    component.storeFlow = 'true';
    fixture.detectChanges();
    loginService.handleOpr.and.returnValue(throwError( () => {
      return {
        error: {
          showRecaptcha: 'Y',
          error: {
            errorCode: ''
          }
        }
      }
    }))
    component.handleSuccess('test-captcha');
    loginService.handleOpr({}, '/test').subscribe({ error: (error) => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(component.showGoogleCaptcha).toBe(true);
      expect(component['resetEnteredAndMaskedValue']).toHaveBeenCalled();
      expect(errorBeanService.handleWrongAttempts).toHaveBeenCalled();
    } })
  });

  it('should call validateOtpWithLogin', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    component.serviceIdFromStore = 'test-id';
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    fixture.detectChanges();
    component.storeFlow = '';
   spyOn<any>(component, 'validateOtp').and.callThrough();
   
   loginService.validateOtp.and.returnValue(of({
    accessToken: 'testToken',
    onboarding: 'Y',
    customerInfo: {
        encryptedcrn: 'GHdsjhjhd676uTYU',
        maskcrn: '123456',
        nickname: 'test',
        image: 'test-img',
        initials: 'AB'
    }
   }))
   component.handleSuccess('test-captcha');
   loginService.validateOtp({
        client_id: 'fghDFGH',
        authMethod: 'OTP',
        rememberMeFlag: 'N',
        state: 'FDhjkERTUIKL',
        guid: 'FGHJ-FGHJ-GHJK',
        credential: 'DFGHJghjklEDFG567Ghjjk'
      }, '/testurl').subscribe({next: () => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(setOnboardCardService.checkUserOnboarded).toHaveBeenCalled();
   }})
  
  });

  it('should call validateOtpWithLogin when onboarding flag is N', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    component.serviceIdFromStore = 'test-id';
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    fixture.detectChanges();
    component.storeFlow = '';
   spyOn<any>(component, 'validateOtp').and.callThrough();
   loginService.validateOtp.and.returnValue(of({
    accessToken: 'DFDFGH56',
    onboarding: 'N',
    customerInfo: {
        encryptedcrn: 'GHdsjhjhd676uTYU',
        maskcrn: '123456',
        nickname: 'test',
        image: 'test-img',
        initials: 'AB'
    }
   }))
   component.handleSuccess('test-captcha');
   loginService.validateOtp({
        client_id: 'fghDFGH',
        authMethod: 'OTP',
        rememberMeFlag: 'N',
        state: 'FDhjkERTUIKL',
        guid: 'FGHJ-FGHJ-GHJK',
        credential: 'DFGHJghjklEDFG567Ghjjk'
      }, '/testurl').subscribe({next: () => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
   }})
  
  });

  it('should call validateOtpWithLogin when access token is not availables', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    component.serviceIdFromStore = 'test-id';
    spyOn<any>(component, 'getDataFromStore');
    spyOn<any>(component, 'handleAutoRefresh');
    fixture.detectChanges();
    component.storeFlow = '';
   spyOn<any>(component, 'validateOtp').and.callThrough();
   loginService.validateOtp.and.returnValue(of({
    accessToken: '',
    onboarding: 'N',
    customerInfo: {
        encryptedcrn: 'GHdsjhjhd676uTYU',
        maskcrn: '123456',
        nickname: 'test',
        image: 'test-img',
        initials: 'AB'
    }
   }))
   component.handleSuccess('test-captcha');
   loginService.validateOtp({
        client_id: 'fghDFGH',
        authMethod: 'OTP',
        rememberMeFlag: 'N',
        state: 'FDhjkERTUIKL',
        guid: 'FGHJ-FGHJ-GHJK',
        credential: 'DFGHJghjklEDFG567Ghjjk'
      }, '/testurl').subscribe({next: () => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
   }})
  
  });

  it('should call validateOtpWithLogin when throws error', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    component.serviceIdFromStore = 'test-id';
    spyOn<any>(component, 'resetEnteredAndMaskedValue');
    fixture.detectChanges();
    component.storeFlow = '';
   spyOn<any>(component, 'validateOtp').and.callThrough();
   loginService.validateOtp.and.returnValue(throwError(() => {
     return {
       error: {
        rmngAtmpts : 0,
        showRecaptcha: 'Y',
        error: {
          errorCode: 'BE0050'
        }
       }
     }
   }))
   component.handleSuccess('test-captcha');
   loginService.validateOtp({
        client_id: 'fghDFGH',
        authMethod: 'OTP',
        rememberMeFlag: 'N',
        state: 'FDhjkERTUIKL',
        guid: 'FGHJ-FGHJ-GHJK',
        credential: 'DFGHJghjklEDFG567Ghjjk'
      }, '/testurl').subscribe({error: (error) => {
      expect(component['resetEnteredAndMaskedValue']).toHaveBeenCalled();
      expect(loaderService.stopLoader).toHaveBeenCalled();
   }})
  
  });

  it('should call validateOtpWithLogin when throws error with remaining attempts', () => {
    window.jscd = {
      os: 'os-test',
      browser: 'chrome'
    }
    configService.getGck.and.returnValue('test-gck');
    component.serviceIdFromStore = 'test-id';
    spyOn<any>(component, 'resetEnteredAndMaskedValue');
    fixture.detectChanges();
    component.storeFlow = '';
   spyOn<any>(component, 'validateOtp').and.callThrough();
   loginService.validateOtp.and.returnValue(throwError(() => {
     return {
       error: {
        rmngAtmpts : 0,
        showRecaptcha: 'Y',
        error: {
          errorCode: 'BE0055'
        }
       }
     }
   }))
   component.handleSuccess('test-captcha');
   loginService.validateOtp({
        client_id: 'fghDFGH',
        authMethod: 'OTP',
        rememberMeFlag: 'N',
        state: 'FDhjkERTUIKL',
        guid: 'FGHJ-FGHJ-GHJK',
        credential: 'DFGHJghjklEDFG567Ghjjk'
      }, '/testurl').subscribe({error: (error) => {
      expect(component['resetEnteredAndMaskedValue']).toHaveBeenCalled();
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(errorBeanService.handleErrorScenariosInLogin).toHaveBeenCalled();
   }})
  
  });

  it('should call didntReceiveOtp', () => {
    component.backgroundCounter = backgroundCounter;
    component.backgroundCounter.left = 123456;
    component.didntReceiveOtp();
    expect(component.backgroundCounter.stop).toHaveBeenCalled();
    expect(component.remainingTimeForActualCounter).toEqual(12);
  })
  
  it('should call didntReceiveOtp', () => {
    component.backgroundCounter = backgroundCounter;
    component.backgroundCounter.left = 123;
    component.didntReceiveOtp();
    expect(component.backgroundCounter.stop).toHaveBeenCalled();
    expect(component.remainingTimeForActualCounter).toEqual(1);
  })

  it('should call resetTimer', () => {
    component.backgroundCounter = backgroundCounter;
    component.resetTimer();
    expect(component.backgroundCounter.stop).toHaveBeenCalled();
    expect(component.backgroundCounter.restart).toHaveBeenCalled();
  })

  it('should call resetTimer', () => {
    component.backgroundCounter = backgroundCounter;
    spyOn(component, 'resetTimer')
    const e: CountdownEvent = {
      action: 'done',
      status: 2,
      left: 2,
      text: 'test-data'
    }
    component.defaultOnFinished(e);
    expect(component.resetTimer).toHaveBeenCalled();
  })

  it('should call onFinished', () => {
    component.actualCounter = backgroundCounter;
    spyOn(component, 'resetTimer')
    const e: CountdownEvent = {
      action: 'done',
      status: 2,
      left: 2,
      text: 'test-data'
    }
    component.onFinished(e);
    expect(component.actualCounter.stop).toHaveBeenCalled();
    expect(component.actualCounter.restart).toHaveBeenCalled();
  })

  it('should call otpViaCall when storeFlow is not set', () => {
    spyOn<any>(component, 'otpViaCallWithOpr');
    spyOn<any>(component, 'otpViaCallWithLogin');
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });

    component.otpViaCall();

    expect(component['otpViaCallWithLogin']).toHaveBeenCalled();
  })

  it('should call otpViaCall when storeFlow is set', () => {
    spyOn<any>(component, 'otpViaCallWithOpr');
    spyOn<any>(component, 'otpViaCallWithLogin');
    component.storeFlow = 'OPR';
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });

    component.otpViaCall();

    expect(component['otpViaCallWithOpr']).toHaveBeenCalled();
  })
  it('should call otpViaCallWithOpr', () => {
    component.otpViaCallClicked = false;
    spyOn(store, 'dispatch');
    spyOn<any>(component, 'handleOtpViaCallSuccessResponseWithOpr').and.callThrough();
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: 'OPR',
      guid: 'sdfs-kkvh-kfjf-jhfn',
      oprState: ''
    });
    loginService.handleOpr.and.returnValue(of({
      flow: 'OPR',
      guid: 'sdfs-kkvh-kfjf-jhfn',
      nextScreen: 'test_screen',
      state: 'ASDFGHJKL',
      authMethod: 'OTP',
      pdfRequested: 'N'
    }));
    (component as any).otpViaCallWithOpr();
    loginService.handleOpr(payload, '/testUrl').subscribe({next: () => {
      expect(component['handleOtpViaCallSuccessResponseWithOpr']).toHaveBeenCalled();
      expect(loaderService.stopLoader).toHaveBeenCalled();
    }})

    expect(payloadService.generatePayloadForOpr).toHaveBeenCalled();
  })

  it('should call otpViaCallWithLogin', () => {
    let payload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: '',
      state: '',
      authMethod: 'OTP',
      guid:'jkhk-kljlk-yuui-klkjh',
      credential: 'KJHKHKEFlkjsdfjklsdfklsd',
      rememberMeFlag: 'Y'
    });
  
    component.serviceIdFromStore = 'test_service';
    component.otpViaCallClicked = false;
    loginService.handleLogin.and.returnValue(of({
      state: 'YSDFGHJKGHbjhkbnjkshdjkfhjaslkjfkvyhgdfghjkl',
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true,
    }));

    (component as any).otpViaCallWithLogin();

    loginService.handleLogin(<any>payload, '/testUrl').subscribe({next: (response) => {
      expect(response.pdfRequested).toBe(true);
      expect(response.authMethod).toEqual('SET_CREDENTIAL');
    }});
  })

  it('should call getDataFromStore', () => {
    spyOn(store, 'select').and.returnValue(of('Y'));
    (component as any).getDataFromStore();

    expect(component.showGoogleCaptcha).toBe(true);
    expect(component.moreOptionsStatus).toBe(true);
    expect(store.select).toHaveBeenCalledWith(getMobileNumber);
    expect(store.select).toHaveBeenCalledWith(getEmail);
  })

  it('should call resendOTP when api success', () => {
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });
    let payload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: '',
      state: '',
      authMethod: 'OTP',
      guid:'jkhk-kljlk-yuui-klkjh',
      credential: 'KJHKHKEFlkjsdfjklsdfklsd',
      rememberMeFlag: 'Y'
    });
    component.serviceIdFromStore = 'FGXXCXVjhBNj';
    component.otpViaCallClicked = false;
    spyOn(component.userOtpForm, 'reset');
    loginService.handleLogin.and.returnValue(of({
      state: 'YSDFGHJKGHbjhkbnjkshdjkfhjaslkjfkvyhgdfghjkl',
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true,
    }));
    component.resendOTP('SMS');
    loginService.handleLogin(<any>payload, '/testUrl').subscribe({ next: (response) => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(component.showOtpExpiryMessage).toBe(false);
      expect(component.userOtpForm.reset).toHaveBeenCalled();
    }})
  })

  it('should call resendOTP when api error', () => {
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });
    let payload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: '',
      state: '',
      authMethod: 'OTP',
      guid:'jkhk-kljlk-yuui-klkjh',
      credential: 'KJHKHKEFlkjsdfjklsdfklsd',
      rememberMeFlag: 'Y'
    });
    component.serviceIdFromStore = 'FGXXCXVjhBNj';
    component.otpViaCallClicked = false;
    spyOn<any>(component, 'resetEnteredAndMaskedValue');
    spyOn<any>(component, 'navigationWithWrongAttempts');
    loginService.handleLogin.and.returnValue(throwError(() => { return 'error' }));
    component.resendOTP('SMS');
    loginService.handleLogin(<any>payload, '/testUrl').subscribe({ error: (response) => {
      expect(component['resetEnteredAndMaskedValue']).toHaveBeenCalled();
      expect(component['navigationWithWrongAttempts']).toHaveBeenCalled();
    }})
  })

  it('should call resendOTP on call', () => {
    spyOn(component, 'otpViaCall');

    component.resendOTP('call');
    expect(component.otpViaCall).toHaveBeenCalled();
  })

  it('should call resendOTPinOPR when api success', () => {
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'xXdfghhjkkFGH',
      flow: 'OTP',
      guid: 'Dfghj-fghjd-gshdj-rtyu',
      oprState: 'XXcvbndfghjklFRRFGHJKLllGHJKljhghjk',
    });
    component.serviceIdFromStore = 'FGXXCXVjhBNj';
    component.otpViaCallClicked = false;
    spyOn(component.userOtpForm, 'reset');
    loginService.handleOpr.and.returnValue(of({
      state: 'YSDFGHJKGHbjhkbnjkshdjkfhjaslkjfkvyhgdfghjkl',
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true,
    }));
    component.resendOTPinOPR();
    loginService.handleOpr(<any>payload, '/testUrl').subscribe({ next: (response) => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(component.showOtpExpiryMessage).toBe(false);
      expect(component.userOtpForm.reset).toHaveBeenCalled();
    }})
  })

  it('should call resendOTPinOPR when api error', () => {
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'xXdfghhjkkFGH',
      flow: 'OTP',
      guid: 'Dfghj-fghjd-gshdj-rtyu',
      oprState: 'XXcvbndfghjklFRRFGHJKLllGHJKljhghjk',
    });
    component.serviceIdFromStore = 'FGXXCXVjhBNj';
    component.otpViaCallClicked = false;
    spyOn<any>(component, 'resetEnteredAndMaskedValue');
    spyOn<any>(component, 'navigationWithWrongAttempts');
    loginService.handleOpr.and.returnValue(throwError(() => { return 'errpr' }));
    component.resendOTPinOPR();
    loginService.handleOpr(<any>payload, '/testUrl').subscribe({ error: (response) => {
      expect(component['resetEnteredAndMaskedValue']).toHaveBeenCalled();
      expect(component['navigationWithWrongAttempts']).toHaveBeenCalled();  
    }})
  })

  it('should call navigationWithWrongAttempts', () => {
    component.userOtpForm = new FormGroup({
      otpValue: new FormControl('', [Validators.minLength(6), Validators.maxLength(6)]),
    });
    spyOn(component.userOtpForm, 'reset');
    const error = new HttpErrorResponse({
      error: {
        rmngAtmpts : 0,
        showRecaptcha: 'Y',
        error: {
          errorCode: 'BE0050'
        }
       }
    });
    (component as any).navigationWithWrongAttempts(error);
    expect(payloadService.setMoreLoginOptionsSource).toHaveBeenCalled();
    expect(component.userOtpForm.reset).toHaveBeenCalled();
  })
});
