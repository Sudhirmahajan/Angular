import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnjoyOneTimeTransferCardComponent } from './enjoy-one-time-transfer-card.component';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { Router } from '@angular/router';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { of } from 'rxjs/internal/observable/of';

describe('EnjoyOneTimeTransferCardComponent', () => {
  let component: EnjoyOneTimeTransferCardComponent;
  let fixture: ComponentFixture<EnjoyOneTimeTransferCardComponent>;
  let service: OnboardingService;
  let setOnboardCardServiceObj = jasmine.createSpyObj('SetOnboardCardService', ['checkCardName','navigateToView']);
  let setOnboardCardService : jasmine.SpyObj<SetOnboardCardService>;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ EnjoyOneTimeTransferCardComponent ],
      providers: [
        { provide : SetOnboardCardService, useValue :  setOnboardCardServiceObj},
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnjoyOneTimeTransferCardComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(OnboardingService);
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should navigate', () => {
    component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
    component.isComplete = 'N';
    spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
      { cardId: 'SERVICE', cardName: 'EMERGENCY'}
      );
    spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:'',isCompleted:'Y'}));
    setOnboardCardService.checkCardName.and.returnValue(true);
    component.navigate();
    expect(setOnboardCardService.checkCardName).toHaveBeenCalled();
  });

  it('should navigate second condition', () => {
    component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
    component.isComplete = 'N';
    spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
      { cardId: 'SERVICE', cardName: 'EMERGENCY'}
      );
    spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:1,isCompleted:'N'}));
    setOnboardCardService.checkCardName.and.returnValue(true);
    component.navigate();
    expect(setOnboardCardService.navigateToView).toHaveBeenCalled();
  });

});
