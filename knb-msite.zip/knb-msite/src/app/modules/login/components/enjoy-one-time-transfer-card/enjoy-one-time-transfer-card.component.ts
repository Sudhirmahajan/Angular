import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { PATHS, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-enjoy-one-time-transfer-card',
  templateUrl: './enjoy-one-time-transfer-card.component.html',
  styleUrls: ['./enjoy-one-time-transfer-card.component.scss']
})
export class EnjoyOneTimeTransferCardComponent implements OnInit {

  public cardData: any;
  public mandateryFlag: any;
  cardID: any;
  completedC: any;
  httpSubscription!: Subscription;
  isComplete: any;
  mandateryError!: string;
  completedCard: any;

  
  constructor(
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
  ) { }

  ngOnInit(): void {
    this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
      this.completedCard = this.cardData.completedCard;
      this.mandateryError = 'N';
    });
  }

  navigate(){
    this.cardID = this.cardData.cardId;
    const responseObj = { cardId: this.cardID, cardName: this.cardData.cardName };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(responseObj);
    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding)
        .subscribe((resp: any) => {
          resp['completedCard'] = this.completedCard + 1;
          const cardDetails = this.onboardingService.setOnboardingCardDetails(resp);
          this.isComplete = resp['isCompleted'];
          const cardFlag = this.cardService.checkCardName(resp.cardName);
          if (!cardFlag) {
            this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
          } else  if (this.isComplete === 'Y') {
            this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
          } else if(cardFlag) {
            this.cardService.navigateToView(resp.cardName);
          }
        }, (err) => {


        }
        );
    }

  }

}
