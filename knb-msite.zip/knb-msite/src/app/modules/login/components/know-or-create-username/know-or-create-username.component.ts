import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { AuthenticationService, getClientSessionId, NavigationService, setClientSessionId, setFlow, setGUID, setMsiteFlow, setMsiteUserID, setRecaptcha, setServerState, setUserId } from 'src/app/auth/auth.index';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { GetPartyDataService } from 'src/app/modules/shared/services/get-party-data/get-party-data.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { knoworCreateUserNameCtaname, redirectToKnoworCreateUserName } from '../../login-analystics';
import { FLOWS, PATHS, ROUTE_KEY } from '../../login.constant';
import { IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-know-or-create-username',
  templateUrl: './know-or-create-username.component.html',
  styleUrls: ['./know-or-create-username.component.scss']
})
export class KnowOrCreateUsernameComponent implements OnInit {

  userDetailsForm!: FormGroup;
  httpSubscription!: Subscription;
  clientSessionIdFromRedux!: string;

  constructor(
    private router: Router,
    public navigation: NavigationService,
    private store: Store,
    private authenticationService: AuthenticationService,
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private errorBeanService: ErrorBeanService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
  ) {
    this.store.select(getClientSessionId).subscribe((clientSessionId) => {
      this.clientSessionIdFromRedux = clientSessionId;
    });
   }

  ngOnInit(): void {
    this.setAnalytics('');
    if (!this.clientSessionIdFromRedux) {
      this.store.dispatch(setClientSessionId({ value: this.authenticationService.generateRandom()}));
    }
    this.userDetailsForm = new FormGroup({
      userData: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(19)]),
      rememberMe: new FormControl(false)
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToKnoworCreateUserName
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=knoworCreateUserNameCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 
  dontKnowCrn() {
    this.router.navigateByUrl(ROUTE_KEY['CRN_THROUGH_CARD'], { skipLocationChange: environment.skipURI });
  }

  validateUserDetails() {
    this.loaderService.startLoader();
    this.store.dispatch(setFlow({ value:  FLOWS.getNickname}))
    const inputField = {loginId:this.userDetailsForm.controls['userData'].value.trim()};
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true);
    if (reqPayload as IVerifyCrnRequest) {
        this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
            .subscribe({next: (verifyCrnResponse: IVerifyCrnResponse) => {
              this.loaderService.stopLoader();
              this.handleOprSuccessResponse(verifyCrnResponse);
                   
            }, error: (error) => {
              this.loaderService.stopLoader();
              this.errorBeanService.handleWrongAttempts(error, this.userDetailsForm);
            }});
    }
  }

  private handleOprSuccessResponse(resp: IVerifyCrnResponse) {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.store.dispatch(setUserId({ value: this.userDetailsForm.controls['userData'].value}));
    this.store.dispatch(setMsiteUserID({value: this.userDetailsForm.controls['userData'].value}));
    this.store.dispatch(setMsiteFlow({ value:  resp['flow']})); 
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });

  }

  public back() {
    this.router.navigateByUrl(ROUTE_KEY['CRN'], { skipLocationChange: environment.skipURI });
   }

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

}
