import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { KnowOrCreateUsernameComponent } from './know-or-create-username.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { AuthenticationService, getClientSessionId, NavigationService } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { PayloadService } from '../../services/payload/payload.service';
import { LoginService } from '../../services/login/login.service';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { NgxCaptchaModule } from 'ngx-captcha';
import { LoginRoutingModule } from '../../login-routing.module';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { CountdownModule } from 'ngx-countdown';
import { Store } from '@ngrx/store';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { GetPartyDataService } from 'src/app/modules/shared/services/get-party-data/get-party-data.service';
import { knoworCreateUserNameCtaname } from '../../login-analystics';

describe('KnowOrCreateUsernameComponent', () => {
  let component: KnowOrCreateUsernameComponent;
  let fixture: ComponentFixture<KnowOrCreateUsernameComponent>;
  let store: MockStore;
  let translate: TranslateService;
  let router: Router;

  let MockAuthservice = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  let authService: jasmine.SpyObj<AuthenticationService>;

  let MockLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loaderService: jasmine.SpyObj<LoaderService>;

  let MockPayloadService = jasmine.createSpyObj('PayloadService', ['generatePayloadForOpr','generatePayloadForLogin']);
  let payloadService: jasmine.SpyObj<PayloadService>;

  let MockLoginService = jasmine.createSpyObj('LoginService', ['handleOpr']);
  let loginService: jasmine.SpyObj<LoginService>;

  let MockErrorBeanService = jasmine.createSpyObj('ErrorBeanService', ['handleWrongAttempts']);
  let errorBeanService: jasmine.SpyObj<ErrorBeanService>;

  let MockBundleLoaderInitializerService = jasmine.createSpyObj('BundleLoaderInitializerService', ['startWatchingIdle']);
  let bundleLoaderInitializerService : jasmine.SpyObj<BundleLoaderInitializerService>;


  let MocknavigationService = jasmine.createSpyObj('NavigationService', ['']);
  let navigationService : jasmine.SpyObj<NavigationService>;


  let MockgetPartyDataService = jasmine.createSpyObj('GetPartyDataService', ['getPartyData']);
  let getPartyDataService : jasmine.SpyObj<GetPartyDataService>;


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnowOrCreateUsernameComponent ],
      imports: [
        RouterTestingModule, 
        HttpClientModule,  
        NoopAnimationsModule,
        TranslateModule.forRoot(), 
        NgxCaptchaModule,
        LoginRoutingModule,
        SharedModule,
        CountdownModule,
        NgxCaptchaModule
      ],
      providers : [provideMockStore({
            selectors : [
              {
                selector : getClientSessionId,
                value : ''
              }
            ]

           }), 
          { provide :AuthenticationService , useValue : MockAuthservice},
          { provide :LoaderService , useValue : MockLoaderService},
          { provide :PayloadService , useValue : MockPayloadService},
          { provide :LoginService , useValue : MockLoginService},
          { provide :ErrorBeanService , useValue : MockErrorBeanService},
          { provide :NavigationService , useValue : MocknavigationService},
          { provide :GetPartyDataService , useValue : MockgetPartyDataService},

          { provide :BundleLoaderInitializerService , useValue : MockBundleLoaderInitializerService},
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture              = TestBed.createComponent(KnowOrCreateUsernameComponent);
    component            = fixture.componentInstance;
    authService          = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    loaderService        = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    payloadService       = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loginService         = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    errorBeanService     = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    navigationService    = TestBed.inject(NavigationService) as jasmine.SpyObj<NavigationService>;
    getPartyDataService  = TestBed.inject(GetPartyDataService) as jasmine.SpyObj<GetPartyDataService>;
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    spyOn(store, 'dispatch');
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test dont know CRN', () => {
    
    spyOn(router,'navigateByUrl')
    component.dontKnowCrn();
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('Should check validat user details when handle opr api success', () => {
    spyOn<any>(component, 'handleOprSuccessResponse').and.callThrough();
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: '',
      guid: '',
      oprState: '',
    })

    loginService.handleOpr.and.returnValue(of({
      flow: 'CREATE_USERNAME',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: 'Y',
    }))

    component.validateUserDetails();

    loginService.handleOpr(payload, '/testUrl').subscribe({ next: resp => {
      expect(component['handleOprSuccessResponse']).toHaveBeenCalled;
    } })
    
    expect(component).toBeTruthy();
  });

  it('Should check validat user details when handle opr api error', () => {
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: '',
      guid: '',
      oprState: '',
    })

    loginService.handleOpr.and.returnValue(throwError(() => ''))

    component.validateUserDetails();

    loginService.handleOpr(payload, '/testUrl').subscribe({ error: error => {
      expect(loaderService.stopLoader).toHaveBeenCalled()
      expect(errorBeanService.handleWrongAttempts).toHaveBeenCalled()
    } })
    
  });
  

  it('should handle Opr Success Response', () => {

   const IVerifyCrnResponse={
      flow: 'flow',
      guid: 'guid',
      nextScreen: 'nextScreen',
      state: 'state',
      showRecaptcha: 'string'
  };
    spyOn(router,'navigateByUrl');
    (component as any).handleOprSuccessResponse(IVerifyCrnResponse);
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should set Analytics', () => {
    component.setAnalytics('next');
    expect(window.digitalData).not.toEqual(knoworCreateUserNameCtaname);
    });

});
