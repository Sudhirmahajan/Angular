import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwitchOnInternationalCardsComponent } from './switch-on-international-cards.component';

describe('SwitchOnInternationalCardsComponent', () => {
  let component: SwitchOnInternationalCardsComponent;
  let fixture: ComponentFixture<SwitchOnInternationalCardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SwitchOnInternationalCardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SwitchOnInternationalCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
