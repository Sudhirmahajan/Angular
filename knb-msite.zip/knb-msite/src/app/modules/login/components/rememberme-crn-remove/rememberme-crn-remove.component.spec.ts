import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of } from 'rxjs';
import { BioCatchService } from 'src/app/auth/auth.index';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { RemembermeCrnRemoveComponent } from './rememberme-crn-remove.component';

describe('RemembermeCrnRemoveComponent', () => {
  let component: RemembermeCrnRemoveComponent;
  let fixture: ComponentFixture<RemembermeCrnRemoveComponent>;
  let router: Router;
  let MockBiocatch = jasmine.createSpyObj('BioCatchService', ['biocatchSetValues']);
  let bioCatchService: jasmine.SpyObj<BioCatchService>;
  let store: MockStore;
  let matDialog : jasmine.SpyObj<MatDialog>;
  const MockMatDialog = jasmine.createSpyObj('MatDialog', ['open']);
 
 
  beforeEach(async () => {
   
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ RemembermeCrnRemoveComponent ],
      providers: [
     
        { provide: BioCatchService, useValue: MockBiocatch },
        { provide: MatDialog, useValue: MockMatDialog },
        provideMockStore({
          selectors: [

          ]
        })


      ],
    })
    .compileComponents();
  });





  beforeEach(() => {
    fixture = TestBed.createComponent(RemembermeCrnRemoveComponent);

    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;
    matDialog = TestBed.inject<any>(MatDialog) as jasmine.SpyObj<MatDialog>;

    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.accountList = ['ads','asd'];

    expect(component).toBeTruthy();

  });

  it('should Remove account', () => {
    component.accountList = ['ads','asd'];

    spyOn(router, 'navigateByUrl');
  component.removeAccount(0);
  expect(router.navigateByUrl).toHaveBeenCalled();


  });

  it('should create confirmRemoveAccount', () => {
    const event = new MouseEvent('click'); 
    spyOn(event, 'preventDefault');
    component.accountList = ['ads','asd'];

 
  matDialog.open.and.returnValue(<any>{ afterClosed: () => of(true) });
  component.confirmRemoveAccount(0)

  });

});
