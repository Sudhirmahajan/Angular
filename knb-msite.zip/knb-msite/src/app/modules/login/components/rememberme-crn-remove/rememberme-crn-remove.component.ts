import { Component, OnInit } from '@angular/core';
import { Storage } from '../../utils/storage/storage';
import { MatDialog } from '@angular/material/dialog';
import { RemembermeCrnRemoveDialogComponent } from '../../utils/rememberme-crn-remove-dialog/rememberme-crn-remove-dialog.component';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { BioCatchService, getPageDetails, NavigationService, setPageName } from 'src/app/auth/auth.index';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { preLoginCta, redirectToRememberMeCrnListRemove } from '../../login-analystics';
import { Store } from '@ngrx/store';


@Component({
  selector: 'app-rememberme-crn-remove',
  templateUrl: './rememberme-crn-remove.component.html',
  styleUrls: ['./rememberme-crn-remove.component.scss']
})
export class RemembermeCrnRemoveComponent implements OnInit {
  accountList!: any[];
  private storage = new Storage();
  accountIndex!: number;
  removeFlag!: boolean;
  page_name: any;

  constructor(
    private warningModal: MatDialog,
    public store: Store,
    private router: Router,
    public navigation: NavigationService,
    private bioCatchService: BioCatchService
  ) { }

  ngOnInit() {
    this.setAnalytics();
    this.store.dispatch(setPageName({ value: 'crn list remove' })); 
    this.accountList = this.storage.getStorageData().map((data) => JSON.parse(data.toString()));
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_LOGIN_USER_LIST_REMOVE);
  }

  setAnalytics(){
    window.digitalData=redirectToRememberMeCrnListRemove
    window._satellite?.track("NB-Msiteload");    
  }

  setAnalyticsOnClick(cta_name:any){
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    window.digitalData=preLoginCta({ctaName:cta_name,pageName:this.page_name});
    window._satellite?.track("NB-Msiteclick");
  }

  public removeAccount(account: number) {
    this.accountList.splice(account, 1);
    const updatedAccountList =  this.accountList.map((data) => JSON.stringify(data));
    this.storage.setStorageData(updatedAccountList);
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN_REMOVE_SUCCESS], { skipLocationChange: environment.skipURI });
}

  public confirmRemoveAccount(account: number) {
    this.accountIndex = account;
    this.setAnalyticsOnClick('remove crn');

    const modalRef = this.warningModal.open(RemembermeCrnRemoveDialogComponent, {
      data: { maskcrn: this.accountList[account].maskcrn, removeFlag: true },
      width: '350px',
      height: '250px'
    });

    modalRef.afterClosed().subscribe(result => {
      if(result) {
        this.removeAccount(account);
      }
    });

  }

}
