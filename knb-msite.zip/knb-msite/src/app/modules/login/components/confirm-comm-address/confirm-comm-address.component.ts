import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-comm-address',
  templateUrl: './confirm-comm-address.component.html',
  styleUrls: ['./confirm-comm-address.component.scss']
})
export class ConfirmCommAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
