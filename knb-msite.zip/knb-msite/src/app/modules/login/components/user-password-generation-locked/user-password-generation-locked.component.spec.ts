import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

import { UserPasswordGenerationLockedComponent } from './user-password-generation-locked.component';
import { getRemainingDays } from 'src/app/auth/auth.index';

describe('UserPasswordGenerationLockedComponent', () => {
  let component: UserPasswordGenerationLockedComponent;
  let fixture: ComponentFixture<UserPasswordGenerationLockedComponent>;
  let router :Router;
  let store: MockStore;
  const remainingDays = '20Days';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPasswordGenerationLockedComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],
      providers:[
        provideMockStore({
          selectors:[
              {
                  selector: getRemainingDays,
                  value: [
                      {
                          remainingDay: remainingDays,
                      },
                  ],
              },
          ]
      })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordGenerationLockedComponent);
    router = TestBed.inject(Router);
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to physical PIN', () => {
    spyOn(router,'navigateByUrl')
    component.navigateToPhysicalPin();
    expect(router.navigateByUrl).toHaveBeenCalled();
   });


  it('should subscribe to Remaining Days',()=>{
    component.ngOnInit();
    store.select(getRemainingDays).subscribe((response) => {
      expect(response).toContain({ remainingDay: '20Days' })
    });
  });

});
