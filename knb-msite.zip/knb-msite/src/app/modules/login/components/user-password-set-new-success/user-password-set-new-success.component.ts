import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { redirectToUserPasswordUnblockSuccess, userPasswordUnblockSuccessCtaname } from '../../login-analystics';

@Component({
  selector: 'app-user-password-set-new-success',
  templateUrl: './user-password-set-new-success.component.html',
  styleUrls: ['./user-password-set-new-success.component.scss']
})
export class UserPasswordSetNewSuccessComponent implements OnInit {

  isSet!: boolean

  constructor(
    private widgetservice: WidgetService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');
    this.widgetservice.isPWDviaPDFset.subscribe(res=>{
      this.isSet=res;
    })
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserPasswordUnblockSuccess
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=userPasswordUnblockSuccessCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
  
  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

}
