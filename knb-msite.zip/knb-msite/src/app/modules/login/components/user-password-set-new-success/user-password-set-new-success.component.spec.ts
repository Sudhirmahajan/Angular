import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore , provideMockStore} from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { UserPasswordSetNewSuccessComponent } from './user-password-set-new-success.component';

describe('UserPasswordSetNewSuccessComponent', () => {
  let component: UserPasswordSetNewSuccessComponent;
  let fixture: ComponentFixture<UserPasswordSetNewSuccessComponent>;
  let router :Router;
  let service: WidgetService;
  let store: MockStore;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPasswordSetNewSuccessComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],
      providers:[
        provideMockStore({
          selectors:[
              
          ]
      })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordSetNewSuccessComponent);
    router = TestBed.inject(Router);
    service = TestBed.inject(WidgetService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
    
})

});

