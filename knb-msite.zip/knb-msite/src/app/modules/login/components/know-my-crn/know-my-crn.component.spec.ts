import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { KnowMyCrnComponent } from './know-my-crn.component';
import { redirectToKnowMyCRNCard } from '../../login-analystics';

describe('KnowMyCrnComponent', () => {
  let component: KnowMyCrnComponent;
  let fixture: ComponentFixture<KnowMyCrnComponent>;
  let translate: TranslateService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnowMyCrnComponent ],
      imports:[RouterTestingModule,    
        TranslateModule.forRoot(),
    ],
  })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KnowMyCrnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle another Option',()=>{
    let viaCard: boolean = true;
    component.handleAnotherOption();
    expect(!viaCard).toBeFalse();    
  });



  it('should handle back navigation',()=>{
    spyOn(component.navigation,'goBack')
    let viaCard: boolean = true;
    component.handleBackNavigation();
    expect(component.navigation.goBack).toHaveBeenCalled();
  });


  it('should navigate', () => {
    spyOn(component.router,'navigateByUrl')
    component.naviateToLogin();
    expect(component.router.navigateByUrl).toHaveBeenCalled();
   });

   it('should set Analytics', () => {
    component.setAnalytics('next');
    expect(window.digitalData).not.toEqual(redirectToKnowMyCRNCard);
    });

});
