import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationService } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { redirectToKnowMyCRNCard, knowMyCRNCardCtaname, redirectToKnowMyCRNMobilleNo, KnowMyCRNMobilleNoCtaname } from '../../login-analystics';
import { ROUTE_KEY } from '../../login.constant';

@Component({
  selector: 'app-know-my-crn',
  templateUrl: './know-my-crn.component.html',
  styleUrls: ['./know-my-crn.component.scss']
})
export class KnowMyCrnComponent implements OnInit {
  viaCard: boolean = true;
  constructor(public navigation: NavigationService,
    public router: Router) { }

  ngOnInit(): void {
    this.setAnalytics('');
  }

  setAnalytics(ctaname: any) {
    if (ctaname === '') {
       if (this.viaCard) {
         window.digitalData = redirectToKnowMyCRNCard
       } else {
        window.digitalData = redirectToKnowMyCRNMobilleNo
      }
      window._satellite?.track("NB-Msiteload");
    } else {
      if (this.viaCard) {
        window.digitalData = knowMyCRNCardCtaname(ctaname)
      } else {
        window.digitalData = KnowMyCRNMobilleNoCtaname(ctaname)
      }
      window._satellite?.track("NB-Msiteclick");
    }
  }

  naviateToLogin() {
    this.router.navigateByUrl(ROUTE_KEY['CRN'], { skipLocationChange: environment.skipURI });
  }

  handleAnotherOption() {
    if (this.viaCard) {
      this.viaCard = false
      this.setAnalytics('')
    }
    
  }

  handleBackNavigation() {
    if (this.viaCard) {
      this.navigation.goBack()
    } else {
      this.viaCard = true;
    }
  }

}
