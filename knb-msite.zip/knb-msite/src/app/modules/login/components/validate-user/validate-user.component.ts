import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { BioCatchService, NavigationService, setFlow, setGUID, setMsiteFlow, setMsiteUserID, setRecaptcha, setServerState, setUserId } from 'src/app/auth/auth.index';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { redirectToValidateUser, validateUserCtaname } from '../../login-analystics';
import { FLOWS, PATHS, ROUTE_KEY } from '../../login.constant';
import { IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-validate-user',
  templateUrl: './validate-user.component.html',
  styleUrls: ['./validate-user.component.scss']
})
export class ValidateUserComponent implements OnInit {
  userDetailsForm!: FormGroup;
  httpSubscription!: Subscription;
  
  constructor(
    private loaderService: LoaderService,
    private store: Store,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private router: Router,
    public navigation: NavigationService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private bioCatchService: BioCatchService,
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_OPR_USERNAME);
    this.userDetailsForm = new FormGroup({
      userData: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(35)]),
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToValidateUser
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=validateUserCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }


  public validateUserDetails(): void {
    this.loaderService.startLoader();
    this.store.dispatch(setFlow({ value:  FLOWS.resetCredential}))
    const rememberMe = 'N';
    const inputField = {loginId:this.userDetailsForm.controls['userData'].value.trim()};
    const userID =    this.userDetailsForm.controls['userData'].value.trim();
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true);
    const payloadForValidUser = this.payloadService.generatePayloadForLogin(userID, rememberMe);

    if (reqPayload as IVerifyCrnRequest) {
    
      this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe({next: (handleOprResp: IVerifyCrnResponse) => {

          this.loaderService.stopLoader();
          this.handleOprSuccessResponse(handleOprResp);
         
        }, error: (errorBean) => {
          this.loaderService.stopLoader();
      }});
    }
  }

  public back() {
    this.router.navigateByUrl(ROUTE_KEY['CRN'], { skipLocationChange: environment.skipURI });
   }

  handleOprSuccessResponse(resp: IVerifyCrnResponse) {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.store.dispatch(setUserId({ value: this.userDetailsForm.controls['userData'].value}));
    this.store.dispatch(setMsiteUserID({value: this.userDetailsForm.controls['userData'].value}));
    this.store.dispatch(setMsiteFlow({ value:  resp['flow']})); 
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

}
