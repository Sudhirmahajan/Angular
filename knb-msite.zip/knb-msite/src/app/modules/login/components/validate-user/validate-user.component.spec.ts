import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of } from 'rxjs';
import { BioCatchService } from 'src/app/auth/auth.index';
import { YourLoansComponent } from 'src/app/modules/onboarding/components/your-loans/your-loans.component';
import { OnboardingModule } from 'src/app/modules/onboarding/onboarding.module';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { ValidateUserComponent } from './validate-user.component';

describe('ValidateUserComponent', () => {
  let component: ValidateUserComponent;
  let fixture: ComponentFixture<ValidateUserComponent>;
  let MockLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loaderService: jasmine.SpyObj<LoaderService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let MockPayservice = jasmine.createSpyObj('PayloadService', ['generatePayloadForOpr']);
  let loginService: jasmine.SpyObj<LoginService>;
  let MockLoginservice = jasmine.createSpyObj('LoginService', ['handleOpr']);
  let bundleLoaderInitializerService;
  const MockBundleLoaderInitializerService = jasmine.createSpyObj('BundleLoaderInitializerService', ['startWatchingIdle', 'changeBundleLoaderStatus']);
  let MockBiocatch = jasmine.createSpyObj('BioCatchService', ['biocatchSetValues']);
  let bioCatchService: jasmine.SpyObj<BioCatchService>;


  let store: MockStore;
  let router: Router;

  beforeEach(async () => {

    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        OnboardingModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ValidateUserComponent],

      providers: [
        { provide: LoaderService, useValue: MockLoaderService },
        { provide: PayloadService, useValue: MockPayservice },
        { provide: LoginService, useValue: MockLoginservice },
        { provide: BundleLoaderInitializerService, useValue: MockBundleLoaderInitializerService },
        { provide: BioCatchService, useValue: MockBiocatch },
        provideMockStore({
          selectors: [

          ]
        })


      ],
    })
      .compileComponents();
  });


  beforeEach(() => {
    fixture = TestBed.createComponent(ValidateUserComponent);
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;

    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService);
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });


  it('should validateUser Details', () => {
    spyOn(store, 'dispatch').and.callThrough();
    spyOn<any>(component, 'handleOprSuccessResponse').and.callThrough();
    fixture.detectChanges();

    component.userDetailsForm.setValue({
      userData: '12013136'

    })
    payloadService.generatePayloadForOpr.and.callThrough();
    const reqPayload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'test',
      flow: '',
      guid: '',
      oprState: '',
    });

    const response = {
      flow: 'USERNAME',
      guid: 'AssdAAddfs6',
      nextScreen: 'PASSWORD',
      state: 'RESET',
      showRecaptcha: 'N'
    }
    loginService.handleOpr.and.returnValue(of(response));

    component.validateUserDetails();

    expect(loaderService.startLoader).toHaveBeenCalled();

    expect(store.dispatch).toHaveBeenCalled();




  });


});
