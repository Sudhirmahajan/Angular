import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthenticateUsingOtpComponent } from './authenticate-using-otp.component';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { of } from 'rxjs';

describe('AuthenticateUsingOtpComponent', () => {
  let component: AuthenticateUsingOtpComponent;
  let fixture: ComponentFixture<AuthenticateUsingOtpComponent>;
  let service: OnboardingService;
  let setOnboardCardServiceObj = jasmine.createSpyObj('SetOnboardCardService', ['checkCardName','navigateToView']);
  let setOnboardCardService : jasmine.SpyObj<SetOnboardCardService>;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ AuthenticateUsingOtpComponent ],
      providers: [
      //  { provide: OnboardingService, useValue: Mockservice },
        { provide : SetOnboardCardService, useValue :  setOnboardCardServiceObj},
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthenticateUsingOtpComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(OnboardingService);
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
     expect(component).toBeTruthy();
  });

  it('should showList', () => {
    service.cardDataObj=new BehaviorSubject<any>({ ad : ''}).asObservable();
    (component as any).showList();
    service.cardDataObj.subscribe((data)=>{
    component.completedC=data;
    expect(component.completedC).toEqual({ ad : ''});
    });
  });

  it('should called on Submit', () => {
    component.responseCardId = '123';
    component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
    component.topBorder = 0;
    component.isComplete = 'N';
    spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
    { cardId: 'SERVICE', cardName: 'EMERGENCY', data: { twoFaFlag: 'Y' } }
    );
    spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:'',isCompleted:'Y'}));
    setOnboardCardService.checkCardName.and.returnValue(true);
    component.onSubmit();
    expect(setOnboardCardService.checkCardName).toHaveBeenCalled();
 });

 it('should called on Submit without card Flag', () => {
  component.responseCardId = '123';
  component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
  component.topBorder = 0;
  component.isComplete = 'N';
  spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
  { cardId: 'SERVICE', cardName: 'EMERGENCY', data: { twoFaFlag: 'Y' } }
  );
  spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:1,isCompleted:'N'}));
  setOnboardCardService.checkCardName.and.returnValue(true);
  component.onSubmit();
  expect(setOnboardCardService.checkCardName).toHaveBeenCalled();
});


it('should called on Skip', () => {
  component.responseCardId = '123';
  component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
  component.topBorder = 0;
  component.isComplete = 'N';
  spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
  { cardId: 'SERVICE', cardName: 'EMERGENCY', data: { twoFaFlag: 'Y' } }
  );
  spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:1,isCompleted:'N'}));
  component.onSkip();
  expect(setOnboardCardService.navigateToView).toHaveBeenCalled();
});



    
});
