import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Storage } from '../../utils/storage/storage';
import { AuthenticationService, BioCatchService, getPageDetails, resetStore, setCardDetailsBlockedStatus, setChannelBlockedStatus, setClientSessionId, setCredentialBlockedStatus, setFlow, setGUID, setMobileNotUpdatedStatus, setPageName, setRecaptcha, setRememberMeDetails, setServerState } from 'src/app/auth/auth.index';
import { Subscription } from 'rxjs';
import { PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { PayloadService } from '../../services/payload/payload.service';
import { LoginService } from '../../services/login/login.service';
import { ILoginSuccessResp, IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { preLoginCta, redirectToRememberMeCrnList } from '../../login-analystics';

@Component({
  selector: 'app-rememberme-crn-list',
  templateUrl: './rememberme-crn-list.component.html',
  styleUrls: ['./rememberme-crn-list.component.scss']
})
export class RemembermeCrnListComponent implements OnInit {
  clientSessionIdFromRedux!: string;
  accountList!: any[];
  private storage = new Storage();
  httpSubscription!: Subscription;
  dataToStore!: { image: string; 
    maskcrn: string; 
    nickname: string; 
    initials: string;
    shortName: string 
  };
  page_name: any;
  

  constructor(
    public store: Store,
    private authenticationService: AuthenticationService,
    private rememberMeService: RememberMeService,
    private router: Router,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private bioCatchService: BioCatchService
  ) { }

  ngOnInit() {
    this.setAnalytics();
    this.store.dispatch(resetStore());
    this.store.dispatch(setPageName({ value: 'crn list' })); 
    if (!this.clientSessionIdFromRedux) {
        this.store.dispatch(setClientSessionId({ value: this.authenticationService.generateRandom()}));
    }
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_LOGIN_USER_LIST);
    this.accountList = this.storage.getStorageData().map((data) => JSON.parse(data.toString()));
    document.getElementById('splash')!.style.display = 'none'; 
  }

  setAnalytics(){
    window.digitalData=redirectToRememberMeCrnList
    window._satellite?.track("NB-Msiteload");    
  }

  setAnalyticsOnClick(cta_name:any){
    this.store.select(getPageDetails).subscribe((resp:any)=>{this.page_name=resp})
    window.digitalData=preLoginCta({ctaName:cta_name,pageName:this.page_name});
    window._satellite?.track("NB-Msiteclick");
  }


  ngOnDestroy() {
     if (this.httpSubscription) {
        this.httpSubscription.unsubscribe();
    }
  }

  public useAnotherAccount() {
    this.rememberMeService.useAnotherAccountFlag = true;
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

  public selectAccount(i: number) {
    this.dataToStore = {
        image: this.accountList[i]['image'],
        maskcrn: this.accountList[i]['maskcrn'],
        nickname: this.accountList[i]['nickname'],
        initials: this.accountList[i]['initials'],
        shortName: this.accountList[i]['shortName']
    };
    const reqPayload = this.payloadService.generatePayloadForCrnList(this.accountList[i]['encryptedcrn']);
    if (reqPayload) {
        this.httpSubscription = this.loginService.validateUserName(reqPayload, PATHS.login, { rememberMeFlag:'Y' })
            .subscribe((resp: ILoginSuccessResp) => {
                this.handleCrnSuccessResponse(resp);
            });
    }
  }

  private handleCrnSuccessResponse(resp: ILoginSuccessResp) {
    (resp['authMethod'] === SCREEN_ROUTING_KEYS.MOBILE) ?
        this.handleBlockedUsername(resp) : this.handleValidUsername(resp);
}

private handleBlockedUsername(resp: ILoginSuccessResp): void {
    this.store.dispatch(setFlow({ value: resp['flow']}))
    this.processBlockedUsername();
}

  private processBlockedUsername(): void {
      const inputField = { loginId: this.accountList[0]['encryptedcrn'] };
      const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true, true);
      if (reqPayload as IVerifyCrnRequest) {
          this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
              .subscribe((resp: IVerifyCrnResponse) => {
                  this.handleOprSuccessResponse(resp);
              });
      }
  }

  private handleOprSuccessResponse(resp: IVerifyCrnResponse): void {
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
}

  private handleValidUsername(resp: ILoginSuccessResp) {
      
      (resp['flow'] !== 'LOGIN') && this.store.dispatch(setFlow({value: resp['flow']}));
      resp['crdntlBlk'] && this.store.dispatch(setCredentialBlockedStatus({value: resp['crdntlBlk']}));
      resp['cdtBlk'] && this.store.dispatch(setCardDetailsBlockedStatus({value: resp['cdtBlk']}));
      resp['chnlBlk'] && this.store.dispatch(setChannelBlockedStatus({value: resp['chnlBlk']}));
      resp['mblNtUpdtd'] && this.store.dispatch(setMobileNotUpdatedStatus({value: resp['mblNtUpdtd']}));
      resp['showRecaptcha'] && this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}));

      this.store.dispatch(setRememberMeDetails({value: this.dataToStore}));
      this.store.dispatch(setServerState({value: resp['state']}));
      this.store.dispatch(setGUID({value: resp['guid']}));
      this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CREDENTIAL_WITH_USER], { skipLocationChange: environment.skipURI });
  }

  public removeAccount() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN_LIST_REMOVE], { skipLocationChange: environment.skipURI });
}

}
