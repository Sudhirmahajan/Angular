import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

import { RemembermeCrnListComponent } from './rememberme-crn-list.component';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { PayloadService } from '../../services/payload/payload.service';
import { LoginService } from '../../services/login/login.service';
import { PATHS } from '../../login.constant';
import { ILoginSuccessResp, IVerifyCrnResponse } from '../../models/login.model';
import { of } from 'rxjs';
import { Component } from '@angular/core';

describe('RemembermeCrnListComponent', () => {
  let component: RemembermeCrnListComponent;
  let fixture: ComponentFixture<RemembermeCrnListComponent>;
  let store : Store;
  let router: Router;

  let payloadServiceObj = jasmine.createSpyObj('PayloadService', ['generatePayloadForCrnList', 'generatePayloadForOpr']);
  let payloadService: jasmine.SpyObj<PayloadService>;

  let loginServiceObj = jasmine.createSpyObj('LoginService', ['handleOpr', 'validateUserName']);
  let loginService: jasmine.SpyObj<LoginService>;


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,],
      declarations: [ RemembermeCrnListComponent ],
      providers:[
        { provide : PayloadService, useValue : payloadServiceObj},
        { provide : LoginService , useValue : loginServiceObj },
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemembermeCrnListComponent);
    component = fixture.componentInstance;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    spyOn(store, 'dispatch');
    component.accountList = ['image','maskcrn', 'nickname', 'initials', 'shortName', 'encryptedcrn'];
    //store.setStorageData(userData);
    fixture.detectChanges();
  });

  it('should Test useAnotherAccount', () => {
    spyOn(router,'navigateByUrl')
    component.useAnotherAccount();
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should Test handleCrnSuccessResponse for handleBlockedUsername', () => {
    
    let loginSuccessResp :ILoginSuccessResp ={
      authMethod: 'MOBILE',
      flow: '',
      guid: '',
      state: '',
      statusCode: 200,
      crdntlBlk: '',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: '',
  };

  spyOn(component,'handleBlockedUsername' as never);
  (component as any).handleCrnSuccessResponse(loginSuccessResp);
  expect((component as any).handleBlockedUsername).toHaveBeenCalled();

  });

  it('should Test handleCrnSuccessResponse for handleValidUsername', () => {
    
    let loginSuccessResp :ILoginSuccessResp ={
      authMethod: '',
      flow: '',
      guid: '',
      state: '',
      statusCode: 123,
      crdntlBlk: 'ABC',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: ''
  };

  spyOn(component,'handleValidUsername' as never);
  (component as any).handleCrnSuccessResponse(loginSuccessResp);
  expect((component as any).handleValidUsername).toHaveBeenCalled();

  });

  it('should Test handleBlockedUsername', () => {
    
    const Resp =  {
      authMethod: 'MOBILE',
      flow: '',
      guid: 'abc',
      state: 'abc',
      statusCode: 200,
      crdntlBlk: 'ascv',
      cdtBlk: 'abc',
      chnlBlk: 'abc',
      mblNtUpdtd: 'abc',
      showRecaptcha: 'abc',
      cardDetailsLogin: 'abc',
  };
  
  spyOn(component,'processBlockedUsername' as never);
  (component as any).handleBlockedUsername(Resp);
  expect((component as any).processBlockedUsername).toHaveBeenCalled();

  });

  it('should Test handleValidUsername', () => {
    const Resp =  {
      authMethod: 'MOBILE',
      flow: '',
      guid: 'abc',
      state: 'abc',
      statusCode: 200,
      crdntlBlk: 'ascv',
      cdtBlk: 'abc',
      chnlBlk: 'abc',
      mblNtUpdtd: 'abc',
      showRecaptcha: 'abc',
      cardDetailsLogin: 'abc',
  };
    spyOn(router, 'navigateByUrl');
    //component['handleValidUsername'];
    (component as any).handleValidUsername(Resp);
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should Test removeAccount', () => {
    
    spyOn(router, 'navigateByUrl');
    component.removeAccount();
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should Test handleOprSuccessResponse', () => {
   
    const IVerifyCrnResponse =  {
      flow:'a',
      guid: 'a',
      nextScreen: 'a',
      state: 'a',
      showRecaptcha: 'abc',
  };
   spyOn(router, 'navigateByUrl');
    (component as any).handleOprSuccessResponse(IVerifyCrnResponse);
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should Test processBlockedUsername', () => {
   
  component.accountList = ['image','maskcrn', 'nickname', 'initials', 'shortName', 'encryptedcrn'];
   const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'A',
      flow: 'A',
      guid: 'A',
      oprState: 'A',
    });

    loginService.handleOpr.and.returnValue(of({
      flow: 'CREATE_USERNAME',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: 'Y',
    }));

    let loginSuccessResp :ILoginSuccessResp ={
      authMethod: 'MOBILE',
      flow: '',
      guid: 'abc',
      state: 'abc',
      statusCode: 200,
      crdntlBlk: 'ascv',
      cdtBlk: 'abc',
      chnlBlk: 'abc',
      mblNtUpdtd: 'abc',
      showRecaptcha: 'abc',
      cardDetailsLogin: 'abc',
   };
  
    spyOn(component,'handleOprSuccessResponse' as never);
    (component as any).processBlockedUsername(loginSuccessResp);
   loginService.handleOpr(payload, '/verifyCrnUrl').subscribe({
      next: (loginSuccessResp) => {
      expect((component as any).handleOprSuccessResponse).toHaveBeenCalled();
      }
    });

  });

  it('should Test selectAccount', () => {
  
    payloadService.generatePayloadForCrnList.and.returnValue({
       client_id: 'sd',
       authMethod: 'NA',
       userId: 'ads',
       rememberMeFlag: 'Y',
     });
   
     let reqPayload = {
       client_id: '',
       authMethod: '',
       userId: '',
       rememberMeFlag: '',
     };
    component.accountList = ['image','maskcrn', 'nickname', 'initials', 'shortName', 'encryptedcrn'];
     
     let loginSuccessResp  = {
      authMethod: '',
      flow: '',
      guid: '',
      state: '',
      statusCode: 200,
      crdntlBlk: '',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: '',
   };
    // spyOn(component,'handleCrnSuccessResponse' as never);
    loginService.validateUserName.and.returnValue(of(loginSuccessResp));
     component.selectAccount(1);
      loginService.validateUserName(reqPayload, 'loginUrl').subscribe({
        next: (loginSuccessResp) => {
         // expect((component as any).handleCrnSuccessResponse).toHaveBeenCalled();
  
          expect(loginSuccessResp).toEqual(loginSuccessResp);
        }
      });
     
     });

  

});
