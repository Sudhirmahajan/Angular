import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-unable-to-process',
  templateUrl: './unable-to-process.component.html',
  styleUrls: ['./unable-to-process.component.scss']
})
export class UnableToProcessComponent implements OnInit {

  constructor (
    private router: Router
  ) { }

  ngOnInit(){
    document.getElementById('splash')!.style.display = 'none';
  }
  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

}
