import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RekycCardComponent } from './rekyc-card.component';

describe('RekycCardComponent', () => {
  let component: RekycCardComponent;
  let fixture: ComponentFixture<RekycCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RekycCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RekycCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
