import { Component, OnInit } from '@angular/core';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-rekyc-card',
  templateUrl: './rekyc-card.component.html',
  styleUrls: ['./rekyc-card.component.scss']
})
export class RekycCardComponent implements OnInit {

  constructor(
    private cardService:SetOnboardCardService,
  ) { }

  ngOnInit(): void {
  }

  navigate(){
    this.cardService.navigateToView(SCREEN_ROUTING_KEYS.SERVICE_NOT_FOUND);
  }
}
