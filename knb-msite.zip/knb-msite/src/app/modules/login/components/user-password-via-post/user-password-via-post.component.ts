import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { getDisableBackFlag, setPhysicalPinDate, setPhysicalPinDays, setServerState } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { redirectToUserPasswordViaPost, userPasswordViaPostCtaname } from '../../login-analystics';
import { PATHS, ROUTE_KEY } from '../../login.constant';
import { IOprBackOperationsRequest, IOprBackOperationsResponse, IPhysicalPinRequest, IPhysicalPinResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-user-password-via-post',
  templateUrl: './user-password-via-post.component.html',
  styleUrls: ['./user-password-via-post.component.scss']
})
export class UserPasswordViaPostComponent implements OnInit {

  public storeDisableBackFlag!: boolean;
  public isLoading!: boolean;
  private httpSubscription!: Subscription;

  constructor(
    private payloadService: PayloadService,
    private router: Router,
    private store: Store,
    private loginService: LoginService,
    private loaderService: LoaderService,
  ) { }

  ngOnInit() {
    this.setAnalytics('');
    this.getDataFromStore();
  }

  
  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserPasswordViaPost
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=userPasswordViaPostCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

  public requestCredentialViaPost() {
    this.loaderService.startLoader();
    const payload = this.payloadService.generatePayloadForOpr();
    if (payload as unknown as IPhysicalPinRequest) {
      this.httpSubscription = this.loginService.handleOpr(payload as unknown as IPhysicalPinRequest, PATHS.physicalPin)
        .subscribe((resp: IPhysicalPinResponse) => {
          this.handleCredentialSuccessResp(resp);
        });
    }
  }

  public back() {
    this.loaderService.startLoader();
    const payload = this.payloadService.generatePayloadForOpr();
    if (payload as unknown as IOprBackOperationsRequest) {
      this.httpSubscription =
        this.loginService.handleOpr(payload as unknown as IOprBackOperationsRequest, PATHS.oprBackOperations)
          .subscribe((resp: IOprBackOperationsResponse) => {
            this.handleBackOperation(resp);
          });
    }
  }

  private handleBackOperation(resp: IOprBackOperationsResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value: resp['state'] }));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  private handleCredentialSuccessResp(resp: IPhysicalPinResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value: resp['state'] }));
    resp['physicalPinDate'] && this.store.dispatch(setPhysicalPinDate({ value: resp['physicalPinDate'] }));
    resp['physicalPinDays'] && this.store.dispatch(setPhysicalPinDays({ value: resp['physicalPinDays'] }));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  private getDataFromStore() {
    this.store.select(getDisableBackFlag).subscribe((resp) => { this.storeDisableBackFlag = resp; });
  }
}
