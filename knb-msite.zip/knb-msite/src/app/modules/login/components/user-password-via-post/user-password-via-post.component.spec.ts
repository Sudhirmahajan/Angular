import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule, getDisableBackFlag } from 'src/app/auth/auth.module';
import { createTranslateLoader, SharedModule } from 'src/app/modules/shared/shared.module';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { UserPasswordViaPostComponent } from './user-password-via-post.component';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { of, Subscription } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UserPasswordViaPostComponent', () => {
  let component: UserPasswordViaPostComponent;
  let fixture: ComponentFixture<UserPasswordViaPostComponent>;
  let store: MockStore;
  let router :Router;
  let loaderService: jasmine.SpyObj<LoaderService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let loginService: jasmine.SpyObj<LoginService>;
  const MockPayLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['setMoreLoginOptionsSource', 'generatePayloadForOpr', 'generatePayloadForAuth']);
  const MockPayLoginService = jasmine.createSpyObj('LoginService', ['handleOpr', 'validateOtp']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPasswordViaPostComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        HttpClientTestingModule,
        AuthModule.forRoot('env'),
        SharedModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],
      providers:[
        provideMockStore({
          selectors:[
            {
             selector: getDisableBackFlag,
             value: true
            },
            {
              selector: getDisableBackFlag,
              value: true
             },
             
          ]
      }),
      { provide: LoaderService, useValue: MockPayLoaderService },
      { provide: PayloadService, useValue: MockPayloadService },
      { provide: LoginService, useValue: MockPayLoginService },

      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordViaPostComponent);
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    router = TestBed.inject(Router);    
    store=TestBed.inject(MockStore)
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call loader Service',()=>{
    const payload = {
      client_id: "knb2",
      flow: '"REQUEST_CREDENTIAL"',
      guid: "dc5c41f4-e4db-4c8d-a86a-d2394db1ad56",
      loginId: "ZmJjOWY3MjQtZWIwMy01Mj",
      oprState: ""
    }
    
    component.back()
    payloadService.generatePayloadForOpr.and.returnValue(payload);
   
  })

  it('should call loader Service',()=>{
  //  spyOn<any>(component, 'handleBackOperation').and.callThrough();
    loginService.handleOpr.and.returnValue(of({
      flow: 'OTP',
      nextScreen: 'DASHBOARD',
      guid: "dd9bf27c-2e95-4a91-8864-023bdd2b1e76",
      state: "ZmJjOWY3MjQtZWIwMy0Mjf",
      securityQuestionFlag: true,
      unBlkSecRemaning: 1234,
      disableMoreOption: true,
      disableBack: true,
      questions: [{'ques': 'ans'}],
      accountQuestions: [{'ques': 'ans'}],
      username: 'test123',
      showRecaptcha: 'true',
      remainingDays: '5',
    }))
    fixture.detectChanges();
    loginService.handleOpr({}, '/test').subscribe((response) => {
      fixture.detectChanges();
      expect(component['handleBackOperation']).toHaveBeenCalled;
    })

    
  })

  it('should request Credential Via Post(',()=>{
    const payload = {
      client_id: "knb2",
      flow: '"REQUEST_CREDENTIAL"',
      guid: "ac5c41f4-e4db-4d8d-a8da-c239ddddad56",
      loginId: "ZmJjOWYasdsatZWIwMy00Mj",
      oprState: ""
    }

    spyOn<any>(component, 'handleCredentialSuccessResp').and.callThrough();

    component.requestCredentialViaPost()
    payloadService.generatePayloadForOpr.and.returnValue(payload);

    loginService.handleOpr.and.returnValue(of({
      flow: 'OTP',
      nextScreen: 'DASHBOARD',
      guid: "ac5c41f4-e4db-4d8d-a8da-c239ddddad56",
      state: "ZmJjOWY3MjQtZWIwMy00Mj",
      securityQuestionFlag: true,
      unBlkSecRemaning: 1234,
      disableMoreOption: true,
      disableBack: true,
      questions: [{'ques': 'ans'}],
      accountQuestions: [{'ques': 'ans'}],
      username: 'test123',
      showRecaptcha: 'true',
      remainingDays: '5',
    }))
      loginService.handleOpr({}, '/test').subscribe({ next: response => {
      spyOn(router,'navigateByUrl')
      expect(component['handleCredentialSuccessResp']).toHaveBeenCalled;
      expect(router.navigateByUrl).toHaveBeenCalled;
     }})
 

   })
   
 it('should call onInit',()=>{
   component.ngOnInit()

 })

 it('should call Handle Back Operation',()=>{
  (component as any).handleBackOperation({value:['state'] })
  spyOn(store, 'dispatch').and.callThrough();
  })

 
 it('should call Handle Credential Success Resp',()=>{
   (component as any).handleCredentialSuccessResp({ value:['state'] })
    spyOn(store, 'dispatch').and.callThrough();
   })


});
