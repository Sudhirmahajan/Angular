import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { NavigationService } from 'src/app/auth/services/navigation/navigation.service';
import { PATHS, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import{SetOnboardCardService} from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import * as sha512 from 'js-sha512';


@Component({
  selector: 'app-security-questions',
  templateUrl: './security-questions.component.html',
  styleUrls: ['./security-questions.component.scss']
})
export class SecurityQuestionsComponent implements OnInit {
  @Output() goBackemit= new EventEmitter<boolean>();
  showQueList!: boolean;
  isShowAnsInpt!: boolean;
  showReview!: boolean;
  showQuesMenu!: boolean;
  httpSubscription!: Subscription;
  public selectArray :any= [];
  public defaultQues:any=[]
  public userAnswers:any=[]
  public currentIndex:any;
  public currentQues:any;
  public cardData: any;
  public cardName: any;
  public backData: any = {};
  public cardDetails: any;
  public borderPercentage: any;
  public mandatoryFlag: any;
  public obj: any;
  public completedC: any;
  public topBorder: any;
  private isComplete!: string;
  private responseCardId!: string;

  
  angForm!:FormGroup;
  error!: string;
  constructor(
    private navigation: NavigationService,
    private loginService: LoginService,
    private fb:FormBuilder,
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService
  ) {  }

  ngOnInit(): void {
    this.showQueList = false;
    this.showQuesMenu = true;
    this.isShowAnsInpt = false;
    this.showReview = false;
    this.createForm();
    this.getQuestionList();
  }
 

  createForm(){
    this.angForm=this.fb.group({
      answer0:['',[Validators.required,Validators.pattern("^[a-zA-Z0-9]*$"),Validators.minLength(1),Validators.maxLength(35)]],
      answer1:['',[Validators.required,Validators.pattern("^[a-zA-Z0-9]*$"),Validators.minLength(1),Validators.maxLength(35)]],
      answer2:['',[Validators.required,Validators.pattern("^[a-zA-Z0-9]*$"),Validators.minLength(1),Validators.maxLength(35)]],
      answer3:['',[Validators.required,Validators.pattern("^[a-zA-Z0-9]*$"),Validators.minLength(1),Validators.maxLength(35)]],
    })
  }

  
 getQuestionList() {
      this.httpSubscription = this.loginService.getSeqQuesList({isFirstRequest:"Y"}, PATHS.getSecQuestion).subscribe((resp: any) => {
        if (!resp['error']) {
          this.selectArray = resp['data']['questions'];
          this.backData = resp;
          this.cardData = resp;
          this.completedC = resp.completedCard;
          this.mandatoryFlag = resp.mandatoryFlag;
          this.topBorder = resp.noOfCard;
          this.cardName = resp.cardName;

        } else {
            this.error = 'Internal Server Error';
        }
      }, (error) => {
         this.error = 'Internal Server Error';
    });
  }



  chooseQue(i:any,ques:any){
    this.showQuesMenu =false;
    this.showQueList=true;
    this.showReview = false; 
    this.currentIndex=i;
    this.currentQues=ques;
   }


  showMenu(){
    this.showQuesMenu= true;
    this.showQueList=false;
    this.showReview = false;
  }

  reviewQues(){
    this.showQuesMenu= false;
    this.showQueList= false;
    this.showReview = true;
  }



  selectedQue(ques:any){
    this.defaultQues.splice(this.currentIndex, 1, ques.selectArray)
    const index = this.selectArray.indexOf(ques.selectArray);
    if (index > -1) {
      this.selectArray.splice(index, 1);
    }
    if (this.currentQues == '') {
    } else {
      this.selectArray.push(this.currentQues)
    }
    this.showQuesMenu = true;
    this.showQueList = false;
  }


  openAnstxt() {
    if (!this.isShowAnsInpt) {
      this.isShowAnsInpt = true;
    } else {
      this.isShowAnsInpt = false;
    }
  }


  onSkip(){
    this.responseCardId = this.cardData.cardId;
    const inputField = { cardId: this.responseCardId, cardName: this.cardData.cardName };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(inputField);
    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.skip).subscribe((resp:any) => {
        resp['completedCard'] = this.cardData.completedCard + 1;
        if (resp['noOfCards'] !== '') {
          this.topBorder = Number(resp['noOfCards']);
        }
        this.isComplete = resp['isCompleted'];
        this.cardName = resp['cardName'];

        const cardFlag = this.cardService.checkCardName(resp.cardName);
        if (!cardFlag) {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else  if (this.isComplete === 'Y') {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else if(cardFlag) {
          this.onboardingService.setOnboardingCardDetails(resp);
          this.cardService.navigateToView(resp.cardName)
        }
      }, (err) => {

     });
    }  

  }

  public createdata() {
    const inputField:any = { cardId: this.backData.cardId, cardName: this.cardName, data: {} };
    this.defaultQues.map((item:any, index:any)=>{
      this.userAnswers.push(sha512.sha512(this.angForm.value['answer'+index].toLowerCase()))
      this.obj = {
        questions: this.defaultQues,
        answers: this.userAnswers
      };
    })
   
  inputField.data['questionList'] = this.obj;
  return inputField;
  }

  onSubmit(){
    const responseObj = this.createdata();
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(responseObj);
    if (reqPayload) {
      this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding)
      .subscribe({ next: (cardResp: any) => {    
       this.cardData=cardResp;
       this.isComplete = cardResp['isCompleted'];
       this.cardName = cardResp['cardName'];
       this.onboardingService.setOnboardingCardDetails(cardResp);
       const cardFlag = this.cardService.checkCardName(this.cardName);
       if (!cardFlag) {
        this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
      } else if(this.isComplete === 'Y' ){
        this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
      }else if(cardFlag){
    
       // this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        this.cardService.navigateToView(this.cardName)
      }
    }, error: (err: any) => {
  }});
}

  }
  goBack() {
    // FOR BACK button redirection
    this.navigation.goBack();
   }
}
