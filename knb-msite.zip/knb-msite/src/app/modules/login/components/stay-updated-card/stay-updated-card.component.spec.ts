import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StayUpdatedCardComponent } from './stay-updated-card.component';

describe('StayUpdatedCardComponent', () => {
  let component: StayUpdatedCardComponent;
  let fixture: ComponentFixture<StayUpdatedCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StayUpdatedCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StayUpdatedCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
