import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CountdownComponent } from 'ngx-countdown';
import { DataEmitterService } from 'src/app/auth/services/data-emitter/data-emitter.service';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-maintenance-card',
  templateUrl: './maintenance-card.component.html',
  styleUrls: ['./maintenance-card.component.scss']
})
export class MaintenanceCardComponent implements OnInit {

  @ViewChild('backgroundCounter') backgroundCounter!: CountdownComponent;
  @ViewChild('actualCounter') actualCounter!: CountdownComponent;  
  
  public downtimeTill!: any;
  public remaingTime!: any;

    constructor(
      private dataEmitterService: DataEmitterService,
      private routeService: Router
    ) { }

  ngOnInit(): void {
     this.dataEmitterService.on('downtime').subscribe((resp:any) => {
      this.downtimeTill = resp['downtimeEnd'];
      this.remaingTime = (Number(resp['diffInSec']));
  }); 

 
  }

  public onFinished(event:any) {
    
    if(event.action == 'done') {
      this.routeService.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
      this.actualCounter?.stop();
    }
    
    }
}
