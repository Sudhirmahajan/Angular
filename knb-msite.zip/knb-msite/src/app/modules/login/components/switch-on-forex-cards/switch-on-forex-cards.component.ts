import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { NavigationService } from 'src/app/auth/auth.index';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { PATHS, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';

@Component({
  selector: 'app-switch-on-forex-cards',
  templateUrl: './switch-on-forex-cards.component.html',
  styleUrls: ['./switch-on-forex-cards.component.scss']
})
export class SwitchOnForexCardsComponent implements OnInit {

  public cardData: any;
  public mandateryFlag: any;
  cardID: any;
  completedC: any;
  httpSubscription!: Subscription;
  isComplete: any;
  completedCard: any;
  responseCardId: any;
  cardDetails: any;
  public disabledCheckbox:any = [];
  private cardObject: any = {};
  topBorder: any;

  constructor(
    private navigation: NavigationService,
    private loginService: LoginService,
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
  ) { }

  ngOnInit(): void {
    this.showList();
  }

  showList() {

     this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
    }); 

    this.responseCardId = this.cardData.cardId;
    this.cardDetails = this.cardData.data.cardList;
    this.mandateryFlag = this.cardData.mandatoryFlag;
    this.completedCard = this.cardData.completedCard;
    this.cardDetails.map((itrem:any) => {
      itrem['flag'] = 'L';
    });
     
  }


  public checkClicked(value:any, i:any, name:any) {
    if (value) {
      this.cardDetails[i].flag = 'UL';
      this.disabledCheckbox.push(i);
    } else {
      this.cardDetails[i].flag = 'L';
    }
    this.cardObject = this.cardDetails.map((x:any) => Object.assign({}, x));
  }

  onSkip(){
    this.responseCardId = this.cardData.cardId;
    const inputField = { cardId: this.responseCardId, cardName: this.cardData.cardName };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(inputField);
    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.skip).subscribe((resp:any) => {
        resp['completedCard'] = this.cardData.completedCard + 1;
        if (resp['noOfCards'] !== '') {
          this.topBorder = Number(resp['noOfCards']);
        }
        this.isComplete = resp['isCompleted'];
        const cardFlag = this.cardService.checkCardName(resp.cardName);
        if (!cardFlag) {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else  if (this.isComplete === 'Y') {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else if(cardFlag) {
          this.onboardingService.setOnboardingCardDetails(resp);
          this.cardService.navigateToView(resp.cardName);
        }
      }, (err) => {

     });
    }  
  }

  onSubmit(){
    const dataObj: any = {};
    this.cardDetails.map((item:any) => {
      delete item['cardName'];
      delete item['cardType'];
    });
    const inputField = { cardId: this.responseCardId, cardName: this.cardData.cardName, data: { cardList: this.cardDetails } };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(inputField);

    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding).subscribe((resp: any) => {
        resp['completedCard'] = this.completedCard + 1;
        if (resp['noOfCards'] !== '') {
          this.topBorder = Number(resp['noOfCards']);
        }
        resp['border'] = this.topBorder;
        this.isComplete = resp['isCompleted'];
        const cardFlag = this.cardService.checkCardName(resp.cardName);
        if (!cardFlag) {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else  if (this.isComplete === 'Y') {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else if(cardFlag) {
          this.onboardingService.setOnboardingCardDetails(resp);
          this.cardService.navigateToView(resp.cardName);
        }
      }, (err) => {

      });
    } 
  }
}
