import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwitchOnForexCardsComponent } from './switch-on-forex-cards.component';

describe('SwitchOnForexCardsComponent', () => {
  let component: SwitchOnForexCardsComponent;
  let fixture: ComponentFixture<SwitchOnForexCardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SwitchOnForexCardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SwitchOnForexCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
