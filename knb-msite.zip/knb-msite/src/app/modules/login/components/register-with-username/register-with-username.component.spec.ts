import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of } from 'rxjs';
import { BioCatchService, setGUID } from 'src/app/auth/auth.index';
import { OnboardingModule } from 'src/app/modules/onboarding/onboarding.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { RegisterWithUsernameComponent } from './register-with-username.component';

describe('RegisterWithUsernameComponent', () => {
  let component: RegisterWithUsernameComponent;
  let fixture: ComponentFixture<RegisterWithUsernameComponent>;
  let MockLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loaderService: jasmine.SpyObj<LoaderService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let MockPayservice = jasmine.createSpyObj('PayloadService', ['generatePayloadForOpr']);
  let loginService: jasmine.SpyObj<LoginService>;
  let MockLoginservice = jasmine.createSpyObj('LoginService', ['handleOpr']);
  let store: MockStore;
  let router: Router;



  beforeEach(async () => {

    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        OnboardingModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [RegisterWithUsernameComponent],

      providers: [
        { provide: LoaderService, useValue: MockLoaderService },
        { provide: PayloadService, useValue: MockPayservice },
        { provide: LoginService, useValue: MockLoginservice },
        { provide: PayloadService, useValue: MockPayservice },

        provideMockStore({
          selectors: [

          ]
        })


      ],
    })
      .compileComponents();
  });




  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterWithUsernameComponent);
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);


    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();

  });



  it('should set isBlur to true and isBlurverified to false', () => {

    component.checkUsername();
    expect(component.isBlur).toBeTruthy();
    expect(component.isBlurverified).toBeFalsy();
    expect(component.showMessage).toBeFalsy();
  });


  it('should set isBlur to true and isBlurverified to false', () => {

    component.resetAlreadyExist();
    expect(component.showMessage).toBeFalsy();
  });




  it('should start the loader and call the loginService', () => {
    spyOn<any>(component, 'handleOprSuccessResponse').and.callThrough();
    fixture.detectChanges();
    component.createUsernameForm.setValue({
      username: 'kotak'
    });

    payloadService.generatePayloadForOpr.and.callThrough();
    const reqPayload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'test',
      flow: '',
      guid: '',
      oprState: '',
    });

    const response = {
      flow: 'USERNAME',
      guid: 'AssdAAddfs6',
      nextScreen: 'PASSWORD',
      state: 'RESET',
      showRecaptcha: 'N'

    }
    loginService.handleOpr.and.returnValue(of(response));
    component.setNickname();
    expect(loaderService.startLoader).toHaveBeenCalled();

  });








  it('should start the loader and chandle Error', () => {
    spyOn<any>(component, 'handleOprSuccessResponse').and.callThrough();
    fixture.detectChanges();
    component.createUsernameForm.setValue({
      username: 'kotak'
    });

    payloadService.generatePayloadForOpr.and.callThrough();
    const reqPayload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'test',
      flow: '',
      guid: '',
      oprState: '',
    });

    const response = {
      flow: 'USERNAME',
      guid: 'AssdAAddfs6',
      nextScreen: 'PASSWORD',
      state: 'RESET',
      showRecaptcha: 'N'

    }
    loginService.handleOpr.and.returnValue(of(response));
    component.setNickname();
    component.createUsernameForm.reset();
  });







});