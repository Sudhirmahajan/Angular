import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { setFlow, setGUID, setServerState } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { CustomValidators } from 'src/app/modules/shared/utils/custom-validators/custom-validators';
import { environment } from 'src/environments/environment';
import { PATHS, ROUTE_KEY } from '../../login.constant';
import { IValidateCardDetailsResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-register-with-username',
  templateUrl: './register-with-username.component.html',
  styleUrls: ['./register-with-username.component.scss']
})
export class RegisterWithUsernameComponent implements OnInit {

  public isSpecialChar= true
  public isAlphabetChar= true
  public createUsernameForm!: FormGroup;
  public isBlur = false;
  public isBlurverified = true;
  public isUserFlag!: string;
  public data!: object;
  public showMessage!: boolean;
  public isLoading!: boolean;
  public enteredUsername!: string;
  public maskedUsername!: string;
  private httpSubscription!: Subscription;
  private cursorPosition!: number | null;
  hide!: boolean;

  constructor(
    private payloadService: PayloadService,
    private loginService: LoginService,
    private loaderService: LoaderService,
    private store: Store,
    private router: Router,
  ) {
  }

  ngOnInit() {
    this.createUsernameForm = new FormGroup({
      username: new FormControl('', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(35), 
      CustomValidators.patternValidator(new RegExp("^[a-zA-Z]"), { hasAlphabets: true }),
      CustomValidators.patternValidator(new RegExp("^[a-zA-Z0-9]*$"), { hasSpecialCharacters: true })])),
    })
  //  this.handleButtonState();
  }

  get username() { return this.createUsernameForm.get('username'); }


  

  public checkUsername() {    
    this.isBlur = true;
    this.isBlurverified = false;
    this.showMessage = false;
  }

  // public changeUsernameValue(event: any) {
  //   const input: HTMLElement | null = document.querySelector('#username');
  //   input&& input.addEventListener('keyup', e => {
  //     let target = event.target as HTMLInputElement;
  //     this.cursorPosition = target && target['selectionStart'];
  //     this.checkUsername()
  //   });
  //  const returnedValue = this.removeBrowserPopUpService.removeBrowserPopUp(event, this.createUsernameForm.controls['username'], input,
  //  this.cursorPosition, 'Show');
   
  //  this.enteredUsername = returnedValue.enteredValue;
  //  const patternSpecial =/^[a-zA-Z0-9_]*$/;
  //  this.isSpecialChar= patternSpecial.test(this.enteredUsername);
  //  const patternAlpha =/[a-zA-Z]/;
  //  this.isAlphabetChar= patternAlpha.test(this.enteredUsername);
  //  this.maskedUsername = returnedValue.maskedValue;
  // }

  public setNickname() {
    this.loaderService.startLoader();
    const inputField = { credential: this.createUsernameForm.controls['username'].value };
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField);
    if (reqPayload) {
      this.loginService.handleOpr(reqPayload, PATHS.setUsername).subscribe((resp: IValidateCardDetailsResponse) => {
        this.handleOprSuccessResponse(resp);
      }, (err) => {
        if (err.error.error.errorCode === 'OPR-BE0036') {
          this.showMessage = true;
        }
        this.createUsernameForm.reset();
      });
    }
  }

  private handleOprSuccessResponse(resp: IValidateCardDetailsResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  // private handleButtonState() {
  //   this.loaderService.isLoading().subscribe((isLoading) => {
  //     this.isLoading = isLoading;
  //   });
  // }

  resetAlreadyExist() {
    this.showMessage = false;
  }

}
