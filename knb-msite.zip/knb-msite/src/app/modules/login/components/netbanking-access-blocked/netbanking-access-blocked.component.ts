import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, ConfigService } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-netbanking-access-blocked',
  templateUrl: './netbanking-access-blocked.component.html',
  styleUrls: ['./netbanking-access-blocked.component.scss']
})
export class NetbankingAccessBlockedComponent implements OnInit {

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private configService: ConfigService
  ) { }

  ngOnInit(): void {

  }

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

  public NavigateToNearestBranchLink() {
    this.authenticationService.openUrlInNewTab(this.configService.getStaticLinks('nearestBranch'));
  }

}
