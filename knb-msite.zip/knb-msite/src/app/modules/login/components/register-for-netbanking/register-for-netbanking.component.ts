import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { NavigationService, AuthenticationService, getClientSessionId, setClientSessionId, setFlow, setServerState, setGUID, setUserId, setRecaptcha, ConfigService, setMsiteUserID, setMsiteFlow } from 'src/app/auth/auth.index';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { redirectToRegisterForNetbanking, registerForNetbankingCtaname } from '../../login-analystics';
import { ROUTE_KEY, FLOWS, PATHS } from '../../login.constant';
import { IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-register-for-netbanking',
  templateUrl: './register-for-netbanking.component.html',
  styleUrls: ['./register-for-netbanking.component.scss']
})
export class RegisterForNetbankingComponent implements OnInit {

  tncFlag: boolean = false;
  userDetailsForm!: FormGroup;
  httpSubscription!: Subscription;
  clientSessionIdFromRedux!: string;
  termsAndConditionsLink!: string;

  constructor(
    private router: Router,
    public navigation: NavigationService,
    public store: Store,
    private authenticationService: AuthenticationService,
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private configService: ConfigService,
    private errorBeanService: ErrorBeanService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
  ) {
    this.store.select(getClientSessionId).subscribe((clientSessionId) => {
      this.clientSessionIdFromRedux = clientSessionId;
    });
   }

  ngOnInit(): void {
    this.setAnalytics('');
    if (!this.clientSessionIdFromRedux) {
      this.store.dispatch(setClientSessionId({ value: this.authenticationService.generateRandom()}));
    }

    
    this.getLinks();

    this.userDetailsForm = new FormGroup({
      userData: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(19)]),
      rememberMe: new FormControl(false),
      tnc: new FormControl(false)
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToRegisterForNetbanking
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=registerForNetbankingCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 

  private getLinks() {
    this.termsAndConditionsLink = this.configService.getStaticLinks('termsAndConditions');
  }

  validateUserDetails() {
    this.loaderService.startLoader();
    this.store.dispatch(setFlow({ value:  FLOWS.netBankingRegister}))
    const inputField = {loginId: this.userDetailsForm.controls['userData'].value.trim()};
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true);
    if (reqPayload as IVerifyCrnRequest) {
      
        
      this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe({next: (handleOprResp: IVerifyCrnResponse) => {
         this.handleOprSuccessResponse(handleOprResp);

          
      }, error: (error) => {
        this.loaderService.stopLoader();
        this.errorBeanService.handleWrongAttempts(error, this.userDetailsForm);
      }});
          
          
               
    }
  }

  private handleOprSuccessResponse(resp: IVerifyCrnResponse) {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    this.store.dispatch(setUserId({ value: this.userDetailsForm.controls['userData'].value}));
    this.store.dispatch(setMsiteUserID({value: this.userDetailsForm.controls['userData'].value}));
    this.store.dispatch(setMsiteFlow({ value:  resp['flow']})); 
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });

  }
  public back() {
    this.router.navigateByUrl(ROUTE_KEY['CRN'], { skipLocationChange: environment.skipURI });
   }
  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }


}
