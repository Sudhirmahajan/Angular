import { HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

import { AuthenticationService, AuthModule, ConfigService, getClientSessionId, NavigationService } from 'src/app/auth/auth.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { NgxCaptchaModule } from 'ngx-captcha';
import { CountdownModule } from 'ngx-countdown';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';


import { RegisterForNetbankingComponent } from './register-for-netbanking.component';
import { Store } from '@ngrx/store';

describe('RegisterForNetbankingComponent', () => {
  let component: RegisterForNetbankingComponent;
  let fixture: ComponentFixture<RegisterForNetbankingComponent>;
  let store : MockStore;
  let configServiceSpy: jasmine.SpyObj<ConfigService>;
  let mockValue = {};
  let router: Router;


  let navigationServiceObj = jasmine.createSpyObj('NavigationService', ['']);
  let navigationService : jasmine.SpyObj<NavigationService>;

  let authenticationServiceObj = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  let authenticationService   : jasmine.SpyObj<AuthenticationService>;

  let loaderServiceObj = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loaderService: jasmine.SpyObj<LoaderService>;

  let payloadServiceObj = jasmine.createSpyObj('PayloadService', ['generatePayloadForOpr']);
  let payloadService: jasmine.SpyObj<PayloadService>;

  let loginServiceObj = jasmine.createSpyObj('LoginService', ['handleOpr']);
  let loginService: jasmine.SpyObj<LoginService>;

  let errorBeanServiceObj = jasmine.createSpyObj('ErrorBeanService', ['handleWrongAttempts']);
  let errorBeanService: jasmine.SpyObj<ErrorBeanService>;

  let bundleLoaderInitializerServiceObj = jasmine.createSpyObj('BundleLoaderInitializerService', ['startWatchingIdle']);
  let bundleLoaderInitializerService : jasmine.SpyObj<BundleLoaderInitializerService>;


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterForNetbankingComponent ],
      imports : [
        NoopAnimationsModule,
        HttpClientModule,
        AuthModule.forRoot('env'),
        SharedModule,   
        RouterTestingModule,
        SharedModule,
        CountdownModule,
        NgxCaptchaModule
      ],
      providers :[
        provideMockStore({  
          selectors :[
            {
              selector : 'userData',
              value : 'abc'
            },
            {
              selector : getClientSessionId,
              value : ''
            }
          ]
        }),
        { provide : NavigationService, useVale : navigationServiceObj},
        { provide : AuthenticationService, useValue : authenticationServiceObj},
        { provide : LoaderService , useValue : loaderServiceObj},
        { provide : PayloadService , useValue : payloadServiceObj},
        { provide : LoginService , useValue : loginServiceObj},
        { provide : ErrorBeanService , useValue : errorBeanServiceObj},
        { provide : BundleLoaderInitializerService , useValue : bundleLoaderInitializerServiceObj},

      ]
    })
    .compileComponents();
  });
    

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterForNetbankingComponent);
    component = fixture.componentInstance;
    store = TestBed.inject<Store>(Store) as MockStore<any>
    configServiceSpy = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    navigationService = TestBed.inject(NavigationService) as jasmine.SpyObj<NavigationService>;
    authenticationService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    loaderService        = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    payloadService       = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loginService         = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    errorBeanService     = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
    router = TestBed.inject(Router);
    spyOn(store, 'dispatch');
    fixture.detectChanges();
  });

  it('should test validateUserDetails Success Response', () => {
    
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'A',
      flow: 'A',
      guid: 'A',
      oprState: 'A',
    });

    loginService.handleOpr.and.returnValue(of({
      flow: 'CREATE_USERNAME',
      guid: '',
      nextScreen: '',
      state: '',
      showRecaptcha: 'Y',
    }));

    const loginSuccessResp  = {
      flow: 'CREATE_USERNAME',
      guid: 'CREATE_USERNAME',
      nextScreen: 'CREATE_USERNAME',
      state: 'CREATE_USERNAME',
      showRecaptcha: 'CREATE_USERNAME',
  }

    spyOn(component, 'handleOprSuccessResponse' as never);
    component.validateUserDetails();

    loginService.handleOpr(payload, '/verifyCrnUrl').subscribe({
      next: (loginSuccessResp) => {
        expect((component as any).handleOprSuccessResponse).toHaveBeenCalled();
      }
    });
  });

  it('should test  validateUserDetails error Response', () => {
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: '',
      guid: '',
      oprState: '',
    })

    loginService.handleOpr.and.returnValue(throwError(() => ''))

    component.validateUserDetails();

    loginService.handleOpr(payload, '/verifyCrnUrl').subscribe({ error: error => {
      expect(loaderService.stopLoader).toHaveBeenCalled()
      expect(errorBeanService.handleWrongAttempts).toHaveBeenCalled()
    }});

  });

  it('should test handleOprSuccessResponse', () => {
    
    let response = {
      flow: 'abc',
      guid: 'abc',
      nextScreen: 'abc',
      state: 'abc',
      showRecaptcha: 'abc',
    };

    spyOn(router, 'navigateByUrl');
    (component as any ).handleOprSuccessResponse(response);
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it ('should call getLinks', ()=>{
    (component as any).getLinks();
    expect(component).toBeTruthy();
  });

  it('should call onInit',()=>{
    component.ngOnInit()
  })

});
