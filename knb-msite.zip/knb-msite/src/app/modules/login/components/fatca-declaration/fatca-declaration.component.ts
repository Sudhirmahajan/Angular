import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthenticationService, ConfigService, NavigationService } from 'src/app/auth/auth.index';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { PATHS, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';

@Component({
  selector: 'app-fatca-component',
  templateUrl: './fatca-declaration.component.html',
  styleUrls: ['./fatca-declaration.component.scss']
})
export class FatcaDeclarationComponent implements OnInit {

  public cardData: any;
  public mandateryFlag: any;
  cardID: any;
  completedC: any;
  private httpSubscription!: Subscription;
  isComplete: any;
  completedCard: any;
  responseCardId: any;
  cardDetails: any;
  public disabledCheckbox:any = [];
  private cardObject: any = {};
  topBorder: any;
  mandatoryFlag: any;
  fatcaUrl: any;
  mandateryError!: string;
  nearestBranchLink!: any;
 
  
  constructor(
    private authenticationService: AuthenticationService,
    private configService: ConfigService,
    private loaderService: LoaderService,
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
  ) { }

  ngOnInit(): void {
    this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
      this.fatcaUrl = this.cardData.fatcaUrl;
      this.completedC = this.cardData.completedCard;
      this.mandateryError = 'N';
    });
  }
  
  public downloadFile() {
    this.fatcaUrl = this.cardData.fatcaUrl;
  }

  public NavigateToNearestBranchLink() {
    this.loaderService.startLoader();
    this.authenticationService.openUrlInNewTab(this.configService.getStaticLinks('nearestBranch'));
    this.loaderService.stopLoader();

  }

  public NavigateToFatcaForms() {
    this.loaderService.startLoader();
    this.authenticationService.openUrlInNewTab(this.fatcaUrl);
    this.loaderService.stopLoader();

  }
  
  next(){
    const reqPayloads = { cardId: '', cardName: '' };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(reqPayloads);
    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding)
        .subscribe((resp: any) => {
          this.loaderService.stopLoader();
          this.nearestBranchLink = this.configService.getStaticLinks('nearestBranch');
          resp['border'] = this.cardData.borderPercentage;
          resp['completedCard'] = this.completedC;
          const cardDetails = this.onboardingService.setOnboardingCardDetails(resp);
          this.isComplete = resp['isCompleted'];
          const cardFlag = this.cardService.checkCardName(resp.cardName);
          if (!cardFlag) {
            this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
          } else  if (this.isComplete === 'Y') {
            this.loaderService.stopLoader();
            this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
          } else if(cardFlag) {
            this.loaderService.stopLoader();
            this.cardService.navigateToView(resp.cardName);
          }
        }, (err) => {


        });
    }
   
  }

}
