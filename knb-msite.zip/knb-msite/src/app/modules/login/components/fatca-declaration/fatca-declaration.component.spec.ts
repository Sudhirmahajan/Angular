import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaDeclarationComponent } from './fatca-declaration.component';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule, AuthenticationService, ConfigService } from 'src/app/auth/auth.module';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { Router } from '@angular/router';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { of } from 'rxjs/internal/observable/of';

describe('FatcaComponentComponent', () => {
  let component: FatcaDeclarationComponent;
  let fixture: ComponentFixture<FatcaDeclarationComponent>;
  let service: OnboardingService;
  let setOnboardCardServiceObj = jasmine.createSpyObj('SetOnboardCardService', ['checkCardName','navigateToView']);
  let setOnboardCardService : jasmine.SpyObj<SetOnboardCardService>;
  let router: Router;
  let configService: jasmine.SpyObj<ConfigService>;
  const MockConfigService = jasmine.createSpyObj('ConfigService', [ 'getStaticLinks']);
  const MockPayLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loaderService: jasmine.SpyObj<LoaderService>;

  let authenticationServiceObj = jasmine.createSpyObj('AuthenticationService', ['openUrlInNewTab']);
  let authenticationService   : jasmine.SpyObj<AuthenticationService>;
  

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ FatcaDeclarationComponent ],
      providers: [
      //  { provide: OnboardingService, useValue: Mockservice },
        { provide : SetOnboardCardService, useValue :  setOnboardCardServiceObj},
        { provide: ConfigService, useValue: MockConfigService },
        { provide: LoaderService, useValue: MockPayLoaderService },
        { provide : AuthenticationService, useValue : authenticationServiceObj},


      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaDeclarationComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(OnboardingService);
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    authenticationService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    configService = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should downloadFile', () => {
    component.cardData={fatcaUrl:'example.pdf'}
    component.downloadFile();
    expect(component.fatcaUrl).toMatch("example.pdf");
  });

  it('should Navigate To Nearest Branch Link', () => {
    component.NavigateToNearestBranchLink();
    expect(authenticationService.openUrlInNewTab).toHaveBeenCalled();
  });

  it('should Navigate To Fatca Forms', () => {
    component.NavigateToFatcaForms();
    expect(authenticationService.openUrlInNewTab).toHaveBeenCalled();
  });

  it('should navigate', () => {
    component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
    component.isComplete = 'N';
    spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
      { cardId: 'SERVICE', cardName: 'EMERGENCY'}
      );
    spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:'',isCompleted:'Y'}));
    setOnboardCardService.checkCardName.and.returnValue(true);
    component.next();
    expect(setOnboardCardService.checkCardName).toHaveBeenCalled();
  });


  it('should navigate', () => {
    component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
    component.isComplete = 'N';
    spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
      { cardId: 'SERVICE', cardName: 'EMERGENCY'}
      );
    spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:'',isCompleted:'N'}));
    setOnboardCardService.checkCardName.and.returnValue(true);
    component.next();
    expect(setOnboardCardService.checkCardName).toHaveBeenCalled();
  });


});
