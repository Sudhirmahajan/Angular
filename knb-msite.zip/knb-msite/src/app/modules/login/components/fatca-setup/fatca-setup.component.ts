import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { PATHS } from '../../login.constant';

@Component({
  selector: 'app-fatca-setup',
  templateUrl: './fatca-setup.component.html',
  styleUrls: ['./fatca-setup.component.scss']
})
export class FatcaSetupComponent implements OnInit {
  public fatcaSetupForm!: FormGroup;
  public cardData: any;
  public mandateryFlag: any;
  cardID: any;
  completedC: any;
  private httpSubscription!: Subscription;
  private httpSubscriptionfatcaN!: Subscription;
  isComplete: any;
  completedCard: any;
  responseCardId: any;
  cardDetails: any;
  public disabledCheckbox:any = [];
  private cardObject: any = {};
  topBorder: any;
  mandatoryFlag: any;
  taxResidence!: any;

  constructor(
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
  ) {this.initializeForm();}

  ngOnInit(): void {
    this.initializeForm();
    this.loadData();

  }

  public initializeForm() {
    this.fatcaSetupForm = new FormGroup({
        taxResidence: new FormControl('', [Validators.required])
    });
}

private loadData() {
  this.onboardingService.cardDataObj.subscribe((response:any) => {
      this.cardData = response;
      this.completedC = this.cardData.completedCard;
  });
}

onSubmit(){
  this.cardID = this.cardData.cardId;
  this.mandatoryFlag = this.cardData.mandatoryFlag;
  this.taxResidence = this.fatcaSetupForm.get('taxResidence')?.value;
  const data = { fatca: this.taxResidence };
  const inputField = { cardId: this.cardID, cardName: this.cardData.cardName, data };
  const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(inputField);
  if (reqPayload) {
    if (this.taxResidence === 'Y') {
        this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding)
            .subscribe((resp: any) => {
                resp['completedCard'] = this.completedC + 1;
                resp['fatcaUrl'] = this.cardData.fatcaUrl;
                this.onboardingService.setOnboardingCardDetails(resp);
                this.cardService.navigateToView(resp.cardName);
            }, (err) => {


            });
    } else {
        if (this.taxResidence === 'N') {
            this.httpSubscriptionfatcaN = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding).
                subscribe((resp: any) => {
                    const cardName = resp.cardName;
                    if (cardName) {
                        resp['completedCard'] = this.completedC + 1;
                        resp['fatcaUrl'] = resp.data.fatcaUrl;
                        const cardDetails = this.onboardingService.setOnboardingCardDetails(resp);
                        this.cardService.navigateToView(resp.cardName);
                    } else {
                        resp['fatcaUrl'] = resp.data.fatcaUrl;
                        resp['completedCard'] = this.completedC + 1;
                        const cardDetails = this.onboardingService.setOnboardingCardDetails(resp);
                        this.cardService.navigateToView('FATCA-DECL');
                    }
                }, (err) => {

                });
        }
    }
}

}


}
