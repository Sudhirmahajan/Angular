import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaSetupComponent } from './fatca-setup.component';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { Router } from '@angular/router';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { of } from 'rxjs';

describe('FatcaSetupComponent', () => {
  let component: FatcaSetupComponent;
  let fixture: ComponentFixture<FatcaSetupComponent>;
  let service: OnboardingService;
  let setOnboardCardServiceObj = jasmine.createSpyObj('SetOnboardCardService', ['checkCardName','navigateToView']);
  let setOnboardCardService : jasmine.SpyObj<SetOnboardCardService>;
  let router: Router;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ FatcaSetupComponent ],
      providers: [
        { provide : SetOnboardCardService, useValue :  setOnboardCardServiceObj},
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaSetupComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(OnboardingService);
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should called on Submit', () => {
    component.fatcaSetupForm.controls['taxResidence'].setValue('Y');
    component.responseCardId = '123';
    component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
    component.topBorder = 0;
    component.isComplete = 'N';
    spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
    { cardId: 'SERVICE', cardName: 'EMERGENCY', data: { twoFaFlag: 'Y' } }
    );
    spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:'',isCompleted:'Y',fatcaUrl:''}));
    component.onSubmit();
    expect(setOnboardCardService.navigateToView).toHaveBeenCalled();
 });


 it('should called on Submit tax Residence is No', () => {
  component.fatcaSetupForm.controls['taxResidence'].setValue('N');
  component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
  spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
  { cardId: 'SERVICE', cardName: 'EMERGENCY', data: { twoFaFlag: 'Y' } }
  );
  spyOn(service, 'handleOnboarding').and.returnValue(of({ completedCard : '',noOfCards:'',isCompleted:'Y',data:{fatcaUrl:''}}));
  component.onSubmit();

});


it('should called on Submit tax Residence is No', () => {
  component.fatcaSetupForm.controls['taxResidence'].setValue('N');
  component.cardData = { cardId: '123', cardName: 'Test Card', mandatoryFlag: 'Y', completedCard: 0 };
  spyOn(service, 'generatePayLoadForInfoPageOnBoarding').and.returnValue(
  { cardId: 'SERVICE', cardName: 'EMERGENCY', data: { twoFaFlag: 'Y' } }
  );
  spyOn(service, 'handleOnboarding').and.returnValue(of({ cardName:'FATCA',completedCard : '',noOfCards:'',isCompleted:'Y',data:{fatcaUrl:''}}));
  component.onSubmit();

});


});
