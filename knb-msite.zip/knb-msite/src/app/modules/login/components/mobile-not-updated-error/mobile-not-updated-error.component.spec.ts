import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { AuthenticationService, ConfigService } from 'src/app/auth/auth.index';
import { AuthModule } from 'src/app/auth/auth.module';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { MobileNotUpdatedErrorComponent } from './mobile-not-updated-error.component';

describe('MobileNotUpdatedErrorComponent', () => {
  let component: MobileNotUpdatedErrorComponent;
  let fixture: ComponentFixture<MobileNotUpdatedErrorComponent>;
  let authservice :AuthenticationService;
  let router :Router
  let service: ConfigService;


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MobileNotUpdatedErrorComponent ],
      imports:[RouterTestingModule,HttpClientModule, 
              AuthModule.forRoot('env'),
              TranslateModule.forRoot(
                {
                  loader: {
                    provide: TranslateLoader,
                    useFactory: (createTranslateLoader),
                    deps: [HttpClient]
                  },
                  isolate: true,
                  defaultLanguage: 'en'
                }
              )
    ],
      providers:[]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileNotUpdatedErrorComponent);
    router = TestBed.inject(Router);
    service = TestBed.inject(ConfigService);
    authservice = TestBed.inject(AuthenticationService);
    component = fixture.componentInstance;
    fixture.detectChanges();

    service.config = {
      staticLinks: {
          key: 'nearestBranch',
      },
      services: {
          dashboardService: {
              dashboardService: '/dashboardService'
          },
          loginService: {
              loginService: '/loginService'
          },
          oprService: {
              oprService: '/oprService'
          },
          investmentService: {
              investmentService: '/investmentService'
          },
          onboardingService: {
              onboardingService: '/onboardingService'
          },
          userPersonaService: {
              userPersonaService: '/userPersonaService'
          },
          accountService: {
              accountService: '/accountService'
          },
          cardService: {
              cardService: '/cardService'
          },
          statementService: {
              statementService: '/statementService'
          },
          paymentsTrfService : {
              paymentService: '/paymentService'
          }
      },
      ipAdd: {
          ipAdd: '10.1.22.365'
      },
      gck: {
          k: 'gckValue'
      }
  }
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
   
   });

   it('should check getStaticLinks', () => {
       
    const dummyUrl = 'https://netbanking.kotak.com/knb2/';
    spyOn(window, 'open').and.callFake(function () {
        return <any>true;
    });
    component.NavigateToNearestBranchLink();
    authservice.openUrlInNewTab(dummyUrl);
    expect(window.open).toHaveBeenCalled();


});
   
  
});
