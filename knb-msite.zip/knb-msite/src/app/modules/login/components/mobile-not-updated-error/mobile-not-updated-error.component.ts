import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, ConfigService } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-mobile-not-updated-error',
  templateUrl: './mobile-not-updated-error.component.html',
  styleUrls: ['./mobile-not-updated-error.component.scss']
})
export class MobileNotUpdatedErrorComponent {

  constructor(
    private router: Router,
    private configService: ConfigService,
    private authenticationService: AuthenticationService
  ) { }

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

  public NavigateToNearestBranchLink() {
    this.authenticationService.openUrlInNewTab(this.configService.getStaticLinks('nearestBranch'));
  }

}
