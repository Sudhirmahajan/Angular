import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RouterTestingModule } from '@angular/router/testing';
import { UserPasswordViaPdfComponent } from './user-password-via-pdf.component';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { getFlow, getGUID, getServerState } from 'src/app/auth/auth.index';
import { Store } from '@ngrx/store';

describe('UserPasswordViaPdfComponent', () => {
  let component: UserPasswordViaPdfComponent;
  let fixture: ComponentFixture<UserPasswordViaPdfComponent>;
  let store: MockStore;
  let translate: TranslateService;
  let router: Router;

  let loaderServiceObj = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loaderService    : jasmine.SpyObj<LoaderService>;

  let loginServiceObj = jasmine.createSpyObj('LoginService', ['handleOpr']);
  let loginService  : jasmine.SpyObj<LoginService>; 

  let payloadServiceObj = jasmine.createSpyObj('payloadService', ['generatePayloadForOpr']);
  let payloadService  : jasmine.SpyObj<PayloadService>;



  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPasswordViaPdfComponent ],
      imports : [RouterTestingModule, TranslateModule.forRoot(), SharedModule,],
      providers : [
        provideMockStore({
          selectors : [
            {
              selector : getFlow,
              value : 'A'
            },
            {
              selector : getGUID,
              value : 'B'
            },
            {
              selector : getServerState,
              value : 'C'
            }
          ]

         }),
        { provide : LoaderService , useValue : loaderServiceObj},
        { provide : LoginService , useValue : loginServiceObj},
        { provide : PayloadService, useValue : payloadServiceObj}


      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordViaPdfComponent);
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    router = TestBed.inject(Router);
    store = TestBed.inject<any>(Store) as MockStore<any>;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should test try another option', () => {
    
    spyOn<any>(component, 'handleTryAnotherOptionSuccess');
    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: '',
      guid: '',
      oprState: '',
    })

    loginService.handleOpr.and.returnValue(of({
      client_id: 'ABC_XYZ',
      flow: '',
      guid: '',
      oprState: '',
    }))

    component.tryAnotherOption();   
    expect(component).toBeTruthy();
  });

  it('Should test request Credential Via PDF', () => {

    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: '',
      guid: '',
      oprState: '',
    })

    loginService.handleOpr.and.returnValue(of({
      client_id: 'ABC_XYZ',
      flow: '',
      guid: '',
      oprState: '',
    }))

    store.select(getFlow).subscribe((resp) => {  
      expect(resp).toEqual('A')
    });

    store.select(getGUID).subscribe((resp) => {  
      expect(resp).toEqual('B')
    });

    store.select(getServerState).subscribe((resp) => {  
      expect(resp).toEqual('C')
    });

    component.requestCredentialViaPDF();
    
    loginService.handleOpr(payload, '/testUrl').subscribe({ next: resp => {
      
      expect(loaderService.stopLoader).toHaveBeenCalled();
    } })

    expect(component).toBeTruthy();
  });

  it('Should test request Credential Via PDF error response', () => {

    const payload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: '',
      flow: '',
      guid: '',
      oprState: '',
    })

    store.select(getFlow).subscribe((resp) => {  
      expect(resp).toEqual('A')
    });

    store.select(getGUID).subscribe((resp) => {  
      expect(resp).toEqual('B')
    });

    store.select(getServerState).subscribe((resp) => {  
      expect(resp).toEqual('C')
    });

    loginService.handleOpr.and.returnValue(throwError(() => ''))
    component.requestCredentialViaPDF();
    
    loginService.handleOpr(payload, '/testUrl').subscribe({ error: error   => {
      
      expect(loaderService.stopLoader).toHaveBeenCalled();
      expect(component.isdisabled).toBeFalse();
    } })

    expect(component).toBeTruthy();
  });

  it('it should call handleTryAnotherOptionSuccess',() =>{
    
    const res = {
      flow: '',
      guid: '',
      nextScreen: '',
      state: '',
      disableMoreOption: '',
    }
    spyOn<any>(store, 'dispatch');
    (component as any).handleTryAnotherOptionSuccess(res);
    expect(loaderService.stopLoader).toHaveBeenCalled();
  });

  it('it should call handleTryAnotherOptionSuccess for disableBack',() =>{
    
    const res = {
      disableBack: 'disableBack',
    }
    spyOn<any>(store, 'dispatch');
    (component as any).handleTryAnotherOptionSuccess(res);
    expect(res.disableBack).toBeTrue;
  });


  it('it should call handleTryAnotherOptionSuccess for questions',() =>{
    
    const res = {
      questions: 'questions',
    }
    spyOn<any>(store, 'dispatch');
    (component as any).handleTryAnotherOptionSuccess(res);
    expect(res.questions).toBeTrue;
  });



});
