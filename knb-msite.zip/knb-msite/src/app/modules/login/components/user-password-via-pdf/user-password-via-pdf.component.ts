import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { getFlow, getGUID, getServerState, NavigationService, setDisableBackFlag, setDisableMoreOptionsFlag, setSecurityQuestions, setServerState } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { PATHS, ROUTE_KEY } from '../../login.constant';
import { INextOprMethodRequest, INextOprMethodResponse, IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { WidgetService } from '../../../shared/services/widget/widget.service';

@Component({
  selector: 'app-user-password-via-pdf',
  templateUrl: './user-password-via-pdf.component.html',
  styleUrls: ['./user-password-via-pdf.component.scss']
})
export class UserPasswordViaPdfComponent implements OnInit {

  storeFlow!: string;
  storeDisableMoreOptionsFlag!: boolean;
  httpSubscription!: Subscription
  storeGuid!: string;
  storeOprState!: string;
  clientId!: string;
  isdisabled!: boolean;

  constructor(public navigation: NavigationService,
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private store: Store,
    private router: Router,
    private widgetservice: WidgetService) {
      this.clientId = environment.clientId;
     }

  ngOnInit(): void {
  }

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

  tryAnotherOption() {
    this.loaderService.startLoader();
    const reqPayload = this.payloadService.generatePayloadForOpr();
    if (reqPayload as unknown as INextOprMethodRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as INextOprMethodRequest, PATHS.oprMfaOptions)
        .subscribe((resp: INextOprMethodResponse) => {
          this.loaderService.stopLoader();
          this.handleTryAnotherOptionSuccess(resp);
        });
    }
  }

  private handleTryAnotherOptionSuccess(resp: INextOprMethodResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({value: resp['state']}));
    resp['disableBack'] && this.store.dispatch(setDisableBackFlag({value: resp['disableBack']}))
    this.store.dispatch(setDisableMoreOptionsFlag({value: resp['disableMoreOption']}))
    resp['questions'] && this.store.dispatch(setSecurityQuestions({ value: resp['questions']}));
    
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  } 

  requestCredentialViaPDF() {
    this.loaderService.startLoader();
    this.store.select(getFlow).subscribe((resp) => {  this.storeFlow = resp; });
    this.store.select(getGUID).subscribe((resp) => {  this.storeGuid = resp; });
    this.store.select(getServerState).subscribe((resp) => { this.storeOprState = resp; });

    const payload = {
      client_id: this.clientId,
      flow: this.storeFlow,
      guid: this.storeGuid,
      oprState: this.storeOprState
    };

    this.httpSubscription = this.loginService.handleOpr(payload as IVerifyCrnRequest, PATHS.postPasswordViaPdf)
    .subscribe({ next: (resp: IVerifyCrnResponse) => {
      this.loaderService.stopLoader();
      if (resp) {
        this.widgetservice.isPWDviaPDFset.next(true);
        this.router.navigateByUrl(ROUTE_KEY['CREDENTIAL_SET_SUCCESS'], { skipLocationChange: environment.skipURI });
      }
    }, error: (error) => {
      this.loaderService.stopLoader();
       this.isdisabled = false;
    }});
  }

}
