import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-validate-card-details-unsuccessful',
  templateUrl: './validate-card-details-unsuccessful.component.html',
  styleUrls: ['./validate-card-details-unsuccessful.component.scss']
})
export class ValidateCardDetailsUnsuccessfulComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

}
