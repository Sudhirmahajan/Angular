import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StayChargedCardComponent } from './stay-charged-card.component';

describe('StayChargedCardComponent', () => {
  let component: StayChargedCardComponent;
  let fixture: ComponentFixture<StayChargedCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StayChargedCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StayChargedCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
