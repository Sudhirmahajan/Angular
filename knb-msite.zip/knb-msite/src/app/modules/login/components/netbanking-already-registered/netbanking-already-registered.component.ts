import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { netbankingAlreadyRegisteredCtaname, redirectToNetbankingAlreadyRegistered } from '../../login-analystics';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-netbanking-already-registered',
  templateUrl: './netbanking-already-registered.component.html',
  styleUrls: ['./netbanking-already-registered.component.scss']
})
export class NetbankingAlreadyRegisteredComponent implements OnInit {

  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToNetbankingAlreadyRegistered
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=netbankingAlreadyRegisteredCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

}
