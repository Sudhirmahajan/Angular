import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { NetbankingAlreadyRegisteredComponent } from './netbanking-already-registered.component';

describe('NetbankingAlreadyRegisteredComponent', () => {
  let component: NetbankingAlreadyRegisteredComponent;
  let fixture: ComponentFixture<NetbankingAlreadyRegisteredComponent>;
  let router :Router


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NetbankingAlreadyRegisteredComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NetbankingAlreadyRegisteredComponent);
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
   
   });


});
