import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { NavigationService } from 'src/app/auth/auth.index';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { PATHS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';

@Component({
  selector: 'app-twofa-register',
  templateUrl: './twofa-register.component.html',
  styleUrls: ['./twofa-register.component.scss']
})
export class TwofaRegisterComponent implements OnInit {
  twoFaRegister: any;
  public cardData: any;
  public mandateryFlag: any;
  cardID: any;
  completedC: any;
  httpSubscription!: Subscription;
  isComplete: any;
  twoFactorAuth: any;

  constructor(
    private navigation: NavigationService,
    private loginService: LoginService,
    private onboardingService: OnboardingService,
    private cardService: SetOnboardCardService,
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    this.initializeForm();
    this.loadData();

  }

  public initializeForm() {
    this.twoFaRegister = new FormGroup({
      twoFactorAuth: new FormControl('', Validators.required)
    });
  }

  loadData() {
    this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
      this.mandateryFlag = this.cardData.mandatoryFlag;
    });
  }


  public formSubmit(): void {
    this.cardID = this.cardData.cardId;
    this.mandateryFlag = this.cardData.mandatoryFlag;
    this.twoFactorAuth = this.twoFaRegister.get('twoFactorAuth').value;
    const data = { twoFaMethod: this.twoFactorAuth };
    const inputField = { cardId: this.cardID, cardName: this.cardData.cardName, data };
    const inputFieldforNextPage = { twoFaMethod: this.twoFactorAuth };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(inputFieldforNextPage);
    if (reqPayload) {
      if (this.twoFactorAuth === 'OTP') {
        this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.updTwoFaMethodUrl)
          .subscribe((resp: any) => {
            resp['completedCard'] = this.completedC + 1;
            resp['borderPercentages'] = this.cardData.border;
            resp['cardName'] = resp.cardName;
            this.onboardingService.setOnboardingCardDetails(resp);
            this.cardService.navigateToView(resp.cardName);
          }, (err) => {
          });
      } else {
        if (this.twoFactorAuth === 'RSA') {
          this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.updTwoFaMethodUrl).
            subscribe((resp: any) => {
              if (resp.cardId) {
                resp['completedCard'] = this.completedC + 1;
                const cardDetails = this.onboardingService.setOnboardingCardDetails(resp);
                if (resp.cardName) {
                  this.onboardingService.setOnboardingCardDetails(resp);
                  resp['cardName'] = resp.cardName;
                  this.onboardingService.setOnboardingCardDetails(resp);
                  this.cardService.navigateToView(resp.cardName);
                } else {
                  this.cardService.navigateToView('RSA_REGISTER');
                }
              } else {
                resp['completedCard'] = this.completedC + 1;
                resp['cardName'] = resp.cardName;
                if (resp.cardName) {
                  this.onboardingService.setOnboardingCardDetails(resp);
                  this.cardService.navigateToView(resp.cardName);
                } else {
                  this.onboardingService.setOnboardingCardDetails(resp);
                  this.cardService.navigateToView('RSA_REGISTER');
                }
              }
            }, (err) => {
          });
        }
      }
    }
  }
  ngOnDestroy() {
  }

}
