import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwofaRegisterComponent } from './twofa-register.component';

describe('TwofaRegisterComponent', () => {
  let component: TwofaRegisterComponent;
  let fixture: ComponentFixture<TwofaRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TwofaRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TwofaRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
