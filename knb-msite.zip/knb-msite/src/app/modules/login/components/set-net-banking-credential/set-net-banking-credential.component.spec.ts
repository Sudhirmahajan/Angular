import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SetNetBankingCredentialComponent } from './set-net-banking-credential.component';

describe('SetNetBankingCredentialComponent', () => {
  let component: SetNetBankingCredentialComponent;
  let fixture: ComponentFixture<SetNetBankingCredentialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SetNetBankingCredentialComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SetNetBankingCredentialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
