import { Component, OnInit } from '@angular/core';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-set-net-banking-credential',
  templateUrl: './set-net-banking-credential.component.html',
  styleUrls: ['./set-net-banking-credential.component.scss']
})
export class SetNetBankingCredentialComponent implements OnInit {

  constructor(
    private router: Router,
  ) { }

  ngOnInit(): void {
  }

  navigate(){
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CARD_NO], { skipLocationChange: environment.skipURI });
  }
}
