import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { redirectToUserPasswordUnblockSuccess, userPasswordUnblockSuccessCtaname } from '../../login-analystics';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-user-password-unblock-success',
  templateUrl: './user-password-unblock-success.component.html',
  styleUrls: ['./user-password-unblock-success.component.scss']
})
export class UserPasswordUnblockSuccessComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.setAnalytics('');
  }

  
  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserPasswordUnblockSuccess
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=userPasswordUnblockSuccessCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }


}
