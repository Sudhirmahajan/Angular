import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { InvisibleReCaptchaComponent } from 'ngx-captcha';
import { Subscription } from 'rxjs';
import { BioCatchService, ConfigService, getFlow, getRecaptcha, getServerState, getUserId, NavigationService, setRecaptcha, setServerState, setServiceId } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS, SERVICE_ID } from '../../login.constant';
import { IAccessTokenResp, IOprBackOperationsRequest, IOprBackOperationsResponse, IValidateCardDetailsRequest, IValidateCardDetailsResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { WidgetService } from '../../../shared/services/widget/widget.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { redirectToValidateCardDetails, validateCardDetailsCtaname } from '../../login-analystics';

@Component({
  selector: 'app-validate-card-details',
  templateUrl: './validate-card-details.component.html',
  styleUrls: ['./validate-card-details.component.scss']
})
export class ValidateCardDetailsComponent implements OnInit {

  cardDetailsForm!: FormGroup;
  showGoogleCaptcha!: boolean;
  @ViewChild('captchaElem') captchaElem!: InvisibleReCaptchaComponent;
  gck!: string;
  cardNumberEntered!: string;
  storeFlow!: string;
  enteredCvv!: string;
  enteredPin!: string;
  httpSubscription!: Subscription;
  disableButton: boolean = true;
  remainingAttemts: number | undefined;
  errorType: string = 'CARD-DETAILS'
  errorTypeOpr: string = 'CARD-DETAILS-OPR';
  

  constructor(
    public navigation: NavigationService,
    private configService: ConfigService,
    private store: Store,
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private router: Router,
    private widgetService: WidgetService,
    private errorBeanService: ErrorBeanService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private bioCatchService: BioCatchService
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_OPR_CARD_DTLS);
    this.gck = this.configService.getGck();
    this.getDataFromStore();
    this.cardDetailsForm = new FormGroup({
      date: new FormControl('', [Validators.required]),
      cvv: new FormControl('', [Validators.required, Validators.maxLength(3), Validators.minLength(3)]),
      cardPin: new FormControl('', [Validators.required, Validators.maxLength(6), Validators.minLength(4)]),
    });

    this.cardDetailsForm.controls['date'].valueChanges.subscribe(() => {
      this.customExpiryDateValidation('date');
    });
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToValidateCardDetails
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=validateCardDetailsCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 

  ngOnDestroy() {
    if (this.httpSubscription) {
        this.httpSubscription.unsubscribe();
    }
  }

  public back() {
    (this.storeFlow) ? this.handleBackWithOpr() : this.handleBackWithLogin();
  }

  public customExpiryDateValidation(controlName: string) {
    const control = this.cardDetailsForm.controls[controlName].value;
    const date = new Date();
    const currentYear = (date.getFullYear().toString()).slice(2);
    const currentmonth = date.getMonth() + 1;
    if (control && control.length === 5) {
        const separateMonthYear = control.split('/');
        const month = separateMonthYear[0];
        const year = separateMonthYear[1];
        this.disableButton = (month > 0 && month <= 12) ? (year >= currentYear) ? false : true : true;
        this.disableButton = (!this.disableButton && currentYear === year) ?
            (month >= currentmonth) ? false : true : this.disableButton;
    } else {
        this.disableButton = true;
    }
}

  public submitForm() {
    (this.showGoogleCaptcha) ? this.captchaElem.execute() : this.validateCardDetails();
  }

  public handleCaptchaSuccess(captchaResponse: string): void {
    if (captchaResponse) {
        this.validateCardDetails(captchaResponse);
    }
  } 

  private validateCardDetails(captchaResp?: string) {
    const credentials = this.mergeCardDetailsToEncrypt();
    (this.storeFlow) ? this.validateCardDetailsWithOpr(credentials, captchaResp) :
        this.validateCardDetailsWithLogin(credentials, captchaResp);
  }

  private mergeCardDetailsToEncrypt() {
    const date = this.generateDate(this.cardDetailsForm.controls['date'].value);
    const credentials = (date + '|' +
    this.cardDetailsForm.controls['cvv'].value + '|' + this.cardDetailsForm.controls['cardPin'].value);
    return credentials;
  }

  private validateCardDetailsWithOpr(credentials: string, captchaResponse?: string) {
    this.loaderService.startLoader();
    const inputField = { credential: credentials };
    let reqPayload = this.payloadService.generatePayloadForOprAuth(inputField);
    if (captchaResponse) {
        reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
        this.store.dispatch(setRecaptcha({ value: '' }))
    }
    if (reqPayload as unknown as IValidateCardDetailsRequest) {
        this.httpSubscription =
            this.loginService.handleOpr(reqPayload as unknown as IValidateCardDetailsRequest, PATHS.validateCardDetails)
                .subscribe({ next: (resp: IValidateCardDetailsResponse) => {
                  this.store.dispatch(setRecaptcha({ value: '' }))
                    this.handleCardDetailsSuccessResponseInOpr(resp);
                }, error: (error) => {
                  this.loaderService.stopLoader();
                  this.remainingAttemts =
                  this.errorBeanService.handleWrongAttempts(error, this.cardDetailsForm);
                  if (error.error['showRecaptcha'] === 'Y') {
                      this.showGoogleCaptcha = true;
                  }
                  this.resetEnteredAndMaskedValue();
                }});
    }
  }

  private handleCardDetailsSuccessResponseInOpr(resp: IValidateCardDetailsResponse) {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    if (resp['showRecaptcha']) {
        this.store.dispatch(setRecaptcha({ value: resp['showRecaptcha'] }))
    }
    this.widgetService.isPWDgenOPR.next(true);  
    this.store.dispatch(setServerState({ value: resp['state'] }))
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  private validateCardDetailsWithLogin(credentials: string, captchaResponse?: string) {
    this.loaderService.startLoader();
    let reqPayload = this.payloadService.generatePayloadForAuth(SCREEN_ROUTING_KEYS.CARD_DETAILS, credentials);
    if (captchaResponse) {
        reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
        this.store.dispatch(setRecaptcha({ value: '' }))
    }
    if (reqPayload) {
        this.httpSubscription = this.loginService.handleLoginOpr(reqPayload, PATHS.authenticate)
            .subscribe({ next: (resp: IAccessTokenResp) => {
              this.store.dispatch(setRecaptcha({ value: '' }))
               // resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
                if(resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true){
                    this.widgetService.isPWDgenOPR.next(true);  
                }
                this.handleCardDetailsSuccessResponseInLogin(resp);
            }, error: (error) => {
                this.loaderService.stopLoader();
                this.handleWithWrongAttempt(error);
                this.resetEnteredAndMaskedValue();
            }});
    }
  }

  private handleCardDetailsSuccessResponseInLogin(resp: IAccessTokenResp) {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServiceId({ value: SERVICE_ID.cardDetailsFlow }));
    this.store.dispatch(setServerState({ value: resp['state'] }));
    if (resp['showRecaptcha']) {
        this.store.dispatch(setRecaptcha({ value: resp['showRecaptcha'] }))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['authMethod']], { skipLocationChange: environment.skipURI });
  }

  private handleWithWrongAttempt(error: HttpErrorResponse) {
    this.remainingAttemts = this.errorBeanService.handleErrorScenariosInLogin(error);
    if (error.error['showRecaptcha'] === 'Y') {
        this.showGoogleCaptcha = true;
    }
    this.cardDetailsForm.reset();
  }

  private resetEnteredAndMaskedValue() {
    this.cardDetailsForm.reset();
  }

  private generateDate(monthYear: string) {
    const yearMonth = monthYear.split('/');
    return yearMonth[1] + yearMonth[0];
  }

  private handleBackWithOpr() {
    this.loaderService.startLoader();
    const reqPayload = this.payloadService.generatePayloadForOpr();
    if (reqPayload as unknown as IOprBackOperationsRequest) {
        this.httpSubscription =
            this.loginService.handleOpr(reqPayload as unknown as IOprBackOperationsRequest, PATHS.oprBackOperations)
                .subscribe((resp: IOprBackOperationsResponse) => {
                    this.handleBackSuccessResponseWithOpr(resp);
                });
    }
  }

  private handleBackSuccessResponseWithOpr(resp: IOprBackOperationsResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value: resp['state'] }));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });

}

  private handleBackWithLogin() {
      this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CARD], { skipLocationChange: environment.skipURI });

  }

  private getDataFromStore() {
    this.store.select(getUserId).subscribe((resp) => {
      const userIdAndType = resp.split('|');
      const userCardNumber = userIdAndType[0];
      let maskedCard = userCardNumber.match(/.{1,4}/g);
      this.cardNumberEntered = maskedCard?.join(' ') || '';
  });
   
    this.store.select(getRecaptcha).subscribe((resp) => {
        if (resp === 'Y') {
            this.showGoogleCaptcha = true;
        }
    });
    this.store.select(getFlow).subscribe((resp) => { this.storeFlow = resp; });
  }

}
