import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore } from '@ngrx/store/testing';
import { TranslateModule } from '@ngx-translate/core';
import { NgxCaptchaModule } from 'ngx-captcha';
import { CountdownModule } from 'ngx-countdown';
import { of, throwError } from 'rxjs';
import { ConfigService, BioCatchService, AuthenticationService } from 'src/app/auth/auth.index';
import { AuthModule } from 'src/app/auth/auth.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { ValidateCardDetailsComponent } from './validate-card-details.component';

describe('ValidateCardDetailsComponent', () => {
  let component: ValidateCardDetailsComponent;
  let fixture: ComponentFixture<ValidateCardDetailsComponent>;
  const MockConfigService = jasmine.createSpyObj('ConfigService', ['getGck']);
  let configService: jasmine.SpyObj<ConfigService>;
  let bioCatchObj  = jasmine.createSpyObj('BioCatchService',['biocatchSetValues']);
  let bioCatchService : jasmine.SpyObj<BioCatchService>;
  let authenticationObj = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  let authenticationService : jasmine.SpyObj<AuthenticationService>;
  let loginObj = jasmine.createSpyObj('LoginService',['handleLogin','handleOprValidateMobNo','handleOpr','handleLoginOpr']);
  let loginService : jasmine.SpyObj<LoginService>;
  let loaderObj = jasmine.createSpyObj('LoaderService',['handleLoginCaptcha','stopLoader','startLoader']);
  let loaderService : jasmine.SpyObj<LoaderService>;
  let payloadObj = jasmine.createSpyObj('PayloadService',['generatePayloadForOpr','generatePayloadForOprAuth','generatePayloadForAuth']);
  let payloadService : jasmine.SpyObj<PayloadService>;
  let errorBeanObj  = jasmine.createSpyObj('ErrorBeanService',['handleWrongAttempts','handleErrorScenariosInLogin']);
  let errorBeanService : jasmine.SpyObj<ErrorBeanService>;
  let bundleLoaderInitializerObj = jasmine.createSpyObj('BundleLoaderInitializerService',['changeBundleLoaderStatus','startWatchingIdle']);
  let bundleLoaderInitializerService : jasmine.SpyObj<BundleLoaderInitializerService>;
  let store: MockStore;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ValidateCardDetailsComponent ],
      imports:[RouterTestingModule,ReactiveFormsModule,
       HttpClientTestingModule,
       NoopAnimationsModule,
       AuthModule.forRoot('env'),
       SharedModule,
       RouterTestingModule,
       CountdownModule,
       NgxCaptchaModule,
       TranslateModule.forRoot()
            ],
          providers:[
           { provide: ConfigService, useValue: MockConfigService },
           { provide : AuthenticationService ,useValue : authenticationObj},
           { provide : LoginService , useValue : loginObj },
           { provide : PayloadService, useValue : payloadObj},
           { provide : LoaderService, useValue : loaderObj},
           { provide : ErrorBeanService, useValue : errorBeanObj},
           { provide : BundleLoaderInitializerService, useValue : bundleLoaderInitializerObj},
           { provide : BioCatchService, useValue : bioCatchObj},
          ]
     })
     .compileComponents();
   });

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidateCardDetailsComponent);
    component = fixture.componentInstance;
    configService = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>
    authenticationService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    errorBeanService = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should back', () => {
      spyOn<any>(component,'handleBackWithLogin');
      component.back();
      expect((component as any).handleBackWithLogin).toHaveBeenCalled();
  });

  it('should custom Expiry Date Validation', () => {
   component.cardDetailsForm.controls['date'].setValue('32023');
   component.customExpiryDateValidation('date')
   expect(component.disableButton).toBe(true)
  });


  it('should submit form',()=>{
    spyOn<any>(component,'validateCardDetails');
    component.submitForm();
    expect((component as any).validateCardDetails).toHaveBeenCalled();
  });

  it('should handle Captcha Success' ,()=>{
    spyOn<any>(component,'validateCardDetails');
    component.handleCaptchaSuccess('Y')
    expect((component as any).validateCardDetails).toHaveBeenCalled();

  })

  it('should validate Card Details',()=>{
    spyOn<any>(component,'validateCardDetails').and.callThrough();
    spyOn<any>(component,'validateCardDetailsWithOpr');
    component.storeFlow='testFlow';
    (component as any).validateCardDetails('Y')
    

  });
 
  it('should validate Card Details With Opr',()=>{
    spyOn(store, 'dispatch');
    spyOn<any>(component,'validateCardDetailsWithOpr').and.callThrough();
    const data ={
    client_id: 'DEFAULTID',
    flow: 'DemoFlow',
    oprState: 'TRUE',
    credential: 'DefaultCred',
    guid: '1234HJHSJS7hs8'
    };
    loginService.handleOpr.and.returnValue(of(data));
    (component as any).validateCardDetailsWithOpr('','Y')
    expect(store.dispatch).toHaveBeenCalled();
  })


  it('should validate Card Details With Opr else if ',()=>{
    spyOn<any>(component,'validateCardDetailsWithOpr').and.callThrough();
    loginService.handleOpr.and.returnValue(throwError({
      error:{showRecaptcha:'Y'}
    }));
    (component as any).validateCardDetailsWithOpr('','Y')
    expect(component.showGoogleCaptcha).toBe(true);
  });


  it('should validate Card Details With Login ',()=>{
    spyOn<any>(component,'validateCardDetailsWithLogin').and.callThrough();
    spyOn<any>(component,'handleCardDetailsSuccessResponseInLogin').and.callThrough();
    const data={
    accessToken: 'token1234',
    authMethod: 'SET_CREDENTIAL',
    pdfRequested: true,
    showRecaptcha: 'Y',
    state: 'Unknown',
    };
    loginService.handleLoginOpr.and.returnValue(of(data));
    (component as any).validateCardDetailsWithLogin('','Y');
    expect((component as any).handleCardDetailsSuccessResponseInLogin).toHaveBeenCalled();

  });


  it('should validate Card Details With Login Error ',()=>{
    spyOn<any>(component,'validateCardDetailsWithLogin').and.callThrough();
    loginService.handleLoginOpr.and.returnValue(throwError({
      error:{showRecaptcha:'Y'}
    }));
    (component as any).validateCardDetailsWithLogin('','Y');
  });


  it('should handle back with Login ',()=>{
    spyOn(router,'navigateByUrl');
    spyOn<any>(component,'handleBackWithLogin').and.callThrough();
    (component as any).handleBackWithLogin();
    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should handle Back Success Response With Opr',()=>{
    spyOn(router,'navigateByUrl');
    spyOn<any>(component,'handleBackSuccessResponseWithOpr').and.callThrough();
    const data={
      flow: 'demoflow',
      guid: '1234GUIDSAMPLE',
      nextScreen: 'NO',
      state: 'TRUE',
    };
    (component as any).handleBackSuccessResponseWithOpr(data);
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should handle Back With Opr',()=>{
    spyOn<any>(component,'handleBackWithOpr').and.callThrough();
    spyOn<any>(component,'handleBackSuccessResponseWithOpr');

    const data={
      flow: 'demoflow',
      guid: '1234GUIDSAMPLE',
      nextScreen: 'NO',
      state: 'TRUE',
    };
    const payload = {
            client_id: 'DemoId1234',
            flow: 'demoflow',
            guid: '1234GUIDSAMPLE',
            oprState: 'TRUE'
    };
    payloadService.generatePayloadForOpr.and.returnValue(payload);
    loginService.handleOpr.and.returnValue(of(data));
    (component as any).handleBackWithOpr();
    expect((component as any).handleBackSuccessResponseWithOpr).toHaveBeenCalled();
  })

  it('should handle Card Details Success Response In Opr',()=>{
    spyOn(store, 'dispatch');
    spyOn<any>(component,'handleCardDetailsSuccessResponseInOpr').and.callThrough();
    const data ={
      client_id: 'DEFAULTID',
      flow: 'DemoFlow',
      oprState: 'TRUE',
      credential: 'DefaultCred',
      guid: '1234HJHSJS7hs8',
      showRecaptcha:'Y'
      };
    (component as any).handleCardDetailsSuccessResponseInOpr(data);
    expect(store.dispatch).toHaveBeenCalled();
  });

});
