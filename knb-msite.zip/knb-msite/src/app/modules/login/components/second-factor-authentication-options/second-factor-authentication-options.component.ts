import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { getServiceId, getTwoFaAuthOptions, setBlockedTimer, setEmail, setIsdCode, setMobileNumber, setServerState } from 'src/app/auth/auth.index';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { moreLoginOptions, PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-second-factor-authentication-options',
  templateUrl: './second-factor-authentication-options.component.html',
  styleUrls: ['./second-factor-authentication-options.component.scss']
})
export class SecondFactorAuthenticationOptionsComponent implements OnInit {

    public loginFinaldata: { imgClass: string, content: string,screenMapped: string}[] = [];
    private moreLoginOptionsSource!: string;
    private httpSubsciption!: Subscription;
    private optionSelected!: string;
    private serviceIdFromStore!: string;
    twoFaAuthOptionsFromStore!: any;

    constructor(
        private router: Router,
        private payloadService: PayloadService,
        private loginService: LoginService,
        private store: Store,
        private widgetService: WidgetService
    ) { }

    ngOnInit() {
        this.payloadService.moreLoginOptionsSourceCast.subscribe((resp) => {
            if (resp) {
                this.moreLoginOptionsSource = resp;
            }
        });
        this.getDataFromStore();
        this.twoFaAuthOptionsFromStore.map((item: any) => {
            const obj = {imgClass:'',content:'',screenMapped:''};
            switch (item['twoFaMethodLuCode']) {
                case 'DSC':
                    obj.imgClass = 'icon-digital_sign leftIcon';
                    obj.content = moreLoginOptions.DSC;
                    obj.screenMapped = item['twoFaMethodLuCode'];
                    break;
                case 'MOB_APP_LOGIN':
                    obj.imgClass = 'icon-mobile leftIcon';
                    obj.content = moreLoginOptions.MB;
                    obj.screenMapped = item['twoFaMethodLuCode'];
                    break;
                case 'RSA':
                    obj.imgClass = 'icon-RSA leftIcon';
                    obj.content = moreLoginOptions.RSA;
                    obj.screenMapped = item['twoFaMethodLuCode'];
                    break;
                case 'OTP':
                    obj.imgClass = 'icon-OTP leftIcon';
                    obj.content = moreLoginOptions.OTP;
                    obj.screenMapped = item['twoFaMethodLuCode'];
                    break;
                case 'TOTP':
                    obj.imgClass = 'icon-OTP leftIcon';
                    obj.content = moreLoginOptions.TOTP;
                    obj.screenMapped = item['twoFaMethodLuCode'];
                    break;    
            }
            this.loginFinaldata.push(obj);
        });
    }

    ngOnDestroy() {
        if (this.httpSubsciption) {
            this.httpSubsciption.unsubscribe();
        }
    }

    public navigateToSelectedOption(selectedOption: string) {
        this.optionSelected = selectedOption;
        switch (selectedOption) {
            case SCREEN_ROUTING_KEYS.MOB_APP_LOGIN:
                this.validateMbLogin();
                break;
            case SCREEN_ROUTING_KEYS.OTP:
                this.validateOtpOption();
                break;
            case SCREEN_ROUTING_KEYS.TOTP:
            this.navigate();
            break;
            case SCREEN_ROUTING_KEYS.RSA:
                this.navigate();
                break;

        }
    }

    public back() {
        this.router.navigateByUrl(ROUTE_KEY[this.moreLoginOptionsSource], { skipLocationChange: environment.skipURI });

    }

    private validateOtpOption() {
        let reqPayload = this.payloadService.
            generatePayloadForAuth(SCREEN_ROUTING_KEYS.NEW_OTP, '');
        if (this.serviceIdFromStore) {
            reqPayload = { ...reqPayload, ...{ serviceId: this.serviceIdFromStore } };
        }
        if (reqPayload) {
            this.loginService.handleLogin(reqPayload, PATHS.authenticate).subscribe({ next: (resp) => {
                if (resp) {
                    //resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
                    if(resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true){
                        this.widgetService.isPWDgenOPR.next(true);  
                    }
                    this.store.dispatch(setEmail({value: resp['emailId']}));
                    this.store.dispatch(setMobileNumber({value: resp['mobilenNumber']}));
                    this.store.dispatch(setIsdCode({value: resp['isdCode']}));
                    this.store.dispatch(setServerState({value: resp['state']}));
                    this.navigate();
                }
            }, error: (error) => {
                if (error.error['blkHr'] && error.error['dacBlk'] === 'Y') {
                    this.store.dispatch(setBlockedTimer({ value: error.error['blkHr'] }))
                    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_LOCKED], { skipLocationChange: environment.skipURI });
                }
            }});
        }
    }

    // private validateTotpOption() { // Validate from TOTP option
    //     let reqPayload = this.payloadService.
    //         generatePayloadForAuth(SCREEN_ROUTING_KEYS.TOTP, '');
    //     if (this.serviceIdFromStore) {
    //         reqPayload = { ...reqPayload, ...{ serviceId: this.serviceIdFromStore } };
    //     }
    //     if (reqPayload) {
    //         this.loginService.handleLogin(reqPayload, PATHS.authenticate).subscribe({next: (resp) => {
    //             if (resp) {
    //                // resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView'])
    //                this.store.dispatch(setEmail({value: resp['emailId']}));
    //                 this.store.dispatch(setMobileNumber({value: resp['mobilenNumber']}));
    //                 this.store.dispatch(setIsdCode({value: resp['isdCode']}));
    //                 this.store.dispatch(setServerState({value: resp['state']}));
    //                 this.navigate();
    //             }
    //         }, error: (error) => {
    //             if (error.error['blkHr'] && error.error['dacBlk'] === 'Y') {
    //               this.store.dispatch(setBlockedTimer({ value: error.error['blkHr'] }))
    //               this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.OTP_LOCKED], { skipLocationChange: environment.skipURI });
    //             }
    //         }});
    //     }
    // }

    private navigate() {
        this.router.navigateByUrl(ROUTE_KEY[this.optionSelected], { skipLocationChange: environment.skipURI });

    }

    private validateMbLogin() {
        const payload = this.payloadService.generatePayloadForAuth(SCREEN_ROUTING_KEYS.MOB_APP_LOGIN, SCREEN_ROUTING_KEYS.MOB_APP_LOGIN);
        this.httpSubsciption = this.loginService.handleLogin(payload, PATHS.authenticate).subscribe((resp) => {
            //resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
            if(resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true){
                this.widgetService.isPWDgenOPR.next(true);  
            }
            this.navigate();
        }, () => {
            this.navigate();
        });
    }

    private getDataFromStore() {
        this.store.select(getTwoFaAuthOptions).subscribe((resp) => {
            if (resp) {
                this.twoFaAuthOptionsFromStore = resp.filter((option: any) => {
                    return option['twoFaMethodLuCode'] !== this.moreLoginOptionsSource;
                });
            }
        });
        this.store.select(getServiceId).subscribe((resp) => { this.serviceIdFromStore = resp; });
    }

}
