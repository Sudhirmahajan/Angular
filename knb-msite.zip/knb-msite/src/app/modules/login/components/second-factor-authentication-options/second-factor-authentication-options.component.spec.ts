import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { AuthModule } from 'src/app/auth/auth.module';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { SecondFactorAuthenticationOptionsComponent } from './second-factor-authentication-options.component';

describe('SecondFactorAuthenticationOptionsComponent', () => {
  let component: SecondFactorAuthenticationOptionsComponent;
  let fixture: ComponentFixture<SecondFactorAuthenticationOptionsComponent>;
  let loginService: jasmine.SpyObj<LoginService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let router: Router;
  
  const MockLoginService = jasmine.createSpyObj('LoginService', ['handleLogin']);
  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['generatePayloadForAuth']);


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SecondFactorAuthenticationOptionsComponent ],
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      providers: [
        { provide: LoginService, useValue: MockLoginService },
        { provide: PayloadService, useValue: MockPayloadService },
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondFactorAuthenticationOptionsComponent);
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test ngOnInit', () => {
    spyOn<any>(component, 'getDataFromStore');
    component.twoFaAuthOptionsFromStore = [
      {
        twoFaMethodLuCode: 'DSC'
      },
      {
        twoFaMethodLuCode: 'MOB_APP_LOGIN'
      },
      {
        twoFaMethodLuCode: 'RSA'
      },
      {
        twoFaMethodLuCode: 'OTP'
      },
      {
        twoFaMethodLuCode: 'TOTP'
      }
    ]
    payloadService.moreLoginOptionsSourceCast = new BehaviorSubject<any>('TOTP').asObservable();
    fixture.detectChanges();
    payloadService.moreLoginOptionsSourceCast.subscribe((loginOption) => {
      expect(component['moreLoginOptionsSource']).toEqual(loginOption);
    })
    expect(component['getDataFromStore']).toHaveBeenCalled();
    expect(component['loginFinaldata']).not.toBeNull();
  })

  it('should call navigateToSelectedOption with option MOB_APP_LOGIN', () => {
    spyOn<any>(component, 'validateMbLogin').and.callThrough();
    component.navigateToSelectedOption('MOB_APP_LOGIN');

    expect(component['validateMbLogin']).toHaveBeenCalled();
  })

  it('should call navigateToSelectedOption when option OTP', () => {
    spyOn<any>(component, 'validateOtpOption');
    component.navigateToSelectedOption('OTP');

    expect(component['validateOtpOption']).toHaveBeenCalled();
  })

  it('should call navigateToSelectedOption when option TOTP', () => {
    spyOn<any>(component, 'navigate').and.callThrough();
    component.navigateToSelectedOption('TOTP');

    expect(component['navigate']).toHaveBeenCalled();
  })

  it('should call navigateToSelectedOption when option RSA', () => {
    spyOn<any>(component, 'navigate').and.callThrough();;
    component.navigateToSelectedOption('RSA');

    expect(component['navigate']).toHaveBeenCalled();
  })

  it('should call back method', () => {
    spyOn(router, 'navigateByUrl')
    component.back();

    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should check validateOtpOption when handle login success', () => {
    const reqPayload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: 'FGH56GBNM',
      state: '',
      authMethod: '',
      guid: 'sdfs-fgdfg-fdg-dfg',
      credential: 'JKHKLhsdfjhhkj',
      rememberMeFlag: 'N'
    })
    spyOn<any>(component, 'navigate');
    payloadService.moreLoginOptionsSourceCast = new BehaviorSubject<any>('TOTP').asObservable();
    fixture.detectChanges();
    loginService.handleLogin.and.returnValue(of({
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true,
      emailId: 'test@gmail.com',
      mobileNumebr: '1234567890',
      state: ''
    }))
    component.navigateToSelectedOption('OTP');
    loginService.handleLogin(<any>reqPayload, '/test').subscribe({ next: () => {
      expect(component['navigate']).toHaveBeenCalled
    }})
  })

  it('should check validateOtpOption when handle login error', () => {
    const reqPayload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: 'FGH56GBNM',
      state: '',
      authMethod: '',
      guid: 'sdfs-fgdfg-fdg-dfg',
      credential: 'JKHKLhsdfjhhkj',
      rememberMeFlag: 'N'
    })
    spyOn<any>(router, 'navigateByUrl');
    payloadService.moreLoginOptionsSourceCast = new BehaviorSubject<any>('TOTP').asObservable();
    fixture.detectChanges();
    loginService.handleLogin.and.returnValue(throwError(() => {
      return {
        error: {
          blkHr: '11',
          dacBlk: 'Y'
        }
      }
    }))
    component.navigateToSelectedOption('OTP');
    loginService.handleLogin(<any>reqPayload, '/test').subscribe({ error: () => {
      expect(router['navigateByUrl']).toHaveBeenCalled
    }})
  })

  it('should check validateMbLogin when login success', () => {
    loginService.handleLogin.and.returnValue(of({
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true
    }))
    component.navigateToSelectedOption('MOB_APP_LOGIN');
    expect(payloadService.generatePayloadForAuth).toHaveBeenCalled();
  })

  it('should check validateMbLogin when login error', () => {
    loginService.handleLogin.and.returnValue(throwError(() => 'error'));
    component.navigateToSelectedOption('MOB_APP_LOGIN');
    expect(payloadService.generatePayloadForAuth).toHaveBeenCalled();
  })
  
});
