import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { redirectToUserLoginUnsuccessful, userLoginUnsuccessfulCtaname } from '../../login-analystics';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-user-login-unsuccessful',
  templateUrl: './user-login-unsuccessful.component.html',
  styleUrls: ['./user-login-unsuccessful.component.scss']
})
export class UserLoginUnsuccessfulComponent implements OnInit {

  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');

  }
  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserLoginUnsuccessful
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=userLoginUnsuccessfulCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 
  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

}
