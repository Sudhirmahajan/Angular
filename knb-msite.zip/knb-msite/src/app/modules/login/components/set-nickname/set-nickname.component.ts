import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { CustomValidators } from 'src/app/modules/shared/utils/custom-validators/custom-validators';
import { PATHS, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-set-nickname',
  templateUrl: './set-nickname.component.html',
  styleUrls: ['./set-nickname.component.scss']
})
export class SetNicknameComponent implements OnInit {

  public isSpecialChar= true
  public isAlphabetChar= true
  public createUsernameForm!: FormGroup;
  public isBlur = false;
  public isBlurverified = true;
  public isUserFlag!: string;
  public data!: object;
  public showMessage!: boolean;
  public isLoading!: boolean;
  public enteredUsername!: string;
  public maskedUsername!: string;
  private httpSubscription!: Subscription;
  private cursorPosition!: number | null;
  hide!: boolean;
  cardData: any;
  cardName: any;
  isComplete: any;

  constructor(
    private payloadService: PayloadService,
    private loginService: LoginService,
    private loaderService: LoaderService,
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
    private store: Store,
    private router: Router,
  ) {
  }

  ngOnInit() {

    this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
    });

    this.createUsernameForm = new FormGroup({
      username: new FormControl('', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(35), 
      CustomValidators.patternValidator(new RegExp("^[a-zA-Z]"), { hasAlphabets: true }),
      CustomValidators.patternValidator(new RegExp("^[a-zA-Z0-9]*$"), { hasSpecialCharacters: true })])),
    })
  }

  get username() { return this.createUsernameForm.get('username'); }

  
  public checkUsername() {    
    this.isBlur = true;
    this.isBlurverified = false;
    this.showMessage = false;
  }


  public setNickname() {
    this.loaderService.startLoader();
    this.data = { username: this.createUsernameForm.controls['username'].value };
    const inputField = { cardId: this.cardData.cardId, cardName: this.cardData.cardName, data:this.data  };
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(inputField);
    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding).subscribe({next:(resp: any) => {
        this.handleOprSuccessResponse(resp);
      },error: (err) => {
        if (err.error.error.errorCode === 'ONBBE002') {
          this.showMessage = true;
        }
        this.createUsernameForm.reset();
      }});
    }
  }

  private handleOprSuccessResponse(resp:any) {
    this.loaderService.stopLoader();
    this.onboardingService.setOnboardingCardDetails(resp);
    this.cardName = resp['cardName'];
    this.isComplete = resp['isCompleted'];
    const cardFlag = this.cardService.checkCardName(resp.cardName);
        if (!cardFlag) {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else  if (this.isComplete === 'Y') {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else if(cardFlag) {
          this.cardService.navigateToView(resp.cardName);
        }
      
  }
 
  resetAlreadyExist() {
    this.showMessage = false;
  }

}
