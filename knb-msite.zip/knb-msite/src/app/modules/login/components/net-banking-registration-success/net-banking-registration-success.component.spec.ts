import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NetBankingRegistrationSuccessComponent } from './net-banking-registration-success.component';

describe('NetBankingRegistrationSuccessComponent', () => {
  let component: NetBankingRegistrationSuccessComponent;
  let fixture: ComponentFixture<NetBankingRegistrationSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NetBankingRegistrationSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NetBankingRegistrationSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
