import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CountdownComponent, CountdownEvent } from 'ngx-countdown';
import { Subscription } from 'rxjs';
import { getBlockedTimer, getFlow, getpartyDetails } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-netbanking-locked',
  templateUrl: './netbanking-locked.component.html',
  styleUrls: ['./netbanking-locked.component.scss']
})
export class NetbankingLockedComponent implements OnInit {

  public timeRemainingActual!: number;
  public timeRemainingModified!: number;
  httpSubscription!: Subscription;
  @ViewChild(CountdownComponent) counter!: CountdownComponent;
  storeFlow!: string;
  partyData: any;

  constructor(
    private router: Router,
    private store: Store,
  ) { }

  ngOnInit(): void {
    this.getDataFromStore();
    this.timeRemainingModified = (Number(this.timeRemainingActual) + 59);

    this.store.select(getpartyDetails).subscribe((data) => {
      this.partyData = data;
    });
  }

  public onFinished(event: CountdownEvent) {
    if(event.action == 'done') {
      this.counter.stop();
      this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
    }
  }

  public navigate() {
    
      (this.storeFlow) ? this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CARD_NO], { skipLocationChange: environment.skipURI })
      : this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CARD_NO], { skipLocationChange: environment.skipURI });
 }

  private getDataFromStore() {
    this.store.select(getBlockedTimer).subscribe((resp) => {
      this.timeRemainingActual = Number(resp);
    });
    this.store.select(getFlow).subscribe((resp) => { this.storeFlow = resp; });
  }


}
