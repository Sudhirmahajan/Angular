import { HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { CountdownComponent, CountdownEvent, CountdownModule } from 'ngx-countdown';
import { of } from 'rxjs';
import { getBlockedTimer, getFlow } from 'src/app/auth/auth.index';
import { createTranslateLoader, SharedModule } from 'src/app/modules/shared/shared.module';

import { NetbankingLockedComponent } from './netbanking-locked.component';

describe('NetbankingLockedComponent', () => {
  const mockValueTimer=10;
  const mockFlow="flow"
  let component: NetbankingLockedComponent;
  let fixture: ComponentFixture<NetbankingLockedComponent>;
  let router: Router;
  let store: MockStore;

  const counter = jasmine.createSpyObj('CountdownComponent', ['stop']);


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule, 
        NoopAnimationsModule,
        CountdownModule,
        SharedModule,
        TranslateModule.forRoot(),
      ],
      declarations: [ NetbankingLockedComponent, CountdownComponent ],
      providers: [
      
        provideMockStore({
          selectors: [
            {
              selector: getBlockedTimer,
              value: mockValueTimer
          },
          {
            selector: getFlow,
            value: mockFlow
        },
          ]
        })
      ],

    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NetbankingLockedComponent);
    component = fixture.componentInstance;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    //fixture.detectChanges();
  });

  it('should create netbanking-locked component', () => {
    component.counter = counter;
    spyOn<any>(component, 'getDataFromStore');
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should call onFinished', () => {
    component.counter = counter;
    const e: CountdownEvent = {
      action: 'done',
      status: 2,
      left: 2,
      text: 'test-data'
    }

    spyOn<any>(component, 'getDataFromStore');
    component.onFinished(e);
    expect(component.counter.stop).toHaveBeenCalled();
  });



  it('should navigate to CARD_NO page when storeFlow is present', () => {
    component.storeFlow = 'someValue';
    spyOn(router, 'navigateByUrl');
  component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();  });
  
  it('should navigate to CARD_NO page when storeFlow is not present', () => {
    component.storeFlow = '';
    spyOn(router, 'navigateByUrl');
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();  });

  it('should get the timeRemainingActual and Flow from store', () => {
    (component as any).getDataFromStore();
    store.select(getBlockedTimer).subscribe((response) => {
      expect(response).toBe(mockValueTimer);
    expect(component.timeRemainingActual).toBe(mockValueTimer);

    store.select(getFlow).subscribe((response) => {
      expect(response).toEqual(mockFlow);
     expect(component.storeFlow).toEqual(response);


   });
  });

   });
  

  
  
  



});
