import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaySecureCardComponent } from './stay-secure-card.component';

describe('StaySecureCardComponent', () => {
  let component: StaySecureCardComponent;
  let fixture: ComponentFixture<StaySecureCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaySecureCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaySecureCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
