import { APP_BASE_HREF } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { AuthenticationService, getClientSessionId } from 'src/app/auth/auth.index';
import { AuthModule } from 'src/app/auth/auth.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { createTranslateLoader, SharedModule } from 'src/app/modules/shared/shared.module';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { UserDetailsComponent } from './user-details.component';

describe('UserDetailsComponent', () => {
  let component: UserDetailsComponent;
  let fixture: ComponentFixture<UserDetailsComponent>;
  let store: MockStore;
  let router: Router;
  let MockLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  let loginService: jasmine.SpyObj<LoginService>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let loaderService: jasmine.SpyObj<LoaderService>;
  let authenticationService; let matDialog; let bundleLoaderInitializerService;

  const MockLoginService = jasmine.createSpyObj('LoginService', ['handleLoginCaptcha', 'validateUserName', 'handleOpr']);
  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['generatePayloadForLogin', 'generatePayloadForOpr']);
  const MockAuthenticationService = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  const MockBundleLoaderInitializerService = jasmine.createSpyObj('BundleLoaderInitializerService', ['startWatchingIdle', 'changeBundleLoaderStatus']);
  const MockMatDialog = jasmine.createSpyObj('MatDialog', ['open']);


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ UserDetailsComponent ],
      providers: [
        { provide: LoginService, useValue: MockLoginService },
        { provide: PayloadService, useValue: MockPayloadService },
        { provide: AuthenticationService, useValue: MockAuthenticationService },
        { provide: MatDialog, useValue: MockMatDialog },
        { provide: BundleLoaderInitializerService, useValue: MockBundleLoaderInitializerService },
        { provide: LoaderService, useValue: MockLoaderService },
        provideMockStore({
          selectors: [
            
          ]
        })
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailsComponent);
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    authenticationService = TestBed.inject(AuthenticationService);
    matDialog = TestBed.inject(MatDialog);
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService);
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    spyOn<any>(component, 'getCaptcha');
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should fetch capthcha success', () => {
    component.params.key = '123456';
    const response = {key: '123', captcha: 'iVBORw0KGgo'}
    loginService.handleLoginCaptcha.and.returnValue(of(response))
    component.getCaptcha();
    loginService.handleLoginCaptcha({key: ""}, '/test-captcha').subscribe({ next: (resp) => {
      expect(resp).toBe(response);
    }})
  });

  it('should fetch capthcha error', () => {
    component.params.key = '123456';
    spyOn<any>(component, 'errorHandle');
    loginService.handleLoginCaptcha.and.returnValue(throwError(() => 'api error'));
    component.getCaptcha();
    loginService.handleLoginCaptcha({key: ""}, '/test-captcha').subscribe({ error: (error) => {
      expect(error).toBe('api error');
      expect(component.errorHandle).toHaveBeenCalled();
    }})
  });

  it('should fetch capthcha error status is 404', () => {
    spyOn<any>(component, 'errorHandle');
    loginService.handleLoginCaptcha.and.returnValue(throwError(() => { return { status: '404' } }));
    component.getCaptcha();
    loginService.handleLoginCaptcha({key: ""}, '/test-captcha').subscribe({ error: (error) => {
      expect(error.status).toBe('404');
    }})
  });

  it('should validate user details success', () => {
    spyOn<any>(component, 'getCaptcha');
    spyOn<any>(component, 'errorHandle');

    fixture.detectChanges();

    component.rememberMeFlag = true;
    component.userDetailsForm.setValue({
      userData: '12013136',
      captchaElement: 'GTY6U',
      rememberMe: true
    })

    const payLoadResponse = { authMethod: "NA", client_id: "knb2", rememberMeFlag: "N", userId: "d6H7X1vIeQc9ds" }
    const loginResponse = { state:"jAzNDZiMDEtYjQyOC0", flow:"LOGIN", cardDetailsLogin: false, pdfRequested: false}
    const payload = payloadService.generatePayloadForLogin.and.returnValue(payLoadResponse);
    loginService.validateUserName.and.returnValue(of(<any>loginResponse));
    spyOn<any>(component, 'handleLoginSuccessResponse');

    component.validateUserDetails();
    
    loginService.validateUserName(<any>payload, '/logintest', {}).subscribe({ next: (resp) => {
       expect(component.handleLoginSuccessResponse).toHaveBeenCalled();
    } })
    
  });

  it('should validate user details error', () => {
    spyOn<any>(component, 'getCaptcha');
    spyOn<any>(component, 'errorHandle');

    fixture.detectChanges();

    component.rememberMeFlag = true;
    component.userDetailsForm.setValue({
      userData: '12013136',
      captchaElement: 'GTY6U',
      rememberMe: true
    })

    const payLoadResponse = { authMethod: "NA", client_id: "knb2", rememberMeFlag: "N", userId: "d6H7X1vIeQc9ds" }
    const loginResponse = { state:"jAzNDZiMDEtYjQyOC0", flow:"LOGIN", cardDetailsLogin: false, pdfRequested: false}
    const payload = payloadService.generatePayloadForLogin.and.returnValue(payLoadResponse);
    loginService.validateUserName.and.returnValue(throwError(() => null));
    spyOn<any>(component, 'handleLoginSuccessResponse');

    component.validateUserDetails();
    
    loginService.validateUserName(<any>payload, '/logintest', {}).subscribe({ error: () => {
       expect(component.errorHandle).toHaveBeenCalled();
       expect(component.getCaptcha).toHaveBeenCalled();
    } })
  });

  it("should check handleLoginSuccessResponse when username is blocked", () => {
    spyOn<any>(component, 'getCaptcha');
    fixture.detectChanges();
    component.userDetailsForm.setValue({
      userData: '12013136',
      captchaElement: 'GTY6U',
      rememberMe: true
    });
    
    spyOn<any>(component, 'findTypeOfCrn');
    spyOn<any>(component, 'handleBlockedUsername');
    spyOn<any>(component, 'handleValidUsername');

    component.handleLoginSuccessResponse({
      authMethod: 'MOBILE',
      flow: '',
      guid: '',
      state: '',
      statusCode: 0,
      crdntlBlk: '',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: ''
    });

    expect(component.findTypeOfCrn).toHaveBeenCalled();
    expect(component.handleBlockedUsername).toHaveBeenCalled();
    expect(component.handleValidUsername).not.toHaveBeenCalled();
  })

  it("should check handleLoginSuccessResponse when username is validated", () => {
    spyOn<any>(component, 'getCaptcha');
    fixture.detectChanges();
    component.userDetailsForm.setValue({
      userData: '12013136',
      captchaElement: 'GTY6U',
      rememberMe: true
    });
    
    spyOn<any>(component, 'findTypeOfCrn');
    spyOn<any>(component, 'handleBlockedUsername');
    spyOn<any>(component, 'handleValidUsername');

    component.handleLoginSuccessResponse({
      authMethod: '',
      flow: '',
      guid: '',
      state: '',
      statusCode: 0,
      crdntlBlk: '',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: ''
    });

    expect(component.findTypeOfCrn).toHaveBeenCalled();
    expect(component.handleBlockedUsername).not.toHaveBeenCalled();
    expect(component.handleValidUsername).toHaveBeenCalled();
  })

  it('should find type when CRN is entered', () => {
    spyOn(store, 'dispatch').and.callThrough();
    component.findTypeOfCrn('12013126');

    expect(store.dispatch).toHaveBeenCalled();
  })

  it('should find type when username is entered', () => {
    spyOn(store, 'dispatch').and.callThrough();
    component.findTypeOfCrn('text');

    expect(store.dispatch).toHaveBeenCalled();
  })

  it('should find type when card number is entered', () => {
    spyOn(store, 'dispatch').and.callThrough();
    component.findTypeOfCrn('1234567891234567');

    expect(store.dispatch).toHaveBeenCalled();
  })

  it('should handle blocked username', () => {
    spyOn(store, 'dispatch').and.callThrough();
    spyOn(component, 'processBlockedUsername');

    component.handleBlockedUsername({
      flow: 'username',
      authMethod: '',
      guid: '',
      state: '',
      statusCode: 0,
      crdntlBlk: '',
      cdtBlk: '',
      chnlBlk: '',
      mblNtUpdtd: '',
      showRecaptcha: '',
      cardDetailsLogin: ''
    })

    expect(component.processBlockedUsername).toHaveBeenCalled();
    expect(store.dispatch).toHaveBeenCalled();
  })

  it('should process blocked name when api success', () => {
    spyOn<any>(component, 'getCaptcha');
    fixture.detectChanges();
    component.userDetailsForm.setValue({
      userData: '12013136',
      captchaElement: 'GTY6U',
      rememberMe: true
    });
    
    spyOn<any>(component, 'handleOprSuccessResponse').and.callThrough();
    payloadService.generatePayloadForOpr.and.callThrough();
    const reqPayload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'test',
      flow: '',
      guid: '',
      oprState: '',
    });

    const response = {
      flow: 'USERNAME',
      guid: 'AssdAAddfs6',
      nextScreen: 'PASSWORD',
      state: 'RESET',
      showRecaptcha: 'N'
    }
    loginService.handleOpr.and.returnValue(of(response));
    component.processBlockedUsername();
    loginService.handleOpr(reqPayload, '/test', ).subscribe({ error: () => {
      expect(loaderService.stopLoader).toHaveBeenCalled();
   } })
  })

   it('should process blocked name when api error', () => {
    spyOn<any>(component, 'getCaptcha');
    fixture.detectChanges();
    component.userDetailsForm.setValue({
      userData: '12013136',
      captchaElement: 'GTY6U',
      rememberMe: true
    });
    
    spyOn<any>(component, 'errorHandle').and.callThrough();
    payloadService.generatePayloadForOpr.and.callThrough();
    const reqPayload = payloadService.generatePayloadForOpr.and.returnValue({
      client_id: 'test',
      flow: '',
      guid: '',
      oprState: '',
    });

    const response = {
      flow: 'USERNAME',
      guid: 'AssdAAddfs6',
      nextScreen: 'PASSWORD',
      state: 'RESET',
      showRecaptcha: 'N'
    }
    loginService.handleOpr.and.returnValue(throwError(() => 'error'));
    component.processBlockedUsername();
    loginService.handleOpr(reqPayload, '/test', ).subscribe({ error: () => {
      expect(component.errorHandle).toHaveBeenCalled();
   } })
  })

  it('should handle valid username', () => {
    spyOn(store, 'dispatch').and.callThrough();
    spyOn(router, 'navigateByUrl');
    component.handleValidUsername({
      flow: 'username',
      authMethod: 'OTP',
      guid: 'test',
      state: 'test',
      statusCode: 0,
      crdntlBlk: 'test',
      cdtBlk: 'test',
      chnlBlk: 'tets',
      mblNtUpdtd: 'test',
      showRecaptcha: 'test',
      cardDetailsLogin: 'test'
    })
    expect(router.navigateByUrl).toHaveBeenCalled();
  });
  
  it('should enable need help username link', () => {
    spyOn(router, 'navigateByUrl');
    component.userNeedsHelp('username');
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should enable need help CRN link', () => {
    spyOn(router, 'navigateByUrl');
    component.userNeedsHelp('CRN');
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should enable need help resetPassword link', () => {
    spyOn(router, 'navigateByUrl');
    component.userNeedsHelp('resetPassword');
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should enable need help register link', () => {
    spyOn(router, 'navigateByUrl');
    component.userNeedsHelp('register');
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should enable need help register link', () => {
    spyOn(router, 'navigateByUrl');
    component.userNeedsHelp('register');
    expect(router.navigateByUrl).toHaveBeenCalled();
  })

  it('should test header', () => {
    spyOn<any>(component, 'getCaptcha');
    const userDetailsDe: DebugElement = fixture.debugElement;
    const userDetailsEl: HTMLElement = userDetailsDe.nativeElement;
    const title = userDetailsEl.querySelector('mat-card-title')!;
    fixture.detectChanges();
    expect(title.textContent).toEqual('login.crn-card-nick.header');
  })

  it('should test sub header', () => {
    spyOn<any>(component, 'getCaptcha');
    const userDetailsDe: DebugElement = fixture.debugElement;
    const userDetailsEl: HTMLElement = userDetailsDe.nativeElement;
    const title = userDetailsEl.querySelector('mat-card-subtitle')!;
    fixture.detectChanges();
    expect(title.textContent).toEqual('login.crn-card-nick.dropdown.option-1');
  })

  it('should test CRN/username/card number text box', () => {
    spyOn<any>(component, 'getCaptcha');
    spyOn<any>(component, 'validateUserDetails').and.callThrough();
    spyOn<any>(component, 'rememberMeModal').and.callThrough();
    const hostElementDe: DebugElement = fixture.debugElement;
    const hostElement: HTMLElement = hostElementDe.nativeElement;
    const nameInput: NodeListOf<HTMLInputElement> = hostElement.querySelectorAll('input')!;
    const btn: HTMLElement = hostElement.querySelector('button')!;
    nameInput[0].value = '12013126';
    nameInput[1].value = 'true';
    nameInput[0].dispatchEvent(new Event('input'));
    nameInput[1].dispatchEvent(new Event('click'));
    btn.dispatchEvent(new Event('click'));
    fixture.detectChanges();
    expect(component.validateUserDetails).toHaveBeenCalled();
    expect(component.rememberMeModal).toHaveBeenCalled();
  })
})
