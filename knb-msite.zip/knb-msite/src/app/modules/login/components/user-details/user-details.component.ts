import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ILoginSuccessResp, IVerifyCrnRequest, IVerifyCrnResponse } from '../../models/login.model';
import { ROUTE_KEY, PATHS, SCREEN_ROUTING_KEYS, FLOWS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { Store } from '@ngrx/store';
import { getClientSessionId, setClientSessionId, AuthenticationService, setUserId, setGUID, setFlow, setServerState, setCredentialBlockedStatus, setCardDetailsBlockedStatus, setChannelBlockedStatus, setMobileNotUpdatedStatus, setRecaptcha, BioCatchService, setPageName,  resetStore, setAuthMethod, setMsiteFlow, setMsiteAuthMethod, setMsiteUserID } from 'src/app/auth/auth.index';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { LoaderService } from '../../../shared/services/loader/loader.service'
import { MatDialog } from '@angular/material/dialog';
import { RemembermeDialogComponent } from '../../utils/rememberme-dialog/rememberme-dialog.component';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import {loginPageCtaname, redirectToLoginPage} from '../../login-analystics'
import { Subscription } from 'rxjs/internal/Subscription';


@Component({
  selector: 'app-user-details',
  templateUrl: 'user-details.component.html',
  styleUrls: ['user-details.component.scss']
})
export class UserDetailsComponent implements OnInit, OnDestroy {
  userDetailsForm!: FormGroup;
  httpSubscription!: Subscription;
  clientSessionId!: string;
  rememberMeFlag!: boolean;
  params = { key: '', captchaValue: '' };
  captchaSource: string = '';
  captchaError!: boolean;
  showCaptcha!: boolean
  cvvData!: string;
  flow!: string;
  authMethod!: string;
  paryDataFlag !: boolean;

  constructor(private loginService: LoginService,
    private payloadService: PayloadService,
    private authenticationService: AuthenticationService,
    private store: Store,
    private router: Router,
    private loaderService: LoaderService,
    public dialog: MatDialog,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private bioCatchService: BioCatchService,
    ) { 
      this.bundleLoaderInitializerService.changeBundleLoaderStatus(true);
      this.store.dispatch(resetStore());
      this.store.select(getClientSessionId).subscribe(value => {
        this.clientSessionId = value;
      });
    }

  ngOnInit(): void {
    this.store.dispatch(setPageName({ value: 'Login' })); 
    this.setAnalyticsOnPageLoad();
    if (!this.clientSessionId) {
      this.store.dispatch(setClientSessionId({value: this.authenticationService.generateRandom()}));
    }
    this.getCaptcha();
    this.bioCatchService.biocatchSetValues(BIO_CATCH_CONTEXT_KEY.MSITE_PRE+this.clientSessionId, BIO_CATCH_CONTEXT_KEY.MSITE_LOGIN_USERNAME);
    this.userDetailsForm = new FormGroup({
      userData: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(35)]),
      rememberMe: new FormControl(false),
      captchaElement: new FormControl('', [Validators.minLength(5), Validators.maxLength(5)])
    });
  }

  setAnalyticsOnPageLoad(){
    window.digitalData=redirectToLoginPage
    window._satellite?.track("NB-Msiteload");
  }

  setAnalytics(cta_name:any){
    window.digitalData=loginPageCtaname(cta_name);
    window._satellite?.track("NB-Msiteclick");
  }

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

  getCaptcha() {
    let payload = { key: '' };
    if(this.params.key){
      payload['key'] = this.params.key;
    }
    this.loginService.handleLoginCaptcha(payload , PATHS.getCaptcha).subscribe({next:
      (res)=>{
      this.showCaptcha = true;
      this.captchaSource = "data:image/png;base64," + res['captcha'];
      this.params.key = res['key'];
       document.getElementById('splash')!.style.display = 'none'; 
    }, error:(err)=>{
       document.getElementById('splash')!.style.display = 'none'; 
      if(err.status == '404') {
        this.showCaptcha = false;
      } else {
        this.captchaError = true;
        this.errorHandle();
      }
    }})
  }

  validateUserDetails(): void {
    const rememberMe = this.rememberMeFlag ? 'Y' : 'N';
    const userData = this.userDetailsForm.controls['userData'].value.trim();
    this.store.dispatch(setUserId({ value: userData}));
    this.params.captchaValue = this.userDetailsForm.controls['captchaElement'].value.trim();
    const repPayload = this.payloadService.generatePayloadForLogin(userData, rememberMe);
    this.loaderService.startLoader();
    
    if (repPayload) {
      this.httpSubscription = this.loginService.validateUserName(repPayload, PATHS.login, this.params).subscribe({next: (validateUserResponse: any) => {
        this.flow = validateUserResponse.flow;
        this.store.dispatch(setMsiteFlow({ value: validateUserResponse.flow})); 
        this.authMethod = validateUserResponse.authMethod;
        this.store.dispatch(setMsiteAuthMethod({ value: this.authMethod }));
        if(validateUserResponse) {
          this.loaderService.stopLoader();
          this.handleLoginSuccessResponse(validateUserResponse);
        } else {
          this.loaderService.stopLoader();
          this.router.navigateByUrl(ROUTE_KEY['SERVICE_NOT_FOUND'], { skipLocationChange: environment.skipURI });
        }
     
      },error:  () => {
        this.getCaptcha();
        this.errorHandle();
      }});
    }
    
  }
  
  handleLoginSuccessResponse(resp: ILoginSuccessResp) {
    const userName = this.userDetailsForm.controls['userData'].value.trim();
    this.findTypeOfCrn(userName);
    (resp['authMethod'] === SCREEN_ROUTING_KEYS.MOBILE || resp['flow'] == FLOWS.unblock || resp['flow'] == FLOWS.mobileNotUpdated ||resp['flow'] === FLOWS.netBankingRegister) ?
      this.handleBlockedUsername(resp) : this.handleValidUsername(resp);
  }

  findTypeOfCrn(userId: string) {
    const numbers = /^[0-9]+$/;
    const userIDType = (numbers.test(userId)) ? (userId.length < 16) ? 'CRN' : '' : 'Username';
    this.store.dispatch(setUserId({value: userId + '|' + userIDType}));
    this.store.dispatch(setMsiteUserID({value: userId}));
  }

  handleBlockedUsername(resp: ILoginSuccessResp) {
    this.store.dispatch(setFlow({value: resp['flow']}));
    this.processBlockedUsername();
  }

  processBlockedUsername() {
		const userName = this.userDetailsForm.controls['userData'].value.trim();
    const inputField = { loginId: userName };
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true);
    if (reqPayload as unknown as IVerifyCrnRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe({next: (resp: IVerifyCrnResponse) => {
          this.loaderService.stopLoader();
          this.handleOprSuccessResponse(resp);
        }, error: () => {
          this.errorHandle();
        }});
    }
  }

  errorHandle() {
    this.loaderService.stopLoader();
    this.userDetailsForm.reset();
  }

  private handleOprSuccessResponse(resp: IVerifyCrnResponse): void {
    this.loaderService.stopLoader();
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({value: resp['state']}))
    this.store.dispatch(setGUID({value: resp['guid']}))
    this.store.dispatch(setFlow({value: resp['flow']}))
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  handleValidUsername(resp: ILoginSuccessResp) {
    const authMethod: string = resp['authMethod'];
    (resp['flow'] !== 'LOGIN') && this.store.dispatch(setFlow({value: resp['flow']}));
		resp['crdntlBlk'] && this.store.dispatch(setCredentialBlockedStatus({value: resp['crdntlBlk']}));
		resp['cdtBlk'] && this.store.dispatch(setCardDetailsBlockedStatus({value: resp['cdtBlk']}));
		resp['chnlBlk'] && this.store.dispatch(setChannelBlockedStatus({value: resp['chnlBlk']}));
		resp['mblNtUpdtd'] && this.store.dispatch(setMobileNotUpdatedStatus({value: resp['mblNtUpdtd']}));
		resp['showRecaptcha'] && this.store.dispatch(setRecaptcha({value: resp['showRecaptcha']}));
    this.store.dispatch(setServerState({value: resp['state']}));
    this.store.dispatch(setGUID({value: resp['guid']}));

		if (authMethod === 'CARD' && !resp['cardDetailsLogin']) {
      this.router.navigateByUrl(ROUTE_KEY['CREDENTIAL'], { skipLocationChange: environment.skipURI });
    } else {
      this.router.navigateByUrl(ROUTE_KEY[resp['authMethod']], { skipLocationChange: environment.skipURI });
    }
		
  }

  rememberMeModal(event: Event) {
    //(event.target as HTMLInputElement).blur();
    if((event.target as HTMLInputElement).checked) {
    event.preventDefault();
    const dialogRef = this.dialog.open(RemembermeDialogComponent, {
      width: '300px'
    });

    dialogRef.afterClosed().subscribe(flag => {
      this.rememberMeFlag = flag;
    })} else {
      this.rememberMeFlag = (event.target as HTMLInputElement).checked
    };
  }

  userNeedsHelp(userRequest: string) {
    //this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_GET_HELP);
    switch(userRequest) {
      case 'username':
        this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_CREATE_USERNAME);
        this.router.navigateByUrl(ROUTE_KEY['KNOW_OR_CREATE_USERNAME'], { skipLocationChange: environment.skipURI });
        break;
      case 'CRN':
        this.router.navigateByUrl(ROUTE_KEY['CRN_THROUGH_CARD'], { skipLocationChange: environment.skipURI });
        break;
      case 'resetPassword':
        this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_OPR);
        this.router.navigateByUrl(ROUTE_KEY['IDENTIFY_YOURSELF'], { skipLocationChange: environment.skipURI });
        break;
      case 'register':
        this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.MSITE_REGISTER);
        this.router.navigateByUrl(ROUTE_KEY['REGISTER_FOR_NET_BANKING'], { skipLocationChange: environment.skipURI });
        break;
        
    }
  }


}
