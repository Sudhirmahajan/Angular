import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-welcome-back',
  templateUrl: './welcome-back.component.html',
  styleUrls: ['./welcome-back.component.scss']
})
export class WelcomeBackComponent implements OnInit {

  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  public unlockNetBanking(): void {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CARD_NO], { skipLocationChange: environment.skipURI });
  }

}
