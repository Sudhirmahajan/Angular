import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';

import { WelcomeBackComponent } from './welcome-back.component';

describe('WelcomeBackComponent', () => {
  let component: WelcomeBackComponent;
  let fixture: ComponentFixture<WelcomeBackComponent>;
  let router :Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WelcomeBackComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WelcomeBackComponent);
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate by URL', () => {
    spyOn(router,'navigateByUrl')
    component.unlockNetBanking();
    expect(router.navigateByUrl).toHaveBeenCalled();
   });
   
});
