import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CountdownComponent } from 'ngx-countdown';
import { getBlockedTimer } from 'src/app/auth/auth.index';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-user-password-generation-locked-wrong-mobile-otp',
  templateUrl: './user-password-generation-locked-wrong-mobile-otp.component.html',
  styleUrls: ['./user-password-generation-locked-wrong-mobile-otp.component.scss']
})
export class UserPasswordGenerationLockedWrongMobileOtpComponent implements OnInit {

  @ViewChild(CountdownComponent) counter!: CountdownComponent;
  public timeRemainingActual!: number;
  public timeRemainingDuplicate!: number;


  constructor(
    private store: Store,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.getDataFromStore();
    this.timeRemainingDuplicate = (Number(this.timeRemainingActual) + 59);
  }

  public onFinished() {
    this.counter.stop();
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
  }

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.CRN], { skipLocationChange: environment.skipURI });
}

  private getDataFromStore() {
    this.store.select(getBlockedTimer).subscribe((resp) => {
      this.timeRemainingActual = Number(resp);
    });
  }

}
