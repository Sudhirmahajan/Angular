import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { UserPasswordGenerationLockedWrongMobileOtpComponent } from './user-password-generation-locked-wrong-mobile-otp.component';
import { getBlockedTimer } from 'src/app/auth/auth.module';

describe('UserPasswordGenerationLockedWrongMobileOtpComponent', () => {
  let component: UserPasswordGenerationLockedWrongMobileOtpComponent;
  let fixture: ComponentFixture<UserPasswordGenerationLockedWrongMobileOtpComponent>;
  let router :Router;
  let store: MockStore;
  const blockedTimer = 'test time';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPasswordGenerationLockedWrongMobileOtpComponent ],
      imports:[RouterTestingModule,HttpClientModule,
        TranslateModule.forRoot(
        {
          loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
          },
          isolate: true,
          defaultLanguage: 'en'
        }
      )],

      providers:[
        provideMockStore({
          selectors:[
              {
                  selector: getBlockedTimer,
                  value: [
                      {
                          Timer: blockedTimer,
                      },
                  ],
              },
          ]
      })
      ]


    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordGenerationLockedWrongMobileOtpComponent);
    router = TestBed.inject(Router);
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate', () => {
    spyOn(router,'navigateByUrl')
    component.navigate();
    expect(router.navigateByUrl).toHaveBeenCalled();
   
   });

   
 xit('should navigate on Finish', () => {
   spyOn(component.counter,'stop').and.callThrough()
   component.onFinished();
   expect(component.counter.stop).toHaveBeenCalled
   
  });
  
});
