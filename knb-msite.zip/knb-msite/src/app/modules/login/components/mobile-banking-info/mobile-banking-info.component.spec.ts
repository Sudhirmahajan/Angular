import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MobileBankingInfoComponent } from './mobile-banking-info.component';
import { LoginRoutingModule } from '../../login-routing.module';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { getTwoFaAuthOptions } from 'src/app/auth/auth.index';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { CountdownEvent } from 'ngx-countdown';
import { HttpErrorResponse } from '@angular/common/http';

describe('MobileBankingInfoComponent', () => {
  let component: MobileBankingInfoComponent;
  let fixture: ComponentFixture<MobileBankingInfoComponent>;
  let translate: TranslateService;
  let store: MockStore;
  let router: Router;

  let loginService = jasmine.createSpyObj('LoginService', ['handleLogin', 'handleOpr']);
  let service : jasmine.SpyObj<LoginService>;

  let rememberMeServiceObj = jasmine.createSpyObj('RememberMeService', ['handleRememberMe']);
  let rememberMeService : jasmine.SpyObj<RememberMeService>;

  let payloadServiceObj = jasmine.createSpyObj('PayloadService', ['generatePayloadForAuth', 'setMoreLoginOptionsSource']);
  let payloadService    : jasmine.SpyObj<PayloadService>;

  let setOnboardCardServiceObj = jasmine.createSpyObj('SetOnboardCardService', ['checkUserOnboarded']);
  let setOnboardCardService : jasmine.SpyObj<SetOnboardCardService>;

  // let widgetServiceObj = jasmine.createSpyObj('WidgetService', ['']);
  // let widgetService   : jasmine.SpyObj<WidgetService>;

  const counter = jasmine.createSpyObj('CountdownComponent', ['stop']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MobileBankingInfoComponent ],
      imports: [ RouterTestingModule,  
                TranslateModule.forRoot(),
                LoginRoutingModule,
                SharedModule, 
              ],
      providers : [
        provideMockStore({
          selectors : [
            {
              selector : getTwoFaAuthOptions,
              value : 'abc'
            }
          ]

         }),
        { provide : LoginService , useValue : loginService},
        { provide : RememberMeService, useValue : rememberMeServiceObj},
        { provide : PayloadService, useValue : payloadServiceObj },
        { provide : SetOnboardCardService, useValue :  setOnboardCardServiceObj},
       // { provide :  WidgetService, useValue : widgetServiceObj}
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture               = TestBed.createComponent(MobileBankingInfoComponent);
    component             = fixture.componentInstance;
    service               = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    rememberMeService     = TestBed.inject(RememberMeService) as jasmine.SpyObj<RememberMeService>;
    payloadService        = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    setOnboardCardService = TestBed.inject(SetOnboardCardService) as jasmine.SpyObj<SetOnboardCardService>;
  //  widgetService         = TestBed.inject(WidgetService) as jasmine.SpyObj<WidgetService>;
    store                 = TestBed.inject<any>(Store) as MockStore<any>;
    router                = TestBed.inject(Router);
    spyOn(store, 'dispatch');
    fixture.detectChanges();
  });

  it('should test get Data From Store', () => {
   (component as any).getDataFromStore();
    
    store.select(getTwoFaAuthOptions).subscribe((resp) => {
      if (resp) {
          expect(component.moreOptionsStatus).toBe(true);
      }
    });

  });

  it('Should check verifyMobileBankingAuthentication success', () => {
    spyOn<any>(component, 'handleMobileBankingSuccessResponse');
    const payload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: '123',
      state: 'abc',
      authMethod: 'qvc',
      guid: 'rty',
      credential: 'kjl',
      rememberMeFlag: 'y',
    });

    loginService.handleLogin.and.returnValue(of({
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true,
    }));


    (component as any).verifyMobileBankingAuthentication();
     loginService.handleLogin(payload, '/testUrl').subscribe({ next: (resp: any) => {
      expect(resp.pdfRequested).toBe(true);
      expect(resp.authMethod).toEqual('SET_CREDENTIAL');
      expect((component as any).handleMobileBankingSuccessResponse).toHaveBeenCalled();

    } })
    
  });

  it('Should check verifyMobileBankingAuthentication error code BE0038', () => {
    spyOn<any>(component, 'handleMobileBankingErrorResponse');
     const payload = payloadService.generatePayloadForAuth.and.returnValue({
       client_id: '123',
       state: 'abc',
       authMethod: 'qvc',
       guid: 'rty',
       credential: 'kjl',
       rememberMeFlag: 'y',
     });
 
     loginService.handleLogin.and.returnValue(throwError(() => {
       return {
        error : {
          error : { errorCode : 'BE0038'},
          
        } 
       }
     }));
      
 
     (component as any).verifyMobileBankingAuthentication();
      loginService.handleLogin(payload, '/testUrl').subscribe({ error: (error : HttpErrorResponse) => {
       expect(Router.call);
 } })
     
   });

   it('Should check verifyMobileBankingAuthentication error code BE0039', () => {
    spyOn<any>(component, 'handleMobileBankingErrorResponse');
     const payload = payloadService.generatePayloadForAuth.and.returnValue({
       client_id: '123',
       state: 'abc',
       authMethod: 'qvc',
       guid: 'rty',
       credential: 'kjl',
       rememberMeFlag: 'y',
     });
 
     loginService.handleLogin.and.returnValue(throwError(() => {
       return {
        error : {
          error : { errorCode : 'BE0039'},
          
        } 
       }
     }));
      
 
     (component as any).verifyMobileBankingAuthentication();
      loginService.handleLogin(payload, '/testUrl').subscribe({ error: (error : HttpErrorResponse) => {
       expect(Router.call);
  }})
     
   });

  it('should be test handleAccessTokenResponse', () => {

    const resp = {
      customerInfo : 'abc',
      onboarding : 'Y',

    };
    (component as any).handleAccessTokenResponse(resp);
    expect(Router.call);
   
  });

  it('Should check CheckMoreLoginOptions', () => {

    const resp = {
      customerInfo : 'abc',
      onboarding : 'N',

    };
    (component as any).handleAccessTokenResponse(resp);
    expect(Router.call);
    
  });

  it('Should check handleMobileBankingSuccessResponse', ()=> {
    const resp = {
      accessToken : 'abc'

    };
    (component as any).handleMobileBankingSuccessResponse(resp);
  });

  it('Should check handleSetCredentialOptionResponse', ()=> {
    const resp = {
      accessToken : 'abc'

    };
    spyOn(router,'navigateByUrl');
    (component as any).handleSetCredentialOptionResponse(resp);
    expect(router.navigateByUrl).toHaveBeenCalled();
    
  });

  it('Should check defaultOnFinished', ()=> {
   
    const event: CountdownEvent = {
      action: 'done',
      status: 2,
      left: 2,
      text: 'test-data'
    }
    
   // spyOn<any>(component, 'getDataFromStore');
    component.defaultOnFinished(event);
        expect(event.action).toBe('done');
    // expect(router.navigateByUrl).toHaveBeenCalled();

  });

  it('Should test CheckMoreLoginOptions', ()=> {
   
    component.CheckMoreLoginOptions();
   // expect(payloadService.setMoreLoginOptionsSource).toHaveBeenCalled();
    
   expect(payloadService.setMoreLoginOptionsSource).toHaveBeenCalled();
    
  });

  it('Should test handleMobileBankingErrorResponse if ', () => {
    const error  = new HttpErrorResponse( {
      error : {
        error : { errorCode : 'BE0038'}
      } 
     });

     (component as any ).handleMobileBankingErrorResponse(error);
  });

  it('Should test handleMobileBankingErrorResponse else ', () => {
    const error  = new HttpErrorResponse( {
      error : {
        error : ''
      } 
    });
    (component as any ).handleMobileBankingErrorResponse(error);
     
    expect((component as any ).verifyMobileBankingAuthentication).toHaveBeenCalled();
    
  })



});
