import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { CountdownEvent } from 'ngx-countdown';
import { Subscription } from 'rxjs';
import { getTwoFaAuthOptions, setAccessToken, setServerState } from 'src/app/auth/auth.index';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';

@Component({
  selector: 'app-mobile-banking-info',
  templateUrl: './mobile-banking-info.component.html',
  styleUrls: ['./mobile-banking-info.component.scss']
})
export class MobileBankingInfoComponent implements OnInit {

    public timeForMobileBankingVerification!: number;
    public timeRemainingDuplicate!: string;
    public moreOptionsStatus = false;
    private httpSubsciption!: Subscription;
  counter: any;

    constructor(
        private loginService: LoginService,
        private rememberMeService: RememberMeService,
        private router: Router,
        private store: Store,
        private payloadService: PayloadService,
        private setOnboardCardService: SetOnboardCardService,
        private widgetService: WidgetService
    ) { }

    ngOnDestroy() {
        if (this.httpSubsciption) {
            this.httpSubsciption.unsubscribe();
        }
    }

    ngOnInit() {
        this.getDataFromStore();
        this.verifyMobileBankingAuthentication();
        this.timeForMobileBankingVerification = environment.mobileBankingVerificationTimer;
    }

    public defaultOnFinished(event: CountdownEvent) {
        if(event.action == 'done') {
            this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.MOB_APP_LOGIN_EXPIRED], { skipLocationChange: environment.skipURI });
        }
    }

    public CheckMoreLoginOptions() {
        this.payloadService.setMoreLoginOptionsSource('MOB_APP_LOGIN');
        this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.SECOND_FACTOR_AUTHENTICATION_OPTIONS], { skipLocationChange: environment.skipURI });
    }

    private verifyMobileBankingAuthentication() {
        const payload = this.payloadService.generatePayloadForAuth(SCREEN_ROUTING_KEYS.MOB_APP_RETRY, SCREEN_ROUTING_KEYS.MOB_APP_RETRY);
        this.httpSubsciption = this.loginService.handleLogin(payload, PATHS.authenticate).subscribe({next: (resp) => {
            //resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
            if(resp['authMethod'] === "SET_CREDENTIAL" && resp['pdfRequested'] === true){
                this.widgetService.isPWDgenOPR.next(true);  
            }
            this.handleMobileBankingSuccessResponse(resp);
        }, error: (error) => {
            this.handleMobileBankingErrorResponse(error);
        }});
    }

    private handleMobileBankingErrorResponse(error: HttpErrorResponse) {
        if (error.error && error.error.error) {
            switch (error.error.error.errorCode) {
                case 'BE0038':
                  this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.MOB_APP_LOGIN_EXPIRED], { skipLocationChange: environment.skipURI });
                    break;
                case 'BE0039':
                  this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.MOB_APP_LOGIN_REJECTED], { skipLocationChange: environment.skipURI });
                    break;
            }
        } else {
            this.verifyMobileBankingAuthentication();
        }
    }

    private handleMobileBankingSuccessResponse(resp: any) {
        (resp['accessToken']) ? this.handleAccessTokenResponse(resp) : this.handleSetCredentialOptionResponse(resp);
    }

    private handleSetCredentialOptionResponse(resp: any) {
        this.store.dispatch(setServerState({ value: resp['state'] }));
        this.router.navigateByUrl(ROUTE_KEY[resp['authMethod']], { skipLocationChange: environment.skipURI });

    }

    private handleAccessTokenResponse(resp: any) {
        if (resp['customerInfo']) {
            this.rememberMeService.handleRememberMe(resp['customerInfo']);
        }
        this.store.dispatch(setAccessToken({ value: resp['accessToken'] }))
       
       if (resp['onboarding'] === 'Y') {
            this.setOnboardCardService.checkUserOnboarded(resp['onboarding']);
        } else {
            this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.DASHBOARD], { skipLocationChange: environment.skipURI });

        }   
    }

    private getDataFromStore() {
        this.store.select(getTwoFaAuthOptions).subscribe((resp) => {
            if (resp) {
                this.moreOptionsStatus = true;
            }
        });
    }

}
