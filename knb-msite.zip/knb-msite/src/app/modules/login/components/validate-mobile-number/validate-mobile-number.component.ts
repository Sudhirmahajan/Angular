import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Form, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { InvisibleReCaptchaComponent } from 'ngx-captcha';
import { map, Observable, startWith, Subscription } from 'rxjs';
import { BIO_CATCH_CONTEXT_KEY } from 'src/app/app.constant';
import { BioCatchService, ConfigService, getCardAuthenticationOption, getCardDetailsBlockedStatus, getChannelBlockedStatus, getCredentialBlockedStatus, getFlow, getMobileNotUpdatedStatus, getRecaptcha, getServiceId, getUserId, NavigationService, setEmail, setFlow, setGUID, setIsdCode, setMobileNumber, setRecaptcha, setServerState } from 'src/app/auth/auth.index';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { environment } from 'src/environments/environment';
import { redirectToValidateMobileNo, validateMobileNoCtaname } from '../../login-analystics';
import { FLOWS, PATHS, ROUTE_KEY } from '../../login.constant';
import { IAuthSuccessResp, IOprBackOperationsRequest, IOprBackOperationsResponse, IVerifyCrnRequest, IVerifyCrnResponse, IVerifyMobileNoRequest, IVerifyMobileNoResponse } from '../../models/login.model';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { FormValidatorService } from '../../services/form-validator/form-validator.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

@Component({
  selector: 'app-validate-mobile-number',
  templateUrl: './validate-mobile-number.component.html',
  styleUrls: ['./validate-mobile-number.component.scss']
})
export class ValidateMobileNumberComponent implements OnInit, OnDestroy {

  @ViewChild('captchaElem') captchaElem!: InvisibleReCaptchaComponent;
  httpSubscription!: Subscription;
  mobileNumberForm!: FormGroup;
  gck!: string;
  showGoogleCaptcha!: boolean;
  storeFlow!: string;
  credentialBlockedStatusFromStore!: string;
  cardDetailsBlockedStatusFromStore!: string;
  channelBlockedStatusFromStore!: string;
  userIdEntered!: string;
  mobileNotUpdatedStatusFromStore!: string;
  serviceIdFromStore!: string;
  cardAuthenticationOptionFromStore!: string;
  displayBackButton!: boolean;
  ispriFix!: boolean;
  errorType: string = 'VALIDATE_MOB_NO'
  remainingAttemts: any;
  isdCodes: any;
  isdCodeArray: any[] = [];
  filteredOptions!: Observable<string[]>;
  readOnlyFlag = true;
  selectedIsdCode = '+91';
  isdCodeWithoutPrefix: string = '91';
  
  constructor(
    private formValidatorService: FormValidatorService,
    private configService: ConfigService,
    private store: Store,
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private router: Router,
    private errorBeanService: ErrorBeanService,
    private bundleLoaderInitializerService: BundleLoaderInitializerService,
    private bioCatchService: BioCatchService
  ) { }

  ngOnInit(): void {
    this.setAnalytics('');
    this.bioCatchService.biocatchSetValues('', BIO_CATCH_CONTEXT_KEY.NB_OPR_MOBILE_NUM);
    this.gck = this.configService.getGck();
    this.checkBackButtonDisplayStatus();
    this.mobileNumberForm = new FormGroup({
      mobileNo: new FormControl('', [Validators.required, Validators.maxLength(20), Validators.minLength(6), this.formValidatorService.numeric]),
    });
    this.getDataFromSTore();

    this.isdCodes = this.configService.getConfig("isdCode");
    this.mapCodes();
  }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToValidateMobileNo
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=validateMobileNoCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  
 }

  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

  public mapCodes(){
    for (const [key, value] of Object.entries(this.isdCodes)) {
      this.isdCodeArray.push({ country:key.replace(/\_/g," ") , isd_code: value, selected: value == "91" ? true : false });
    }
  }

  public setCountryCode(isd_code: string) {
    this.selectedIsdCode = '+'+isd_code;
    this.isdCodeWithoutPrefix = isd_code;
  }

  checkSelectedFlag(isd_code: string) {
    isd_code = '+'+isd_code;
    return this.selectedIsdCode == isd_code;
  }

  public handleSuccess(captchaResponse: string): void {
    if (captchaResponse) {
      this.validateMobileNumber(captchaResponse);
    }
  }

  public submitForm() {
    (this.showGoogleCaptcha) ? this.captchaElem.execute() : this.checkBlockedStatusForValidationOfMobileNUmber();
  }

  public preFixValidation(e: any){
    const val = Array.from(e.target.value);  
      this.ispriFix =val[0] === '0' || val[0] === '+' ? true : false; 
  }

  public back() {
    (this.displayBackButton) ? this.processWithBlockedJourney(true) : this.processBackWithOpr(false);
  }

  private checkBlockedStatusForValidationOfMobileNUmber() {
    if (this.credentialBlockedStatusFromStore === 'Y' && this.cardDetailsBlockedStatusFromStore === 'Y') {
      this.processWithBlockedJourney(false);
    } else if ((this.credentialBlockedStatusFromStore === 'Y' || this.channelBlockedStatusFromStore === 'Y'
      || this.mobileNotUpdatedStatusFromStore === 'Y') && this.cardAuthenticationOptionFromStore === 'credential') {
      this.processWithBlockedJourney(false);
    } else if ((this.cardDetailsBlockedStatusFromStore === 'Y' || this.channelBlockedStatusFromStore === 'Y'
      || this.mobileNotUpdatedStatusFromStore === 'Y') && this.cardAuthenticationOptionFromStore === 'cardDetails') {
      this.processWithBlockedJourney(false);
    } else {
      this.validateMobileNumber();
    }
  }

  private validateMobileNumber(captchaResp?: string) {
    (this.storeFlow) ? this.procesMobileNumberVerificationWithOpr(true, captchaResp) : this.validateMobileNumberWithLogin(captchaResp);
  }

  private procesMobileNumberVerificationWithOpr(startLoader: boolean, captchaResponse?: string) {
    if (startLoader) {
      this.loaderService.startLoader();
    }
    const inputField = { mobileNo: this.mobileNumberForm.controls['mobileNo'].value };
    let reqPayload = this.payloadService.generatePayloadForOpr(inputField);
    if (captchaResponse) {
      reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
    }
    // reqPayload = { ...reqPayload, ...{isdCode: this.isdCodeWithoutPrefix} };
    if (reqPayload as unknown as IVerifyMobileNoRequest) {
      this.httpSubscription = this.loginService.handleOprValidateMobNo(reqPayload as unknown as IVerifyMobileNoRequest, PATHS.verifyMobileNumber)
        .subscribe({ next: (resp: IVerifyMobileNoResponse) => {
          this.store.dispatch(setRecaptcha({ value: '' }))
          this.handleValidateMobileSuccessResponseWithOpr(resp);
        }, error: (error) => {
          this.loaderService.stopLoader();
          this.remainingAttemts = this.errorBeanService.handleWrongAttempts(error, this.mobileNumberForm);
          if (error.error['showRecaptcha'] === 'Y') {
            this.showGoogleCaptcha = true;
          }
        }});
    }
  }

  private validateMobileNumberWithLogin(captchaResponse?: string) {
    this.loaderService.startLoader();
    let reqPayload = this.payloadService.generatePayloadForAuth('MOBILE', (this.mobileNumberForm.controls['mobileNo'].value));
    reqPayload = { ...reqPayload, ...{ serviceId: this.serviceIdFromStore } };
    if (captchaResponse) {
      reqPayload = { ...reqPayload, ...{ gCaptchaResponse: captchaResponse } };
    }
    if (reqPayload) {
      this.httpSubscription = this.loginService.handleLogin(reqPayload, PATHS.authenticate)
        .subscribe({next: (resp: IAuthSuccessResp) => {
          this.store.dispatch(setRecaptcha({ value: '' }))
          //resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView']);
          if(resp['authMethod'] === "SET_CREDENTIAL" && resp.pdfRequested === true){
            //this.widgetService.isPWDgenOPR.next(true);  
        }
          this.handleValidateMobileSuccessResponseWithLogin(resp);
        }, error: (error) => {
          this.loaderService.stopLoader();
          this.handleWrongAttempt(error);
        }});
    }
  }
  private handleValidateMobileSuccessResponseWithLogin(resp: IAuthSuccessResp) {
    this.loaderService.stopLoader();
    this.storeData(resp['state'], resp['mobilenNumber'], resp['emailId'], resp['isdCode']);
    if (resp['showRecaptcha']) {
      this.store.dispatch(setRecaptcha({ value: resp.showRecaptcha }))
    }
    //this.routerService.navigateToView(resp['authMethod']);
  }

  handleWrongAttempt(error: any) {
    let loginIdAna= 'NA';
    if(this.userIdEntered){
      loginIdAna = this.userIdEntered;
    } else{
      loginIdAna = 'varify Mobile Number' +  loginIdAna;
    }
    this.remainingAttemts = this.errorBeanService.handleErrorScenariosInLogin(error);
    if (error.error['showRecaptcha'] === 'Y') {
      this.showGoogleCaptcha = true;
    }
    this.mobileNumberForm.reset();
  }

  private handleValidateMobileSuccessResponseWithOpr(resp: IVerifyMobileNoResponse) {
    this.loaderService.stopLoader();
    this.storeData(resp['state'], resp['prefMobileNo'], resp['prefEmailId'], resp['isdCode']);
    if (resp.showRecaptcha) {
      this.store.dispatch(setRecaptcha({ value:  resp.showRecaptcha}))
    }
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }
  
  private storeData(state: string, mobileNumber: string, email: string, isdCode: string) {
    this.store.dispatch(setServerState({ value: state }));
    this.store.dispatch(setMobileNumber({ value: mobileNumber }));
    this.store.dispatch(setEmail({ value: email }));
    this.store.dispatch(setIsdCode({ value: isdCode }));
  }

  private processWithBlockedJourney(blockedJourney: boolean): void {
    this.loaderService.startLoader();
    if (!this.storeFlow) {
      this.store.dispatch(setFlow({ value: FLOWS.unblock }))
    }
    const inputField = { loginId: this.userIdEntered };
    const reqPayload = this.payloadService.generatePayloadForOpr(inputField, true);
    if (reqPayload as IVerifyCrnRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as IVerifyCrnRequest, PATHS.verifyCrn)
        .subscribe((resp: IVerifyCrnResponse) => {
          this.handleOprSuccessResponse(resp, blockedJourney);
        });
    }
  }

  private handleOprSuccessResponse(resp: IVerifyCrnResponse, blockedJourney: boolean): void {
    this.bundleLoaderInitializerService.startWatchingIdle(true);
    this.store.dispatch(setServerState({ value: resp['state']}));
    this.store.dispatch(setGUID({value: resp['guid'] }));
    this.store.dispatch(setFlow({ value: resp['flow'] }));
    (blockedJourney) ? this.processBackWithOpr(blockedJourney) : this.procesMobileNumberVerificationWithOpr(blockedJourney);
  }

  private checkBackButtonDisplayStatus() {
    if (this.credentialBlockedStatusFromStore === 'Y' && this.cardDetailsBlockedStatusFromStore === 'Y') {
      this.displayBackButton = true;
    } else if ((this.credentialBlockedStatusFromStore === 'Y' || this.channelBlockedStatusFromStore === 'Y'
      || this.mobileNotUpdatedStatusFromStore === 'Y') && this.cardAuthenticationOptionFromStore === 'credential') {
      this.displayBackButton = true;
    } else if ((this.cardDetailsBlockedStatusFromStore === 'Y' || this.channelBlockedStatusFromStore === 'Y'
      || this.mobileNotUpdatedStatusFromStore === 'Y') && this.cardAuthenticationOptionFromStore === 'cardDetails') {
      this.displayBackButton = true;
    } else {
      this.displayBackButton = false;
    }
  }
  
  private processBackWithOpr(blockedJourney: boolean) {
    if (!blockedJourney) {
      this.loaderService.startLoader();
    }
    const reqPayload = this.payloadService.generatePayloadForOpr();
    if (reqPayload as unknown as IOprBackOperationsRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as IOprBackOperationsRequest, PATHS.oprBackOperations)
        .subscribe((resp: IOprBackOperationsResponse) => {
          this.handleBackSuccessResponse(resp);
        });
    }
  }

  private handleBackSuccessResponse(resp: IOprBackOperationsResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value: resp['state'] }));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  private getDataFromSTore() {
    this.store.select(getFlow).subscribe(value => this.storeFlow = value)
    this.store.select(getCredentialBlockedStatus).subscribe(value => this.credentialBlockedStatusFromStore = value)
    this.store.select(getCardDetailsBlockedStatus).subscribe(value => this.cardDetailsBlockedStatusFromStore = value)
    this.store.select(getChannelBlockedStatus).subscribe(value => this.channelBlockedStatusFromStore = value)
    this.store.select(getMobileNotUpdatedStatus).subscribe(value => this.mobileNotUpdatedStatusFromStore = value)
    this.store.select(getServiceId).subscribe(value => this.serviceIdFromStore = value)
    this.store.select(getCardAuthenticationOption).subscribe(value => this.cardAuthenticationOptionFromStore = value)
    this.store.select(getRecaptcha).subscribe(value => {
      if (value === 'Y') {
        this.showGoogleCaptcha = true;
      }
    })
    this.store.select(getUserId).subscribe(value => {
      const crnAndType = value.split('|');
      this.userIdEntered = crnAndType[0];
    })
  }
}
