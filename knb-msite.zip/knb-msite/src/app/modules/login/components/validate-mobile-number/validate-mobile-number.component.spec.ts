import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore } from '@ngrx/store/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { NgxCaptchaModule } from 'ngx-captcha';
import { CountdownModule } from 'ngx-countdown';
import { of, throwError } from 'rxjs';
import { AuthenticationService, AuthModule, BioCatchService, ConfigService } from 'src/app/auth/auth.module';
import { BundleLoaderInitializerService } from 'src/app/modules/shared/services/bundle-loader-initializer/bundle-loader-initializer.service';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { ErrorBeanService } from '../../services/error-bean/error-bean.service';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';

import { ValidateMobileNumberComponent } from './validate-mobile-number.component';

describe('ValidateMobileNumberComponent', () => {
  let component: ValidateMobileNumberComponent;
  let fixture: ComponentFixture<ValidateMobileNumberComponent>;
  const MockConfigService = jasmine.createSpyObj('ConfigService', ['getGck']);
  let configService: jasmine.SpyObj<ConfigService>;
  let bioCatchObj  = jasmine.createSpyObj('BioCatchService',['biocatchSetValues']);
  let bioCatchService : jasmine.SpyObj<BioCatchService>;
  let authenticationObj = jasmine.createSpyObj('AuthenticationService', ['generateRandom']);
  let authenticationService : jasmine.SpyObj<AuthenticationService>;
  let loginObj = jasmine.createSpyObj('LoginService',['handleLogin','handleOprValidateMobNo','handleOpr']);
  let loginService : jasmine.SpyObj<LoginService>;
  let loaderObj = jasmine.createSpyObj('LoaderService',['handleLoginCaptcha','stopLoader','startLoader']);
  let loaderService : jasmine.SpyObj<LoaderService>;
  let payloadObj = jasmine.createSpyObj('PayloadService',['generatePayloadForAuth','generatePayloadForOpr']);
  let payloadService : jasmine.SpyObj<PayloadService>;
  let errorBeanObj  = jasmine.createSpyObj('ErrorBeanService',['handleWrongAttempts','handleErrorScenariosInLogin']);
  let errorBeanService : jasmine.SpyObj<ErrorBeanService>;
  let bundleLoaderInitializerObj = jasmine.createSpyObj('BundleLoaderInitializerService',['changeBundleLoaderStatus','startWatchingIdle']);
  let bundleLoaderInitializerService : jasmine.SpyObj<BundleLoaderInitializerService>;
  let store: MockStore;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ValidateMobileNumberComponent ],
     imports:[RouterTestingModule,ReactiveFormsModule,
      HttpClientTestingModule,
      NoopAnimationsModule,
      AuthModule.forRoot('env'),
      SharedModule,
      RouterTestingModule,
      CountdownModule,
      NgxCaptchaModule,
      TranslateModule.forRoot()
           ],
         providers:[
          { provide: ConfigService, useValue: MockConfigService },
          { provide : AuthenticationService ,useValue : authenticationObj},
          { provide : LoginService , useValue : loginObj },
          { provide : PayloadService, useValue : payloadObj},
          { provide : LoaderService, useValue : loaderObj},
          { provide : ErrorBeanService, useValue : errorBeanObj},
          { provide : BundleLoaderInitializerService, useValue : bundleLoaderInitializerObj},
          { provide : BioCatchService, useValue : bioCatchObj},
         ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidateMobileNumberComponent);
    component = fixture.componentInstance;
    configService = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>
    authenticationService = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    errorBeanService = TestBed.inject(ErrorBeanService) as jasmine.SpyObj<ErrorBeanService>;
    bundleLoaderInitializerService = TestBed.inject(BundleLoaderInitializerService) as jasmine.SpyObj<BundleLoaderInitializerService>;
    bioCatchService = TestBed.inject(BioCatchService) as jasmine.SpyObj<BioCatchService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    router = TestBed.inject(Router);

    fixture.detectChanges();
 
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle success else Part', () => {
    let captcharesponse = '';
    spyOn((component as any ),'validateMobileNumber' )
    component.handleSuccess(captcharesponse)
    expect((component as any).validateMobileNumber).not.toHaveBeenCalled();
  });


  it('should handle success', () => {
    let captcharesponse = 'true';
    spyOn((component as any ),'validateMobileNumber' )
    component.handleSuccess(captcharesponse)
    expect((component as any).validateMobileNumber).toHaveBeenCalled();
  });
   
  it('should submitForm', () => {
    spyOn((component as any),'checkBlockedStatusForValidationOfMobileNUmber');
    component.showGoogleCaptcha=false
    component.submitForm();
    expect((component as any).checkBlockedStatusForValidationOfMobileNUmber).toHaveBeenCalled();
    
  });

  it('should Fix Validation',()=>{
    const data={
     target:{
       value:true
     }
    }
    component.preFixValidation(data)
    expect(component.ispriFix).toBe(false)

  });

  it('should call back',()=>{
   spyOn(component as any,'processWithBlockedJourney');
   component.displayBackButton=true;
   component.back();
   expect((component as any).processWithBlockedJourney).toHaveBeenCalled();

  });

  it('should validate Mobile Number',()=>{
    spyOn<any>(component,'procesMobileNumberVerificationWithOpr');
    component.storeFlow='have data';
    const captchaResp ='';
    (component as any).validateMobileNumber(captchaResp);
    expect((component as any ).procesMobileNumberVerificationWithOpr).toHaveBeenCalled();
  });


  it('should process Mobile Number Verification With Opr',()=>{

   spyOn<any>(component,'procesMobileNumberVerificationWithOpr').and.callThrough();
   spyOn<any>(component,'handleValidateMobileSuccessResponseWithOpr');

   const startLoader = true;
   const captchaResponse = 'success';
   const data = {
    showRecaptcha: 'yes',
    flow: 'demoflow',
    guid: '1234GUIDSAMPLE',
    nextScreen: 'NO',
    state: 'TRUE',
    isdCode: '123',
    prefEmailId: 'sample@gmail.com',
    prefMobileNo: '7777666676',
    rmngAtmpts: 1,
    attempt: 1,
    disableMoreOption: true,
    securityQuestionFlag: true,
   }
   loginService.handleOprValidateMobNo.and.returnValue(of(data));
   (component as any).procesMobileNumberVerificationWithOpr(startLoader,captchaResponse);
   expect((component as any ).handleValidateMobileSuccessResponseWithOpr).toHaveBeenCalled();
  });


  it('should process Mobile Number Verification With Opr throw error',()=>{

    spyOn<any>(component,'procesMobileNumberVerificationWithOpr').and.callThrough();

    const startLoader = true;
    const captchaResponse = 'success';
    const data = {
     showRecaptcha: 'yes',
     flow: 'demoflow',
     guid: '1234GUIDSAMPLE',
     nextScreen: 'NO',
     state: 'TRUE',
     isdCode: '123',
     prefEmailId: 'sample@gmail.com',
     prefMobileNo: '7777666676',
     rmngAtmpts: 1,
     attempt: 1,
     disableMoreOption: true,
     securityQuestionFlag: true,
    }
    loginService.handleOprValidateMobNo.and.returnValue(throwError({
      error:{showRecaptcha:'Y'}
    }));
    (component as any).procesMobileNumberVerificationWithOpr(startLoader,captchaResponse);
     expect(errorBeanService.handleWrongAttempts).toHaveBeenCalled();
   });

   it('should check Blocked Status For Validation Of Mobile Number ',()=>{
    
    spyOn<any>(component,'processWithBlockedJourney');
    spyOn<any>(component,'checkBlockedStatusForValidationOfMobileNUmber').and.callThrough();
    component.credentialBlockedStatusFromStore = 'Y';
    component.cardDetailsBlockedStatusFromStore  = 'Y';
       
    (component as any).checkBlockedStatusForValidationOfMobileNUmber();
    expect((component as any).processWithBlockedJourney).toHaveBeenCalled();

   });

   
   it('should check Blocked Status For Validation Of Mobile Number else IF',()=>{
    
    spyOn<any>(component,'processWithBlockedJourney');
    spyOn<any>(component,'validateMobileNumber');
    spyOn<any>(component,'checkBlockedStatusForValidationOfMobileNUmber').and.callThrough();
    component.credentialBlockedStatusFromStore = 'Y';
    component.cardAuthenticationOptionFromStore   = 'credential';
    component.channelBlockedStatusFromStore ='Y';  
   
    (component as any).checkBlockedStatusForValidationOfMobileNUmber();
    expect((component as any).processWithBlockedJourney).toHaveBeenCalled();

   });
   

   it('should check Blocked Status For Validation Of Mobile Number else IF',()=>{
    
    spyOn<any>(component,'processWithBlockedJourney');
    spyOn<any>(component,'validateMobileNumber');
    spyOn<any>(component,'checkBlockedStatusForValidationOfMobileNUmber').and.callThrough();
    component.credentialBlockedStatusFromStore = 'Y';
    component.cardAuthenticationOptionFromStore   = 'cardDetails';
    component.channelBlockedStatusFromStore ='Y';  
   
    (component as any).checkBlockedStatusForValidationOfMobileNUmber();
    expect((component as any).processWithBlockedJourney).toHaveBeenCalled();

   });

   it('should check Blocked Status For Validation Of Mobile Number else IF',()=>{
    
    spyOn<any>(component,'processWithBlockedJourney');
    spyOn<any>(component,'validateMobileNumber');
    spyOn<any>(component,'checkBlockedStatusForValidationOfMobileNUmber').and.callThrough();
   
    (component as any).checkBlockedStatusForValidationOfMobileNUmber();
    expect((component as any).validateMobileNumber).toHaveBeenCalled();

   });

  it('should validate Mobile Number With Login',()=>{
     spyOn<any>(component,'validateMobileNumberWithLogin').and.callThrough();
     spyOn<any>(component,'handleValidateMobileSuccessResponseWithLogin');
     const captchaResponse='Y';
     const data = {
      authMethod: 'SET_CREDENTIAL',
      pdfRequested: true,
      emailId: 'test@gmail.com',
      mobileNumebr: '1234567890',
      state: ''
     };

     loginService.handleLogin.and.returnValue(of(data));
    (component as any).validateMobileNumberWithLogin(captchaResponse);
    expect((component as any).handleValidateMobileSuccessResponseWithLogin).toHaveBeenCalled();

  });


  it('should validate Mobile Number With Login error Part',()=>{
    spyOn<any>(component,'validateMobileNumberWithLogin').and.callThrough();
    spyOn(component,'handleWrongAttempt');
    const captchaResponse='Y';
    const data = {
     authMethod: 'SET_CREDENTIAL',
     pdfRequested: true,
     emailId: 'test@gmail.com',
     mobileNumebr: '1234567890',
     state: ''
    };

    loginService.handleLogin.and.returnValue(throwError({
      error:{showRecaptcha:'Y'}
    }));

   (component as any).validateMobileNumberWithLogin(captchaResponse);
    expect(component.handleWrongAttempt).toHaveBeenCalled();
 });

 it('should handle Validate Mobile Success Response With Login',()=>{
    spyOn(store, 'dispatch');
    const resp = {
      pdfRequested: true,
      showRecaptcha: 'Y',
      authMethod: 'OTP',
      emailId: 'email@email.com',
      isdCode: '91',
      message: 'done Auth',
      mobilenNumber: '9987776678',
      state: 'BH',
      statusCode: 9988,
    }
  spyOn<any>(component,'handleValidateMobileSuccessResponseWithLogin').and.callThrough();
  (component as any).handleValidateMobileSuccessResponseWithLogin(resp)
  expect(store.dispatch).toHaveBeenCalled();
 });

 it('should handle Wrong Attempt ',()=>{
  const error={
    error:{
      showRecaptcha:'Y'
    }
  }
  component.handleWrongAttempt(error);
  expect(component.showGoogleCaptcha).toBe(true);
});

it('should handle Validate Mobile Success Response With Opr',()=>{

  spyOn(router,'navigateByUrl');
  spyOn<any>(component,'handleValidateMobileSuccessResponseWithOpr').and.callThrough();
  const data={
    showRecaptcha: 'yes',
    flow: 'demoflow',
    guid: '1234GUIDSAMPLE',
    nextScreen: 'NO',
    state: 'TRUE',
    isdCode: '123',
    prefEmailId: 'sample@gmail.com',
    prefMobileNo: '7777666676',
    rmngAtmpts: 1,
    attempt: 1,
    disableMoreOption: true,
    securityQuestionFlag: true,
  };
  (component as any).handleValidateMobileSuccessResponseWithOpr(data)
  expect(router.navigateByUrl).toHaveBeenCalled();

});


it('should process With Blocked Journey',()=>{
  spyOn(store, 'dispatch');
  spyOn<any>(component,'processWithBlockedJourney').and.callThrough();
  (component as any).processWithBlockedJourney(true);
  expect(store.dispatch).toHaveBeenCalled();
});

it('should handle Opr Success Response',()=>{
 spyOn<any>(component,'processBackWithOpr');
  const data={
    flow: 'demoflow',
    guid: '123UYHT&^YT%CFF$#',
    nextScreen: 'N',
    state: 'Y',
    showRecaptcha: 'Y'
  };
  spyOn<any>(component,'handleOprSuccessResponse').and.callThrough();
  (component as any).handleOprSuccessResponse(data,true);
  expect((component as any).processBackWithOpr).toHaveBeenCalled();
});

it('should process Back With Opr',()=>{

  spyOn<any>(component,'processBackWithOpr').and.callThrough();
  loginService.handleOpr.and.returnValue(of({
    flow: 'CREATE_USERNAME',
    guid: '',
    nextScreen: '',
    state: '',
    showRecaptcha: 'Y',
  }));
  
  (component as any).processBackWithOpr(false);
  expect(payloadService.generatePayloadForOpr).toHaveBeenCalled();

})

it('should handle Back Success Response',()=>{
  spyOn(router,'navigateByUrl');
  const data={
    flow: 'CREATE_USERNAME',
    guid: '',
    nextScreen: '',
    state: ''
  };
  spyOn<any>(component,'handleBackSuccessResponse').and.callThrough();
  (component as any).handleBackSuccessResponse(data);
  expect(router.navigateByUrl).toHaveBeenCalled();
})

});
