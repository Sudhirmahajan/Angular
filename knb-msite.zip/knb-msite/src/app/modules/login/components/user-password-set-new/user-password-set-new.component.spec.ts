import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { AuthModule } from 'src/app/auth/auth.module';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { SharedModule, createTranslateLoader } from 'src/app/modules/shared/shared.module';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { UserPasswordSetNewComponent } from './user-password-set-new.component';

describe('UserPasswordSetNewComponent', () => {
  let component: UserPasswordSetNewComponent;
  let fixture: ComponentFixture<UserPasswordSetNewComponent>;
  let payloadService: jasmine.SpyObj<PayloadService>;
  let loaderService: jasmine.SpyObj<LoaderService>;
  let loginService: jasmine.SpyObj<LoginService>;
  let rememberMeService : jasmine.SpyObj<RememberMeService>;
  let matDialog : jasmine.SpyObj<MatDialog>;

  const MockPayloadService = jasmine.createSpyObj('PayloadService', ['generatePayloadForOprAuth', 'generatePayloadForAuth']);
  const MockPayLoaderService = jasmine.createSpyObj('LoaderService', ['startLoader', 'stopLoader']);
  const MockPayLoginService = jasmine.createSpyObj('LoginService', ['handleLogin', 'handleOpr']);
  const MockRememberMeService = jasmine.createSpyObj('RememberMeService', ['handleRememberMe']);
  const MockMatDialog = jasmine.createSpyObj('MatDialog', ['open']);


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NoopAnimationsModule,
        AuthModule.forRoot('env'),
        RouterTestingModule,
        SharedModule,
        TranslateModule.forRoot(
          {
            loader: {
              provide: TranslateLoader,
              useFactory: (createTranslateLoader),
              deps: [HttpClient]
            },
            isolate: true,
            defaultLanguage: 'en'
          }
        )
      ],
      declarations: [ UserPasswordSetNewComponent ],
      providers: [
        { provide: PayloadService, useValue: MockPayloadService },
        { provide: LoaderService, useValue: MockPayLoaderService },
        { provide: LoginService, useValue: MockPayLoginService },
        { provide : RememberMeService, useValue : MockRememberMeService},
        { provide: MatDialog, useValue: MockMatDialog },
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPasswordSetNewComponent);
    payloadService = TestBed.inject(PayloadService) as jasmine.SpyObj<PayloadService>;
    loaderService = TestBed.inject(LoaderService) as jasmine.SpyObj<LoaderService>;
    loginService = TestBed.inject(LoginService) as jasmine.SpyObj<LoginService>;
    rememberMeService = TestBed.inject(RememberMeService) as jasmine.SpyObj<RememberMeService>;
    matDialog = TestBed.inject<any>(MatDialog) as jasmine.SpyObj<MatDialog>;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call setCredential when flow is OPR', () => {
    component.storeFlow = 'OPR';
    spyOn<any>(component, 'setCredentialWithOpr');
    spyOn<any>(component, 'setCredentialWithLogin');
    component.setCredential();
    expect(component['setCredentialWithOpr']).toHaveBeenCalled()
  })

  it('should call setCredential when flow is Login', () => {
    component.storeFlow = '';
    spyOn<any>(component, 'setCredentialWithOpr');
    spyOn<any>(component, 'setCredentialWithLogin');
    component.setCredential();
    expect(component['setCredentialWithLogin']).toHaveBeenCalled()
  })

  it('should call showValidationList', () => {
    component.showValidationList();
    expect(component.showValidationListFlag).toBe(true);
  })

  it('should call confirmRedirection', () => {
    const event = new MouseEvent('click'); 
    spyOn(event, 'preventDefault');
    spyOn(component, 'useExistingCredential');

    matDialog.open.and.returnValue(<any>{ afterClosed: () => of(true) });
    component.confirmRedirection(event);

    expect(component.useExistingCredential).toHaveBeenCalled();
  })

  it('should call useExistingCredential when api success', () => {
    const payload = payloadService.generatePayloadForOprAuth.and.returnValue({
      client_id: 'GHgthjkG',
      flow: 'TEST_FLOW',
      guid: 'fghj-fghH-erty-fghj',
      oprState: '',
    })
    loginService.handleOpr.and.returnValue(of({
      flow: 'TEST_FLOW',
      guid: 'fghj-fghH-erty-fghj',
      nextScreen: 'TEST_SCREEN',
      state: '',
    }))
    component.useExistingCredential();
    loginService.handleOpr(payload, '/testUrl').subscribe({ next: ()=> {
      expect(loaderService.stopLoader).toHaveBeenCalled();
    }})
    expect(loaderService.startLoader).toHaveBeenCalled();
    expect(payloadService.generatePayloadForOprAuth).toHaveBeenCalled();
  })

  it('should call useExistingCredential when api success', () => {
    const payload = payloadService.generatePayloadForOprAuth.and.returnValue({
      client_id: 'GHgthjkG',
      flow: 'TEST_FLOW',
      guid: 'fghj-fghH-erty-fghj',
      oprState: '',
    })
    loginService.handleOpr.and.returnValue(throwError(() => 'error'))
    component.useExistingCredential();
    expect(loaderService.startLoader).toHaveBeenCalled();
    expect(payloadService.generatePayloadForOprAuth).toHaveBeenCalled();
  })

  it('should check replaceNewCredential', ()=> {
    const event = new MouseEvent('click');
    spyOn(component, "removeBrowserPopUp").and.returnValue({
      maskedValue: 'test@1234',
      enteredValue: 'test@1234'
    })
    spyOn(component, "credentialStrengthValidator")
    spyOn(component, "mustMatchCredentials")
    spyOn(document, "querySelector").and.callThrough();
    component.replaceNewCredential(event);

    expect(component.credentialStrengthValidator).toHaveBeenCalled();
    expect(component.credentialStrengthValidator).toHaveBeenCalled();
    expect(component.removeBrowserPopUp).toHaveBeenCalled();
  })

  it('should test credentialStrengthValidator', () => {
    component['enteredNewCredential'] = 'test@12345';
    component.credentialStrengthValidator();
    expect(component.isPasswordCorrect).toBe(true);
    expect(component.specialCharFlag).toBe(true);
  })

  it('should test credentialStrengthValidator when password is null', () => {
    component['enteredNewCredential'] = '';
    component.credentialStrengthValidator();
    expect(component.minLenFlag).toBe(false);
    expect(component.maxLenFlag).toBe(false);
  })

  it('should test mustMatchCredentials', () => {
    component['enteredNewCredential'] = 'test@12345';
    component['enteredConfirmCredential'] = 'test@12345';

    component.mustMatchCredentials();

    expect(component.checkConfirmPassLenFlag).toBe(true);
    expect(component.credentailMatchFlag).toBe(true);
  })

  it('should call ShowHidePass when field is set to show', () => {
    component['confirmshowHideIcon'] = 'Show';
    component.ShowHidePass();
    expect(component.confirmshowHideIcon).toEqual('Hide');
  })

  it('should call ShowHidePass when field is set to Hide', () => {
    component['confirmshowHideIcon'] = 'Hide';
    component.ShowHidePass();
    expect(component.confirmshowHideIcon).toEqual('Show');
  })

  it('should call removeBrowserPopUp when entered value length is 1', () => {
    const event = {
      target: {
        value: 't',
      }
    }
    const inputFormControl = component.setPasswordForm.controls['newPassword'];
    const input = By.css('#newPassword');
    component.removeBrowserPopUp(event, inputFormControl, input, '1', 'test@123', 'Show');
    expect(component['enteredValue']).toEqual('t');
  });

  it('should call removeBrowserPopUp when entered value length is greater than old value', () => {
    const event = {
      target: {
        value: 'test@1234',
      }
    }
    const inputFormControl = component.setPasswordForm.controls['newPassword'];
    const input = By.css('#newPassword');
    component.removeBrowserPopUp(event, inputFormControl, input, '1', 'test@123', 'Show');
    expect(component['enteredValue']).toEqual('test@1234');
  })

  it('should call removeBrowserPopUp when entered value length is less than old value', () => {
    const event = {
      target: {
        value: 'test@123',
      }
    }
    const inputFormControl = component.setPasswordForm.controls['newPassword'];
    const input = By.css('#newPassword');
    component['maskedValue'] = '•••••';
    component.removeBrowserPopUp(event, inputFormControl, input, '5', 'test@1234', 'Show');
    expect(component['enteredValue']).toEqual('test1234');
  })

  it('should call removeBrowserPopUp when entered value length is less than old value and cursor position is same as entered value position', () => {
    const event = {
      target: {
        value: 'test@123',
      }
    }
    const inputFormControl = component.setPasswordForm.controls['newPassword'];
    const input = By.css('#newPassword');
    component['maskedValue'] = '••••••••';
    component.removeBrowserPopUp(event, inputFormControl, input, '8', 'test@123', 'Show');
    expect(component['enteredValue']).toEqual('test@12');
  })

  it('should call setCaretPosition when selection range is set', () => {
    let ctrl = {
      createTextRange: function() {
        return {
          collapse: function(flag: boolean) {},
          moveEnd: function(character: boolean, pos: number) {},
          moveStart: function(character: boolean, pos: number) {},
          select: function() {}
        }
      }
    };
    (component as any).setCaretPosition(ctrl, 1);
  })

  it('should call setCaretPosition when selection range is set', () => {
    let ctrl = {
      setSelectionRange: function(pos: number, pos1: number) {},
      focus: function() {}, 
    };

    (component as any).setCaretPosition(ctrl, 1);
  })

  it('should call replaceConfirmCredential', () => {
    const event = new MouseEvent('click'); 
    spyOn(event, 'preventDefault');
    spyOn(component, 'mustMatchCredentials');
    spyOn(component, 'removeBrowserPopUp').and.returnValue({
      enteredValue: 'test@123',
      maskedValue: '•••••••'
    });
    component.replaceConfirmCredential(event);
  })

  it('should call validatePattern', () => {
    component.minLenFlag = true;
    component.maxLenFlag = true;
    component.isSpaceFlag = false;
    component.specialCharFlag = true;
    const returnvalue = component.validatePattern();
    expect(returnvalue).toBe(true);
  })

  it('should call setCredentialWithLogin when API success', () => {
    const payload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: 'fdhgjDFGHjFGHJNKihj',
      state: '',
      authMethod: 'SET_CREDENTIAL',
      guid: 'ghjk-jnbb-njkk-njkj',
      credential: 'ghkjjhDEFCVewrdefgbnmjkVHGCTSRstyhjnmydtyughyufghjeRTYHcvg',
      rememberMeFlag: 'Y'
    });
    loginService.handleLogin.and.returnValue(of({
      accessToken: 'dfghJKLKOGHJKLfghjnkml',
      onboarding: 'Y',
      customerInfo: {
          encryptedcrn: 'rtdyfghnjmDFGVHBJNUYRDF%RTYBUNMJK',
          maskcrn: 'erfghbjnhdrewdefghjkllmjhvrewedf567',
          nickname: 'test',
          image: '',
          initials: 'AB'
      }
    }));
    spyOn((component as any), 'credentialUpdatedWithLogin').and.callThrough();
    (component as any).setCredentialWithLogin();
    loginService.handleLogin(<any>payload, '/test').subscribe({ next: response => {
      expect(component['credentialUpdatedWithLogin']).toHaveBeenCalled();
    } })
  });

  xit('should call setCredentialWithLogin when API throws error', () => {
    const payload = payloadService.generatePayloadForAuth.and.returnValue({
      client_id: 'fdhgjDFGHjFGHJNKihj',
      state: '',
      authMethod: 'SET_CREDENTIAL',
      guid: 'ghjk-jnbb-njkk-njkj',
      credential: 'ghkjjhDEFCVewrdefgbnmjkVHGCTSRstyhjnmydtyughyufghjeRTYHcvg',
      rememberMeFlag: 'Y'
    });
    loginService.handleLogin.and.returnValue(throwError(() => {
      return {
        
      }
    }));
    spyOn((component as any), 'credentialUpdatedWithLogin').and.callThrough();
    (component as any).setCredentialWithLogin();
    loginService.handleLogin(<any>payload, '/test').subscribe({ next: response => {
      expect(component['credentialUpdatedWithLogin']).toHaveBeenCalled();
    } })
  })
});

