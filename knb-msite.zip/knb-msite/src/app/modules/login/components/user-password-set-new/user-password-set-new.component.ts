import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { getFlow, setAccessToken, setServerState } from 'src/app/auth/auth.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';
import { WidgetService } from 'src/app/modules/shared/services/widget/widget.service';
import { environment } from 'src/environments/environment';
import { redirectToUserPasswordSet, userPasswordSetCtaname } from '../../login-analystics';
import { checkPasswordValidation, chekSpecialChar, credentialRegex, PATHS, ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { IAccessTokenAndCustomerInfoResp, IAccessTokenAndOnboardingResp, IExistingCredentialRequest, IExistingCredentialResponse, ISetCredentialRequest, ISetCredentialResponse } from '../../models/login.model';
import { LoginService } from '../../services/login/login.service';
import { PayloadService } from '../../services/payload/payload.service';
import { RememberMeService } from '../../services/remember-me/remember-me.service';
import { ExistingPasswordDialogComponent } from '../../utils/existing-password-dialog/existing-password-dialog.component';

@Component({
  selector: 'app-user-password-set-new',
  templateUrl: './user-password-set-new.component.html',
  styleUrls: ['./user-password-set-new.component.scss']
})
export class UserPasswordSetNewComponent implements OnInit {
  public setPasswordForm!: FormGroup;
  public credentailMatchFlag = false;
  public minLenFlag = false;
  public maxLenFlag = false;
  public specialCharFlag = false;
  public isSpaceFlag = false;
  public showValidationListFlag = false;
  public checkNewPassLenFlag = false;
  public checkConfirmPassLenFlag = false;
  public passwordMatchValidation = false;
  public confirmshowHideIcon = 'Show';
  public storeFlow!: string;
  public isNicknameSame= false;
  public showCredentialPolicyError!: boolean;
  private httpSubscription!: Subscription;
  private enteredNewCredential!: string;
  private enteredConfirmCredential!: string;
  private maskedConfirmCredential!: string;
  private cursorPosition!: number | null;
  checkSpecialCharacter!: boolean;
  private maskedValue!: string;
  private enteredValue!: string;
  private objectToReturn = {
      maskedValue: '',
      enteredValue: ''
  };
  public isPWDsetOPr: boolean=false;
  isPasswordCorrect: boolean = false;
  checkPasswordCorrect!: RegExpMatchArray | null;
  hide: boolean = true;
  errorType: string = 'SET-PASSWORD'

  constructor(private store: Store,
    private widgetService: WidgetService,
    private loaderService: LoaderService,
    private payloadService: PayloadService,
    private loginService: LoginService,
    private rememberMeService: RememberMeService,
    private router: Router,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.setAnalytics('');
    this.setPasswordForm = new FormGroup({
      newPassword: new FormControl ('', [Validators.required, Validators.minLength(8), Validators.maxLength(60)]),
      confirmPassword: new FormControl ('', [Validators.required, Validators.minLength(8), Validators.maxLength(60)])
    });

    this.widgetService.isPWDgenOPR.subscribe(res=>{
      this.isPWDsetOPr = res;
    }) 
    this.getDataFromStore();
   }

  setAnalytics(ctaname:any) {
    if(ctaname===''){
      window.digitalData=redirectToUserPasswordSet
      window._satellite?.track("NB-Msiteload");
    }else{
      window.digitalData=userPasswordSetCtaname(ctaname)
      window._satellite?.track("NB-Msiteclick");
    }
  }
 
  ngOnDestroy() {
    if (this.httpSubscription) {
      this.httpSubscription.unsubscribe();
    }
  }

  public setCredential() {
    (this.storeFlow) ? this.setCredentialWithOpr() : this.setCredentialWithLogin();
  }

  public showValidationList() {
      this.showValidationListFlag = true;  
  }

  public confirmRedirection(event: Event) {
    event.preventDefault();
    const dialogRef = this.dialog.open(ExistingPasswordDialogComponent, {
      data: { flag: false },
      width: '400px',
    });

    dialogRef.afterClosed().subscribe(flag => {
      if(flag) {
        this.useExistingCredential();
      }
    });
  }

  public useExistingCredential() {
    this.setPasswordForm.reset();
    this.loaderService.startLoader();
    const reqPayload = this.payloadService.generatePayloadForOprAuth();
    this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as IExistingCredentialRequest, PATHS.unlockOldCredential)
      .subscribe({ next: (resp: IExistingCredentialResponse) => {
        this.loaderService.stopLoader();
        this.store.dispatch(setServerState({ value: resp['state'] }));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
      }, error: () => {

       }});
  }

  public replaceNewCredential(event: any) {
    const input: HTMLElement | null = document.querySelector('#newPassword');
    input && input.addEventListener('keyup', e => {
      let target = event.target as HTMLInputElement;
      this.cursorPosition = target && target['selectionStart'];
    });
    
   const returnedValue= this.removeBrowserPopUpPass(event, this.setPasswordForm.controls['newPassword'], input,
    this.cursorPosition,this.enteredNewCredential,'Show');
    this.enteredNewCredential = returnedValue.enteredValue;
    this.credentialStrengthValidator();
    this.mustMatchCredentials();
  }

  public credentialStrengthValidator() {
    if (this.enteredNewCredential) {
      this.checkNewPassLenFlag = (this.enteredNewCredential.length > 0) ? true : false;
      this.minLenFlag = (this.enteredNewCredential.length >= 8) ? true : false;
      this.maxLenFlag = (this.enteredNewCredential.length > 60) ? false : true;
      this.specialCharFlag = (credentialRegex.test(this.enteredNewCredential)) ? true : false;
      this.checkSpecialCharacter = (chekSpecialChar.test(this.enteredNewCredential)) ? true : false;
      this.checkPasswordCorrect = this.enteredNewCredential.match(checkPasswordValidation);
      if(this.checkPasswordCorrect!== null) {
        this.isPasswordCorrect = true;
      } else {
        this.isPasswordCorrect = false;
      }
   
      if(!this.checkSpecialCharacter && this.specialCharFlag && this.isPasswordCorrect) {
        this.specialCharFlag = true;
      } else {
        this.specialCharFlag = false;
      }
      
      this.isSpaceFlag = (this.enteredNewCredential.indexOf(' ') !== -1) ? true : false;
    } else {
      this.checkNewPassLenFlag = false;
      this.minLenFlag = false;
      this.maxLenFlag = false;
      this.specialCharFlag = false;
      this.isSpaceFlag = false;
    }
  }

  public mustMatchCredentials() {
    if (this.enteredNewCredential && this.enteredConfirmCredential) {
      this.checkConfirmPassLenFlag = (this.enteredConfirmCredential.length > 0) ? true : false;
      if (this.enteredConfirmCredential.length > 0 && this.enteredNewCredential.length > 0) {
        this.credentailMatchFlag = (this.enteredNewCredential !== this.enteredConfirmCredential) ? false : true;
      }
    }
  }

  public ShowHidePass() {
    if (this.confirmshowHideIcon === 'Show') {
      this.confirmshowHideIcon = 'Hide';
      this.setPasswordForm.controls['confirmPassword'].setValue(this.enteredConfirmCredential);
    } else {
      this.confirmshowHideIcon = 'Show';
      this.setPasswordForm.controls['confirmPassword'].setValue(this.maskedConfirmCredential);
    }
  }


  public removeBrowserPopUpPass(event: any, inputFormControl: any, input: any, cursorPosition: any, oldvalue: any, showHideIcon?: any) {
    this.enteredValue = oldvalue;
    
    if (event.target.value && event.target.value.substring(event.target.value.length - 1) !== '•') {

    if(this.enteredValue){
    }
        if (event.target.value.length === 1) {
            this.maskedValue = '•';
            this.enteredValue = event.target.value;
            if (showHideIcon === 'Show') {
              //  inputFormControl.setValue(this.maskedValue);
            }
        } else if (event.target.value.length > this.enteredValue.length) {
            this.maskedValue = this.maskedValue + '•';
            if (showHideIcon === 'Show') {
                this.enteredValue = this.enteredValue + event.target.value.substring(event.target.value.length - 1);
               // inputFormControl.setValue(this.maskedValue);
            } else {
                this.enteredValue = event.target.value
            }
        } else {

            if (cursorPosition === this.enteredValue.length) {
                this.enteredValue = this.enteredValue.substring(0, this.enteredValue.length - 1);
                this.maskedValue = this.maskedValue.substring(0, this.maskedValue.length - 1);
            } else {
                this.enteredValue = this.enteredValue.slice(0, cursorPosition - 1) + this.enteredValue.slice(cursorPosition);
                this.maskedValue = this.maskedValue.slice(0, cursorPosition - 1) + this.maskedValue.slice(cursorPosition);
            }
        }
    } else if (event.target.value.indexOf('•') !== -1 && event.target.value.length > this.enteredValue.length) {
        let splittedString = event.target.value.split('');
        let enteredCharacter = splittedString.find((data: string) => {
            return data !== '•';
        });
        let enteredIndex = splittedString.findIndex((data: string) => {
            return data !== '•';
        });
        this.enteredValue = this.enteredValue.slice(0, enteredIndex) + enteredCharacter + this.enteredValue.slice(enteredIndex);
        this.maskedValue = this.maskedValue.slice(0, enteredIndex) + '•' + this.maskedValue.slice(enteredIndex);
        if (showHideIcon === 'Show') {
           // inputFormControl.setValue(this.maskedValue);
            this.setCaretPosition(input, enteredIndex + 1)
        }
    } else {
        if (cursorPosition === this.enteredValue.length) {
            this.enteredValue = this.enteredValue.substring(0, this.enteredValue.length - 1);
            this.maskedValue = this.maskedValue.substring(0, this.maskedValue.length - 1);
        } else if (inputFormControl.value.length === 0) {
            this.maskedValue = '';
            this.enteredValue = '';
        } else {
            this.enteredValue = this.enteredValue.slice(0, cursorPosition - 1) + this.enteredValue.slice(cursorPosition);
            this.maskedValue = this.maskedValue.slice(0, cursorPosition - 1) + this.maskedValue.slice(cursorPosition);
        }
    }
    this.objectToReturn = {
      enteredValue: this.enteredValue,
      maskedValue: this.maskedValue
    }
    return this.objectToReturn;
  }




  public removeBrowserPopUp(event: any, inputFormControl: any, input: any, cursorPosition: any, oldvalue: any, showHideIcon?: any) {
    this.enteredValue = oldvalue;
    
    if (event.target.value && event.target.value.substring(event.target.value.length - 1) !== '•') {

    if(this.enteredValue){
    }
        if (event.target.value.length === 1) {
            this.maskedValue = '•';
            this.enteredValue = event.target.value;
            if (showHideIcon === 'Show') {
                inputFormControl.setValue(this.maskedValue);
            }
        } else if (event.target.value.length > this.enteredValue.length) {
            this.maskedValue = this.maskedValue + '•';
            if (showHideIcon === 'Show') {
                this.enteredValue = this.enteredValue + event.target.value.substring(event.target.value.length - 1);
                inputFormControl.setValue(this.maskedValue);
            } else {
                this.enteredValue = event.target.value
            }
        } else {

            if (cursorPosition === this.enteredValue.length) {
                this.enteredValue = this.enteredValue.substring(0, this.enteredValue.length - 1);
                this.maskedValue = this.maskedValue.substring(0, this.maskedValue.length - 1);
            } else {
                this.enteredValue = this.enteredValue.slice(0, cursorPosition - 1) + this.enteredValue.slice(cursorPosition);
                this.maskedValue = this.maskedValue.slice(0, cursorPosition - 1) + this.maskedValue.slice(cursorPosition);
            }
        }
    } else if (event.target.value.indexOf('•') !== -1 && event.target.value.length > this.enteredValue.length) {
        let splittedString = event.target.value.split('');
        let enteredCharacter = splittedString.find((data: string) => {
            return data !== '•';
        });
        let enteredIndex = splittedString.findIndex((data: string) => {
            return data !== '•';
        });
        this.enteredValue = this.enteredValue.slice(0, enteredIndex) + enteredCharacter + this.enteredValue.slice(enteredIndex);
        this.maskedValue = this.maskedValue.slice(0, enteredIndex) + '•' + this.maskedValue.slice(enteredIndex);
        if (showHideIcon === 'Show') {
            inputFormControl.setValue(this.maskedValue);
            this.setCaretPosition(input, enteredIndex + 1)
        }
    } else {
        if (cursorPosition === this.enteredValue.length) {
            this.enteredValue = this.enteredValue.substring(0, this.enteredValue.length - 1);
            this.maskedValue = this.maskedValue.substring(0, this.maskedValue.length - 1);
        } else if (inputFormControl.value.length === 0) {
            this.maskedValue = '';
            this.enteredValue = '';
        } else {
            this.enteredValue = this.enteredValue.slice(0, cursorPosition - 1) + this.enteredValue.slice(cursorPosition);
            this.maskedValue = this.maskedValue.slice(0, cursorPosition - 1) + this.maskedValue.slice(cursorPosition);
        }
    }
    this.objectToReturn = {
      enteredValue: this.enteredValue,
      maskedValue: this.maskedValue
    }
    return this.objectToReturn;
  }
  private setCaretPosition(ctrl: any, pos: any) {
    // Modern browsers
    if (ctrl.setSelectionRange) {
        ctrl.focus();
        ctrl.setSelectionRange(pos, pos);
        // IE8 and below
    } else if (ctrl.createTextRange) {
        const range = ctrl.createTextRange();
        range.collapse(true);
        range.moveEnd('character', pos);
        range.moveStart('character', pos);
        range.select();
    }
  }

  public replaceConfirmCredential(event: any) {
    const input: HTMLElement | null = document.querySelector('#confirmPassword');
    input && input.addEventListener('keyup', e => {
      let target = event.target as HTMLInputElement;
      this.cursorPosition = target && target['selectionStart'];
    });
      const returnedValue= this.removeBrowserPopUp(event, this.setPasswordForm.controls['confirmPassword'],
      input, this.cursorPosition,this.enteredConfirmCredential, this.confirmshowHideIcon);
    this.enteredConfirmCredential = returnedValue.enteredValue;
    this.maskedConfirmCredential = returnedValue.maskedValue;
    this.passwordMatchValidation = true;
    this.showValidationListFlag = false;
    this.mustMatchCredentials();
  }

  validatePattern() {
    return (this.minLenFlag && this.maxLenFlag && !this.isSpaceFlag && this.specialCharFlag)
  }

  private setCredentialWithLogin() {
    this.loaderService.startLoader();
    const reqPayload = this.payloadService.
      generatePayloadForAuth(SCREEN_ROUTING_KEYS.SET_CREDENTIAL, this.enteredConfirmCredential);
    if (reqPayload) {
      this.httpSubscription = this.loginService.handleLogin(reqPayload, PATHS.authenticate)
        .subscribe({ next: (resp: (IAccessTokenAndCustomerInfoResp | IAccessTokenAndOnboardingResp)) => {
          if (!resp['error']) {
            //resp['prefView'] && this.isLoginNb1Service.checkIsNbOne(resp['prefView'])
            this.credentialUpdatedWithLogin(resp);
          }
        }, error: (err) => {
          if (err.error.error.errorCode === 'BE0048') {
            this.isNicknameSame =true;
            this.showCredentialPolicyError = false;
          }
         else if (err.error.errorCode === 'BE0045') {
            this.showCredentialPolicyError = true;
          }
          else if (err.error.errorCode === 'BE0046') {
            this.showCredentialPolicyError= true;
            this.isNicknameSame =false;
          }
          this.setPasswordForm.reset();
          this.resetEnteredAndMaskedCredential();
        }});
    }
  }

  private credentialUpdatedWithLogin(resp: any) {
    this.loaderService.stopLoader();
    this.store.dispatch(setAccessToken({value: resp['accessToken']}));
    if (resp['customerInfo']) {
      this.rememberMeService.handleRememberMe(resp['customerInfo']);
    }
    // (resp['onboarding'] === 'Y') ? this.routerService.navigateToView(screenRoutingKeys.ONBOARDING) :
    //   this.routerService.navigateToView(screenRoutingKeys.DASHBOARD);
  }

  private resetEnteredAndMaskedCredential() {
    this.enteredConfirmCredential = '';
    this.maskedConfirmCredential = '';
    this.enteredNewCredential = '';
    this.passwordMatchValidation = false;
    this.setPasswordForm.reset();
  }

  private setCredentialWithOpr() {
    this.loaderService.startLoader();
    const inputField = { credential: this.enteredConfirmCredential };
    let reqPayload = this.payloadService.generatePayloadForOprAuth(inputField);
    const additionalPayloadForTrustedDevice = {
      deviceOS: window['jscd']['os'],
      browser: window['jscd']['browser']
    };
    reqPayload = { ...reqPayload, ...additionalPayloadForTrustedDevice };
    if (reqPayload as unknown as ISetCredentialRequest) {
      this.httpSubscription = this.loginService.handleOpr(reqPayload as unknown as ISetCredentialRequest, PATHS.setCredential)
        .subscribe({ next: (resp: ISetCredentialResponse) => {
          this.credentialUpdatedWithOpr(resp);
        }, error: (error) => {      
          if (error.error.error.errorCode === 'BE0048') {
            this.isNicknameSame =true;
            this.showCredentialPolicyError = false;
          }
         else if (error.error.error.errorCode === 'BE0045') {
            this.showCredentialPolicyError = true;
          }
          this.setPasswordForm.reset();
          this.resetEnteredAndMaskedCredential();
        }});
    }
  }

  private credentialUpdatedWithOpr(resp: ISetCredentialResponse) {
    this.loaderService.stopLoader();
    this.store.dispatch(setServerState({ value: resp['state'] }));
    this.router.navigateByUrl(ROUTE_KEY[resp['nextScreen']], { skipLocationChange: environment.skipURI });
  }

  getDataFromStore() {
    this.store.select(getFlow).subscribe((resp) => {
       this.storeFlow = resp;
        if(resp=='FORCE_FORGET_PASSWORD_PAGE' || resp=='NET_BANKING_REGISTER' ){
         this.isPWDsetOPr=false
       }
    
    });
  }
}
