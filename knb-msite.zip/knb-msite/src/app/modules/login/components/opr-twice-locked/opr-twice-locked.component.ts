import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ROUTE_KEY, SCREEN_ROUTING_KEYS } from '../../login.constant';

@Component({
  selector: 'app-opr-twice-locked',
  templateUrl: './opr-twice-locked.component.html',
  styleUrls: ['./opr-twice-locked.component.scss']
})
export class OprTwiceLockedComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  public navigate() {
    this.router.navigateByUrl(ROUTE_KEY[SCREEN_ROUTING_KEYS.SET_CREDENTIAL], { skipLocationChange: environment.skipURI });
  }

}
