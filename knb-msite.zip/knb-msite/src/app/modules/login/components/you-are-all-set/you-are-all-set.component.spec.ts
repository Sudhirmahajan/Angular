import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YouAreAllSetComponent } from './you-are-all-set.component';

describe('YouAreAllSetComponent', () => {
  let component: YouAreAllSetComponent;
  let fixture: ComponentFixture<YouAreAllSetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YouAreAllSetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YouAreAllSetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
