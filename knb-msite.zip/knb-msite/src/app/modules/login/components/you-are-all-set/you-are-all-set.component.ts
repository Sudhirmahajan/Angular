import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { NavigationService } from 'src/app/auth/auth.index';
import { OnboardingService } from 'src/app/modules/onboarding/services/onboarding/onboarding.service';
import { SetOnboardCardService } from 'src/app/modules/shared/services/set-onboard-card/set-onboard-card.service';
import { PATHS, SCREEN_ROUTING_KEYS } from '../../login.constant';
import { LoginService } from '../../services/login/login.service';

@Component({
  selector: 'app-you-are-all-set',
  templateUrl: './you-are-all-set.component.html',
  styleUrls: ['./you-are-all-set.component.scss']
})
export class YouAreAllSetComponent implements OnInit {

  public cardData: any;
  public mandateryFlag!: any;
  cardID: any;
  completedC: any;
  httpSubscription!: Subscription;
  isComplete: any;


  constructor(
    private navigation: NavigationService,
    private loginService: LoginService,
    private onboardingService: OnboardingService,
    private cardService:SetOnboardCardService,
  ) {  }

  ngOnInit(): void {
    this.onboardingService.cardDataObj.subscribe((response) => {
      this.cardData = response;
      this.mandateryFlag = this.cardData.mandatoryFlag;
    });
    
  }
 

  navigate(){
    this.cardID = this.cardData.cardId;
    const responseObj = { cardId: this.cardID, cardName: this.cardData.cardName };
    this.completedC = this.cardData.completedCard;
    const reqPayload = this.onboardingService.generatePayLoadForInfoPageOnBoarding(responseObj);
    if (reqPayload) {
      this.httpSubscription = this.onboardingService.handleOnboarding(reqPayload, PATHS.onboarding)
      .subscribe({ next: (cardResp: any) => {    
        cardResp['completedCard'] = this.completedC + 1;
        this.onboardingService.setOnboardingCardDetails(cardResp);
        this.isComplete = cardResp['isCompleted'];
        const cardFlag = this.cardService.checkCardName(cardResp.cardName);
        if (!cardFlag) {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else  if (this.isComplete === 'Y') {
          this.cardService.navigateToView(SCREEN_ROUTING_KEYS.DASHBOARD);
        } else if(cardFlag) {
          this.cardService.navigateToView(cardResp.cardName);
        }
     }, error: (err: any) => {
   }});

  }
 }
}
