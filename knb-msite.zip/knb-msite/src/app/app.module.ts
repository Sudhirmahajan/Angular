import { APP_INITIALIZER, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { HttpClientModule } from '@angular/common/http';
import { AuthModule } from './auth/auth.module';
import { ModuleLoadingIndicatorComponent } from './components/module-loading-indicator/module-loading-indicator.component';
import { ConfigService, NavigationService } from './auth/auth.index';
import { APP_BASE_HREF } from '@angular/common';
import { SharedModule } from './modules/shared/shared.module';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ServiceWorkerModule } from '@angular/service-worker';
import { InlineStylesCSPModule } from './inline-styles-csp.module';

@NgModule({
  declarations: [
    AppComponent,
    ModuleLoadingIndicatorComponent,
  ],
  imports: [
    HttpClientModule,
    AppRoutingModule,
    SharedModule,
    NgIdleKeepaliveModule.forRoot(),
    AuthModule.forRoot(environment),
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      registrationStrategy: 'registerWhenStable:30000'
    }),
    BrowserAnimationsModule,
    InlineStylesCSPModule
  ],
  providers: [
  {
    provide: APP_INITIALIZER,
    useFactory: (config: ConfigService) => (): Promise<any> => config.load(),
    deps: [ConfigService],
    multi: true
  },
  {
    provide: APP_BASE_HREF,
    useValue: '/'
  }],
  bootstrap: [AppComponent]
})
export class AppModule {
    constructor(private navigation: NavigationService) {
      navigation.startSaveHistory();
    }
 }
