import { tick } from '@angular/core/testing';
import { PreloadingStrategy, Route, Routes } from '@angular/router';
import { timer } from 'rxjs/internal/observable/timer';
import { mergeMap } from 'rxjs/operators';
import { AppPreloadingStrategy } from './app-preloading-strategy';

describe('AppPreloadingStrategy', () => {
    let appPreloadingStrategy: AppPreloadingStrategy;
    beforeEach(() => {
        appPreloadingStrategy = new AppPreloadingStrategy();
    });

    it('should preload called', () => {
        const route: Route = { path: 'contacts', component: AppPreloadingStrategy }
        const load = () => {
        };
        appPreloadingStrategy.preload(route, load);
        expect(appPreloadingStrategy.preload(route, load)).toBeTruthy();
    });

    it('shouild loadRoute called', () => {
        const route: Route = {
            data: {
                preload: true
            }
        };
        expect(route.data).toBeDefined();
        // expect(route.data['preload']).toBeTruthy();
        const load = () => void {};
        const loadRoute = (delay: any) => delay ? timer(150).pipe(mergeMap(async (_) => load())) : load();
        appPreloadingStrategy.preload(route, load);
        expect(loadRoute(true)).toBeTruthy();
    });
});

function setup() {
    const builder = {
        default() {
            return builder;
        },
        build() {
            return new AppPreloadingStrategy();
        }
    };
    return builder;
}
