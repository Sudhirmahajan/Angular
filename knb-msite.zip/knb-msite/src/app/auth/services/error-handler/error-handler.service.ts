import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { getAccessToken, resetStore } from '../../auth.index';
import { ConfigService } from '../config/config.service';
import { DataEmitterService } from '../data-emitter/data-emitter.service';

@Injectable({
    providedIn: 'root'
})

export class ErrorHandlerService {

    private isLoggedOut!: boolean;
    private accessTokenFromStore!: string;

    constructor(
        private store: Store,
        private router: Router,
        private httpClient: HttpClient,
        private configService: ConfigService,
        private dataEmitterService: DataEmitterService
    ) {
        this.getDataFromStore();
    }

    /**
     * If any error then logout the application and refresh the page
     * @param error
     */
    public ErrorHandle(error: HttpErrorResponse) {
        if (this.accessTokenFromStore) {
            if (error.status === 403) {
                this.logoutWithSpecificPageNavigation('/login/sessionExpired');
            } 
        } else {
            if (error.status === 403) {
                this.sessionExpiredBeforeAuthentication('/login/sessionExpired');
            } else if (error.status === 400 || error.status === 500 || error.status === 422 || error.status === 0 || error.error.error.errorCode === 'SERVERR001') {
                if(error.url?.indexOf(this.configService.getGenericPartyDataUrl()) == -1){
                    this.sessionExpiredBeforeAuthentication('login/unableToProcess');
                }
            } else if (error.status === 401 && error.error.error.errorCode === 'MWFBE001') {
                this.sessionExpiredBeforeAuthentication('login/unableToProcess');
            }
        }
        /* if (error.status === 403) {
            this.sessionExpiredBeforeAuthentication('/login/sessionExpired');
        } else {
            if (this.accessTokenFromStore) {
                return throwError(error);
            } else {
                if (error.status === 400 || error.status === 500 || error.status === 422 || error.status === 0) {
                    this.logoutWithSpecificPageNavigation('login/unableToProcess');
                } else {
                    return throwError(error);
                }
            }
        } */
    }

    public logoutWithSpecificPageNavigation(screenToNavigate: string) {
        if (!this.isLoggedOut) {
            this.dataEmitterService.broadcast('isLoggedOut', false);
        }
        this.dataEmitterService.on('isLoggedOut').subscribe((resp) => {
            this.isLoggedOut = true;
            if (!resp) {
                this.dataEmitterService.broadcast('isLoggedOut', true);
                this.httpClient.post(this.configService.getLoginEndPointsWithDomain('logoutUrl'), {}).subscribe(() => {
                    this.store.dispatch(resetStore());
                    this.router.navigateByUrl(screenToNavigate, { skipLocationChange: true });
                }, () => {
                    this.store.dispatch(resetStore());
                    this.router.navigateByUrl(screenToNavigate, { skipLocationChange: true });
                });
            } else if (resp) {
                this.router.navigateByUrl(screenToNavigate, { skipLocationChange: true });
            }
        });
    }

    private sessionExpiredBeforeAuthentication(screenToNavigate: string) {
        this.store.dispatch(resetStore());
        this.router.navigateByUrl(screenToNavigate, { skipLocationChange: true });
    }

    private getDataFromStore() {
        this.store.select(getAccessToken).subscribe((resp) => {
            this.accessTokenFromStore = resp;
        });
    }
}
