import { fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { ErrorHandlerService } from './error-handler.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpHandlerService } from '../http-handler/http-handler.service';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthModule, ConfigService, getAccessToken } from '../../auth.module';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { DataEmitterService } from '../data-emitter/data-emitter.service';
import { Data, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { getClientSessionId, getSecretKey, getServerState } from '../../auth.index';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

@Component({
  selector: 'dummy-component',
  template: '<p>dummy</p>'
})
class DummyComponent {}

describe('ErrorHandlerService', () => {
    let service: ErrorHandlerService;
    let dataEmitterServiceSpy: jasmine.SpyObj<DataEmitterService>;
    let configServiceSpy: jasmine.SpyObj<ConfigService>;
    let dataEmitterSpy: { on: () => Observable<string | boolean> };
    let router: Router;
    let location: Location;
    let httpClient: HttpClient;
    let httpTestingController: HttpTestingController;

    const errorMock = new HttpErrorResponse({
      status: 403
    });
    const errorMock400 = new HttpErrorResponse({
      status: 400
    });
    const errorMock401 = new HttpErrorResponse({
      status: 401,
      error: { 
        error: { 
        errorCode: 'MWFBE001'
        }
      }
    });
    const errorMockError = new HttpErrorResponse({
      status: -1
    });
    
    let store: MockStore;

    beforeEach(() => {
        dataEmitterSpy = jasmine.createSpyObj('DataEmitterService', ['broadcast', 'on']);
        const configSpy = jasmine.createSpyObj('ConfigService', ['getLoginEndPointsWithDomain']);

        TestBed.configureTestingModule({
            imports: [
                AuthModule.forRoot('env'),
                HttpClientTestingModule,
                RouterTestingModule.withRoutes(
                  [{path: 'login/sessionExpired', component: DummyComponent}, { path: 'test', component: DummyComponent}]
                )
                
            ],
            providers: [
              ErrorHandlerService,
              HttpHandlerService,
              { provide: ConfigService, useValue: configSpy },
              { provide: DataEmitterService , useValue: dataEmitterSpy },
              provideMockStore({
                selectors: [
                  {
                    selector: getAccessToken,
                    value: '12345'
                  },
                  {
                    selector: getClientSessionId,
                    value: '12345'
                  },
                  {
                    selector: getSecretKey,
                    value: '12345'
                  },
                  {
                    selector: getServerState,
                    value: '12345'
                  },
                ],
              }),
            ],
        })
        service = TestBed.inject(ErrorHandlerService);
        dataEmitterServiceSpy = TestBed.inject(DataEmitterService) as jasmine.SpyObj<DataEmitterService>;
        configServiceSpy = TestBed.inject(ConfigService) as jasmine.SpyObj<ConfigService>;
        store = TestBed.inject<Store>(Store) as MockStore<any>;
        router = TestBed.inject(Router);
        location = TestBed.inject(Location);
        httpClient = TestBed.inject(HttpClient);
        httpTestingController = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
      store.resetSelectors();
    });

    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('should call error handle when access token is available', () => {
      spyOn<any>(service, 'logoutWithSpecificPageNavigation')
      expect(service.ErrorHandle(errorMock)).toBeTruthy;
      expect(service.logoutWithSpecificPageNavigation).toHaveBeenCalled();
    });

    it('should call error handle when access token is not available and error code is 403', () => {
      service['accessTokenFromStore'] = '';
      spyOn<any>(service, 'sessionExpiredBeforeAuthentication').and.callThrough();
      expect(service.ErrorHandle(errorMock)).toBeTruthy;
      expect(service['sessionExpiredBeforeAuthentication']).toHaveBeenCalled();
    });

    it('should call error handle when access token is not available and error code is 400', () => {
      service['accessTokenFromStore'] = '';
      spyOn<any>(service, 'sessionExpiredBeforeAuthentication').and.callThrough();
      expect(service.ErrorHandle(errorMock400)).toBeTruthy;
      expect(service['sessionExpiredBeforeAuthentication']).toHaveBeenCalled();
    });

    it('should call error handle when access token is not available and error code is 401', () => {
      service['accessTokenFromStore'] = '';
      spyOn<any>(service, 'sessionExpiredBeforeAuthentication').and.callThrough();
      expect(service.ErrorHandle(errorMock401)).toBeTruthy;
      expect(service['sessionExpiredBeforeAuthentication']).toHaveBeenCalled();
    });

    it('should call logoutWithSpecificPageNavigation to redirect', fakeAsync(()=> {
      service['isLoggedOut'] = false;
      dataEmitterServiceSpy.broadcast('isLoggedOut', false);
      dataEmitterSpy.on = () => of('isLoggedOut', false);
      router.navigateByUrl('login/sessionExpired');
      tick();
      dataEmitterServiceSpy.on('isLoggedOut').subscribe({next: (resp) => {
        expect(location.path()).toBe('/login/sessionExpired');
      }})
      
      service.logoutWithSpecificPageNavigation('login/sessionExpired');
      expect(dataEmitterServiceSpy.broadcast).toHaveBeenCalled();
      flush();
    }));

    it('should call logoutWithSpecificPageNavigation to redirect when response is available', fakeAsync(()=> {
      service['isLoggedOut'] = false;
      configServiceSpy.getLoginEndPointsWithDomain;
      dataEmitterServiceSpy.broadcast('isLoggedOut', false);
      dataEmitterSpy.on = () => of('isLoggedOut', false);
      router.navigateByUrl('login/sessionExpired');
      tick();
      dataEmitterServiceSpy.on('isLoggedOut').subscribe({next: (resp) => {
        expect(location.path()).toBe('/login/sessionExpired');
        
        const testData: Data = {name: 'Test Data'};

          httpClient.post<Data>('/logoutUrl', {})
          .subscribe(data =>
            expect(data).toEqual(testData)
          );
          const req = httpTestingController.expectOne('/logoutUrl');
          expect(req.request.method).toEqual('POST');
          req.flush(testData);
          httpTestingController.verify();

      }})
      
      service.logoutWithSpecificPageNavigation('login/sessionExpired');
      expect(dataEmitterServiceSpy.broadcast).toHaveBeenCalled();
      flush();
    }));

  });
