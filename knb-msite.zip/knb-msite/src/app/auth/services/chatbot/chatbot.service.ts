import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
//import { select } from '@angular-redux/store';
// import * as $ from 'jquery';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../authentication/authentication.service';
import { InterceptorService } from '../interceptor/interceptor.service';
import { Store } from '@ngrx/store';
import { getAccessToken, stateModel } from '../../ngrx-store/store.index';

declare function passContextDetails(params: any): any;
declare function receiveMessage(params: any): any;
// declare function botSessionTokenRefresh(params: any): any;

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  private accessTokenFromStore!: string;
  private isLoaded = false;
  private config:any;


  constructor(
    private authService: AuthenticationService,
    private interceptorService: InterceptorService,
    private store: Store<stateModel>,
  ) {

   }

  public loadChatbot(config:any) {
    this.config = config;
    const updatedInitParams = this.updateInitParams(config);
    if (typeof passContextDetails !== 'undefined') {
      passContextDetails(updatedInitParams);
      this.isLoaded = true;
    }
  }

  public closechatbot(chatBotCloseParams:any) {
    if (typeof receiveMessage !== 'undefined') {
      receiveMessage(chatBotCloseParams);
    }
  }


  // public botSessionTokenRefreshData() {
  //   botSessionTokenRefresh(this.botRefreshData);
  // }
  // private botRefreshData() {
  //   const nonce = this.authService.generateNonce();
  //   let headers: HttpHeaders = new HttpHeaders();
  //   headers = headers.set('Authorization', this.accessTokenFromStore);
  //   headers = headers.set('nonce', nonce);
  //   const state = this.interceptorService.generateRequestMac('POST', this.config.endPointToGenerateMacForPP, null, headers);
  //   const botSessionTokenRefresh = { appSessionToken: this.accessTokenFromStore, customerInfo: { nonce: nonce, state: state } };
  //   return botSessionTokenRefresh;
  // }

  private updateInitParams(config:any) {
    const nonce = this.authService.generateNonce();
    let headers: HttpHeaders = new HttpHeaders();
    this.store.select(getAccessToken).subscribe((sessionId) => {
        this.accessTokenFromStore = sessionId;
        this.accessTokenFromStore = `Bearer ${this.accessTokenFromStore}`;

      });

    headers = headers.set('Authorization', this.accessTokenFromStore);
    headers = headers.set('nonce', nonce);
    const state = this.interceptorService.generateRequestMac('POST', config.endPointToGenerateMacForPP, null, headers);
    const botSessionTokenRefresh = { appSessionToken: this.accessTokenFromStore, customerInfo: { nonce: nonce, state: state } };
    const initParams = { ...config, ...botSessionTokenRefresh, ...{ isLoaded: this.isLoaded } };

    return initParams;
  }
}
