import { TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { environment } from 'src/environments/environment';
import { getAccessToken } from '../../auth.index';
import { AuthenticationService, InterceptorService } from '../services.index';
import { ChatbotService } from './chatbot.service';

declare global {
  interface Window {
    passContextDetails: Function,
    receiveMessage: Function
  }
}

describe('ChatbotService', () => {
  let service: ChatbotService;
  let authSpy: jasmine.SpyObj<AuthenticationService>;
  let interceptorSpy: jasmine.SpyObj<InterceptorService>;
  let store: MockStore;

  beforeEach(() => {
    const authSpyObj = jasmine.createSpyObj('AuthenticationService', ['generateNonce'])
    const interceptorSpyObj = jasmine.createSpyObj('InterceptorService', ['generateRequestMac'])
    TestBed.configureTestingModule({
      providers: [
        { provide: AuthenticationService, useValue: authSpyObj },
        { provide: InterceptorService, useValue: interceptorSpyObj},
        provideMockStore({
          selectors: [
            {
              selector: getAccessToken,
              value: '12345'
            },
          ],
        }),
      ]
    });
    service = TestBed.inject(ChatbotService);
    authSpy = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
    interceptorSpy = TestBed.inject(InterceptorService) as jasmine.SpyObj<InterceptorService>;
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    
    Object.defineProperty(service, 'accessToken', { writable: true });
  });

  afterEach(() => {
    store.resetSelectors();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('load chat bot', () => {
    spyOn<any>(service, 'updateInitParams').and.callThrough();
    window.passContextDetails = function(params: any) {};
    const chatBotConfig = { ...environment.chatBotInitParams, ...{ endPointToGenerateMacForPP: environment.endPointToGenerateMacForPP } };
    service.loadChatbot(chatBotConfig);
    expect(service).toBeTruthy();
    expect(service['updateInitParams']).toHaveBeenCalled();
  });

  it('close chat bot', () => {
    window.receiveMessage = function(params: any) {};
    service.closechatbot(environment.chatBotCloseParams);
    expect(service).toBeTruthy();
  });
});


