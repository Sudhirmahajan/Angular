import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { Base64 } from 'js-base64';
import * as jsrsasign from 'jsrsasign';
import { authServiceConst } from 'src/app/app.constant';
import { ConfigService } from '../services.index';
import { HttpHandlerService } from '../http-handler/http-handler.service';
import { Store } from '@ngrx/store';
import {
  getAccessToken,
  getClientSessionId,
  resetStore,
  setSecretKey,
  stateModel,
} from '../../ngrx-store/store.index';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private clientSessionIdFromRedux!: string;
  private logoutLandingUrl!: string;

  constructor(
    private store: Store<stateModel>,
    private configService: ConfigService,
    private httpHandlerService: HttpHandlerService
  ) {
    this.store.select(getClientSessionId).subscribe((sessionId) => {
      this.clientSessionIdFromRedux = sessionId;
    });
  }

  /**
   * generate base 64 mac value using input data , secret key and HMAC algorithm
   * @param inputData:
   * @param secretKey:
   */
  public computeBase64MAC(inputData: string, secretKey: string) {
    const mac = new jsrsasign.KJUR.crypto.Mac({
      alg: authServiceConst.HMAC,
      pass: { b64u: secretKey },
    });
    const computedMAC = mac.doFinalString(inputData);
    return jsrsasign.hextob64u(computedMAC);
  }

  public generateEncrptedCredential(valueToEncrypt: string) {
    const credentail = this.encrypt(
      valueToEncrypt,
      this.configService.getknb2Key()
    );
    return credentail;
  }

  /**
   * generate  secret key and stores it in redux store and then encrypt it
   * @param state
   */
  public generateEncryptedSecretKey(state: string) {
    const secretKey = this.getSecretKey(state);
    this.store.dispatch(setSecretKey({ value: secretKey }));
    // const encyptedSecretKey = this.encrypt(secretKey);
    return secretKey;
  }

  public generateNonce() {
    return this.generateClientID() + '|' + this.generateRequestId();
  }

  /**
   * generate a random number to be used in the nonce
   */
  public generateRandom() {
    const cryptoObj: any = window.crypto;
    if (cryptoObj && cryptoObj.getRandomValues) {
      const asciiArray = new Uint32Array([0xfafba, 0xaffbc, 0xfabbd, 0xfffba]);
      cryptoObj.getRandomValues(asciiArray);
      return this.padZero(asciiArray);
    } else {
      const randomNumberArray = this.generateRandomNumberArray();
      return this.padZero(randomNumberArray);
    }
  }

  public openUrlInNewTab(url: string) {
    window.open(url, '_blank');
  }

  /**
   * Method to generate random number array using javascript random method.
   * When 'window.crypto' not supported in browser this method will create random number array.
   */
  generateRandomNumberArray(): number[] {
    return [
      Math.floor(Math.random() * 900000000) + 100000000,
      Math.floor(Math.random() * 900000000) + 100000000,
      Math.floor(Math.random() * 900000000) + 100000000,
      Math.floor(Math.random() * 900000000) + 100000000,
    ];
  }

  /**
   * logout the application and if success refresh the application
   */
  public logout() {
    this.logoutLandingUrl = this.configService.getStaticLinks('kotak');
    this.httpHandlerService
      .Post(
        this.configService.getDashboardEndPointsWithDomain(
          'offersTerminateService'
        ),
        {}
      )
      .subscribe({
        next: () => {
          this.logoutAndRedirect();
        },
        error: () => {
          this.logoutAndRedirect();
        },
      });
  }

  public isLoggedIn() {
    let status = false;
    this.store.select(getAccessToken).subscribe((accessToken) => {
      if (accessToken) {
        status = true;
      }
    });
    return status;
  }

  public generateMwfEncryptedCredential(dataToEncrypt: string) {
    return this.encrypt(dataToEncrypt, this.configService.getmwfKey());
  }

  public mergedEncryptedCredential(credential: string, state: string) {
    const encryptedSecretKey = this.generateEncryptedSecretKey(state);
    return this.generateSecuredEncryptedCredential(
      credential,
      encryptedSecretKey
    );
  }

  public generateSecuredEncryptedCredential(
    credential: string,
    encryptedSecretKey: string
  ) {
    const encryptedCredential = this.encrypt(
      credential,
      this.configService.getmwfKey()
    );
    const firstPartOfencryptedCredential = encryptedCredential.substr(
      0,
      encryptedSecretKey.length
    );
    const secondPartOfencryptedCredential = encryptedCredential.substr(
      encryptedSecretKey.length,
      encryptedCredential.length
    );
    const mergedCredential =
      this.encrypt(
        encryptedSecretKey + '|' + firstPartOfencryptedCredential,
        this.configService.getknb2Key()
      ) +
      '|' +
      secondPartOfencryptedCredential;
    return mergedCredential;
  }

  /**
   * public key decryption using base64 CryptoJs
   * @param publicKey:
   */
  private decodePublicKey(publicKey: string) {
    return Base64.decode(publicKey);
  }

  /**
   * logout nb2.0 and redirect to logout page
   */
  private logoutAndRedirect() {
    this.httpHandlerService
      .Post(this.configService.getLoginEndPointsWithDomain('logoutUrl'), {})
      .subscribe({
        next: () => {
          this.store.dispatch(resetStore());
          window.open(this.logoutLandingUrl, '_self');
        },
        error: () => {
          this.store.dispatch(resetStore());
          window.open(this.logoutLandingUrl, '_self');
        },
      });
  }
  /**
   * encryption of the credentials using decrypted public key, RSA algo
   * @param valueToBeEncrypt:
   */
  private encrypt(valueToBeEncrypt: string, publicKey: string) {
    const decodedPublicKey = this.decodePublicKey(publicKey);
    const jsrsasignKey = <jsrsasign.RSAKey>(
      jsrsasign.KEYUTIL.getKey(decodedPublicKey)
    );
    return jsrsasign.hextob64u(
      jsrsasign.KJUR.crypto.Cipher.encrypt(
        valueToBeEncrypt,
        jsrsasignKey,
        authServiceConst.RSA
      )
    );
  }

  /**
   * return client session id from store
   */
  private generateClientID() {
    return this.clientSessionIdFromRedux;
  }

  private generateRequestId() {
    const requestID = this.generateRandom();
    return requestID;
  }

  /**
   * generate secret key using salt, random values and state with the help of CryptoJS
   * @param state:
   */
  private generateSecretKey(state: string) {
    const salt = CryptoJS.lib.WordArray.random(128 / 8);
    const randomIterations = 1000 + Math.floor(Math.random() * 200);
    const key512Bits = CryptoJS.PBKDF2(state, salt, {
      keySize: 512 / 32,
      iterations: randomIterations,
    });
    return jsrsasign.b64tob64u(CryptoJS.enc.Base64.stringify(key512Bits));
  }

  /**
   * generate  secret key and stores it in redux store and then encrypt it
   * @param state:
   */
  private getSecretKey(state: string) {
    const secretKey = this.generateSecretKey(state);
    return secretKey;
  }

  /**
   * converts the random number into 88 char string
   * @param randomNumberArray:
   */
  private padZero(randomNumberArray: number[] | Uint32Array | string[]) {
    return (
      '0' +
      randomNumberArray[0] +
      '0' +
      randomNumberArray[1] +
      '0' +
      randomNumberArray[2] +
      '0' +
      randomNumberArray[3]
    );
  }
}
