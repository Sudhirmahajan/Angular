import { TestBed } from '@angular/core/testing';
import { AuthenticationService } from './authentication.service';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { ConfigService, HttpHandlerService } from '../services.index';
import {
    HttpClientTestingModule,
    HttpTestingController,
} from '@angular/common/http/testing';
import { AuthModule } from '../../auth.module';
import { getAccessToken, getClientSessionId, getSecretKey, getServerState } from '../../auth.index';
import { Data } from '@angular/router';
import { of } from 'rxjs';

describe('AuthenticationService', () => {
    let service: AuthenticationService;
    let httpTestingController: HttpTestingController;
    let configServiceSpy: jasmine.SpyObj<ConfigService>;
    let httpHandlerService: jasmine.SpyObj<HttpHandlerService>;

    const mfwKey = "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KICAgIE1JSUJJakFOQmdrcWhraUc5dzBCQVFFRkFBT0NBUThBTUlJQkNnS0NBUUVBdjArVlRwbU0yMFVWdlpBMVVzK2UKICAgIFNHTmRMSjlLSjBvbmVYeWYzbHJaRytMWEN3aE4yZ2J5N0R2QklDblc5bnFidnJJVytXOUh1WnNxMWVJZnNwWCsKICAgIHVSanhzVVNGdFI5K1A3bTErSEN1WHBSRFltUUlKaDRUdVRPZDNTWWFEWUtGcHFvbEo2UGNxVmUxUDhIeG9FQ1oKICAgIG56ZVZ6Q0wycFhRYVExMUEzUXBzLzVlbW5Ua3pQR3FwNHJmRlRrMlZpTFVUaGg2NXdoSExNSW8xOGhhYjdDZmQKICAgIFgyRmxNQ1NLcWoyUHlxNzRBTGdpUkhZd0UvRG04RmhnWXQ2TEtMSEpBMDMrUXZVVkpyRzl3TUt3dm9icW5FQnUKICAgIDQzVGdhUmM4Q0t4bEF2VjRBWThjQmlHRXdZYTlLR2drT01nZlQ5dFdma3NlcklnSlhJL0NtcEJSRlRoMkJ5cDkKICAgIElRSURBUUFCCiAgICAtLS0tLUVORCBQVUJMSUMgS0VZLS0tLS0="
    const knb2Key = "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUExdk1XNGdyZlc0aGRJQnV0c1R5UQo3YVI0YnFZVy93TmNzK3dYWGIwQ2doZGgycXljZnMxdlcwUVRFeUFkT05naGt5TWloUjViOENFdDlEb3pCenIxCnVOR202VGRhZVdobi9EQTJvVHo3bkVkajNBb2dMejVpa3lEbFBqSHEwKzQ3Y2NZWkV6dmptUFdmeUlaVVNxaFIKRFFtWFdlNTlNeGR1SjluUVg3QVRsQm5WdDlsNlY3d2h1MHJBdFBjMDU5eVRrdDRKWGluYnpQdWhnazZ4b1BSSgpGdWI0TGZEUnpGam5TVndybHA5ZkJzemVTRjRka3g0QjB6UTRkUkZ2ZFVGdEh0N0tmNTh3Z3pFSEk3NmtpZzZ6ClU0SEdydlNVaXJyQ29MQmZQYUUyZ0h6NmxWaUl0bGFibjlVM1lhdkg0YzFPaGZmVWhXZFFhSDU0eEUrNVlwSzcKR1FJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0t"
    const mockSession_id =
        '0232882800305860625103858924808036118885460166175463903804168864016742942904243440316';
    const inputData =
        'POST/knb2/v1/verifyMfa0250685883103583960712035700835730427099508503664053609029265562450230004129301448317976|0364825940906030260090164994509303020148442022854457890821368473033161811220631869454Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkpkR3ZBYWZCdVdEOFQ5VG81dXUxdXkxMDlrVSIsImtpZCI6IkpkR3ZBYWZCdVdEOFQ5VG81dXUxdXkxMDlrVSJ9.eyJhdWQiOiJlZWY2MTkwMS0xZTBhLTQzNjEtODNiNS1mZTM2NTQxNjM1N2EiLCJpc3MiOiJodHRwczovL3N0cy5waWxvdC5jb20vYWRmcyIsImlhdCI6MTU3NDE0MzgyMiwiZXhwIjoxNTc0MTQ3NDIyLCJhdXRoX3RpbWUiOjE1NzQxNDM4MjIsInN1YiI6IkxmZlZOblNmdzJrWTZLSWs0TTBtbDU4eElJZWxBMFV6R20wTlBmYVB3aDA9IiwidXBuIjoiNTcxMDAxMUBwaWxvdC5jb20iLCJ1bmlxdWVfbmFtZSI6IlBJTE9UXFw1NzEwMDExIiwicHdkX2V4cCI6Ijg1NjM5NDUxIiwic2lkIjoiUy0xLTUtMjEtMzg4MDYzMjMwMS0zNTcwMzUzMTEzLTE5MTQ1OTg2NTYtMTEzMSIsImNybiI6IjU3MTAwMTEiLCJjcm5fZ3JvdXBzIjoiRG9tYWluIFVzZXJzIiwiYXBwdHlwZSI6IkNvbmZpZGVudGlhbCIsImFwcGlkIjoiZWVmNjE5MDEtMWUwYS00MzYxLTgzYjUtZmUzNjU0MTYzNTdhIiwiYXV0aG1ldGhvZCI6InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphYzpjbGFzc2VzOlBhc3N3b3JkUHJvdGVjdGVkVHJhbnNwb3J0IiwidmVyIjoiMS4wIiwic2NwIjoib3BlbmlkIn0.IhyT08X3-rq5WqVHVu-RDwPqeAFXJr3LwjcgBZxHRVDW_0tsnzc0xXoId0DLeV1RBqmUHr17ZeDQikvmr7nmf90Q3sxtiwqejt-ojyj9NNnHbEoHoKN_Oi6GovLH25wzFAFVT4soPS97okFSj3C1yrDflI_4cVqyFbP_lxJruj6ELAa5mIln9cFGpJ8_9MrKQw29WaWjuXBhlDNXBYHLT9ldduy6vgRGNCclTREFEK7lXpsm-bj0_FjgxPPpGIWWF3DcwrWojD98y4ID-h-GPmHuAIZ-2EGA0VtOOiIN1gjiC5LyQNtMJwPOJdYFE5UL_X6abfS1fYO-AMXnruHVmgNTQ1NWNlMzQtZWIwNC00OGExLTg4NDItYTgyZDQwMDIyMTlmfE1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS83NS4wLjM3NzAuOTAgU2FmYXJpLzUzNy4zNnxrb3RhazEyM3wwMjUwNjg1ODgzMTAzNTgzOTYwNzEyMDM1NzAwODM1NzMwNDI3MDk5NTA4NTAzNjY0MDUzNjA5MDI5MjY1NTYyNDUwMjMwMDA0MTI5MzAxNDQ4MzE3OTc2fDU3MTAwMTF8NTcxMDAxMXw3MzkyOThiNi1mMWFkLTQxODUtODQwNi1lNjBiNGQxNjE5MDY={"appName":"oneView"}';
    const secretKey =
        'C4cuEhMLLWYXuuV1V05lk8tMmuD113JdvqeM0DjcnzsH9VcSIThmftQ_FEqQmR0sjtEEhIvrAXprNw7Dn8VQGQ';
    const base64res =
        '9utSBxHsw8SbdAhKsmS-3kvmJ8OaePYvd-wiOMd3DK_PcWkwBb8n76PIdOSnjWRNMIo-d4Rdje7fQfzoVGNWrw';
    const valueToEncrypt = '16660445';
    const accessToken = 'NNFhhfhdfgjlkjjlkfd_95689gkjlkl';
    const state =
        'ZjA2NTlmYzItNzUyYS00OWM4LThjZGMtMWRhYTA4Mjc2YTc1fE1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS83NS4wLjM3NzAuOTAgU2FmYXJpLzUzNy4zNnxrb3RhazEyM3wwMzA1NjM0NzU2NDAyMDIyNDYzNTM1MDIxNzc4NDM3NjAyOTM2NTQ3MDAyNzcyOTY5NDg4MDUzMzQ2NTYxNzAzMDkyMDg4MDYwMDIwNjM5NzAwNzV8NTcxMDAxMXw1NzEwMDExfDY2ZDc4NmUwLTBlZDctNGE3Yi05YWQ1LWEzN2QwYWRmYjBiOQ==';

    let store: MockStore;
   
    beforeEach(() => {
        const MockConfigService = jasmine.createSpyObj('ConfigService', [
            'getStaticLinks',
            'getDashboardEndPointsWithDomain',
            'getknb2Key',
            'getmwfKey'
        ]);
        const MockHttpHandlerService = jasmine.createSpyObj('HttpHandlerService', ['Post'])
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule, AuthModule.forRoot('env')],
            providers: [
                { provide: ConfigService, useValue: MockConfigService },
                { provide: HttpHandlerService, useValue: MockHttpHandlerService },
                
                provideMockStore({
                    selectors: [
                        {
                            selector: getClientSessionId,
                            value: mockSession_id
                        },
                        {
                            selector: getAccessToken,
                            value: accessToken 
                        },
                        {
                            selector: getSecretKey,
                            value: secretKey
                        },
                        {
                            selector: getServerState,
                            value: state
                        }
                    ],
                }),
            ],
        });

        httpTestingController = TestBed.inject(HttpTestingController);
        store = TestBed.inject<Store>(Store) as MockStore<any>;
        httpHandlerService = TestBed.inject(
            HttpHandlerService
        ) as jasmine.SpyObj<HttpHandlerService>;
        service = TestBed.inject(AuthenticationService);
        configServiceSpy = TestBed.inject(
            ConfigService
        ) as jasmine.SpyObj<ConfigService>;
    });

    afterEach(() => {
        store.resetSelectors();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('session id should not be null', (done) => {
        store.select(getClientSessionId).subscribe((sessionId) => {
            expect(sessionId).not.toBeNull();
            done();
        });
    });

    it('it should compute Base 64 Mac', () => {
        const base64mac = service.computeBase64MAC(inputData, secretKey);
        expect(base64mac).toEqual(base64res);
    });

    it('it should generate EncrptedCredential', () => {
        configServiceSpy.getknb2Key.and.returnValue(knb2Key);
        const genCredentials =
            service.generateEncrptedCredential(valueToEncrypt);

        expect(configServiceSpy.getknb2Key).toHaveBeenCalled();
    });

    it('it should generate EncryptedSecretKey', async () => {
        spyOn(store, 'dispatch').and.callThrough();
        service.generateEncryptedSecretKey(state);
        expect(store.dispatch).toHaveBeenCalled();
    });

    it('it should generate Nonce', () => {
        spyOn<any>(service, 'generateClientID').and.returnValue('abcd');
        spyOn<any>(service, 'generateRequestId').and.returnValue('xyz');
        const stubValue = 'abcd|xyz';
        const nonce = service.generateNonce();

        expect(service['generateClientID']).toHaveBeenCalled();
        expect(service['generateRequestId']).toHaveBeenCalled();
        expect(nonce).toEqual(stubValue);
    });

    it('it should generate Random', () => {
        const genRandom = spyOn(service, 'generateRandom').and.callThrough();
        service.generateRandom();
        expect(genRandom).toBeDefined();
        expect(genRandom).toHaveBeenCalled();
    });

    it('it should generate Random when crypto is not available on window object', () => {
        const genRandom = spyOn(service, 'generateRandom').and.callThrough();
        spyOnProperty(window, 'crypto').and.returnValue(null);

        service.generateRandom();
        expect(genRandom).toBeDefined();
        expect(genRandom).toHaveBeenCalled();
    });

    it('it should call open url method', () => {
        const dummyUrl = 'https://netbanking.kotak.com/knb2/';
        spyOn(window, 'open').and.callFake(function () {
            return <any>true;
        });
        service.openUrlInNewTab(dummyUrl);

        expect(window.open).toHaveBeenCalled();
        expect(window.open).toHaveBeenCalledWith(dummyUrl, '_blank');
    });

    it('it should perform logout', () => {
        const testUrl = '/logout';
        configServiceSpy.getStaticLinks.and.returnValue(testUrl);
        configServiceSpy.getDashboardEndPointsWithDomain.and.returnValue(
            testUrl
        );
        spyOn<any>(service, 'logoutAndRedirect')
        httpHandlerService.Post.and.returnValue(of());

        service.logout();

        httpHandlerService.Post(testUrl, {}).subscribe({ next: ()=> {
            expect(service['logoutAndRedirect']).toHaveBeenCalled();
        } })

        
    });

    it('it should check is LoggedIn', (done) => {
        store.select(getAccessToken).subscribe((accessToken) => {
            expect(accessToken).not.toBeNull();
            done();
        });

        service.isLoggedIn();
    });

    it('it should generate merged Encrypted Credential', () => {
        const stubValue = 'sdf4jh5sdfk';
        spyOn<any>(service, 'encrypt').and.returnValue(stubValue);

        const mockData = service.generateMwfEncryptedCredential(stubValue);
        expect(service['encrypt']).toHaveBeenCalled();
        expect(mockData).toEqual(stubValue);
    });

    it('it should merge Encrypted Credential', () => {
        const stubValue = 'sdf4jh5sdfk';
        spyOn(service, 'generateEncryptedSecretKey').and.returnValue(stubValue);
        spyOn(service, 'generateSecuredEncryptedCredential').and.returnValue(stubValue);

        const mockData = service.mergedEncryptedCredential('credentials', 'state');
        expect(service.generateEncryptedSecretKey).toHaveBeenCalled();
        expect(service.generateSecuredEncryptedCredential).toHaveBeenCalled();
        expect(mockData).toEqual(stubValue);
    });

    it('it should generate secured encrypted credentials', () => {
        configServiceSpy.getmwfKey.and.returnValue(mfwKey);
        configServiceSpy.getknb2Key.and.returnValue(knb2Key);
        const secureKey = "5gsbDQzDnlZMGMe4zNd_m12b9TnojybabMajXtluG8yOI-ndsG64xUxpp6-rJH3wHnZDdoqCCQM4pCpCL3lbrA";
        service.generateSecuredEncryptedCredential('Quality123', secureKey);

        expect(configServiceSpy.getmwfKey).toHaveBeenCalled();
    })
});
