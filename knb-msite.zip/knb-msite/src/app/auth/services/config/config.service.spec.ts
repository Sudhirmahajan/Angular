import { TestBed } from '@angular/core/testing';
import { ConfigService } from './config.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpHandlerService } from '../http-handler/http-handler.service';
import { AuthModule } from '../../auth.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Store } from '@ngrx/store';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs/internal/observable/of';

describe('ConfigService', () => {
    let service: ConfigService;
    let store: MockStore;
    let httpClient: HttpClient;
    let httpTestingController: HttpTestingController;
    let httpHandlerServiceSpy: jasmine.SpyObj<HttpHandlerService>;
    let endPoint: '';
    
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                AuthModule.forRoot('env'),
                HttpClientTestingModule,
                RouterTestingModule,
            ],
            providers: [
                HttpHandlerService,
                provideMockStore({
                    selectors: [],
                }),
            ],
        });

        httpClient = TestBed.inject(HttpClient);
        httpTestingController = TestBed.inject(HttpTestingController);
        store = TestBed.inject<Store>(Store) as MockStore<any>;
        service = TestBed.inject(ConfigService);
        httpHandlerServiceSpy = TestBed.inject(HttpHandlerService) as jasmine.SpyObj<HttpHandlerService>;

        service.config = {
            staticLinks: {
                key: 'staticLink',
            },
            services: {
                dashboardService: {
                    dashboardService: '/dashboardService'
                },
                loginService: {
                    loginService: '/loginService'
                },
                oprService: {
                    oprService: '/oprService'
                },
                investmentService: {
                    investmentService: '/investmentService'
                },
                onboardingService: {
                    onboardingService: '/onboardingService'
                },
                userPersonaService: {
                    userPersonaService: '/userPersonaService'
                },
                accountService: {
                    accountService: '/accountService'
                },
                cardService: {
                    cardService: '/cardService'
                },
                statementService: {
                    statementService: '/statementService'
                },
                paymentsTrfService : {
                    paymentService: '/paymentService'
                }
            },
            ipAdd: {
                ipAdd: '10.1.22.365'
            },
            gck: {
                k: 'gckValue'
            }
        }
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should check getmwfKey', () => {
        spyOn(service, 'getEnv').and.returnValue({mwfPublicKey: 'mwfPublicKey'})
        const response = service.getmwfKey();
        expect(response).toEqual('mwfPublicKey');
    });
    it('should check getknb2Key', () => {
        spyOn(service, 'getEnv').and.returnValue({knb2PublicKey: 'knb2PublicKey'})
        const response = service.getknb2Key();
        expect(response).toEqual('knb2PublicKey');
    });
    it('should check load', (done: DoneFn) => {
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        spyOn<any>(httpHandlerServiceSpy, 'Post').and.returnValue(of('test'));
        spyOn(service, 'getEnv').and.returnValue({apiConfig: { apiConfigPath: '/knb2/bootstrap-service/config-params' }})
        const result = service.load();
        result.then((resolve) => {
            expect(httpHandlerServiceSpy.Post).toHaveBeenCalled();
        }).then(done);
    });
    it('should check getEnv', () => {
        const result = service.getEnv();
        expect(result).toEqual('env');
    })
    it('should check getStaticLinks', () => {
        const key = 'key'
        const result = service.getStaticLinks(key);
        expect(result).toEqual('staticLink');
    })
    it('should check getDashboardEndPointsWithDomain', () => {
        const endpoint = 'dashboardService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getDashboardEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/dashboardService');
    })
    it('should check getLoginEndPointsWithDomain', () => {
        const endpoint = 'loginService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getLoginEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/loginService');
    })
    it('should check getIpAddress', () => {
        const result = service.getIpAddress();
        expect(result).toEqual('10.1.22.365');
    })
    it('should check getOprEndPointsWithDomain', () => {
        const endpoint = 'oprService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getOprEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/oprService');
    })
    it('should check getInvestmentEndPointsWithDomain', () => {
        const endpoint = 'investmentService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getInvestmentEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/investmentService');
    })
    it('should check getGck', () => {
        const result = service.getGck();
        expect(result).toEqual('gckValue');
    })
    it('should check getOnboardingEndPointsWithDomain', () => {
        const endpoint = 'onboardingService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getOnboardingEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/onboardingService');
    })
    it('should check getUserPersonaEndPointsWithDomain', () => {
        const endpoint = 'userPersonaService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getUserPersonaEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/userPersonaService');
    })
    it('should check getAccountEndPointsWithDomain', () => {
        const endpoint = 'accountService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getAccountEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/accountService');
    })
    it('should check getConfig', () => {
        const result = service.getConfig('staticLinks');
        expect(result).toBeTruthy();
    })
    it('should check getCardEndPointsWithDomain', () => {
        const endpoint = 'cardService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getCardEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/cardService');
    })
    it('should check getStatementEndPointsWithDomain', () => {
        const endpoint = 'statementService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getStatementEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/statementService');
    })
    it('should check getPaymentEndPointsWithDomain', () => {
        const endpoint = 'paymentService';
        spyOn<any>(service, 'getDomain').and.returnValue('http://test.com');
        const result = service.getStatementEndPointsWithDomain(endpoint);
        expect(result).toEqual('http://test.com/paymentService');
    })
});
