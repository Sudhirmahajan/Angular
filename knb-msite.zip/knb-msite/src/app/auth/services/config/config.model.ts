
export interface IConfigModel {
    [key: string]: {};
    staticLinks: {
        [key: string]: string,
    },
    services: {
        dashboardService: {
            [endPoint: string]: string
        },
        loginService: {
            [endPoint: string]: string
        },
        oprService: {
            [endPoint: string]: string
        },
        investmentService: {
            [endPoint: string]: string
        },
        onboardingService: {
            [endPoint: string]: string
        },
        userPersonaService: {
            [endPoint: string]: string
        },
        accountService: {
            [endPoint: string]: string
        },
        cardService: {
            [endPoint: string]: string
        },
        statementService: {
            [endPoint: string]: string
        }
        paymentsTrfService : {
            [endPoint: string]: string
        }
    },
    ipAdd: {
        ipAdd: string
    },
    gck: {
        k: string
    }
}