import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { HttpHandlerService } from '../http-handler/http-handler.service';
import { IConfigModel } from './config.model';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  public downtimeData!: object;
  public config!: IConfigModel;

  constructor(
    private httpService: HttpHandlerService,
    @Inject(DOCUMENT) private document: any,
    @Inject('env') private env:any
  ) {
  }

  load() {
    return new Promise<void>((resolve) => {
      const api = this.getDomain() + this.getEnv().apiConfig.apiConfigPath;
      this.httpService.Post(api, {}).subscribe((config: any) => {
        this.config = config;
        resolve();
      });
    });
  }

  public getEnv() {
    return this.env;
  }

  public getmwfKey() {
    const mwfPublicKey = this.getEnv().mwfPublicKey;
    return mwfPublicKey;
  }

  public getknb2Key() {
    const knb2PublicKey = this.getEnv().knb2PublicKey;
    return knb2PublicKey;
  }

  public getStaticLinks(key: string) {
    return this.config['staticLinks'][key];
  }

  public getDashboardEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].dashboardService[endPoint];
  }

  public getLoginEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].loginService[endPoint];
  }

  public getIpAddress() {
    return this.config['ipAdd']['ipAdd'];
  }

  public getOprEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].oprService[endPoint];
  }

  public getInvestmentEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].investmentService[endPoint];
  }

  public getGck() {
    return this.config['gck'].k;
  }

  public getOnboardingEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].onboardingService[endPoint];
  }

  public getUserPersonaEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].userPersonaService[endPoint];
  }

  public getAccountEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].accountService[endPoint];
  }

  public getConfig(key: string) {
    return (this.config) ? this.config[key] : '';
  }
  public getCardEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].cardService[endPoint];
  }

  public getStatementEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].statementService[endPoint];
  }

  public getPaymentEndPointsWithDomain (endPoint : string ){
    return this.getDomain() + this.config['services'].paymentsTrfService[endPoint];
  }

  public getSecQusEndPoint (endPoint : string ){
    return this.getDomain() + this.config['services'].onboardingService[endPoint];
  }
  public getDownTime() {
    return this.config['downtime'];
  }

  // public methos for get domain name
  public getUrlDomain(){
    
    return this.getDomain();
  }
  
  public getGenericPartyDataUrl() {
    return this.config['services']['loginService']['genericPartyData'];
  }
  /*
  public getProductProcessorUrl(productProcessorName: string) {
    return this.config['productProcessor'][productProcessorName];
  }

 

  public getInvestmentEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].investmentService[endPoint];
  }

  public getUserPreferenceEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].userprefService[endPoint];
  }

 



  public getStatementEndPointsWithDomain(endPoint: string) {
    return this.getDomain() + this.config['services'].statementService[endPoint];
  }



  

 



 

  public getClientId() {
    return this.config['kotakClientId']['clientId'];
  }



  public getKotakTollFreeNumber() {
    return this.config['kotakTollFreeNumber'];
  }

 

 

  public getConfig(key: any): any {
    return (this.config) ? this.config[key] || undefined : undefined;
  }

  public getFeedbackUrl(key: string) {
    return this.config['feedbackUrls'][key];
  }
  */
 
  private getDomain() { 
    let domain = window.location.origin;
    if (domain?.indexOf(this.env.apiConfig.domainString) === -1) {
      domain = this.env.apiConfig.apiBaseUrl ? this.env.apiConfig.apiBaseUrl : domain.replace('https://', this.env.apiConfig.replaceWith);
    }
    return domain;
  }
}
