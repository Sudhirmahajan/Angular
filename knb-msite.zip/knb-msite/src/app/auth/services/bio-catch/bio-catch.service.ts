import { Injectable } from '@angular/core';
import {Renderer2,RendererFactory2,Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

declare var cdApi:object
@Injectable({
  providedIn: 'root'
})
export class BioCatchService {

  private renderer: Renderer2;
  constructor(rendererFactory: RendererFactory2,@Inject(DOCUMENT) private document: Document) {
    this.renderer = rendererFactory.createRenderer(null, null);
}

  setNewSession() {
    let script2 = this.renderer.createElement('script');
    script2.type = `text/javascript`;
    script2.text = `cdApi.startNewSession()`;
    this.renderer.appendChild(this.document.body, script2);
  }
  setPageContext(contextName: string) {  
        let script = this.renderer.createElement('script');
        script.type = `text/javascript`;
        script.text = 'cdApi.changeContext ("' + contextName + '")';
        this.renderer.appendChild(this.document.body, script);
  }
 
  setCSID(clientSessionId:string) {
          let script1 = this.renderer.createElement('script');
          script1.type = `text/javascript`;
          script1.text = 'cdApi.setCustomerSessionId("' + clientSessionId + '")';
          this.renderer.appendChild(this.document.body, script1);
  }


  biocatchPromiseFunc() {
    return new Promise(function (resolve, reject) {
      if (cdApi) {
        resolve("biocatch working"); }
      else {
        reject("biocatch not working");}})
  }

 
biocatchSetValues(clientSessionId:string ,bioCatchContextName:string){
 this.biocatchPromiseFunc().then(()=>{ 
   if(clientSessionId!=null){
    // this.setNewSession();
      this.setCSID(clientSessionId);     
    }this.setPageContext(bioCatchContextName.toUpperCase().replace(/\s/g,""));
}).catch(()=> console.log("issue with biocatch"));
  }
}
