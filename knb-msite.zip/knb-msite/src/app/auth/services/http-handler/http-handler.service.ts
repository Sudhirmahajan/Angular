import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class HttpHandlerService {
    constructor(private httpClient: HttpClient) { }

    public Get(url: string, options = {}) {
        return this.httpClient.get(url, options);
    }
    public Post(url: string, requestBody: any, options = {}) {
        return this.httpClient.post(url, requestBody, options);
    }
}
