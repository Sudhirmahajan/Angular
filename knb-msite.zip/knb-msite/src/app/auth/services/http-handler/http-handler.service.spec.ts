import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { HttpHandlerService } from './http-handler.service';

describe('HttpHandlerService', () => {
  const url = 'https://knb2-bootstrap-service-uat-nb.apps.pcfdev.prod.kotak.int/downtime';
  const requestBody = {};
  let service: HttpHandlerService;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  beforeEach(() => {
      TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [HttpHandlerService]
    })
    service= TestBed.inject(HttpHandlerService);
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  it('should be created http Handler Service', () => {
    expect(service).toBeTruthy();
  });

  it('should Place the Get  request', () => {
    service.Get(url);
  });

  it('should Place the Post  request', () => {
    service.Post(url, requestBody);
  });
});
