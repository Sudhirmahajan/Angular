import {
    HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { headers } from 'src/app/app.constant';
import { catchError, map } from 'rxjs/operators';
import { AuthenticationService, ErrorHandlerService } from '../services.index';
import { Store } from '@ngrx/store';
import { getAccessToken, getSecretKey, getServerState } from '../../ngrx-store/store.index';
import { LoaderService } from 'src/app/modules/shared/services/loader/loader.service';

@Injectable({
    providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {

    accessToken!: Observable<string>;
    secretKey!: Observable<string>;
    serverState!: Observable<string>;
    private accessTokenFromStore!: string;
    private respState!: string;
    private secretKeyFromStore!: string;
    private stateFromStore!: string;

    constructor(
        private authenticationService: AuthenticationService,
        private store: Store,
        private errorHandlerService: ErrorHandlerService,
        private loaderService: LoaderService
    ) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        request = this.addHeaders(request);
        // store nonce from request header for verification of response nonce
        const reqNonce = <string>request.headers.get('nonce');

        this.getDataFromStore();
        // Store request Hmac for verification with response Hmac
        const reqHmac = this.checkUrlForReq(request);
        // add request Hmac in headers after authentication
        if (reqHmac) {
            request = request.clone({ headers: request.headers.set('state', reqHmac) });
        }
        return next.handle(request).pipe(
            map((event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {
                    /** store nonce from response header */
                    const respNonce = event.headers.get(headers.nonce);
                    /** Store response Hmac for verification with request Hmac */
                    const respHmac = this.checkUrlForResp(respNonce, event);
                    /** If valid nonce and response HMac is present then compare Hmac otherwise return state mismatch or nonse mismatch
                     *  In case of only valid nonce, the event is returned
                     */
                    if (respNonce) {
                        
                        if (this.validateNonce(reqNonce, respNonce)) {
                            if (respHmac) {
                                
                                if (this.compareResponseHmac(respHmac)) {
                                    return event;
                                } else {
                                    // return event;
                                    this.errorHandlerService.logoutWithSpecificPageNavigation('login/unableToProcess');
                                }
                                
                            } else {
                                return event;
                            }
                        } else {
                            this.errorHandlerService.logoutWithSpecificPageNavigation('login/unableToProcess');
                        }
                        
                    }
                }
                return event;
            }),
            catchError((error: HttpErrorResponse) => { 
                this.loaderService.stopLoader();
                this.errorHandlerService.ErrorHandle(error);
                return throwError(() => error);
                
            })
        );
    }

    /**
     * Generate Hmac for both request and response based on the values passed as an arguments
     * @param requestMethod
     * @param requestURI
     * @param requestBody
     * @param callType
     * @param reqHeaders
     */
    public generateRequestMac(requestMethod: string, requestURI: string, requestBody: any, reqHeaders?: HttpHeaders) {
        // const serverState = this.respState;
        this.getDataFromStore();
        if (this.secretKeyFromStore && (requestMethod === 'GET' || requestMethod === 'POST')) {
            if (requestURI.startsWith('http')) {
                const index = requestURI.indexOf('/', 8);
                if (index > -1) {
                    requestURI = requestURI.substring(index);
                }
            }
            let inputData = requestMethod + encodeURI(requestURI);
            if (requestMethod === 'POST') {
                try {
                    if (!(requestBody instanceof FormData)) {
                        const requestJSON = JSON.stringify(requestBody);
                        inputData = inputData + this.generateInputData(requestJSON, this.stateFromStore, reqHeaders);
                    }
                } catch (err) { }
            } else if (requestMethod === 'GET') {
                inputData = inputData + this.generateInputDataForGet(this.stateFromStore, reqHeaders);
            }
            const base64MAC = this.authenticationService.computeBase64MAC(inputData, this.secretKeyFromStore);
            return this.stateFromStore + '|' + base64MAC;
        }
        return ''; //sachin
    }

    /**
     * add headers to the request
     * @param request
     */
    private addHeaders(request: HttpRequest<any>) {
        
        this.store.select(getAccessToken).subscribe(accessToken => {
            this.accessTokenFromStore = accessToken
        });
        if (this.accessTokenFromStore) {
            request = request.clone({ headers: request.headers.set('Authorization', 'Bearer ' + this.accessTokenFromStore) });
        }
        request = request.clone({ setHeaders: { 'Content-Type': 'application/json' } });
        request = request.clone({ setHeaders: { nonce: this.authenticationService.generateNonce() } });
        return request;
    }

    /**
     * generate request Hmac after user authentication
     * @param request
     * @param callType
     */
    private checkUrlForReq(request: HttpRequest<any>) {
        try {
            if (!request.url.endsWith('/authenticate') && !request.url.endsWith('/login')) {
                return this.generateRequestMac(request.method, request.url, request.body, request.headers);
            } else {
                return false;
            }
        } catch (err) {
            return false; //sachin
        }
    }

    /**
     * generate response if stae is present in header
     * @param callType
     * @param event
     */
    private checkUrlForResp(responseNonce:string | null, event?: HttpResponse<any>) {
        try {
            if (event && event.headers.get('state')) {
                return this.responseAuthentication(event, <string>responseNonce);
            } else {
                return false;
            }
        } catch (err) {
            return false;
        }
       
    }

    /**
     * compare Hmac and send the callback
     * @param clientRespHmac
     * @param callBack
     */
    private compareResponseHmac(respHmac: string) {
       
            if (this.respState === respHmac) {
                return true;
            } 
        return false;
    }

    private getDataFromStore() {
        this.store.select(getSecretKey).subscribe(secretKey => {
            this.secretKeyFromStore = secretKey
        });
        this.store.select(getServerState).subscribe(serverState => {
            this.stateFromStore = serverState;
        });
    }

    /**
     * get the nonce and authorization from request header and concatenate both with client sate and retuen it
     * @param reqHeaders
     * @param clientState
     */
    private getHeaderString(reqHeaders: HttpHeaders | undefined, clientState: string) {
        let headerStr: string;
        headerStr = <string>reqHeaders?.get('nonce') + reqHeaders?.get('Authorization') + clientState;
        return headerStr;
    }

    /**
     * If response then return response body else return the concatenation  the request body , client state and request headers
     * @param requestJSON
     * @param callType
     * @param clientState
     * @param reqHeaders
     */
    private generateInputData(requestJSON: string, clientState: string, reqHeaders?: HttpHeaders) {
        let inputData = this.getHeaderString(reqHeaders, clientState);
        if (requestJSON !== 'null' && requestJSON !== '') {
            inputData = inputData + requestJSON;
        }
        return inputData;
    }

    /**
     * get the nonce and authorization from request header and concatenate both with client sate and retuen it
     * @param clientState
     * @param reqHeaders
     */
    private generateInputDataForGet(clientState: string, reqHeaders?: HttpHeaders) {
        return this.getHeaderString(reqHeaders, clientState);
    }

    /**
     * Store the state from response header in redux store and return generated response Hmac
     * @param event
     */
    private responseAuthentication(event: HttpResponse<any>, responseNonce:string) {
        this.setState(<string>event.headers.get(headers.state));
        const dateToGenerateMac = responseNonce + JSON.stringify(event.body);
        return this.generateResponseMac(dateToGenerateMac);
    }

    private generateResponseMac(dateToGenerateMac: string) {
        this.getDataFromStore();
        return this.authenticationService.computeBase64MAC(dateToGenerateMac, this.secretKeyFromStore);
    }

    /**
     * store state from response header locally
     * @param state
     */
    private setState(state: string) {
        this.respState = state;
    }

    /**
     * validate nonce and send the callback
     * @param reqNonce
     * @param respNonce
     * @param callback
     */
    private validateNonce(reqNonce: string, respNonce: string) {
        if (reqNonce === respNonce) {
            return true;
        }
        return false;
        
    }
}
