import { HttpClient, HttpHeaders, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Data } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { getSecretKey, getServerState } from '../../auth.index';
import { AuthModule, getAccessToken } from '../../auth.module';
import { AuthenticationService } from '../services.index';
import { InterceptorService } from './interceptor.service';

describe('InterceptorService', () => {
  let service: InterceptorService;
  let store: MockStore;
  let authenticationServiceSpy: jasmine.SpyObj<AuthenticationService>;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;

  const accessToken = 'NNFhhfhdfgjlkjjlkfd_95689gkjlkl';
  const secretKey = 'HHFnnhjdhjdfyuuifjnnNNGGJH';

  beforeEach(() => {
    const authenticationSpy = jasmine.createSpyObj('AuthenticationService', ['computeBase64MAC', 'generateNonce'])
    TestBed.configureTestingModule({
        imports:[AuthModule.forRoot('env'), HttpClientTestingModule, RouterTestingModule],
        providers: [
            { provide: AuthenticationService, useValue: authenticationSpy },
            { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
            provideMockStore({
                selectors:[
                    {
                        selector: getAccessToken,
                        value: [
                            {
                                accessToken: accessToken,
                            },
                        ],
                    },
                    {
                        selector: getSecretKey,
                        value: [
                            {
                                secretKey: secretKey,
                            },
                        ],
                    },
                    {
                        selector: getServerState,
                        value: [
                            {
                                accessToken: accessToken,
                            },
                        ],
                    },
                ]
            })
        ]
    });
    service = TestBed.inject(InterceptorService);
    store = TestBed.inject<Store>(Store) as MockStore<any>;
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
    authenticationServiceSpy = TestBed.inject(AuthenticationService) as jasmine.SpyObj<AuthenticationService>;
  });

  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should intercept when no error, then subscribe returns successfully', () => {
    authenticationServiceSpy.generateNonce.and.returnValue('1111111111111111|44444444444444444')
    spyOn<any>(service, 'addHeaders').and.callThrough();
    spyOn<any>(service, 'getDataFromStore');
    const reqHmac = spyOn<any>(service, 'checkUrlForReq').and.returnValue('abcdfffff');
    const testData: Data = {name: 'Test Data'};

    httpClient.get<Data>('/test')
        .subscribe(data => expect(data).toEqual(testData));

    const req = httpTestingController.expectOne('/test');
    expect(req.request.method).toEqual('GET');
    req.flush(testData, {
        status: 200,
        statusText: 'OK',
        headers: new HttpHeaders(
            {
                'nonce': '1111111111111111|44444444444444444',
                'state': 'jjhgyiornghFFTTHkfhrtgF'
            }
        )
      });
    httpTestingController.verify();
            
  });

});
