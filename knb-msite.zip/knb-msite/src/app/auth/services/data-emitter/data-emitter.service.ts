import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})

export class DataEmitterService {

    protected _eventsSubject = new BehaviorSubject<any>(undefined);

    constructor() {
    }
    broadcast(key: any, value: any) {
        this._eventsSubject.next({ key, value });
    }

    on<T>(key: any): Observable<T> {
        return this._eventsSubject.pipe(
                filter((data) => data.key === key),
                map((data) => data.value)
            );
    }

}
