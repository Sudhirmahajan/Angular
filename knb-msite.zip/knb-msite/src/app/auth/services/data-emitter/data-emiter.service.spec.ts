import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { DataEmitterService } from './data-emitter.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthModule, ErrorHandlerService } from '../../auth.module';

const errorHandlerServiceMock = {
    logoutWithSpecificPageNavigation() { }
};

describe('CustomErrorService', () => {
    let service: DataEmitterService;
    beforeEach(() => { TestBed.configureTestingModule({
            imports: [
                AuthModule.forRoot('env'),
                HttpClientTestingModule,
                RouterTestingModule
            ],
            providers: [
                { provide: ErrorHandlerService, useValue: errorHandlerServiceMock },
            ],
        })
        service = TestBed.inject(DataEmitterService);
    });

    it('should create DataEmitterService', () => {
        expect(service).toBeTruthy();
    });

    it('should check broadcast and on functions', (done) => {
        service.broadcast('key', 'test data');
        service.on('key').subscribe((response) => {
            expect(response).toEqual('test data');
            done();
        });
    });
});
