import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { NavigationService } from './navigation.service';

@Component({
    selector: 'dummy-component',
    template: '<p>dummy</p>'
})
class DummyComponent {}

describe('Navigation service', () => {
  let service: NavigationService;
  let router: Router;

  beforeEach(() => {
    TestBed.configureTestingModule({
        imports: [
            RouterTestingModule.withRoutes(
                [{path: 'login/sessionExpired', component: DummyComponent}, { path: 'test', component: DummyComponent}]
              )
        ]
    });
    service = TestBed.inject(NavigationService);
    router = TestBed.inject(Router);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should save history', () => {
      router.navigateByUrl('login/sessionExpired');
      service.startSaveHistory();
      expect(service['history']).not.toBeNull();
  })

  it('should get navigation history', () => {
    service['history'] = ['test'];
    const value = service.getNavHistory();
    expect(value[0]).toEqual('test');
  })

  it('should get reset history', () => {
    service.resetNavHistory();
    expect(service['history']).toEqual([]);
  })

  it('should go back to login page', () => {
    service.goBack();
    expect(service['history']).toEqual([]);
  })

  it('should go back to previous page', () => {
    router.navigateByUrl('login/sessionExpired');
    service.goBack();
    expect(service['history']).not.toBeNull();
  })

});
