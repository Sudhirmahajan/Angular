import { Injectable } from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
import { ROUTE_KEY } from "src/app/modules/login/login.constant";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class NavigationService {
    private history: string[] = [];

    constructor(private router: Router) {}

    public startSaveHistory() {
        this.router.events.subscribe(event => {


            if (event instanceof NavigationEnd) {
                if (!(event.urlAfterRedirects == "/onboarding/otp" || event.urlAfterRedirects == "/onboarding/fundTransfer/getOTP" || event.urlAfterRedirects == "/onboarding/fundTransfer/editBeneOTP"))
                    this.history.push(event.urlAfterRedirects)
            }
            document.querySelectorAll(".parent-top").forEach(element => {
                element.scrollIntoView();
            });
        })
    }

    public getNavHistory() {
        return this.history
    }

    public resetNavHistory() { 
        this.history = [];
    }

    public goBack() {
        this.history.pop();
        if(this.history.length > 0) {
            this.router.navigateByUrl(this.history[this.history.length-1], { skipLocationChange: environment.skipURI });
           
            
        } else {
            this.router.navigateByUrl(ROUTE_KEY['CRN'], { skipLocationChange: environment.skipURI });
        }
    }
}