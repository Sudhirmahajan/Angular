import { createReducer, on } from '@ngrx/store';


import { setSecretKey, setClientSessionId, setAccessToken, resetStore, setServerState, setUserId, setFlow, setGUID, setRecaptcha, setMobileNumber, setEmail, setIsdCode, setLoaderStatus, setServiceId, setCredentialBlockedStatus, setCardDetailsBlockedStatus, setChannelBlockedStatus, setMobileNotUpdatedStatus, setTwoFaAuthOptions, setRememberMeDetails, setCardAuthenticationOption, setSecurityQuestionFlag, setBlockedTimer, 
   setDisableMoreOptionsFlag, setDisableBackFlag, setSecurityQuestions, setAccountQuestions, setRemainingDays, setUserDetails, setRmData, setAccountList, setPhysicalPinDate, setPhysicalPinDays, setDepositDetails, setInvestmentDetails, setLoanDetails, setLoanLoader, setDepositLoader, setPreferredAmountFormat, setBackId ,setCardDetails, setFooterFlag, setAccSummary ,setBankandIFSC,setBeneSuccessRes, setLang,setAllTransferDtls, setIfscSearch, setIfscCode, setIfsc, setOneTimeBene, setBeneficiaryDetails, setOtpPayload,
   setAccountArray, setEditBene,setBeneLimit,setFTError,setDebitAct, setKotakCreditAct, setKotakDebiitAct, setUniqAcctId, setPageName,setSelectedAct, setPartyDetails, setTransferDetails, setAuthMethod, setMsiteFlow, setMsiteAuthMethod, setMsiteUserID} from './action';

import { stateModel } from './model';

export const initialState: stateModel = {
   secretKey: '',
   clientSessionId: '',
   accessToken: '',
   resetStore: '',
   serverState: '',
   userId: '',
   flow: '',
   guid: '',
   recaptcha: '',
   mobileNumber: '',
   email: '',
   isdCode: '',
   loaderStatus: false,
   serviceId: '',
   credentialBlockedStatus: '',
   cardDetailsBlockedStatus: '',
   channelBlockedStatus: '',
   mobileNotUpdatedStatus: '',
   twoFaAuthOptions: [],
   rememberMeDetails: {
      image: '',
      shortName: '',
      nickname: '',
      initials: '',
      maskcrn: ''
   },
   cardAuthenticationOption: '',
   securityQuestionFlag: false,
   blockedTimer: '',
   disableMoreOptionsFlag: false,
   disableBackFlag: false,
   accountQuestions: [],
   securityQuestions: [],
   remainingDays: '',
   UserDetails: {
      crn: '',
      fullName: '',
      prefEmailId: '',
      image: '',
      homeBranch: '',
      customerSegmentCd: '',
      classificationCd: '',
      userPref: {},
      logo: '',
      partyItType: '',
      partyItTypeCd: '',
      shortName: '',
      failedLoginDate: ''
   },
   rmData: '',
   accountList: {
      currencyWiseResponse: [],
      currentAccts: [],
      overDraftAccts: [],
      savingsAccts: []
   },
   allTransferDtls: {
      userDtls: {},
      beneDtls: {}
   },
   physicalPinDate: '',
   physicalPinDays: 0,
   loandetails: '',


   bankAndIFSClist: [],
   investmentdetails: '',
   depositdetails: '',
   loanLoader: true,
   depositLoader: true,
   carddetails: '',
   preferredAmountFormat: '',
   backId: 'summary',
   footerFlag: true,
   acctSummary: '',
   beneSuccessResponse: '',
   lang: "en",
   beneFlow: false,
   ifscSearch: [],
   ifscCode: '',
   ifsc: [],
   beneficiaryDetails: {
      benef_record_id: '',
      benef_bank_ac_no: '',
      benef_bank_acct_type: '',
      benef_bank_acct_type_code: '',
      benef_bank_name: '',
      benef_bank_ifsc_code: '',
      benef_nick_name: '',
      benef_name: '',
      benef_email: '',
      benef_mobile: '',
      my_acct: '',
      favorite_flag: '',
      active_flag: '',
      schme_code: ''
   },
   otppayload: {},
   editBene: {},
   beneLimit: {},
   ftError: {},
   kotakBeneDetails: {
      benef_acct_frez_code: '',
      benef_bank_ac_no: '',
      benef_bank_acct_type: '',
      benef_bank_acct_type_code: '',
      acount_status: '',
      currency_code: '',
   },
   kotakDebitBeneDetails: {
      debit_acct_frez_code: '',
      debit_bank_ac_no: '',
      debit_bank_acct_type: '',
      debit_bank_acct_type_code: '',
      acount_status: '',
      currency_code: ''
   },
   uniqAccId: '',
   page_name: '',
   accountArray: {},
   account: '',
   debitAct: false,
   partyDetails: {},
   transferDetails: {},
   authMethod: '',
   msiteAuthMethod: '',
   msiteFlow: '',
   msiteUserID:''
}



export const stateReducer = createReducer(
      initialState,
      on(setSecretKey, (state, { value }) =>  {
         return {...state, secretKey: value}
      }),
      on(setClientSessionId, (state, { value }) =>  {
         return {...state, clientSessionId: value}
      }),
      on(setAccessToken, (state, { value }) =>  {
         return {...state, accessToken: value}
      }),
      on(setServerState, (state, { value }) =>  {
         return {...state, serverState: value}
      }),
      on(setUserId, (state, { value }) =>  {
         return {...state, userId: value}
      }),
      on(setFlow, (state, { value }) =>  {
         return {...state, flow: value}
      }),
      on(setGUID, (state, { value }) =>  {
         return {...state, guid: value}
      }),
      on(setRecaptcha, (state, { value }) =>  {
         return {...state, recaptcha: value}
      }),
      on(setMobileNumber, (state, { value }) =>  {
         return {...state, mobileNumber: value}
      }),
      on(setEmail, (state, { value }) =>  {
         return {...state, email: value}
      }),
      on(setIsdCode, (state, { value }) =>  {
         return {...state, isdCode: value}
      }),
      on(setLoaderStatus, (state, { value }) =>  {
         return {...state, loaderStatus: value}
      }),
      on(setServiceId, (state, { value }) =>  {
         return {...state, serviceId: value}
      }),
      on(setCredentialBlockedStatus, (state, { value }) =>  {
         return {...state, credentialBlockedStatus: value}
      }),
      on(setCardDetailsBlockedStatus, (state, { value }) =>  {
         return {...state, cardDetailsBlockedStatus: value}
      }),
      on(setChannelBlockedStatus, (state, { value }) =>  {
         return {...state, channelBlockedStatus: value}
      }),
      on(setMobileNotUpdatedStatus, (state, { value }) =>  {
         return {...state, mobileNotUpdatedStatus: value}
      }),
      on(setTwoFaAuthOptions, (state, { value }) =>  {
         return {...state, twoFaAuthOptions: value}
      }),
      on(setRememberMeDetails, (state, { value }) =>  {
         return {...state, rememberMeDetails: value}
      }),
      on(setCardAuthenticationOption, (state, { value }) =>  {
         return {...state, cardAuthenticationOption: value}
      }),
      on(setSecurityQuestionFlag, (state, { value }) =>  {
         return {...state, securityQuestionFlag: value}
      }),
      on(setBlockedTimer, (state, { value }) =>  {
         return {...state, blockedTimer: value}
      }),
      on(setDisableMoreOptionsFlag, (state, { value }) =>  {
         return {...state, disableMoreOptionsFlag: value}
      }),
      on(setDisableBackFlag, (state, { value }) =>  {
         return {...state, disableBackFlag: value}
      }),
      on(setSecurityQuestions, (state, { value }) =>  {
         return {...state, securityQuestions: value}
      }),
      on(setAccountQuestions, (state, { value }) =>  {
         return {...state, accountQuestions: value}
      }),
      on(setRemainingDays, (state, { value }) =>  {
         return {...state, remainingDays: value}
      }),
      on(setUserDetails, (state, { value }) =>  {
         return {...state, UserDetails: value }
      }),

      on(setUserDetails, (state, { value }) =>  {
         return {...state, UserDetails: value }
      }),
      on(setRmData, (state, { value }) =>  {
         return {...state, rmData: value }
      }),
      on(setAccountList, (state, { value }) =>  {
         return {...state, accountList: value }
      }),
      on(setPhysicalPinDate, (state, { value }) =>  {
         return {...state, physicalPinDate: value }
      }),
      on(setPhysicalPinDays, (state, { value }) =>  {
         return {...state, physicalPinDays: value }
      }),
      on(setLoanDetails, (state, { value }) =>  {
         return {...state, loandetails: value }
      }),
      on(setInvestmentDetails, (state, { value }) =>  {
         return {...state, investmentdetails: value }
      }),
      on(setDepositDetails, (state, { value }) =>  {
         return {...state, depositdetails: value }
      }),
      on(setLoanLoader, (state, { value }) =>  {
         return {...state, loanLoader: value }
      }),
      on(setDepositLoader, (state, { value }) =>  {
         return {...state, depositLoader: value }
      }),
      on(setPreferredAmountFormat, (state, { value }) =>  {
         return {...state, preferredAmountFormat: value }
      }),
      on(setBackId, (state, { value }) =>  {
         return {...state, backId: value }
      }),
      on(setCardDetails, (state, { value }) =>  {
         return {...state, carddetails: value }
      }),
      on(setFooterFlag, (state, { value }) =>  {
         return {...state, footerFlag: value }
      }),
      on(setAccSummary, (state, { value }) =>  {
         return {...state, acctSummary: value }
      }),
      on(resetStore, () =>  {
         return initialState
      }),
      
      
      on(setBankandIFSC,(state,{value}) =>{
         return {...state ,bankAndIFSClist : value
         }
      }),
      on(setBeneSuccessRes,(state,{value}) =>{
         return {...state ,beneSuccessResponse : value
         }
      }),
      on(setLang,(state,{value}) =>{
         return {...state ,lang : value
         }
      }),
      on(setAllTransferDtls,(state,{value}) =>{
         return {...state, allTransferDtls : value

         }
      }),
     
      
      on(setOneTimeBene,(state ,{ value}) =>{
         return {...state, beneficiaryDetails: value }
      }),
      on(setIfscSearch, (state, { value }) =>  {
         return {...state, ifscSearch: value }
      }),
      on(setIfscCode, (state, { value }) =>  {
         return {...state, ifscCode: value }
      }),
      on(setIfsc, (state, { value }) =>  {
         return {...state, ifsc: value }
      }),
     
      on(setBeneficiaryDetails, (state, { value }) =>  {
         return {...state, beneficiaryDetails: value }
      }),

      on(setOtpPayload, (state, { value }) =>  {
         return {...state, otppayload: value }
      }),
      on(setEditBene, (state, { value }) =>  {
         return {...state, editBene: value }
      }),
      on(setBeneLimit, (state, { value }) =>  {
         return {...state, beneLimit: value }
      }),
      on(setFTError, (state, { value }) =>  {
         return {...state, ftError: value }
      }),
      on(setKotakCreditAct, (state, { value }) =>  {
         return {...state, kotakBeneDetails : value }
      }),
      on(setKotakDebiitAct, (state, { value }) =>  {
         return {...state, kotakDebitBeneDetails : value }
      }),
      on(setUniqAcctId, (state, { value }) =>  {
         return {...state, uniqAccId : value }
      }),
      on(setPageName, (state, { value }) =>  {
         return {...state, page_name : value }
      }),
      on(setAccountArray, (state, { value }) =>  {
         return {...state, accountArray : value }
      }),
      on(setSelectedAct, (state, { value }) =>  {
         return {...state, account : value }
      }),
      on(setDebitAct, (state, { value }) =>  {
         return {...state, debitAct : value }
      }),
      on(setPartyDetails, (state, { value }) =>  {
         return {...state, partyDetails : value }
      }),
      on(setTransferDetails, (state, { value }) =>  {
         return {...state, transferDetails: value }
      }),
      on(setAuthMethod, (state, { value }) =>  {
         return {...state, authMethod: value }
      }),
      on(setMsiteAuthMethod, (state, { value }) =>  {
         return {...state, msiteAuthMethod: value }
      }),
      on(setMsiteFlow, (state, { value }) =>  {
         return {...state, msiteFlow: value }
      }),
      on(setMsiteUserID, (state, { value }) =>  {
         return {...state, msiteUserID: value }
      }),   
  );


