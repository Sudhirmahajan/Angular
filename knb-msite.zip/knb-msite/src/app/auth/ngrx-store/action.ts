import { createAction, props } from '@ngrx/store';
import { IAccountListNew, IUserDetails } from 'src/app/modules/onboarding/model/onboarding.model';
import { IKotakBene, IKotakDebitAct, ITransferDtls } from 'src/app/modules/onboarding/modules/fund-transfer/model/fundTransfer.model';
import { IBenStoreDetails, IRememberMeDetails } from './model';

export const setSecretKey = createAction('SECRET_KEY', props<{ value: string }>());
export const setClientSessionId = createAction('CLIENT_SESSION_ID', props<{ value: string }>());
export const setAccessToken = createAction('ACCESS_TOKEN', props<{ value: string }>());
export const resetStore = createAction('RESET_STORE');
export const setServerState = createAction('SERVER_STATE', props<{ value: string }>());
export const setUserId = createAction('USER_ID', props<{ value: string }>());
export const setFlow = createAction('FLOW', props<{ value: string }>());
export const setGUID = createAction('GUID', props<{ value: string }>());
export const setRecaptcha = createAction('SHOW_RECAPTCHA', props<{ value: string }>());
export const setMobileNumber = createAction('MOBILE_NUMBER', props<{ value: string }>());
export const setEmail = createAction('EMAIL', props<{ value: string }>());
export const setIsdCode = createAction('ISD_CODE', props<{ value: string }>());
export const setLoaderStatus = createAction('LOADER_STATUS', props<{ value: boolean }>());
export const setServiceId = createAction('SERVICE_ID', props<{ value: string }>());
export const setCredentialBlockedStatus = createAction('CREDENTIAL_BLOCKED_STATUS', props<{ value: string }>());
export const setCardDetailsBlockedStatus = createAction('CARD_DETAILS_BLOCKED_STATUS', props<{ value: string }>());
export const setChannelBlockedStatus = createAction('CHANNEL_BLOCKED_STATUS', props<{ value: string }>());
export const setMobileNotUpdatedStatus = createAction('MOBILE_NOT_UPDATED_STATUS', props<{ value: string }>());
export const setTwoFaAuthOptions = createAction('TWO_FA_AUTH_OPTIONS', props<{ value: object[] }>());
export const setRememberMeDetails = createAction('REMEMBER_ME_DETAILS', props<{ value: IRememberMeDetails }>());
export const setCardAuthenticationOption = createAction('CARD_AUTHENTICATION_OPTION', props<{ value: string }>());
export const setSecurityQuestionFlag = createAction('SECURITY_QUESTION_FLAG', props<{ value: boolean }>());
export const setBlockedTimer = createAction('BLOCKED_TIMER', props<{ value: string }>());
export const setDisableMoreOptionsFlag = createAction('DISABLE_MORE_OPTIONS', props<{ value: boolean }>());
export const setDisableBackFlag = createAction('DISABLE_BACK', props<{ value: boolean }>());
export const setSecurityQuestions = createAction('SECURITY_QUESTIONS', props<{ value: object[] }>());
export const setAccountQuestions = createAction('ACCOUNT_QUESTIONS', props<{ value: object[] }>());
export const setRemainingDays = createAction('REMAINING_DAYS', props<{ value: string }>());
export const setUserDetails = createAction('USER_DETAILS', props<{ value: IUserDetails }>());
export const setRmData = createAction('RM_DATA', props<{ value: any }>());
export const setAccountList = createAction('ACCOUNTS_LIST', props<{ value: IAccountListNew }>());
export const setPhysicalPinDate = createAction('PHYSICAL_PIN_DATE', props<{ value: string }>());
export const setPhysicalPinDays = createAction('PHYSICAL_PIN_DAYS', props<{ value: number }>());
export const setLoanDetails = createAction('LOAN_DETAILS', props<{ value: any }>());
export const setInvestmentDetails = createAction('INVESTMENT_DETAILS', props<{ value: any }>());
export const setDepositDetails = createAction('DEPOSIT_DETAILS', props<{ value: any }>());
export const setLoanLoader = createAction('LOAN_LOADER', props<{ value: boolean }>());
export const setDepositLoader = createAction('DEPOSIT_LOADER', props<{ value: boolean }>());
export const setPreferredAmountFormat = createAction('PREFERRED_AMOUNT_FORMAT_STORE', props<{ value: string }>());
export const setBackId = createAction('BACK_ID', props<{ value: string }>());
export const setCardDetails = createAction('CARD_DETAILS', props<{ value: any }>());
export const setFooterFlag = createAction('FOOTER_FlAG', props<{ value: boolean }>());
export const setAccSummary = createAction('ACCOUNT_SUMMARY', props<{ value: any }>());
export const setOneTimeBene = createAction('ONETIMEBNE_DETAILS', props<{ value: IBenStoreDetails }>());
export const setBankandIFSC = createAction('BANKIFSC_LIST', props<{ value: [] }>());
export const setBeneSuccessRes = createAction('BENE_SUCCESS_RESPONSE', props<{ value: any }>());
export const setLang = createAction('LANG', props<{ value: string }>());
export const setAllTransferDtls = createAction('', props<{ value: ITransferDtls }>())
export const setIfscSearch = createAction('IFSC_SEARCH', props<{ value: [] }>());
export const setIfscCode = createAction('IFSC_CODE', props<{ value: string }>());
export const setIfsc = createAction('IFSC', props<{ value: [] }>());
export const setBeneficiaryDetails = createAction('BENEFICIARY_DETAILS', props<{ value: IBenStoreDetails }>());
export const setKotakCreditAct = createAction('KOTAK_BENEF_DETAILS', props<{ value: IKotakBene }>());
export const setKotakDebiitAct = createAction('KOTAK_DEBIT_DETAILS', props<{ value: IKotakDebitAct }>());
export const setOtpPayload = createAction('OTP_PAYLOAD', props<{ value: any}>());
export const setEditBene = createAction('EDIT_BENE', props<{ value: any}>());
export const setBeneLimit = createAction('BENE_LIMIT', props<{ value: any}>());
export const setFTError = createAction('FT_ERROR', props<{ value: any}>());
export const setUniqAcctId = createAction('UNIQ_ACCTID', props<{ value: string }>());
export const setPageName = createAction('PAGE_NAME', props<{ value: string }>());
export const setAccountArray = createAction('ACCOUNT_LIST', props<{ value: any}>());
export const setSelectedAct = createAction('ACCOUNT', props<{ value: any}>());
export const setDebitAct = createAction('DEBITACT_FLAG', props<{ value: boolean}>());
export const setPartyDetails = createAction('PARY_DETAILS', props<{ value: any }>());
export const setTransferDetails = createAction('AMT_REMARK', props<{ value: any}>());
export const setAuthMethod = createAction('AUTH_METHOD', props<{ value: string }>());
export const setMsiteFlow = createAction('MSITE_FLOW', props<{ value: string }>());
export const setMsiteAuthMethod = createAction('MSITE_AUTH_METHOD', props<{ value: string }>());
export const setMsiteUserID = createAction('MSITE_USER_TYPE', props<{ value: string }>());






