import { IAccountListNew } from "src/app/modules/onboarding/model/onboarding.model";
import { IKotakBene, IKotakDebitAct } from "src/app/modules/onboarding/modules/fund-transfer/model/fundTransfer.model";

export interface stateModel {
    secretKey: string;
    clientSessionId: string;
    accessToken: string;
    resetStore: string;
    serverState: string;
    userId: string;
    flow: string;
    guid: string;
    recaptcha: string;
    mobileNumber: string;
    email: string;
    isdCode: string;
    loaderStatus: boolean;
    serviceId:string;
    credentialBlockedStatus: string;
    cardDetailsBlockedStatus: string;
    channelBlockedStatus: string;
    mobileNotUpdatedStatus: string;
    twoFaAuthOptions: object[];
    rememberMeDetails: IRememberMeDetails;
    cardAuthenticationOption: string;
    securityQuestionFlag: boolean;
    blockedTimer: string;
    disableMoreOptionsFlag: boolean;
    disableBackFlag: boolean;
    accountQuestions: object[];
    securityQuestions: object[];
    remainingDays: string;
    UserDetails:IUserDetails;
    rmData:any;
    accountList:IAccountListNew;
    physicalPinDate: string,
    physicalPinDays: number;
    loandetails:any;
    investmentdetails:any;
    depositdetails:any;
    loanLoader:boolean;
    depositLoader:boolean;
    preferredAmountFormat: string;
    backId:string;
    carddetails:any;
    footerFlag:boolean;
    acctSummary:any;
    bankAndIFSClist : [];
    beneSuccessResponse : any;
    lang:string;
    allTransferDtls:object;
    beneFlow:boolean;
    ifscSearch : [];
    ifscCode:string;
    ifsc : [];
    beneficiaryDetails: IBenStoreDetails;
    otppayload:any;
    editBene:any;
    beneLimit : any;
    ftError : object;
    kotakBeneDetails : IKotakBene,
    kotakDebitBeneDetails : IKotakDebitAct,
    uniqAccId: string,
    page_name: string;
    accountArray : {},
    account : any,
    debitAct : boolean,
    partyDetails : any,
    transferDetails : any,
    authMethod   : string,
    msiteAuthMethod   : string,
    msiteFlow   : string,
    msiteUserID   : string,
}

export interface IRememberMeDetails {
    image: string;
    shortName: string;
    nickname: string;
    initials: string;
    maskcrn: string;
}

export interface IUserDetails {
    crn: string;
    fullName: string;
    prefEmailId: string;
    image?: string;
    homeBranch?: string;
    customerSegmentCd: string;
    classificationCd: string;
    userPref: {},
    logo?: string;
    partyItType:string;
    partyItTypeCd:string;
    shortName:string;
    failedLoginDate:string;
}

export interface IBenStoreDetails {
    benef_record_id: string;
    benef_bank_ac_no: string | Number | null;
    benef_bank_acct_type: string;
    benef_bank_acct_type_code: string;
    benef_bank_name: string;
    benef_bank_ifsc_code: string;
    benef_nick_name: string;
    benef_name: string;
    benef_email: string;
    benef_mobile: string;
    my_acct: string;
    favorite_flag: string;
    active_flag:string;
    schme_code :string;
}

