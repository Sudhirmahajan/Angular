import { createSelector, createFeatureSelector } from '@ngrx/store';
import { stateModel } from './model';

const getStoreState = createFeatureSelector<stateModel>('ngrxState');

export const getAccessToken = createSelector(getStoreState,
  (state: stateModel) => state.accessToken
);

export const getClientSessionId = createSelector(getStoreState,
  (state: stateModel) => state.clientSessionId    
);

export const getSecretKey = createSelector(getStoreState,
  (state: stateModel) => state.secretKey    
);

export const getResetStore = createSelector(getStoreState,
  (state: stateModel) => state.resetStore    
);

export const getServerState = createSelector(getStoreState,
  (state: stateModel) => state.serverState    
);

export const getUserId = createSelector(getStoreState,
  (state: stateModel) => state.userId    
);

export const getFlow = createSelector(getStoreState,
  (state: stateModel) => state.flow    
);

export const getGUID = createSelector(getStoreState,
  (state: stateModel) => state.guid    
);

export const getRecaptcha = createSelector(getStoreState,
  (state: stateModel) => state.recaptcha    
);

export const getMobileNumber = createSelector(getStoreState,
  (state: stateModel) => state.mobileNumber    
);

export const getEmail = createSelector(getStoreState,
  (state: stateModel) => state.email    
);

export const getIsdCode = createSelector(getStoreState,
  (state: stateModel) => state.isdCode    
);

export const getLoaderStatus = createSelector(getStoreState,
  (state: stateModel) => state.loaderStatus    
);

export const getServiceId = createSelector(getStoreState,
  (state: stateModel) => state.serviceId    
);

export const getCredentialBlockedStatus = createSelector(getStoreState,
  (state: stateModel) => state.credentialBlockedStatus    
);

export const getCardDetailsBlockedStatus = createSelector(getStoreState,
  (state: stateModel) => state.cardDetailsBlockedStatus    
);

export const getChannelBlockedStatus = createSelector(getStoreState,
  (state: stateModel) => state.channelBlockedStatus    
);

export const getMobileNotUpdatedStatus = createSelector(getStoreState,
  (state: stateModel) => state.mobileNotUpdatedStatus    
);

export const getTwoFaAuthOptions = createSelector(getStoreState,
  (state: stateModel) => state.twoFaAuthOptions    
);

export const getRememberMeDetails = createSelector(getStoreState,
  (state: stateModel) => state.rememberMeDetails    
);

export const getCardAuthenticationOption = createSelector(getStoreState,
  (state: stateModel) => state.cardAuthenticationOption    
);

export const getSecurityQuestionFlag = createSelector(getStoreState,
  (state: stateModel) => state.securityQuestionFlag    
);

export const getBlockedTimer = createSelector(getStoreState,
  (state: stateModel) => state.blockedTimer    
);

export const getDisableMoreOptionsFlag = createSelector(getStoreState,
  (state: stateModel) => state.disableMoreOptionsFlag    
);

export const getDisableBackFlag = createSelector(getStoreState,
  (state: stateModel) => state.disableBackFlag    
);

export const getSecurityQuestions = createSelector(getStoreState,
  (state: stateModel) => state.securityQuestions    
);

export const getAccountQuestions = createSelector(getStoreState,
  (state: stateModel) => state.accountQuestions    
);

export const getRemainingDays = createSelector(getStoreState,
  (state: stateModel) => state.remainingDays    
);

export const getUserDetails = createSelector(getStoreState,
  (state: stateModel) => state.UserDetails
);

export const getRmData = createSelector(getStoreState,
  (state: stateModel) => state.rmData
);

export const getAccountList= createSelector(getStoreState,
  (state: stateModel) => state.accountList
);

export const getPhysicalPinDate= createSelector(getStoreState,
  (state: stateModel) => state.physicalPinDate
);

export const getPhysicalPinDays= createSelector(getStoreState,
  (state: stateModel) => state.physicalPinDays
);
export const getLoanDetails= createSelector(getStoreState,
  (state: stateModel) => state.loandetails
);
export const getInvestmentDetails= createSelector(getStoreState,
  (state: stateModel) => state.investmentdetails
);
export const getDepositDetails= createSelector(getStoreState,
  (state: stateModel) => state.depositdetails
);
export const getLoanLoader= createSelector(getStoreState,
  (state: stateModel) => state.loanLoader
);
export const getDepositLoader= createSelector(getStoreState,
  (state: stateModel) => state.depositLoader
);
export const getCardDetails= createSelector(getStoreState,
  (state: stateModel) => state.carddetails
);

export const getPreferredAmountFormat= createSelector(getStoreState,
  (state: stateModel) => state.preferredAmountFormat
);

export const getFooterFlag= createSelector(getStoreState,
  (state: stateModel) => state.footerFlag
);
export const getBackId= createSelector(getStoreState,
  (state: stateModel) => state.backId
);

export const getAcctSummary= createSelector(getStoreState,
  (state: stateModel) => state.acctSummary
);

export const getBankandIFSC = createSelector(getStoreState,
  (state: stateModel) => state.bankAndIFSClist
);
export const getBeneSuccessRes = createSelector(getStoreState,
  (state: stateModel) => state.beneSuccessResponse
);
export const getLang = createSelector(getStoreState,
  (state: stateModel) => state.lang
);
export const getAllTransferDtls = createSelector(getStoreState,
  (state: stateModel) => state.allTransferDtls
);


export const getOneTimeBene= createSelector(getStoreState,
  (state: stateModel) => state.beneficiaryDetails
);
export const getIfscSearch = createSelector(getStoreState,
  (state: stateModel) => state.ifscSearch
);
export const getIfsc = createSelector(getStoreState,
  (state: stateModel) => state.ifsc
);
export const getIfscCode = createSelector(getStoreState,
  (state: stateModel) => state.ifscCode
);
export const getBeneficiaryDetails = createSelector(getStoreState,
  (state: stateModel) => state.beneficiaryDetails
);

export const getOtpPayload = createSelector(getStoreState,
  (state: stateModel) => state.otppayload
);
export const getEditBene = createSelector(getStoreState,
  (state: stateModel) => state.editBene
);
export const getBeneLimit = createSelector(getStoreState,
  (state: stateModel) => state.beneLimit
);
export const getFTError = createSelector(getStoreState,
  (state: stateModel) => state.ftError
);
export const getKotakCreditAct = createSelector(getStoreState,
  (state: stateModel) => state.kotakBeneDetails
);
export const getKotakDebitAct = createSelector(getStoreState,
  (state: stateModel) => state.kotakDebitBeneDetails
);
export const getUniqAcctId = createSelector(getStoreState,
  (state: stateModel) => state.uniqAccId
);
export const getPageDetails = createSelector(getStoreState,
  (state: stateModel) => state.page_name
);
export const getAccountArray = createSelector(getStoreState,
  (state: stateModel) => state.accountArray
);
export const getSelectedAct = createSelector(getStoreState,
  (state: stateModel) => state.account
);
export const getDebitAct = createSelector(getStoreState,
  (state: stateModel) => state.debitAct
);
export const getpartyDetails = createSelector(getStoreState,
  (state: stateModel) => state.partyDetails
); //setTransferDetails
export const getTransferDetails = createSelector(getStoreState,
  (state: stateModel) => state.transferDetails
);
export const getAuthMethod = createSelector(getStoreState,
  (state: stateModel) => state.authMethod
);
export const getMsiteAuthMethod = createSelector(getStoreState,
  (state: stateModel) => state.msiteAuthMethod
);
export const getMsiteFlow = createSelector(getStoreState,
  (state: stateModel) => state.msiteFlow
);
export const getMsiteUserID = createSelector(getStoreState,
  (state: stateModel) => state.msiteUserID
);
