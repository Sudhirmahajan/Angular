import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { AuthenticationService, InterceptorService, stateReducer } from './auth.index';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forRoot({ ngrxState: stateReducer}),
  ],
  exports: []
})
export class AuthModule {
  constructor() {}

  static forRoot(environment: any): ModuleWithProviders<AuthModule> {
    return {
      ngModule: AuthModule,
      providers: [
        { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
        AuthenticationService,
        {
          provide: 'env', // you can also use InjectionToken
          useValue: environment
        }
      ]
    };
  }
}

export * from './auth.index';

