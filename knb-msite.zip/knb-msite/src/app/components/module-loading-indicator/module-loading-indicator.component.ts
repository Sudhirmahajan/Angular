import { Component } from '@angular/core';
import {Event, RouterEvent, Router, RouteConfigLoadStart, RouteConfigLoadEnd} from '@angular/router';
import { filter } from 'rxjs';

@Component({
  selector: 'app-module-loading-indicator',
  templateUrl: './module-loading-indicator.component.html',
})
export class ModuleLoadingIndicatorComponent {

  public isShowingRouteLoadIndicator: boolean;

  constructor(public router: Router) {
    let asyncLoadCount = 0;
    this.isShowingRouteLoadIndicator = false;
    router.events.pipe(
       filter((e: Event): e is RouterEvent => e instanceof RouterEvent)
    ).subscribe((e: RouterEvent) => {
      if (e instanceof RouteConfigLoadStart) {
        asyncLoadCount++;
      } else if (e instanceof RouteConfigLoadEnd) {
        asyncLoadCount--;
      }
      this.isShowingRouteLoadIndicator = !!asyncLoadCount;
    });
  }
}